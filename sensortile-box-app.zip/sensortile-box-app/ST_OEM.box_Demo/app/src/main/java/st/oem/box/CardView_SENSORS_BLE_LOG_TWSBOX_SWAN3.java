package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_SENSORS_BLE_LOG_TWSBOX_SWAN3 extends CardView {

    @SuppressLint("StaticFieldLeak")
    private static LinearLayout lsm6dsv16xAccelConfigLinearLayout;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xAccelConfigTextView;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xAccelOdrTextView;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xAccelFullScaleTextView;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xAccelPowerModeTextView;
    @SuppressLint("StaticFieldLeak")
    private static Spinner lsm6dsv16xAccelOdrSpinner;
    @SuppressLint("StaticFieldLeak")
    private static Spinner lsm6dsv16xAccelFullScaleSpinner;
    @SuppressLint("StaticFieldLeak")
    private static Spinner lsm6dsv16xAccelPowerModeSpinner;

    @SuppressLint("StaticFieldLeak")
    private static LinearLayout lsm6dsv16xGyroConfigLinearLayout;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xGyroConfigTextView;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xGyroOdrTextView;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xGyroFullScaleTextView;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xGyroPowerModeTextView;
    @SuppressLint("StaticFieldLeak")
    private static Spinner lsm6dsv16xGyroOdrSpinner;
    @SuppressLint("StaticFieldLeak")
    private static Spinner lsm6dsv16xGyroFullScaleSpinner;
    @SuppressLint("StaticFieldLeak")
    private static Spinner lsm6dsv16xGyroPowerModeSpinner;

    @SuppressLint("StaticFieldLeak")
    private static LinearLayout lsm6dsv16xQvarConfigLinearLayout;
    @SuppressLint("StaticFieldLeak")
    private static CheckBox lsm6dsv16xQvarEnabledCheckBox;
    @SuppressLint("StaticFieldLeak")
    private static TextView lsm6dsv16xQvarZinTextView;
    @SuppressLint("StaticFieldLeak")
    private static Spinner lsm6dsv16xQvarZinSpinner;

    @SuppressLint("StaticFieldLeak")
    private static LinearLayout accelQvarLinearLayout;
    @SuppressLint("StaticFieldLeak")
    private static TextView accelQvarHighRateTextView;
    @SuppressLint("StaticFieldLeak")
    private static CheckBox accelQvarHighRateCheckBox;
    @SuppressLint("StaticFieldLeak")
    private static TextView accelAxisTextView;
    @SuppressLint("StaticFieldLeak")
    private static Spinner accelAxisSpinner;

    @SuppressLint("StaticFieldLeak")
    private static LinearLayout filenameLinearLayout;
    @SuppressLint("StaticFieldLeak")
    private static EditText filenameEditText;

    @SuppressLint("StaticFieldLeak")
    private static TextView loggingTextView;
    @SuppressLint("StaticFieldLeak")
    private static Button startStopBleLogButton;

    private final CardView mMainLayout;

    private Timer mTimerUpdateUI;

    // TWS.box Swan3 devices
    private static boolean lsm6dsv16x_xl_pd = true;
    private static boolean lsm6dsv16x_g_pd = true;
    private static boolean lsm6dsv16x_q_pd = true;
    private static int lsm6dsv16x_reg_10 = 0x00; // xl pm, odr
    private static int lsm6dsv16x_reg_11 = 0x00; // g pm, odr
    private static int lsm6dsv16x_reg_15 = 0x00; // g fsr
    private static int lsm6dsv16x_reg_16 = 0x00; // qvar en, zin
    private static int lsm6dsv16x_reg_17 = 0x00; // xl fsr

    // Common
    private static boolean accel_qvar_high_rate = false;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_SENSORS_LOG_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_SENSORS_BLE_LOG_TWSBOX_SWAN3(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_sensors_ble_log_twsbox_swan3, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        lsm6dsv16xAccelConfigTextView = mMainLayout.findViewById(R.id.lsm6dsv16xAccelConfigTextView);
        lsm6dsv16xAccelOdrTextView = mMainLayout.findViewById(R.id.lsm6dsv16xAccelOdrTextView);
        lsm6dsv16xAccelFullScaleTextView = mMainLayout.findViewById(R.id.lsm6dsv16xAccelFullScaleTextView);
        lsm6dsv16xAccelPowerModeTextView = mMainLayout.findViewById(R.id.lsm6dsv16xAccelPowerModeTextView);
        lsm6dsv16xAccelOdrSpinner = mMainLayout.findViewById(R.id.lsm6dsv16xAccelOdrSpinner);
        lsm6dsv16xAccelFullScaleSpinner = mMainLayout.findViewById(R.id.lsm6dsv16xAccelFullScaleSpinner);
        lsm6dsv16xAccelPowerModeSpinner = mMainLayout.findViewById(R.id.lsm6dsv16xAccelPowerModeSpinner);

        lsm6dsv16xGyroConfigTextView = mMainLayout.findViewById(R.id.lsm6dsv16xGyroConfigTextView);
        lsm6dsv16xGyroOdrTextView = mMainLayout.findViewById(R.id.lsm6dsv16xGyroOdrTextView);
        lsm6dsv16xGyroFullScaleTextView = mMainLayout.findViewById(R.id.lsm6dsv16xGyroFullScaleTextView);
        lsm6dsv16xGyroPowerModeTextView = mMainLayout.findViewById(R.id.lsm6dsv16xGyroPowerModeTextView);
        lsm6dsv16xGyroOdrSpinner = mMainLayout.findViewById(R.id.lsm6dsv16xGyroOdrSpinner);
        lsm6dsv16xGyroFullScaleSpinner = mMainLayout.findViewById(R.id.lsm6dsv16xGyroFullScaleSpinner);
        lsm6dsv16xGyroPowerModeSpinner = mMainLayout.findViewById(R.id.lsm6dsv16xGyroPowerModeSpinner);

        lsm6dsv16xQvarConfigLinearLayout = mMainLayout.findViewById(R.id.lsm6dsv16xQvarConfigLinearLayout);
        lsm6dsv16xQvarEnabledCheckBox = mMainLayout.findViewById(R.id.lsm6dsv16xQvarEnabledCheckBox);
        lsm6dsv16xQvarZinTextView = mMainLayout.findViewById(R.id.lsm6dsv16xQvarZinTextView);
        lsm6dsv16xQvarZinSpinner = mMainLayout.findViewById(R.id.lsm6dsv16xQvarZinSpinner);
        lsm6dsv16xQvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
        lsm6dsv16xQvarZinSpinner.setEnabled(false);

        accelQvarHighRateTextView = mMainLayout.findViewById(R.id.accelQvarHighRateTextView);
        accelQvarHighRateCheckBox = mMainLayout.findViewById(R.id.accelQvarHighRateCheckBox);
        accelAxisTextView = mMainLayout.findViewById(R.id.accelAxisTextView);
        accelAxisSpinner = mMainLayout.findViewById(R.id.accelAxisSpinner);

        accelAxisTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
        accelAxisSpinner.setEnabled(false);

        lsm6dsv16xAccelOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsv16x_reg_10 &= 0xF0;
                lsm6dsv16x_reg_10 |= position;
                lsm6dsv16x_xl_pd = !(position > 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsv16xAccelFullScaleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsv16x_reg_17 &= 0xFC;
                lsm6dsv16x_reg_17 |= position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsv16xAccelPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
		/*
		<string-array name="lsm6dsv16x_xl_pm_array">
			<item>High Performance</item>   000
			<item>High Accuracy ODR</item>  001
			<item>Normal Mode</item>        111
			<item>Low Power Mode 1</item>   100
			<item>Low Power Mode 2</item>   101
			<item>Low Power Mode 3</item>   110
		</string-array>
		 */
                lsm6dsv16x_reg_10 &= 0x0F;
                if (position == 0) { // High Performance
                    lsm6dsv16x_reg_10 |= 0x00;
                } else if (position == 1) { // High Accuracy ODR
                    lsm6dsv16x_reg_10 |= 0x10;
                } else if (position == 2) { // Normal Mode
                    lsm6dsv16x_reg_10 |= 0x70;
                } else if (position == 3) { // Low Power Mode 1
                    lsm6dsv16x_reg_10 |= 0x40;
                } else if (position == 4) { // Low Power Mode 2
                    lsm6dsv16x_reg_10 |= 0x50;
                } else if (position == 5) { // Low Power Mode 3
                    lsm6dsv16x_reg_10 |= 0x60;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsv16xGyroOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsv16x_reg_11 &= 0xF0;
                lsm6dsv16x_reg_11 |= position;
                lsm6dsv16x_g_pd = !(position > 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsv16xGyroFullScaleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsv16x_reg_15 &= 0xF0;
                if (position == 5) // 4000 dps
                    lsm6dsv16x_reg_15 |= 0x0C;
                else
                    lsm6dsv16x_reg_15 |= position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsv16xGyroPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
		/*
		<string-array name="lsm6dsv16x_g_pm_array">
			<item>High Performance</item>   000
			<item>High Accuracy ODR</item>  001
			<item>Low Power Mode</item>     101
		</string-array>
		 */
                lsm6dsv16x_reg_11 &= 0x0F;
                if (position == 0) { // High Performance
                    lsm6dsv16x_reg_11 |= 0x00;
                } else if (position == 1) { // High Accuracy ODR
                    lsm6dsv16x_reg_11 |= 0x10;
                } else if (position == 2) { // Low Power Mode
                    lsm6dsv16x_reg_11 |= 0x50;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsv16xQvarEnabledCheckBox.setOnCheckedChangeListener((buttonView, isChecked) ->
        {
            lsm6dsv16x_q_pd = !isChecked;

            if (lsm6dsv16x_q_pd) {
                lsm6dsv16x_reg_16 &= 0x7F;
                lsm6dsv16xQvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lsm6dsv16xQvarZinSpinner.setEnabled(false);
            } else {
                lsm6dsv16x_reg_16 |= 0x80;
                lsm6dsv16xQvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lsm6dsv16xQvarZinSpinner.setEnabled(true);
            }
        });

        lsm6dsv16xQvarZinSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsv16x_reg_16 |= (position << 5);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        accelQvarHighRateCheckBox.setOnCheckedChangeListener((buttonView, isChecked) ->
        {
            accel_qvar_high_rate = isChecked;

            if (isChecked) {
                lsm6dsv16xAccelOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lsm6dsv16xAccelFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lsm6dsv16xAccelPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lsm6dsv16xAccelOdrSpinner.setEnabled(false);
                lsm6dsv16xAccelFullScaleSpinner.setEnabled(false);
                lsm6dsv16xAccelPowerModeSpinner.setEnabled(false);

                lsm6dsv16xGyroOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lsm6dsv16xGyroFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lsm6dsv16xGyroPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lsm6dsv16xGyroOdrSpinner.setEnabled(false);
                lsm6dsv16xGyroFullScaleSpinner.setEnabled(false);
                lsm6dsv16xGyroPowerModeSpinner.setEnabled(false);

                lsm6dsv16xQvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lsm6dsv16xQvarEnabledCheckBox.setEnabled(false);
                lsm6dsv16xQvarZinTextView.setEnabled(false);
                lsm6dsv16xQvarZinSpinner.setEnabled(false);

                accelAxisTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                accelAxisSpinner.setEnabled(true);
            }
            else {
                lsm6dsv16xAccelOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lsm6dsv16xAccelFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lsm6dsv16xAccelPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lsm6dsv16xAccelOdrSpinner.setEnabled(true);
                lsm6dsv16xAccelFullScaleSpinner.setEnabled(true);
                lsm6dsv16xAccelPowerModeSpinner.setEnabled(true);

                lsm6dsv16xGyroOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lsm6dsv16xGyroFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lsm6dsv16xGyroPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lsm6dsv16xGyroOdrSpinner.setEnabled(true);
                lsm6dsv16xGyroFullScaleSpinner.setEnabled(true);
                lsm6dsv16xGyroPowerModeSpinner.setEnabled(true);

                lsm6dsv16xQvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lsm6dsv16xQvarEnabledCheckBox.setEnabled(true);
                if (lsm6dsv16xQvarEnabledCheckBox.isChecked())
                {
                    lsm6dsv16xQvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsv16xQvarZinSpinner.setEnabled(true);
                }
                else
                {
                    lsm6dsv16xQvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dsv16xQvarZinSpinner.setEnabled(false);
                }

                accelAxisTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                accelAxisSpinner.setEnabled(false);
            }
        });

        filenameLinearLayout = mMainLayout.findViewById(R.id.filenameLinearLayout);
        filenameEditText = mMainLayout.findViewById(R.id.filenameEditText);

        loggingTextView = mMainLayout.findViewById(R.id.loggingTextView);
        startStopBleLogButton = mMainLayout.findViewById(R.id.startStopBleLogButton);

        startStopBleLogButton.setOnClickListener((View view) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!BluetoothLeService.mFirstCtrlPacketReceived) {
                    BLECommands.sendGetStatus(getContext());    // Try getting again the status
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_waiting_first_ble_packet_ongoing), Toast.LENGTH_SHORT).show();
                } else {
                    if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                        if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                            if (MyCtrlData.battery_present == 1 && MyCtrlData.battery_level < 30) {
                                AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                                alertDialog.setTitle(getContext().getString(R.string.title_warning));
                                alertDialog.setMessage(getContext().getString(R.string.alert_low_battery_message));
                                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getContext().getString(R.string.yes_string),
                                        (dialog, which) -> {
                                            startLog();
                                            dialog.dismiss();
                                        });
                                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getContext().getString(R.string.no_string),
                                        (dialog, which) -> dialog.dismiss());
                                alertDialog.show();
                            } else {
                                startLog();
                            }
                        } else if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_LOGGING) {
                            stopLog();
                        }
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void stopLog()
    {
        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STOPPING);
        MyLogging.setLogFileStatus(MyLogging.LOGFILE_STATUS_CLOSING);
        BLECommands.sendBleStop(getContext());
        BLECommands.sendBleLogStop(getContext());
        BLECommands.sendGetBatteryLevel(getContext());
    }

    private void startLog()
    {
        // Reset device if needed
        if (MyCtrlData.conf == 1)
            BLECommands.sendResetDeviceConfiguration(getContext());

        // Configure device
        if (!accel_qvar_high_rate)
        {
            String lsm6dsv16x_reg10 = String.format(Locale.ENGLISH, "%02x", lsm6dsv16x_reg_10);
            BLECommands.sendWriteLSM6DSOX(getContext(), "10", lsm6dsv16x_reg10);

            String lsm6dsv16x_reg11 = String.format(Locale.ENGLISH, "%02x", lsm6dsv16x_reg_11);
            BLECommands.sendWriteLSM6DSOX(getContext(), "11", lsm6dsv16x_reg11);

            String lsm6dsv16x_reg15 = String.format(Locale.ENGLISH, "%02x", lsm6dsv16x_reg_15);
            BLECommands.sendWriteLSM6DSOX(getContext(), "15", lsm6dsv16x_reg15);

            String lsm6dsv16x_reg16 = String.format(Locale.ENGLISH, "%02x", lsm6dsv16x_reg_16);
            BLECommands.sendWriteLSM6DSOX(getContext(), "16", lsm6dsv16x_reg16);

            String lsm6dsv16x_reg17 = String.format(Locale.ENGLISH, "%02x", lsm6dsv16x_reg_17);
            BLECommands.sendWriteLSM6DSOX(getContext(), "17", lsm6dsv16x_reg17);

            BLECommands.sendWriteLSM6DSOX(getContext(), "0E", "03");

            MyLogging.setBleLogHighRate(false);
            MyLogging.setBleLogHighRateAccelAxis("");
        }
        else
        {
            MyLogging.setBleLogHighRate(true);
            String accelAxis = (String)accelAxisSpinner.getSelectedItem();
            if (accelAxis.contains("X-axis"))
                MyLogging.setBleLogHighRateAccelAxis("X");
            else if (accelAxis.contains("Y-axis"))
                MyLogging.setBleLogHighRateAccelAxis("Y");
            else if (accelAxis.contains("Z-axis"))
                MyLogging.setBleLogHighRateAccelAxis("Z");
            else if (accelAxis.contains("Norm Vector"))
                MyLogging.setBleLogHighRateAccelAxis("V");
        }

        // Just to be sure that the mic is off
        BLECommands.sendAudioOff(getContext());

        // Prepare app for logging data
        String filename = filenameEditText.getText().toString();
        MySharedPreferences.getInstance(getContext()).setLogFilename(filename);
        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STARTING);
        MyLogging.setLogFileStatus(MyLogging.LOGFILE_STATUS_CREATING);
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                switch (MyLogging.getLogStatus())
                {
                    case MyLogging.LOG_STATUS_IDLE:
                        loggingTextView.setEnabled(true);
                        if (!accel_qvar_high_rate && (lsm6dsv16x_xl_pd && !lsm6dsv16x_q_pd || lsm6dsv16x_xl_pd && lsm6dsv16x_g_pd)) {
                            startStopBleLogButton.setEnabled(false);
                            startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                        }
                        else {
                            startStopBleLogButton.setEnabled(true);
                            startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        }
                        loggingTextView.setText(R.string.logging_false_string);
                        startStopBleLogButton.setText(R.string.start_string);
                        if (MyCtrlData.ble_log > 0) {
                            MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                        }
                        break;
                    case MyLogging.LOG_STATUS_STARTING:
                        startStopBleLogButton.setEnabled(false);
                        startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                        startStopBleLogButton.setText(R.string.starting_string);
                        if (MyCtrlData.ble_log > 0) {
                            MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                        }
                        break;
                    case MyLogging.LOG_STATUS_LOGGING:
                        loggingTextView.setText(R.string.logging_true_string);
                        startStopBleLogButton.setEnabled(true);
                        startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        startStopBleLogButton.setText(R.string.stop_string);
                        if (MyCtrlData.ble_log == 0) {
                            MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                        }
                        break;
                    case MyLogging.LOG_STATUS_STOPPING:
                        startStopBleLogButton.setText(R.string.stopping_string);
                        startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                        startStopBleLogButton.setEnabled(false);
                        if (MyCtrlData.ble_log == 0) {
                            MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                        }
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

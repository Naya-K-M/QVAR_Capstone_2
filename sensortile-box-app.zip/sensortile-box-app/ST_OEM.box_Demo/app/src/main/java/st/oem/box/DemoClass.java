package st.oem.box;

import android.content.Context;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import st.oem.R;

/**
 * Created by s rivolta on 4/12/2018.
 */

public class DemoClass implements Parcelable {

    final static Integer PARAM_TYPE_THRESHOLD = 0;
    final static Integer PARAM_TYPE_SHORT_TIMER = 1;
    final static Integer PARAM_TYPE_LONG_TIMER = 2;

    final static Integer PATENT_NONE = 0;
    final static Integer PATENT_DONE = 1;
    final static Integer PATENT_PENDING = 2;

    private Context mContext;

    // Data
    private String DEMO_Name = "";
    private String DEMO_LogName = "";
    private Integer DEMO_IconID = 0;
    private String DEMO_ShortDescription = "";
    private String DEMO_OtherText = "";
    private String DEMO_Description = "";
    private String DEMO_SensorsDescription = "";
    private String DEMO_CurrentConsumption = "";
    private boolean usage_XL = false;
    private boolean usage_G = false;
    private boolean usage_Q = false;
    private boolean usage_P = false;
    private boolean usage_MLC = false;
    private boolean usage_FSM = false;
    private boolean usage_EMB = false;
    private boolean usage_PED = false;
    private boolean usage_SFLP = false;
    private boolean usage_ISPU = false;
    private boolean usage_LIB = false;
    private boolean usage_PedoMobileConfigCard = false;
    private boolean usage_PedoWristConfigCard = false;
    private boolean usage_LeftRightConfigCard = false;
    private Integer DEMO_ConfigFile_Left = 0;
    private Integer DEMO_ConfigFile_Right = 0;
    private boolean usage_RamConfigCard = false;
    private ArrayList<String> ramConfigParamNames;
    private ArrayList<Integer> ramConfigParamTypes;
    private ArrayList<Float> ramConfigParamDefaults;
    private ArrayList<List<String>> ramConfigParamRamAddresses;
    private ArrayList<String> ramConfigParamDescriptions;
    private boolean usage_LibConfigCard = false;
    private ArrayList<String> libConfigParamNames;
    private ArrayList<Integer> libConfigParamIndexes;
    private ArrayList<Double> libConfigParamValues;
    private ArrayList<String> libConfigParamDescriptions;
    private boolean usage_SDLogCard = false;
    private boolean usage_BLELogCard = false;
    private boolean usage_BLEStreamCard = false;
    private boolean usage_DemoLogCard = true;
    private boolean usage_MassStorageCard = false;
    private boolean usage_FusionCard = false;
    private boolean usage_UnsupervisedOdlCard = false;
    private boolean usage_InBagDetectionCard = false;
    private boolean usage_FallHeightEstimationCard = false;
    private Integer DEMO_ConfigFile = 0;
    private Integer DEMO_JsonFile = 0;
    private Uri DEMO_ConfigUri = Uri.EMPTY;
    private Uri DEMO_JsonUri = Uri.EMPTY;
    private long DEMO_StartupLatency = 0;
    private Integer DEMO_Patent = PATENT_NONE;
    private ArrayList<SingleDemoClass> FSM_DEMOs;
    private ArrayList<SingleDemoClass> MLC_DEMOs;
    private ArrayList<SingleDemoClass> EMB_DEMOs;
    private ArrayList<SingleDemoClass> PED_DEMOs;
    private ArrayList<SingleDemoClass> SFLP_DEMOs;
    private ArrayList<SingleDemoClass> ISPU_DEMOs;
    private ArrayList<SingleDemoClass> LIB_DEMOs;

    // Constructor
    DemoClass(Context context, String demoName, String demoLogName, String demoDescription, String demoShortDescription, String demoCurrentConsumption, Integer demoIconID, Integer configurationFile, Integer jsonFile) {
        this.mContext = context;
        this.DEMO_Name = demoName;
        this.DEMO_LogName = demoLogName;
        this.DEMO_IconID = demoIconID;
        this.DEMO_Description = demoDescription;
        this.DEMO_ShortDescription = demoShortDescription;
        this.DEMO_CurrentConsumption = demoCurrentConsumption;
        this.DEMO_ConfigFile = configurationFile;
        this.DEMO_JsonFile = jsonFile;
        this.FSM_DEMOs = new ArrayList<>();
        this.MLC_DEMOs = new ArrayList<>();
        this.EMB_DEMOs = new ArrayList<>();
        this.PED_DEMOs = new ArrayList<>();
        this.SFLP_DEMOs = new ArrayList<>();
        this.ISPU_DEMOs = new ArrayList<>();
        this.LIB_DEMOs = new ArrayList<>();
        this.ramConfigParamNames = new ArrayList<>();
        this.ramConfigParamTypes = new ArrayList<>();
        this.ramConfigParamDefaults = new ArrayList<>();
        this.ramConfigParamRamAddresses = new ArrayList<>();
        this.ramConfigParamDescriptions = new ArrayList<>();
        this.libConfigParamNames = new ArrayList<>();
        this.libConfigParamIndexes = new ArrayList<>();
        this.libConfigParamValues = new ArrayList<>();
        this.libConfigParamDescriptions = new ArrayList<>();

        // Parse config file to get XL and G ODR automatically
        InputStream inputStream = mContext.getResources().openRawResource(configurationFile);
        BufferedReader myReader = new BufferedReader(new InputStreamReader(inputStream));
        String myDataRow;

        boolean stmc_page = false;
        String stmc_page_en = "";
        String stmc_page_dis = "";

        boolean XL_avail = false;
        String XL_reg = "00";
        String XL_regValue = "00";

        boolean G_avail = false;
        String G_reg = "00";
        String G_regValue = "00";

        boolean Qvar_avail = false;
        String Qvar_reg = "00";
        String Qvar_regValue = "00";

        switch (MyCtrlData.device) {
            case MyCtrlData.DEVICE_LIS2DUXS12:
                stmc_page_en = "3F 80";
                stmc_page_dis = "3F 00";
                XL_avail = true;
                XL_reg = "14";
                Qvar_avail = true;
                Qvar_reg = "31";
                break;
            case MyCtrlData.DEVICE_LSM6DSOX:
            case MyCtrlData.DEVICE_LSM6DSO16IS:
                stmc_page_en = "01 80";
                stmc_page_dis = "01 00";
                XL_avail = true;
                XL_reg = "10";
                G_avail = true;
                G_reg = "11";
                break;
            case MyCtrlData.DEVICE_LSM6DSV16X:
            case MyCtrlData.DEVICE_LSM6DSV16BX:
            case MyCtrlData.DEVICE_LSM6DSV32X:
                stmc_page_en = "01 80";
                stmc_page_dis = "01 00";
                XL_avail = true;
                XL_reg = "10";
                G_avail = true;
                G_reg = "11";
                Qvar_avail = true;
                Qvar_reg = "16";
                break;
        }

        if (Objects.equals(MyCtrlData.device, MyCtrlData.DEVICE_LSM6DSO16IS))
            this.usage_ISPU = true;

        try {
            while ((myDataRow = myReader.readLine()) != null) {

                // Make the row lowercase
                myDataRow = myDataRow.toUpperCase();

                // Discard empty line and comments
                if (myDataRow.isEmpty() || myDataRow.contains("--")) {
                    continue;
                }

                // Valid row
                if (myDataRow.contains("AC ") && myDataRow.length() == 8) {
                    if (myDataRow.contains(stmc_page_en))
                        stmc_page = true;
                    else if (myDataRow.contains(stmc_page_dis))
                        stmc_page = false;
                    else if (!stmc_page) {
                        String[] separated = myDataRow.split("\\s+"); // "\\s+" is the space

                        String regAddress = separated[1];
                        String regValue = separated[2];

                        // XL
                        if (XL_avail && regAddress.equals(XL_reg)) {
                            XL_regValue = regValue;
                        }
                        // G
                        if (G_avail && regAddress.equals(G_reg)) {
                            G_regValue = regValue;
                        }
                        // Qvar
                        if (Qvar_avail && regAddress.equals(Qvar_reg)) {
                            Qvar_regValue = regValue;
                        }
                    }
                }
            }
            myReader.close();
        } catch (Exception e) {
            Log.d("EXCEPTION_LOAD_DEMO", "Exception during load-demo: " + e);
        }

        this.DEMO_SensorsDescription = "Sensors ODR:\n";

        switch (MyCtrlData.device) {
            case MyCtrlData.DEVICE_LSM6DSOX:
            case MyCtrlData.DEVICE_LSM6DSO16IS:
                switch (XL_regValue.charAt(0)) {
                    case '0':
                        this.usage_XL = false;
                        break;
                    case '1':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 13 Hz\n";
                        break;
                    case '2':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 26 Hz\n";
                        break;
                    case '3':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 52 Hz\n";
                        break;
                    case '4':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 104 Hz\n";
                        break;
                    case '5':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 208 Hz\n";
                        break;
                    case '6':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 416 Hz\n";
                        break;
                    default:
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "XL @ N/A\n";
                        break;
                }
                switch (G_regValue.charAt(0)) {
                    case '0':
                        this.usage_G = false;
                        break;
                    case '1':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 13 Hz\n";
                        break;
                    case '2':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 26 Hz\n";
                        break;
                    case '3':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 52 Hz\n";
                        break;
                    case '4':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 104 Hz\n";
                        break;
                    case '5':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 208 Hz\n";
                        break;
                    case '6':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- G @ 416 Hz\n";
                        break;
                    default:
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- G @ N/A\n";
                        break;
                }
                break;
            case MyCtrlData.DEVICE_LSM6DSV16X:
            case MyCtrlData.DEVICE_LSM6DSV16BX:
            case MyCtrlData.DEVICE_LSM6DSV32X:
                switch (XL_regValue.charAt(1)) {
                    case '0':
                        this.usage_XL = false;
                        break;
                    case '1':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 1.875 Hz\n";
                        break;
                    case '2':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 7.5 Hz\n";
                        break;
                    case '3':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 15 Hz\n";
                        break;
                    case '4':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 30 Hz\n";
                        break;
                    case '5':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 60 Hz\n";
                        break;
                    case '6':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 120 Hz\n";
                        break;
                    case '7':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 240 Hz\n";
                        break;
                    case '8':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 480 Hz\n";
                        break;
                    case '9':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 960 Hz\n";
                        break;
                    default:
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ N/A\n";
                        break;
                }
                switch (G_regValue.charAt(1)) {
                    case '0':
                        this.usage_G = false;
                        break;
                    case '2':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 7.5 Hz\n";
                        break;
                    case '3':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 15 Hz\n";
                        break;
                    case '4':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 30 Hz\n";
                        break;
                    case '5':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 60 Hz\n";
                        break;
                    case '6':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 120 Hz\n";
                        break;
                    case '7':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 240 Hz\n";
                        break;
                    case '8':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 480 Hz\n";
                        break;
                    case '9':
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ 960 Hz\n";
                        break;
                    default:
                        this.usage_G = true;
                        this.DEMO_SensorsDescription += "- Gyro @ N/A\n";
                        break;
                }
                switch (Qvar_regValue.charAt(0)) {
                    case '8':
                    case '9':
                    case 'A':
                    case 'B':
                    case 'C':
                    case 'D':
                    case 'E':
                    case 'F':
                        this.usage_Q = true;
                        this.DEMO_SensorsDescription += "- Qvar @ 240 Hz\n";
                        break;
                }
                break;
            case MyCtrlData.DEVICE_LIS2DUXS12:
                switch (XL_regValue.charAt(0)) {
                    case '0':
                        this.usage_XL = false;
                        break;
                    case '1':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 1.6 Hz\n";
                        break;
                    case '2':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 3 Hz\n";
                        break;
                    case '3':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 25 Hz\n";
                        break;
                    case '4':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 6 Hz\n";
                        break;
                    case '5':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 12.5 Hz\n";
                        break;
                    case '6':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 25 Hz\n";
                        break;
                    case '7':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 50 Hz\n";
                        break;
                    case '8':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 100 Hz\n";
                        break;
                    case '9':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 200 Hz\n";
                        break;
                    case 'A':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 400 Hz\n";
                        break;
                    case 'B':
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ 800 Hz\n";
                        break;
                    default:
                        this.usage_XL = true;
                        this.DEMO_SensorsDescription += "- XL @ N/A\n";
                        break;
                }
                switch (Qvar_regValue.charAt(0)) {
                    case '8':
                    case '9':
                    case 'A':
                    case 'B':
                    case 'C':
                    case 'D':
                    case 'E':
                    case 'F':
                        this.usage_Q = true;
                        this.DEMO_SensorsDescription += "- Qvar enabled\n";
                        break;
                }
                break;
        }
    }

    private void clearDemoClass() {
        for(int i = 0; i < this.MLC_DEMOs.size(); i++) {
            this.MLC_DEMOs.get(i).clearSingleDemo();
        }
        for(int i = 0; i < this.FSM_DEMOs.size(); i++) {
            this.FSM_DEMOs.get(i).clearSingleDemo();
        }
        for(int i = 0; i < this.EMB_DEMOs.size(); i++) {
            this.EMB_DEMOs.get(i).clearSingleDemo();
        }
        for(int i = 0; i < this.PED_DEMOs.size(); i++) {
            this.PED_DEMOs.get(i).clearSingleDemo();
        }
        for(int i = 0; i < this.SFLP_DEMOs.size(); i++) {
            this.SFLP_DEMOs.get(i).clearSingleDemo();
        }
        for(int i = 0; i < this.ISPU_DEMOs.size(); i++) {
            this.ISPU_DEMOs.get(i).clearSingleDemo();
        }
        for(int i = 0; i < this.LIB_DEMOs.size(); i++) {
            this.LIB_DEMOs.get(i).clearSingleDemo();
        }
        this.MLC_DEMOs.clear();
        this.FSM_DEMOs.clear();
        this.EMB_DEMOs.clear();
        this.PED_DEMOs.clear();
        this.SFLP_DEMOs.clear();
        this.ISPU_DEMOs.clear();
        this.LIB_DEMOs.clear();

        this.usage_XL = false;
        this.usage_G = false;
        this.usage_Q = false;
        this.usage_P = false;
        this.usage_MLC = false;
        this.usage_FSM = false;
        this.usage_EMB = false;
        this.usage_PED = false;
        this.usage_SFLP = false;
        this.usage_ISPU = false;
        this.usage_LIB = false;
        this.usage_PedoMobileConfigCard = false;
        this.usage_PedoWristConfigCard = false;
        this.usage_LeftRightConfigCard = false;
        this.DEMO_ConfigFile_Left = 0;
        this.DEMO_ConfigFile_Right = 0;
        this.usage_RamConfigCard = false;
        this.ramConfigParamNames = new ArrayList<>();
        this.ramConfigParamTypes = new ArrayList<>();
        this.ramConfigParamDefaults = new ArrayList<>();
        this.ramConfigParamRamAddresses = new ArrayList<>();
        this.ramConfigParamDescriptions = new ArrayList<>();
        this.usage_LibConfigCard = false;
        this.libConfigParamNames = new ArrayList<>();
        this.libConfigParamIndexes = new ArrayList<>();
        this.libConfigParamValues = new ArrayList<>();
        this.libConfigParamDescriptions = new ArrayList<>();
        this.usage_DemoLogCard = false;
        this.usage_SDLogCard = false;
        this.usage_BLELogCard = false;
        this.usage_BLEStreamCard = false;
        this.DEMO_LogName = mContext.getString(R.string.empty_string);
        this.usage_MassStorageCard = false;
        this.usage_FusionCard = false;
        this.usage_UnsupervisedOdlCard = false;
        this.usage_InBagDetectionCard = false;
        this.usage_FallHeightEstimationCard = false;
        if (MyCtrlData.isDemoLogSupported())
            this.usage_DemoLogCard = true;
    }

    void addRamConfigItem(String paramName, Integer paramType, Float paramDefault, List<String> paramRamAddress, String paramDescription) {
        ramConfigParamNames.add(paramName);
        ramConfigParamTypes.add(paramType);
        ramConfigParamDefaults.add(paramDefault);
        ramConfigParamRamAddresses.add(paramRamAddress);
        ramConfigParamDescriptions.add(paramDescription);
    }

    void addLibConfigItem(String paramName, Integer paramIndex, Double paramValue, String paramDescription) {
        libConfigParamNames.add(paramName);
        libConfigParamIndexes.add(paramIndex);
        libConfigParamValues.add(paramValue);
        libConfigParamDescriptions.add(paramDescription);
    }

    void addSingleDemo(String featureName, String demoName, ArrayList<Byte> values, ArrayList<String> strings, ArrayList<Integer> imageIDs, String outputType) {

        // Create demo
        SingleDemoClass newDemo = new SingleDemoClass(featureName, demoName);

        if (values != null) {
            for (int i = 0; i < values.size(); i++) {
                newDemo.addValuesStringsImagesRelationship(values.get(i), strings.get(i), imageIDs.get(i));
            }
        }
        newDemo.setOutputType(outputType);

        // Add demo to correct demo array
        if (featureName.equals(AppConfig.FINITE_STATE_MACHINE_STR)) {
            FSM_DEMOs.add(newDemo);
            usage_FSM = true;
        }
        if (featureName.equals(AppConfig.MACHINE_LEARNING_CORE_STR)) {
            MLC_DEMOs.add(newDemo);
            usage_MLC = true;
        }
        if (featureName.equals(AppConfig.EMBEDDED_FUNCTION_STR)) {
            EMB_DEMOs.add(newDemo);
            usage_EMB = true;
        }
        if (featureName.equals(AppConfig.PEDOMETER_2_0_STR)) {
            PED_DEMOs.add(newDemo);
            usage_PED = true;
        }
        if (featureName.equals(AppConfig.SENSOR_FUSION_LOW_POWER_STR)) {
            SFLP_DEMOs.add(newDemo);
            usage_SFLP = true;
        }
        if (featureName.equals(AppConfig.ISPU_STR)) {
            ISPU_DEMOs.add(newDemo);
            usage_ISPU = true;
        }
        if (featureName.equals(AppConfig.SW_LIB_STR)) {
            LIB_DEMOs.add(newDemo);
            usage_LIB = true;
        }
    }

    private void setNumberOf_MLC(int n) {
        this.MLC_DEMOs.clear();
        this.usage_MLC = false;
        String featureName;
        String singleDemoName;
        ArrayList<Byte> values = new ArrayList<>();
        ArrayList<String> strings = new ArrayList<>();
        ArrayList<Integer> imageIDs = new ArrayList<>();
        String outputType;
        for (int i = 0; i < n; i++) {
            featureName = AppConfig.MACHINE_LEARNING_CORE_STR;
            outputType = AppConfig.CONTINUOUS_STR;
            singleDemoName = String.format(mContext.getString(R.string.mlc_index), i);
            values.add((byte)0xFF); // TO CHECK
            strings.add(mContext.getString(R.string.na_string));
            imageIDs.add(R.drawable.none);
            this.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);
        }
    }
    private void setNumberOf_FSM(int n) {
        this.FSM_DEMOs.clear();
        this.usage_FSM = false;
        for (int i = 0; i < n; i++) {
            addSingleDemo(AppConfig.FINITE_STATE_MACHINE_STR, String.format(mContext.getString(R.string.fsm_index), i),  null, null, null, AppConfig.MANY_EVENT_BASED_STR);
        }
    }
    private void setNumberOf_EMB(int n) {
        this.EMB_DEMOs.clear();
        this.usage_EMB = false;
        for (int i = 0; i < n; i++) {
            addSingleDemo(AppConfig.EMBEDDED_FUNCTION_STR, String.format(mContext.getString(R.string.emb_index), i), null, null, null, AppConfig.EVENT_BASED_STR);
        }
    }
    private void setNumberOf_PED(int n) {
        this.PED_DEMOs.clear();
        this.usage_PED = false;
        for (int i = 0; i < n; i++) {
            addSingleDemo(AppConfig.PEDOMETER_2_0_STR, mContext.getString(R.string.ped_string), null, null, null, AppConfig.CONTINUOUS_STR);
        }
    }
    private void setNumberOf_SFLP(int n) {
        this.SFLP_DEMOs.clear();
        this.usage_SFLP = false;
        for (int i = 0; i < n; i++) {
            addSingleDemo(AppConfig.SENSOR_FUSION_LOW_POWER_STR, mContext.getString(R.string.sflp_string), null, null, null, AppConfig.CONTINUOUS_STR);
        }
    }
    private void setNumberOf_ISPU(int n) {
        this.ISPU_DEMOs.clear();
        this.usage_ISPU = false;
        for (int i = 0; i < n; i++) {
            addSingleDemo(AppConfig.ISPU_STR, mContext.getString(R.string.ispu_string), null, null, null, AppConfig.CONTINUOUS_STR);
        }
    }
    private void setNumberOf_LIB(int n) {
        this.LIB_DEMOs.clear();
        this.usage_LIB = false;
        for (int i = 0; i < n; i++) {
            addSingleDemo(AppConfig.SW_LIB_STR, mContext.getString(R.string.lib_string), null, null, null, AppConfig.CONTINUOUS_STR);
        }
    }

    void setDemoSensorsDescription(String description) { this.DEMO_SensorsDescription = description; }
    void setDemoOtherText(String otherText) { this.DEMO_OtherText = otherText; }
    void setDemoLogName(String demoLogName) {
        this.DEMO_LogName = demoLogName;
    }

    boolean getDemoUsage_XL() { return this.usage_XL; }
    boolean getDemoUsage_G() { return this.usage_G; }
    boolean getDemoUsage_Q() { return this.usage_Q; }
    boolean getDemoUsage_P() { return this.usage_P; }
    boolean getDemoUsage_FSM() { return this.usage_FSM; }
    boolean getDemoUsage_MLC() { return this.usage_MLC; }
    boolean getDemoUsage_EMB() { return this.usage_EMB; }
    boolean getDemoUsage_PED() { return this.usage_PED; }
    boolean getDemoUsage_SFLP() { return this.usage_SFLP; }
    boolean getDemoUsage_ISPU() { return this.usage_ISPU; }
    boolean getDemoUsage_LIB() { return this.usage_LIB; }
    boolean getDemoUsage_PedoMobileConfigCard() { return this.usage_PedoMobileConfigCard; }
    boolean getDemoUsage_PedoWristConfigCard() { return this.usage_PedoWristConfigCard; }
    boolean getDemoUsage_LeftRightConfigCard() { return this.usage_LeftRightConfigCard; }
    Integer getDemoUsage_LeftConfig() { return this.DEMO_ConfigFile_Left; }
    Integer getDemoUsage_RightConfig() { return this.DEMO_ConfigFile_Right; }
    boolean getDemoUsage_RamConfigCard() { return this.usage_RamConfigCard; }
    boolean getDemoUsage_LibConfigCard() { return this.usage_LibConfigCard; }
    boolean getDemoUsage_SDLogCard() { return this.usage_SDLogCard; }
    boolean getDemoUsage_BLELogCard() { return this.usage_BLELogCard; }
    boolean getDemoUsage_BLEStreamCard() { return this.usage_BLEStreamCard; }
    boolean getDemoUsage_DemoLogCard() { return this.usage_DemoLogCard; }
    boolean getDemoUsage_MassStorage() { return this.usage_MassStorageCard; }
    boolean getDemoUsage_FusionCard() { return this.usage_FusionCard; }
    boolean getDemoUsage_UnsupervisedOdlCard() { return this.usage_UnsupervisedOdlCard; }
    boolean getDemoUsage_InBagDetectionCard() { return this.usage_InBagDetectionCard; }
    boolean getDemoUsage_FallHeightEstimationCard() { return this.usage_FallHeightEstimationCard; }

    void setDemoUsage_XL(boolean status) { this.usage_XL = status; }
    void setDemoUsage_G(boolean status) { this.usage_G = status; }
    void setDemoUsage_Q(boolean status) { this.usage_Q = status; }
    void setDemoUsage_P(boolean status) { this.usage_P = status; }
    void setDemoUsage_FSM(boolean status) { this.usage_FSM = status; }
    void setDemoUsage_MLC(boolean status) { this.usage_MLC = status; }
    void setDemoUsage_EMB(boolean status) { this.usage_EMB = status; }
    void setDemoUsage_PED(boolean status) { this.usage_PED = status; }
    void setDemoUsage_SFLP(boolean status) { this.usage_SFLP = status; }
    void setDemoUsage_ISPU(boolean status) { this.usage_ISPU = status; }
    void setDemoUsage_LIB(boolean status) { this.usage_LIB = status; }
    void setDemoUsage_PedoMobileConfigCard(boolean status) { this.usage_PedoMobileConfigCard = status; }
    void setDemoUsage_PedoWristConfigCard(boolean status) { this.usage_PedoWristConfigCard = status; }
    void setDemoUsage_RamConfigCard(boolean status) { this.usage_RamConfigCard = status; }
    void setDemoUsage_LibConfigCard(boolean status) { this.usage_LibConfigCard = status; }
    void setDemoUsage_LeftRightConfigCard(Integer left, Integer right) {
        this.usage_LeftRightConfigCard = true;
        this.DEMO_ConfigFile_Left = left;
        this.DEMO_ConfigFile_Right = right;
    }
    void setDemoUsage_SDLogCard(boolean status) { this.usage_SDLogCard = status; }
    void setDemoUsage_BLELogCard(boolean status) { this.usage_BLELogCard = status; }
    void setDemoUsage_BLEStreamCard(boolean status) { this.usage_BLEStreamCard = status; }
    void setDemoUsage_DemoLogCard(boolean status) { this.usage_DemoLogCard = status; }
    void setDemoUsage_MassStorage(boolean status) { this.usage_MassStorageCard = status; }
    void setDemoUsage_FusionCard(boolean status) { this.usage_FusionCard = status; }
    void setDemoUsage_UnsupervisedOdlCard(boolean status) { this.usage_UnsupervisedOdlCard = status; }
    void setDemoUsage_InBagDetectionCard(boolean status) { this.usage_InBagDetectionCard = status; }
    void setDemoUsage_FallHeightEstimationCard(boolean status) { this.usage_FallHeightEstimationCard = status; }
    void setDemoStartupLatency(long latency) { this.DEMO_StartupLatency = latency; }
    void setDemoPatent(Integer patent) { this.DEMO_Patent = patent; }

    Integer getNumberOf_FSM() { return this.FSM_DEMOs.size(); }
    Integer getNumberOf_MLC() { return this.MLC_DEMOs.size(); }
    Integer getNumberOf_EMB() { return this.EMB_DEMOs.size(); }
    Integer getNumberOf_PED() { return this.PED_DEMOs.size(); }
    Integer getNumberOf_SFLP() { return this.SFLP_DEMOs.size(); }
    Integer getNumberOf_ISPU() { return this.ISPU_DEMOs.size(); }
    Integer getNumberOf_LIB() { return this.LIB_DEMOs.size(); }
    Integer getNumberOf_RamConfigItems() { return this.ramConfigParamNames.size(); }
    Integer getNumberOf_LibConfigItems() { return this.libConfigParamNames.size(); }

    public String getDemoName() {
        return this.DEMO_Name;
    }
    Integer getDemoIconID() {
        return this.DEMO_IconID;
    }
    String getDemoDescription() {
        return this.DEMO_Description;
    }
    String getDemoShortDescription() {
        return this.DEMO_ShortDescription;
    }
    String getDemoOtherText() {
        return this.DEMO_OtherText;
    }
    String getDemoSensorsDescription() { return this.DEMO_SensorsDescription; }
    String getDemoCurrentConsumption() { return this.DEMO_CurrentConsumption; }
    String getDemoLogName() {
        return this.DEMO_LogName;
    }
    String getLibConfigParamName(Integer i) {
        return this.libConfigParamNames.get(i);
    }
    Integer getLibConfigParamIndex(Integer i) {
        return this.libConfigParamIndexes.get(i);
    }
    Double getLibConfigParamValue(Integer i) {
        return this.libConfigParamValues.get(i);
    }
    void setLibConfigParamValue(Integer i, Double value) {
        this.libConfigParamValues.set(i, value);
    }
    String getLibConfigParamDescription(Integer i) {
        return this.libConfigParamDescriptions.get(i);
    }
    String getRamConfigParamName(Integer i) {
        return this.ramConfigParamNames.get(i);
    }
    Integer getRamConfigParamType(Integer i) {
        return this.ramConfigParamTypes.get(i);
    }
    Float getRamConfigParamDefault(Integer i) {
        return this.ramConfigParamDefaults.get(i);
    }
    List<String> getRamConfigParamRamAddress(Integer i) {
        return this.ramConfigParamRamAddresses.get(i);
    }
    String getRamConfigParamDescription(Integer i) {
        return this.ramConfigParamDescriptions.get(i);
    }

    String getSingleDemoName(String feature, int n) {
        String singleDemoName = mContext.getString(R.string.empty_string);
        switch (feature)
        {
            case AppConfig.MACHINE_LEARNING_CORE_STR:
                singleDemoName = this.MLC_DEMOs.get(n).DEMO_Name;
                break;
            case AppConfig.FINITE_STATE_MACHINE_STR:
                singleDemoName = this.FSM_DEMOs.get(n).DEMO_Name;
                break;
            case AppConfig.EMBEDDED_FUNCTION_STR:
                singleDemoName = this.EMB_DEMOs.get(n).DEMO_Name;
                break;
            case AppConfig.PEDOMETER_2_0_STR:
                singleDemoName = this.PED_DEMOs.get(n).DEMO_Name;
                break;
            case AppConfig.SENSOR_FUSION_LOW_POWER_STR:
                singleDemoName = this.SFLP_DEMOs.get(n).DEMO_Name;
                break;
            case AppConfig.ISPU_STR:
                singleDemoName = this.ISPU_DEMOs.get(n).DEMO_Name;
                break;
            case AppConfig.SW_LIB_STR:
                singleDemoName = this.LIB_DEMOs.get(n).DEMO_Name;
                break;
            default:
                break;
        }
        return singleDemoName;
    }

    Integer getConfigurationFileResource() {
        return this.DEMO_ConfigFile;
    }
    Integer getJsonFileResource() {
        return this.DEMO_JsonFile;
    }
    Uri getConfigurationFileUri() {
        return this.DEMO_ConfigUri;
    }
    Uri getJsonFileUri() {
        return this.DEMO_JsonUri;
    }
    long getDemoStartupLatency() {
        return this.DEMO_StartupLatency;
    }
    Integer getDemoPatent() { return this.DEMO_Patent; }
    void setConfigurationFileUri(Uri configUri) {
        this.DEMO_ConfigUri = configUri;

        if (MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS))
        {
            this.clearDemoClass();
            this.setNumberOf_ISPU(1);
        }
        else
        {
            // Parse config file to get XL and G ODR automatically
            InputStream inputStream = null;
            try {
                inputStream = mContext.getContentResolver().openInputStream(configUri);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            assert inputStream != null;
            BufferedReader myReader = new BufferedReader( new InputStreamReader(inputStream));
            String myDataRow;

            boolean stmc_page = false;
            String stmc_page_en = "";
            String stmc_page_dis = "";

            // Events routing:
            // - SensorTile.box --> INT1
            // - SensorTile.box pro
            //   - LSM6DSV16BX --> INT2
            //   - Others --> INT1
            // - TWS.box --> INT2
            String MLC_int_reg = "00";
            String MLC_int_regValue = "00";
            String FSM_int_reg = "00";
            String FSM_int_regValue = "00";
            String PED_int_reg = "00";
            String PED_int_regValue = "00";
            // TODO: check the need of handling SFLP in UCFLoader
            String SFLP_int_reg = "00";
            String SFLP_int_regValue = "00";
            String EMB_int_reg = "00";
            String EMB_int_regValue = "00";
            String TAP_en_reg = "00";           // dux only, TAP_CFG5 (74h) register address
            String TAP_en_regValue = "00";      // dux only, TAP_CFG5 (74h) register value
            int TAP_bit = 0;                    // dux only, MDx_CFG bit for enabling taps
            int SINGLE_TAP_bit = 0;
            int DOUBLE_TAP_bit = 0;
            int TRIPLE_TAP_bit = 0;             // dux only
            int WAKE_UP_bit = 0;
            int FREE_FALL_bit = 0;

            switch (MyCtrlData.device) {
                case MyCtrlData.DEVICE_LIS2DUXS12:
                    stmc_page_en = "3F 80";
                    stmc_page_dis = "3F 00";
                    PED_int_reg = "0A";
                    FSM_int_reg = "0B";
                    MLC_int_reg = "0D";
                    EMB_int_reg = "1F";
                    TAP_en_reg = "74";
                    SINGLE_TAP_bit = 5;     // single-tap bit in TAP_CFG5 register
                    DOUBLE_TAP_bit = 6;     // double-tap bit in TAP_CFG5 register
                    TRIPLE_TAP_bit = 7;     // triple-tap bit in TAP_CFG5 register
                    FREE_FALL_bit = 4;      // free-fall bit in MDx_CFG register
                    WAKE_UP_bit = 5;        // wake-up bit in MDx_CFG register
                    break;
                case MyCtrlData.DEVICE_LSM6DSOX:
                case MyCtrlData.DEVICE_LSM6DSV32X:
                    stmc_page_en = "01 80";
                    stmc_page_dis = "01 00";
                    SFLP_int_reg = "44";
                    PED_int_reg = "0A";
                    FSM_int_reg = "0B";
                    MLC_int_reg = "0D";
                    EMB_int_reg = "5E";
                    DOUBLE_TAP_bit = 3;     // double-tap bit in MDx_CFG register
                    FREE_FALL_bit = 4;      // free-fall bit in MDx_CFG register
                    WAKE_UP_bit = 5;        // wake-up bit in MDx_CFG register
                    SINGLE_TAP_bit = 6;     // single-tap bit in MDx_CFG register
                    break;
                case MyCtrlData.DEVICE_LSM6DSV16X:
                case MyCtrlData.DEVICE_LSM6DSV16BX:
                    stmc_page_en = "01 80";
                    stmc_page_dis = "01 00";
                    SFLP_int_reg = "44";
                    if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3) ||
                        (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B) ||
                        (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX))) {
                        PED_int_reg = "0E";
                        FSM_int_reg = "0F";
                        MLC_int_reg = "11";
                        EMB_int_reg = "5F";
                    } else {
                        PED_int_reg = "0A";
                        FSM_int_reg = "0B";
                        MLC_int_reg = "0D";
                        EMB_int_reg = "5E";
                    }
                    DOUBLE_TAP_bit = 3;     // double-tap bit in MDx_CFG register
                    FREE_FALL_bit = 4;      // free-fall bit in MDx_CFG register
                    WAKE_UP_bit = 5;        // wake-up bit in MDx_CFG register
                    SINGLE_TAP_bit = 6;     // single-tap bit in MDx_CFG register
                    break;
            }

            try
            {
                while ((myDataRow = myReader.readLine()) != null)
                {
                    // Make the row lowercase
                    myDataRow = myDataRow.toUpperCase();

                    // Discard empty line and comments
                    if (myDataRow.isEmpty() || myDataRow.contains("--")) {
                        continue;
                    }

                    // Valid row
                    if (myDataRow.contains("AC ") && myDataRow.length() == 8)
                    {
                        if (myDataRow.contains(stmc_page_en)) {
                            stmc_page = true;
                        }
                        else if (myDataRow.contains(stmc_page_dis))  {
                            stmc_page = false;
                        }
                        else {
                            String[] separated = myDataRow.split("\\s+"); // "\\s+" is the space
                            String regAddress = separated[1];
                            String regValue = separated[2];
                            if (stmc_page) {
                                // MLC, FSM, PED, SFLP
                                if (regAddress.equals(SFLP_int_reg))
                                    SFLP_int_regValue = regValue;
                                if (regAddress.equals(PED_int_reg))
                                    PED_int_regValue = regValue;
                                if (regAddress.equals(FSM_int_reg))
                                    FSM_int_regValue = regValue;
                                if (regAddress.equals(MLC_int_reg))
                                    MLC_int_regValue = regValue;
                            }
                            else {
                                // EMB
                                if (regAddress.equals(EMB_int_reg))
                                    EMB_int_regValue = regValue;
                                if (MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12))
                                    if (regAddress.equals(TAP_en_reg))
                                        TAP_en_regValue = regValue;
                            }
                        }
                    }
                }
                myReader.close();
            }
            catch (Exception e)
            {
                Log.d("EXCEPTION_LOAD_DEMO", "Exception during load-demo: " + e);
            }

            this.clearDemoClass();

            if (MLC_int_regValue.charAt(1) == '1')
                this.setNumberOf_MLC(1);
            else if (MLC_int_regValue.charAt(1) == '3')
                this.setNumberOf_MLC(2);
            else if (MLC_int_regValue.charAt(1) == '7')
                this.setNumberOf_MLC(3);
            else if (MLC_int_regValue.charAt(1) == 'F')
                this.setNumberOf_MLC(4);

            if (FSM_int_regValue.charAt(1) == '1')
                this.setNumberOf_FSM(1);
            else if (FSM_int_regValue.charAt(1) == '3')
                this.setNumberOf_FSM(2);
            else if (FSM_int_regValue.charAt(1) == '7')
                this.setNumberOf_FSM(3);
            else if (FSM_int_regValue.charAt(1) == 'F')
                this.setNumberOf_FSM(4);

            byte value = Byte.parseByte(EMB_int_regValue,16);
            if (MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12)) {
                byte value2 = Byte.parseByte(TAP_en_regValue,16);
                if (((value >> TAP_bit) & 1) > 0 && ((value2 >> SINGLE_TAP_bit) & 1) > 0) {
                    this.addSingleDemo(AppConfig.EMBEDDED_FUNCTION_STR, "Single-Tap", null, null, null, AppConfig.SINGLE_TAP_STR);
                }
                if (((value >> TAP_bit) & 1) > 0 && ((value2 >> DOUBLE_TAP_bit) & 1) > 0) {
                    this.addSingleDemo(AppConfig.EMBEDDED_FUNCTION_STR, "Double-Tap", null, null, null, AppConfig.DOUBLE_TAP_STR);
                }
                if (((value >> TAP_bit) & 1) > 0 && ((value2 >> TRIPLE_TAP_bit) & 1) > 0) {
                    this.addSingleDemo(AppConfig.EMBEDDED_FUNCTION_STR, "Triple-Tap", null, null, null, AppConfig.TRIPLE_TAP_STR);
                }
            } else {
                if (((value >> SINGLE_TAP_bit) & 1) > 0) {
                    this.addSingleDemo(AppConfig.EMBEDDED_FUNCTION_STR, "Single-Tap", null, null, null, AppConfig.SINGLE_TAP_STR);
                }
                if (((value >> DOUBLE_TAP_bit) & 1) > 0) {
                    this.addSingleDemo(AppConfig.EMBEDDED_FUNCTION_STR, "Double-Tap", null, null, null, AppConfig.DOUBLE_TAP_STR);
                }
            }
            if (((value >> FREE_FALL_bit) & 1) > 0) {
                this.addSingleDemo(AppConfig.EMBEDDED_FUNCTION_STR, "Free-Fall", null, null, null, AppConfig.FREE_FALL_STR);
            }
            if (((value >> WAKE_UP_bit) & 1) > 0) {
                this.addSingleDemo(AppConfig.EMBEDDED_FUNCTION_STR, "Wake-Up", null, null, null, AppConfig.WAKE_UP_STR);
            }

            if (PED_int_regValue.charAt(1) == '8')
                this.setNumberOf_PED(1);

            int SFLP_int_regValue_tmp = Integer.parseInt(SFLP_int_regValue, 16);
            if ((SFLP_int_regValue_tmp & 0x02) > 0)
                this.setNumberOf_SFLP(1);

            this.setNumberOf_LIB(0);
        }
    }
    void setJsonFileUri(Uri jsonUri) { this.DEMO_JsonUri = jsonUri; }

    String getSingleDemoOutputType(String feature, int n) {
        String defaultOutput = AppConfig.CONTINUOUS_STR;

        switch (feature)
        {
            case AppConfig.MACHINE_LEARNING_CORE_STR:
                defaultOutput = this.MLC_DEMOs.get(n).outputType;
                break;
            case AppConfig.FINITE_STATE_MACHINE_STR:
                defaultOutput = this.FSM_DEMOs.get(n).outputType;
                break;
            case AppConfig.EMBEDDED_FUNCTION_STR:
                defaultOutput = this.EMB_DEMOs.get(n).outputType;
                break;
            case AppConfig.PEDOMETER_2_0_STR:
                defaultOutput = this.PED_DEMOs.get(n).outputType;
                break;
            case AppConfig.SENSOR_FUSION_LOW_POWER_STR:
                defaultOutput = this.SFLP_DEMOs.get(n).outputType;
                break;
            case AppConfig.ISPU_STR:
                defaultOutput = this.ISPU_DEMOs.get(n).outputType;
                break;
            case AppConfig.SW_LIB_STR:
                defaultOutput = this.LIB_DEMOs.get(n).outputType;
                break;
            default:
                break;
        }
        return defaultOutput;
    }

    Integer getSingleDemoImageID(String feature, int n, byte value) {
        Integer outputImageID = R.drawable.none;
        if (this.DEMO_Name.contains(mContext.getString(R.string.tool_name_ucfloader))) {
            if (value == 0)
                outputImageID = R.drawable.none;
            else
                outputImageID = R.drawable.event;
        }
        else {
            ArrayList<Byte> values = new ArrayList<>();
            ArrayList<Integer> imageIDs = new ArrayList<>();

            switch (feature)
            {
                case AppConfig.MACHINE_LEARNING_CORE_STR:
                    values = this.MLC_DEMOs.get(n).values;
                    imageIDs = this.MLC_DEMOs.get(n).imageIDs;
                    break;
                case AppConfig.FINITE_STATE_MACHINE_STR:
                    values = this.FSM_DEMOs.get(n).values;
                    imageIDs = this.FSM_DEMOs.get(n).imageIDs;
                    break;
                case AppConfig.EMBEDDED_FUNCTION_STR:
                    values = this.EMB_DEMOs.get(n).values;
                    imageIDs = this.EMB_DEMOs.get(n).imageIDs;
                    break;
                case AppConfig.PEDOMETER_2_0_STR:
                    values = this.PED_DEMOs.get(n).values;
                    imageIDs = this.PED_DEMOs.get(n).imageIDs;
                    break;
                case AppConfig.SENSOR_FUSION_LOW_POWER_STR:
                    values = this.SFLP_DEMOs.get(n).values;
                    imageIDs = this.SFLP_DEMOs.get(n).imageIDs;
                    break;
                case AppConfig.ISPU_STR:
                    values = this.ISPU_DEMOs.get(n).values;
                    imageIDs = this.ISPU_DEMOs.get(n).imageIDs;
                    break;
                case AppConfig.SW_LIB_STR:
                    values = this.LIB_DEMOs.get(n).values;
                    imageIDs = this.LIB_DEMOs.get(n).imageIDs;
                    break;
                default:
                    break;
            }

            for(int i = 0; i < values.size(); i++) {
                if (value == values.get(i).intValue()) {
                    outputImageID = imageIDs.get(i);
                    break;
                }
            }
        }
        return outputImageID;
    }

    String getSingleDemoString(String feature, int n, byte value) {
        String outputString = String.format("0x%02x", value);
        if (this.DEMO_Name.contains(mContext.getString(R.string.tool_name_ucfloader))) {
            outputString = String.format("0x%02x", value);
        }
        else {
            ArrayList<Byte> values = new ArrayList<>();
            ArrayList<String> strings = new ArrayList<>();

            switch (feature)
            {
                case AppConfig.MACHINE_LEARNING_CORE_STR:
                    values = this.MLC_DEMOs.get(n).values;
                    strings = this.MLC_DEMOs.get(n).strings;
                    break;
                case AppConfig.FINITE_STATE_MACHINE_STR:
                    values = this.FSM_DEMOs.get(n).values;
                    strings = this.FSM_DEMOs.get(n).strings;
                    break;
                case AppConfig.EMBEDDED_FUNCTION_STR:
                    values = this.EMB_DEMOs.get(n).values;
                    strings = this.EMB_DEMOs.get(n).strings;
                    break;
                case AppConfig.PEDOMETER_2_0_STR:
                    values = this.PED_DEMOs.get(n).values;
                    strings = this.PED_DEMOs.get(n).strings;
                    break;
                case AppConfig.SENSOR_FUSION_LOW_POWER_STR:
                    values = this.SFLP_DEMOs.get(n).values;
                    strings = this.SFLP_DEMOs.get(n).strings;
                    break;
                case AppConfig.ISPU_STR:
                    values = this.ISPU_DEMOs.get(n).values;
                    strings = this.ISPU_DEMOs.get(n).strings;
                    break;
                case AppConfig.SW_LIB_STR:
                    values = this.LIB_DEMOs.get(n).values;
                    strings = this.LIB_DEMOs.get(n).strings;
                    break;
                default:
                    break;
            }

            for (int i = 0; i < values.size(); i++) {
                if (value == values.get(i).intValue()) {
                    outputString = strings.get(i);
                    break;
                }
            }
        }
        return outputString;
    }

    // Parcelling part
    private DemoClass(Parcel in)
    {
        Uri.Builder builder = new Uri.Builder();
        /*
        private String DEMO_Name = "";
        private Integer DEMO_IconID = 0;
        private String DEMO_ShortDescription = "";
        private String DEMO_OtherText = "";
        private String DEMO_Description = "";
        private String DEMO_SensorsDescription = "";
        private String DEMO_CurrentConsumption = "";
        private boolean usage_XL = false;
        private boolean usage_G = false;
        private boolean usage_Q = false;
        private boolean usage_P = false;
        private boolean usage_MLC = false;
        private boolean usage_FSM = false;
        private boolean usage_EMB = false;
        private boolean usage_PED = false;
        private boolean usage_SFLP = false;
        private boolean usage_ISPU = false;
        private boolean usage_LIB = false;
        private boolean usage_PedoMobileConfigCard = false;
        private boolean usage_PedoWristConfigCard = false;
        private boolean usage_LeftRightConfigCard = false;
        private Integer DEMO_ConfigFile_Left = 0;
        private Integer DEMO_ConfigFile_Right = 0;
        private boolean usage_RamConfigCard = false;
        private ArrayList<String> ramConfigParamNames;
        private ArrayList<Integer> ramConfigParamTypes;
        private ArrayList<Float> ramConfigParamDefaults;
        private ArrayList<List<String>> ramConfigParamRamAddresses;
        private ArrayList<String> ramConfigParamDescriptions;
        private boolean usage_LibConfigCard = false;
        private ArrayList<String> libConfigParamNames;
        private ArrayList<Integer> libConfigParamIndexes;
        private ArrayList<Float> libConfigParamValues;
        private ArrayList<String> libConfigParamDescriptions;
        private boolean usage_SDLogCard = false;
        private boolean usage_BLELogCard = false;
        private boolean usage_BLEStreamCard = false;
        private boolean usage_DemoLogCard = true;
        private boolean usage_MassStorage = false;
        private boolean usage_FusionCard = false;
        private boolean usage_UnsupervisedOdlCard = false;
        private boolean usage_InBagDetectionCard = false;
        private boolean usage_FallHeightEstimationCard = false;
        private Integer DEMO_ConfigFile = 0;
        private Integer DEMO_JsonFile = 0;
        private Uri DEMO_ConfigUri = Uri.EMPTY;
        private Uri DEMO_JsonUri = Uri.EMPTY;
        private long DEMO_StartupLatency = 0;
        private Integer DEMO_Patent = PATENT_NONE;
        private ArrayList<SingleDemoClass> FSM_DEMOs;
        private ArrayList<SingleDemoClass> MLC_DEMOs;
        private ArrayList<SingleDemoClass> EMB_DEMOs;
        private ArrayList<SingleDemoClass> PED_DEMOs;
        private ArrayList<SingleDemoClass> SFLP_DEMOs;
        private ArrayList<SingleDemoClass> ISPU_DEMOs;
        private ArrayList<SingleDemoClass> LIB_DEMOs;
        */

        // the order needs to be the same as in writeToParcel() method
        try {
            this.DEMO_Name = in.readString();
            this.DEMO_IconID = in.readInt();
            this.DEMO_ShortDescription = in.readString();
            this.DEMO_OtherText = in.readString();
            this.DEMO_Description = in.readString();
            this.DEMO_SensorsDescription = in.readString();
            this.DEMO_CurrentConsumption = in.readString();
            this.usage_XL = in.readByte() != 0;
            this.usage_G = in.readByte() != 0;
            this.usage_Q = in.readByte() != 0;
            this.usage_P = in.readByte() != 0;
            this.usage_MLC = in.readByte() != 0;
            this.usage_FSM = in.readByte() != 0;
            this.usage_EMB = in.readByte() != 0;
            this.usage_PED = in.readByte() != 0;
            this.usage_SFLP = in.readByte() != 0;
            this.usage_ISPU = in.readByte() != 0;
            this.usage_LIB = in.readByte() != 0;
            this.usage_PedoMobileConfigCard = in.readByte() != 0;
            this.usage_PedoWristConfigCard = in.readByte() != 0;
            this.usage_LeftRightConfigCard = in.readByte() != 0;
            this.DEMO_ConfigFile_Left = in.readInt();
            this.DEMO_ConfigFile_Right = in.readInt();
            this.usage_RamConfigCard = in.readByte() != 0;
            for (int i = 0; i < this.ramConfigParamNames.size(); i++) {
                this.ramConfigParamNames.add(in.readString());
            }
            for (int i = 0; i < this.ramConfigParamTypes.size(); i++) {
                this.ramConfigParamTypes.add(in.readInt());
            }
            for (int i = 0; i < this.ramConfigParamDefaults.size(); i++) {
                this.ramConfigParamDefaults.add(in.readFloat());
            }
            for (int i = 0; i < this.ramConfigParamRamAddresses.size(); i++) {
                List<String> addresses = this.ramConfigParamRamAddresses.get(i);
                for (int j = 0; j < addresses.size(); j++)
                    addresses.add(in.readString());
            }
            for (int i = 0; i < this.ramConfigParamDescriptions.size(); i++) {
                this.ramConfigParamDescriptions.add(in.readString());
            }
            this.usage_LibConfigCard = in.readByte() != 0;
            for (int i = 0; i < this.libConfigParamNames.size(); i++) {
                this.libConfigParamNames.add(in.readString());
            }
            for (int i = 0; i < this.libConfigParamIndexes.size(); i++) {
                this.libConfigParamIndexes.add(in.readInt());
            }
            for (int i = 0; i < this.libConfigParamValues.size(); i++) {
                this.libConfigParamValues.add(in.readDouble());
            }
            for (int i = 0; i < this.libConfigParamDescriptions.size(); i++) {
                this.libConfigParamDescriptions.add(in.readString());
            }
            this.usage_SDLogCard = in.readByte() != 0;
            this.usage_BLELogCard = in.readByte() != 0;
            this.usage_BLEStreamCard = in.readByte() != 0;
            this.usage_DemoLogCard = in.readByte() != 0;
            this.usage_MassStorageCard = in.readByte() != 0;
            this.usage_FusionCard = in.readByte() != 0;
            this.usage_UnsupervisedOdlCard = in.readByte() != 0;
            this.usage_InBagDetectionCard = in.readByte() != 0;
            this.usage_FallHeightEstimationCard = in.readByte() != 0;
            this.DEMO_ConfigFile = in.readInt();
            this.DEMO_JsonFile = in.readInt();
            this.DEMO_ConfigUri = builder.path(in.readString()).build();
            this.DEMO_JsonUri = builder.path(in.readString()).build();
            this.DEMO_StartupLatency = in.readLong();
            this.DEMO_Patent = in.readInt();

            /*
            public String FEATURE_Name;
            public String DEMO_Name;
            public ArrayList<Integer> values;
            public ArrayList<String> strings;
            public ArrayList<Integer> imageIDs;
             */
            for (int i = 0; i < this.FSM_DEMOs.size(); i++) {
                this.FSM_DEMOs.get(i).FEATURE_Name = in.readString();
                this.FSM_DEMOs.get(i).DEMO_Name = in.readString();
                for (int j = 0; j < this.FSM_DEMOs.get(i).values.size(); j++)
                    this.FSM_DEMOs.get(i).values.add(in.readByte());
                for (int j = 0; j < this.FSM_DEMOs.get(i).strings.size(); j++)
                    this.FSM_DEMOs.get(i).strings.add(in.readString());
                for (int j = 0; j < this.FSM_DEMOs.get(i).imageIDs.size(); j++)
                    this.FSM_DEMOs.get(i).imageIDs.add(in.readInt());
            }
            for (int i = 0; i < this.MLC_DEMOs.size(); i++) {
                this.MLC_DEMOs.get(i).FEATURE_Name = in.readString();
                this.MLC_DEMOs.get(i).DEMO_Name = in.readString();
                for (int j = 0; j < this.MLC_DEMOs.get(i).values.size(); j++)
                    this.MLC_DEMOs.get(i).values.add(in.readByte());
                for (int j = 0; j < this.MLC_DEMOs.get(i).strings.size(); j++)
                    this.MLC_DEMOs.get(i).strings.add(in.readString());
                for (int j = 0; j < this.MLC_DEMOs.get(i).imageIDs.size(); j++)
                    this.MLC_DEMOs.get(i).imageIDs.add(in.readInt());
            }
            for (int i = 0; i < this.EMB_DEMOs.size(); i++) {
                this.EMB_DEMOs.get(i).FEATURE_Name = in.readString();
                this.EMB_DEMOs.get(i).DEMO_Name = in.readString();
                for (int j = 0; j < this.EMB_DEMOs.get(i).values.size(); j++)
                    this.EMB_DEMOs.get(i).values.add(in.readByte());
                for (int j = 0; j < this.EMB_DEMOs.get(i).strings.size(); j++)
                    this.EMB_DEMOs.get(i).strings.add(in.readString());
                for (int j = 0; j < this.EMB_DEMOs.get(i).imageIDs.size(); j++)
                    this.EMB_DEMOs.get(i).imageIDs.add(in.readInt());
            }
            for (int i = 0; i < this.PED_DEMOs.size(); i++) {
                this.PED_DEMOs.get(i).FEATURE_Name = in.readString();
                this.PED_DEMOs.get(i).DEMO_Name = in.readString();
                for (int j = 0; j < this.PED_DEMOs.get(i).values.size(); j++)
                    this.PED_DEMOs.get(i).values.add(in.readByte());
                for (int j = 0; j < this.PED_DEMOs.get(i).strings.size(); j++)
                    this.PED_DEMOs.get(i).strings.add(in.readString());
                for (int j = 0; j < this.PED_DEMOs.get(i).imageIDs.size(); j++)
                    this.PED_DEMOs.get(i).imageIDs.add(in.readInt());
            }
            for (int i = 0; i < this.SFLP_DEMOs.size(); i++) {
                this.SFLP_DEMOs.get(i).FEATURE_Name = in.readString();
                this.SFLP_DEMOs.get(i).DEMO_Name = in.readString();
                for (int j = 0; j < this.SFLP_DEMOs.get(i).values.size(); j++)
                    this.SFLP_DEMOs.get(i).values.add(in.readByte());
                for (int j = 0; j < this.SFLP_DEMOs.get(i).strings.size(); j++)
                    this.SFLP_DEMOs.get(i).strings.add(in.readString());
                for (int j = 0; j < this.SFLP_DEMOs.get(i).imageIDs.size(); j++)
                    this.SFLP_DEMOs.get(i).imageIDs.add(in.readInt());
            }
            for (int i = 0; i < this.ISPU_DEMOs.size(); i++) {
                this.ISPU_DEMOs.get(i).FEATURE_Name = in.readString();
                this.ISPU_DEMOs.get(i).DEMO_Name = in.readString();
                for (int j = 0; j < this.ISPU_DEMOs.get(i).values.size(); j++)
                    this.ISPU_DEMOs.get(i).values.add(in.readByte());
                for (int j = 0; j < this.ISPU_DEMOs.get(i).strings.size(); j++)
                    this.ISPU_DEMOs.get(i).strings.add(in.readString());
                for (int j = 0; j < this.ISPU_DEMOs.get(i).imageIDs.size(); j++)
                    this.ISPU_DEMOs.get(i).imageIDs.add(in.readInt());
            }
            for (int i = 0; i < this.LIB_DEMOs.size(); i++) {
                this.LIB_DEMOs.get(i).FEATURE_Name = in.readString();
                this.LIB_DEMOs.get(i).DEMO_Name = in.readString();
                for (int j = 0; j < this.LIB_DEMOs.get(i).values.size(); j++)
                    this.LIB_DEMOs.get(i).values.add(in.readByte());
                for (int j = 0; j < this.LIB_DEMOs.get(i).strings.size(); j++)
                    this.LIB_DEMOs.get(i).strings.add(in.readString());
                for (int j = 0; j < this.LIB_DEMOs.get(i).imageIDs.size(); j++)
                    this.LIB_DEMOs.get(i).imageIDs.add(in.readInt());
            }
        }
        catch (Exception e) { e.printStackTrace(); }
    }

    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        /*
        private String DEMO_Name = "";
        private Integer DEMO_IconID = 0;
        private String DEMO_ShortDescription = "";
        private String DEMO_OtherText = "";
        private String DEMO_Description = "";
        private String DEMO_SensorsDescription = "";
        private String DEMO_CurrentConsumption = "";
        private boolean usage_XL = false;
        private boolean usage_G = false;
        private boolean usage_Q = false;
        private boolean usage_P = false;
        private boolean usage_MLC = false;
        private boolean usage_FSM = false;
        private boolean usage_EMB = false;
        private boolean usage_PED = false;
        private boolean usage_SFLP = false;
        private boolean usage_ISPU = false;
        private boolean usage_LIB = false;
        private boolean usage_PedoMobileConfigCard = false;
        private boolean usage_PedoWristConfigCard = false;
        private boolean usage_LeftRightConfigCard = false;
        private Integer DEMO_ConfigFile_Left = 0;
        private Integer DEMO_ConfigFile_Right = 0;
        private boolean usage_RamConfigCard = false;
        private ArrayList<String> ramConfigParamNames;
        private ArrayList<Integer> ramConfigParamTypes;
        private ArrayList<Float> ramConfigParamDefaults;
        private ArrayList<List<String>> ramConfigParamRamAddresses;
        private ArrayList<String> ramConfigParamDescriptions;
        private boolean usage_LibConfigCard = false;
        private ArrayList<String> libConfigParamNames;
        private ArrayList<Integer> libConfigParamIndexes;
        private ArrayList<Float> libConfigParamValues;
        private ArrayList<String> libConfigParamDescriptions;
        private boolean usage_SDLogCard = false;
        private boolean usage_BLELogCard = false;
        private boolean usage_BLEStreamCard = false;
        private boolean usage_DemoLogCard = true;
        private boolean usage_MassStorage = false;
        private boolean usage_FusionCard = false;
        private boolean usage_UnsupervisedOdlCard = false;
        private boolean usage_InBagDetectionCard = false;
        private boolean usage_FallHeightEstimationCard = false;
        private Integer DEMO_ConfigFile = 0;
        private Integer DEMO_JsonFile = 0;
        private Uri DEMO_ConfigUri = Uri.EMPTY;
        private Uri DEMO_JsonUri = Uri.EMPTY;
        private long DEMO_StartupLatency = 0;
        private Integer DEMO_Patent = PATENT_NONE;
        private ArrayList<SingleDemoClass> FSM_DEMOs;
        private ArrayList<SingleDemoClass> MLC_DEMOs;
        private ArrayList<SingleDemoClass> EMB_DEMOs;
        private ArrayList<SingleDemoClass> PED_DEMOs;
        private ArrayList<SingleDemoClass> SFLP_DEMOs;
        private ArrayList<SingleDemoClass> ISPU_DEMOs;
        private ArrayList<SingleDemoClass> LIB_DEMOs;
        */
        try {
            dest.writeString(DEMO_Name);
            dest.writeInt(DEMO_IconID);
            dest.writeString(DEMO_ShortDescription);
            dest.writeString(DEMO_OtherText);
            dest.writeString(DEMO_Description);
            dest.writeString(DEMO_SensorsDescription);
            dest.writeString(DEMO_CurrentConsumption);
            dest.writeByte((byte) (usage_XL ? 1 : 0));
            dest.writeByte((byte) (usage_G ? 1 : 0));
            dest.writeByte((byte) (usage_Q ? 1 : 0));
            dest.writeByte((byte) (usage_P ? 1 : 0));
            dest.writeByte((byte) (usage_MLC ? 1 : 0));
            dest.writeByte((byte) (usage_FSM ? 1 : 0));
            dest.writeByte((byte) (usage_EMB ? 1 : 0));
            dest.writeByte((byte) (usage_PED ? 1 : 0));
            dest.writeByte((byte) (usage_SFLP ? 1 : 0));
            dest.writeByte((byte) (usage_ISPU ? 1 : 0));
            dest.writeByte((byte) (usage_LIB ? 1 : 0));
            dest.writeByte((byte) (usage_PedoMobileConfigCard ? 1 : 0));
            dest.writeByte((byte) (usage_PedoWristConfigCard ? 1 : 0));
            dest.writeByte((byte) (usage_LeftRightConfigCard ? 1 : 0));
            dest.writeInt(DEMO_ConfigFile_Left);
            dest.writeInt(DEMO_ConfigFile_Right);
            dest.writeByte((byte) (usage_RamConfigCard ? 1 : 0));
            for (int i = 0; i < this.ramConfigParamNames.size(); i++) {
                dest.writeString(this.ramConfigParamNames.get(i));
            }
            for (int i = 0; i < this.ramConfigParamTypes.size(); i++) {
                dest.writeInt(this.ramConfigParamTypes.get(i));
            }
            for (int i = 0; i < this.ramConfigParamDefaults.size(); i++) {
                dest.writeFloat(this.ramConfigParamDefaults.get(i));
            }
            for (int i = 0; i < this.ramConfigParamRamAddresses.size(); i++) {
                List<String> addresses = this.ramConfigParamRamAddresses.get(i);
                for (int j = 0; j < addresses.size(); j++)
                    dest.writeString(addresses.get(j));
            }
            for (int i = 0; i < this.ramConfigParamDescriptions.size(); i++) {
                dest.writeString(this.ramConfigParamDescriptions.get(i));
            }
            dest.writeByte((byte) (usage_LibConfigCard ? 1 : 0));
            for (int i = 0; i < this.libConfigParamNames.size(); i++) {
                dest.writeString(this.libConfigParamNames.get(i));
            }
            for (int i = 0; i < this.libConfigParamIndexes.size(); i++) {
                dest.writeInt(this.libConfigParamIndexes.get(i));
            }
            for (int i = 0; i < this.libConfigParamValues.size(); i++) {
                dest.writeDouble(this.libConfigParamValues.get(i));
            }
            for (int i = 0; i < this.libConfigParamDescriptions.size(); i++) {
                dest.writeString(this.libConfigParamDescriptions.get(i));
            }
            dest.writeByte((byte) (usage_SDLogCard ? 1 : 0));
            dest.writeByte((byte) (usage_BLELogCard ? 1 : 0));
            dest.writeByte((byte) (usage_BLEStreamCard ? 1 : 0));
            dest.writeByte((byte) (usage_DemoLogCard ? 1 : 0));
            dest.writeByte((byte) (usage_MassStorageCard ? 1 : 0));
            dest.writeByte((byte) (usage_FusionCard ? 1 : 0));
            dest.writeByte((byte) (usage_UnsupervisedOdlCard ? 1 : 0));
            dest.writeByte((byte) (usage_InBagDetectionCard ? 1 : 0));
            dest.writeByte((byte) (usage_FallHeightEstimationCard ? 1 : 0));
            dest.writeInt(DEMO_ConfigFile);
            dest.writeInt(DEMO_JsonFile);
            dest.writeString(DEMO_ConfigUri.toString());
            dest.writeString(DEMO_JsonUri.toString());
            dest.writeLong(DEMO_StartupLatency);
            dest.writeInt(DEMO_Patent);

            /*
            public String FEATURE_Name;
            public String DEMO_Name;
            public ArrayList<Integer> values;
            public ArrayList<String> strings;
            public ArrayList<Integer> imageIDs;
             */
            for (int i = 0; i < this.FSM_DEMOs.size(); i++) {
                dest.writeString(this.FSM_DEMOs.get(i).FEATURE_Name);
                dest.writeString(this.FSM_DEMOs.get(i).DEMO_Name);
                for (int j = 0; j < this.FSM_DEMOs.get(i).values.size(); j++)
                    dest.writeInt(this.FSM_DEMOs.get(i).values.get(j));
                for (int j = 0; j < this.FSM_DEMOs.get(i).strings.size(); j++)
                    dest.writeString(this.FSM_DEMOs.get(i).strings.get(j));
                for (int j = 0; j < this.FSM_DEMOs.get(i).imageIDs.size(); j++)
                    dest.writeInt(this.FSM_DEMOs.get(i).imageIDs.get(j));
            }
            for (int i = 0; i < this.MLC_DEMOs.size(); i++) {
                dest.writeString(this.MLC_DEMOs.get(i).FEATURE_Name);
                dest.writeString(this.MLC_DEMOs.get(i).DEMO_Name);
                for (int j = 0; j < this.MLC_DEMOs.get(i).values.size(); j++)
                    dest.writeInt(this.MLC_DEMOs.get(i).values.get(j));
                for (int j = 0; j < this.MLC_DEMOs.get(i).strings.size(); j++)
                    dest.writeString(this.MLC_DEMOs.get(i).strings.get(j));
                for (int j = 0; j < this.MLC_DEMOs.get(i).imageIDs.size(); j++)
                    dest.writeInt(this.MLC_DEMOs.get(i).imageIDs.get(j));
            }
            for (int i = 0; i < this.EMB_DEMOs.size(); i++) {
                dest.writeString(this.EMB_DEMOs.get(i).FEATURE_Name);
                dest.writeString(this.EMB_DEMOs.get(i).DEMO_Name);
                for (int j = 0; j < this.EMB_DEMOs.get(i).values.size(); j++)
                    dest.writeInt(this.EMB_DEMOs.get(i).values.get(j));
                for (int j = 0; j < this.EMB_DEMOs.get(i).strings.size(); j++)
                    dest.writeString(this.EMB_DEMOs.get(i).strings.get(j));
                for (int j = 0; j < this.EMB_DEMOs.get(i).imageIDs.size(); j++)
                    dest.writeInt(this.EMB_DEMOs.get(i).imageIDs.get(j));
            }
            for (int i = 0; i < this.PED_DEMOs.size(); i++) {
                dest.writeString(this.PED_DEMOs.get(i).FEATURE_Name);
                dest.writeString(this.PED_DEMOs.get(i).DEMO_Name);
                for (int j = 0; j < this.PED_DEMOs.get(i).values.size(); j++)
                    dest.writeInt(this.PED_DEMOs.get(i).values.get(j));
                for (int j = 0; j < this.PED_DEMOs.get(i).strings.size(); j++)
                    dest.writeString(this.PED_DEMOs.get(i).strings.get(j));
                for (int j = 0; j < this.PED_DEMOs.get(i).imageIDs.size(); j++)
                    dest.writeInt(this.PED_DEMOs.get(i).imageIDs.get(j));
            }
            for (int i = 0; i < this.SFLP_DEMOs.size(); i++) {
                dest.writeString(this.SFLP_DEMOs.get(i).FEATURE_Name);
                dest.writeString(this.SFLP_DEMOs.get(i).DEMO_Name);
                for (int j = 0; j < this.SFLP_DEMOs.get(i).values.size(); j++)
                    dest.writeInt(this.SFLP_DEMOs.get(i).values.get(j));
                for (int j = 0; j < this.SFLP_DEMOs.get(i).strings.size(); j++)
                    dest.writeString(this.SFLP_DEMOs.get(i).strings.get(j));
                for (int j = 0; j < this.SFLP_DEMOs.get(i).imageIDs.size(); j++)
                    dest.writeInt(this.SFLP_DEMOs.get(i).imageIDs.get(j));
            }
            for (int i = 0; i < this.ISPU_DEMOs.size(); i++) {
                dest.writeString(this.ISPU_DEMOs.get(i).FEATURE_Name);
                dest.writeString(this.ISPU_DEMOs.get(i).DEMO_Name);
                for (int j = 0; j < this.ISPU_DEMOs.get(i).values.size(); j++)
                    dest.writeInt(this.ISPU_DEMOs.get(i).values.get(j));
                for (int j = 0; j < this.ISPU_DEMOs.get(i).strings.size(); j++)
                    dest.writeString(this.ISPU_DEMOs.get(i).strings.get(j));
                for (int j = 0; j < this.ISPU_DEMOs.get(i).imageIDs.size(); j++)
                    dest.writeInt(this.ISPU_DEMOs.get(i).imageIDs.get(j));
            }
            for (int i = 0; i < this.LIB_DEMOs.size(); i++) {
                dest.writeString(this.LIB_DEMOs.get(i).FEATURE_Name);
                dest.writeString(this.LIB_DEMOs.get(i).DEMO_Name);
                for (int j = 0; j < this.LIB_DEMOs.get(i).values.size(); j++)
                    dest.writeInt(this.LIB_DEMOs.get(i).values.get(j));
                for (int j = 0; j < this.LIB_DEMOs.get(i).strings.size(); j++)
                    dest.writeString(this.LIB_DEMOs.get(i).strings.get(j));
                for (int j = 0; j < this.LIB_DEMOs.get(i).imageIDs.size(); j++)
                    dest.writeInt(this.LIB_DEMOs.get(i).imageIDs.get(j));
            }
        }
        catch (Exception e) { e.printStackTrace(); }
    }
    public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public DemoClass createFromParcel(Parcel in) {
            return new DemoClass(in);
        }

        public DemoClass[] newArray(int size) {
            return new DemoClass[size];
        }
    };
}


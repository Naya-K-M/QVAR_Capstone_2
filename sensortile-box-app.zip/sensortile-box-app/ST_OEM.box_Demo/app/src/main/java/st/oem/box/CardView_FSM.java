package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;

import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_FSM extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private LinearLayout[] mFsmLinearLayout = new LinearLayout[4];
    private TextView[] mFsmTitleTextView = new TextView[4];
    private ImageView[] mFsmImageView = new ImageView[4];
    private TextView[] mFsmDataTextView = new TextView[4];
    private SwitchCompat[] mFsmLedSwitchCompat = new SwitchCompat[4];
    private LinearLayout[] mFsmLedLinearLayout = new LinearLayout[4];
    private SwitchCompat[] mFsmBuzSwitchCompat = new SwitchCompat[4];
    private LinearLayout[] mFsmBuzLinearLayout = new LinearLayout[4];
    private MyCountDownTimer[] mFsmTimer = new MyCountDownTimer[4];

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    // State
    private final static boolean[] mFsmLedSwitchCompatState = new boolean[4];
    private final static boolean[] mFsmBuzSwitchCompatState = new boolean[4];
    private final static String[] mFsmDataTextViewString = new String[4];
    private final static Integer[] mFsmImageViewResource = new Integer[4];

    public void saveState()
    {
        for (int i = 0; i < 4; i++)
        {
            try {
                mFsmLedSwitchCompatState[i] = mFsmLedSwitchCompat[i].isChecked();
            } catch(Exception ignored) { }

            try {
                mFsmBuzSwitchCompatState[i] = mFsmBuzSwitchCompat[i].isChecked();
            } catch(Exception ignored) { }

            try {
                String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, i);
                if (outputType.equals(AppConfig.CONTINUOUS_STR))
                {
                    mFsmImageViewResource[i] = (Integer)mFsmImageView[i].getTag();
                }
            } catch(Exception ignored) { }

            try {
                String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, i);
                if (outputType.equals(AppConfig.CONTINUOUS_STR))
                {
                    mFsmDataTextViewString[i] = mFsmDataTextView[i].getText().toString();
                }
            } catch(Exception ignored) { }
        }
    }

    public void restoreState()
    {
        for (int i = 0; i < 4; i++)
        {
            try {
                mFsmLedSwitchCompat[i].setChecked(mFsmLedSwitchCompatState[i]);
            } catch(Exception ignored) { }

            try {
                mFsmBuzSwitchCompat[i].setChecked(mFsmBuzSwitchCompatState[i]);
            } catch(Exception ignored) { }

            try {
                String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, i);
                if (outputType.equals(AppConfig.CONTINUOUS_STR))
                {
                    mFsmImageView[i].setImageResource(mFsmImageViewResource[i]);
                    mFsmImageView[i].setTag(mFsmImageViewResource[i]);
                }
            } catch(Exception ignored) { }

            try {
                String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, i);
                if (outputType.equals(AppConfig.CONTINUOUS_STR))
                {
                    mFsmDataTextView[i].setText(mFsmDataTextViewString[i]);
                }
            } catch(Exception ignored) { }
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_FSM_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mFsmLinearLayout = null;
        mFsmTitleTextView = null;
        mFsmImageView = null;
        mFsmDataTextView = null;
        mFsmLedSwitchCompat = null;
        mFsmLedLinearLayout = null;
        mFsmBuzSwitchCompat = null;
        mFsmBuzLinearLayout = null;
        mFsmTimer = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_FSM(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(getContext());
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_fsm, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mFsmLinearLayout[0] = mMainLayout.findViewById(R.id.fsm0LinearLayout);
        mFsmTitleTextView[0] = mMainLayout.findViewById(R.id.fsm0TitleTextView);
        mFsmImageView[0] = mMainLayout.findViewById(R.id.fsm0ImageView);
        mFsmImageView[0].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mFsmDataTextView[0] = mMainLayout.findViewById(R.id.fsm0DataTextView);

        mFsmLinearLayout[1] = mMainLayout.findViewById(R.id.fsm1LinearLayout);
        mFsmTitleTextView[1] = mMainLayout.findViewById(R.id.fsm1TitleTextView);
        mFsmImageView[1] = mMainLayout.findViewById(R.id.fsm1ImageView);
        mFsmImageView[1].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mFsmDataTextView[1] = mMainLayout.findViewById(R.id.fsm1DataTextView);

        mFsmLinearLayout[2] = mMainLayout.findViewById(R.id.fsm2LinearLayout);
        mFsmTitleTextView[2] = mMainLayout.findViewById(R.id.fsm2TitleTextView);
        mFsmImageView[2] = mMainLayout.findViewById(R.id.fsm2ImageView);
        mFsmImageView[2].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mFsmDataTextView[2] = mMainLayout.findViewById(R.id.fsm2DataTextView);

        mFsmLinearLayout[3] = mMainLayout.findViewById(R.id.fsm3LinearLayout);
        mFsmTitleTextView[3] = mMainLayout.findViewById(R.id.fsm3TitleTextView);
        mFsmImageView[3] = mMainLayout.findViewById(R.id.fsm3ImageView);
        mFsmImageView[3].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mFsmDataTextView[3] = mMainLayout.findViewById(R.id.fsm3DataTextView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        if (MyCtrlData.isLedSupported())
        {
            mFsmLedSwitchCompat[0] = mMainLayout.findViewById(R.id.fsmLed0SwitchCompat);
            mFsmLedSwitchCompat[1] = mMainLayout.findViewById(R.id.fsmLed1SwitchCompat);
            mFsmLedSwitchCompat[2] = mMainLayout.findViewById(R.id.fsmLed2SwitchCompat);
            mFsmLedSwitchCompat[3] = mMainLayout.findViewById(R.id.fsmLed3SwitchCompat);
            for(int j = 0; j < 4; j++)
            {
                final int k = j;
                mFsmLedSwitchCompat[j].setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
                {
                    if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                        if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                            if (b) {
                                if (DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, 0).contains(AppConfig.MULTIPLE_OUTPUTS_STR)) {
                                    DemoFragment.getInstance().fsm_ledMask = (byte) 0xFF;
                                } else {
                                    DemoFragment.getInstance().fsm_ledMask = (byte) (DemoFragment.getInstance().fsm_ledMask | (1 << k));
                                }
                            }
                            else {
                                if (DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, 0).contains(AppConfig.MULTIPLE_OUTPUTS_STR)) {
                                    DemoFragment.getInstance().fsm_ledMask = 0x00;
                                } else {
                                    DemoFragment.getInstance().fsm_ledMask = (byte) (DemoFragment.getInstance().fsm_ledMask & (~(1 << k)));
                                }
                            }

                            DemoFragment.getInstance().prepareAndSendLedMask();
                        } else {
                            mFsmLedSwitchCompat[k].setChecked(!b);
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        mFsmLedSwitchCompat[k].setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            mFsmLedLinearLayout[0] = mMainLayout.findViewById(R.id.fsmLed0LinearLayout);
            mFsmLedLinearLayout[1] = mMainLayout.findViewById(R.id.fsmLed1LinearLayout);
            mFsmLedLinearLayout[2] = mMainLayout.findViewById(R.id.fsmLed2LinearLayout);
            mFsmLedLinearLayout[3] = mMainLayout.findViewById(R.id.fsmLed3LinearLayout);
            for (int i = 0; i < 4; i++) {
                mFsmLedLinearLayout[i].setVisibility(GONE);
            }
        }

        if (MyCtrlData.isBuzSupported())
        {
            mFsmBuzSwitchCompat[0] = mMainLayout.findViewById(R.id.fsmBuz0SwitchCompat);
            mFsmBuzSwitchCompat[1] = mMainLayout.findViewById(R.id.fsmBuz1SwitchCompat);
            mFsmBuzSwitchCompat[2] = mMainLayout.findViewById(R.id.fsmBuz2SwitchCompat);
            mFsmBuzSwitchCompat[3] = mMainLayout.findViewById(R.id.fsmBuz3SwitchCompat);
            for(int j = 0; j < 4; j++)
            {
                final int k = j;
                mFsmBuzSwitchCompat[j].setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
                {
                    if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                        if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                            if (b) {
                                if (DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, 0).contains(AppConfig.MULTIPLE_OUTPUTS_STR)) {
                                    DemoFragment.getInstance().fsm_buzMask = (byte) 0xFF;
                                } else {
                                    DemoFragment.getInstance().fsm_buzMask = (byte) (DemoFragment.getInstance().fsm_buzMask | (1 << k));
                                }
                            }
                            else {
                                if (DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, 0).contains(AppConfig.MULTIPLE_OUTPUTS_STR)) {
                                    DemoFragment.getInstance().fsm_buzMask = 0x00;
                                } else {
                                    DemoFragment.getInstance().fsm_buzMask = (byte) (DemoFragment.getInstance().fsm_buzMask & (~(1 << k)));
                                }
                            }

                            DemoFragment.getInstance().prepareAndSendBuzMask();
                        } else {
                            mFsmBuzSwitchCompat[k].setChecked(!b);
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        mFsmBuzSwitchCompat[k].setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            mFsmBuzLinearLayout[0] = mMainLayout.findViewById(R.id.fsmBuz0LinearLayout);
            mFsmBuzLinearLayout[1] = mMainLayout.findViewById(R.id.fsmBuz1LinearLayout);
            mFsmBuzLinearLayout[2] = mMainLayout.findViewById(R.id.fsmBuz2LinearLayout);
            mFsmBuzLinearLayout[3] = mMainLayout.findViewById(R.id.fsmBuz3LinearLayout);
            for (int i = 0; i < 4; i++) {
                mFsmBuzLinearLayout[i].setVisibility(GONE);
            }
        }

        // Manage layouts
        float screenDensity = getResources().getDisplayMetrics().density;
        if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_FSM() == 1) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_1) / screenDensity;
            mFsmTitleTextView[0].setTextSize(textSize);
            mFsmTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 0));
            mFsmDataTextView[0].setTextSize(textSize);
            mFsmLinearLayout[1].setVisibility(View.GONE);
            mFsmLinearLayout[2].setVisibility(View.GONE);
            mFsmLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_FSM() == 2) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_2) / screenDensity;
            mFsmTitleTextView[0].setTextSize(textSize);
            mFsmTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 0));
            mFsmDataTextView[0].setTextSize(textSize);
            mFsmTitleTextView[1].setTextSize(textSize);
            mFsmTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 1));
            mFsmDataTextView[1].setTextSize(textSize);
            mFsmLinearLayout[2].setVisibility(View.GONE);
            mFsmLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_FSM() == 3) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_3) / screenDensity;
            mFsmTitleTextView[0].setTextSize(textSize);
            mFsmTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 0));
            mFsmDataTextView[0].setTextSize(textSize);
            mFsmTitleTextView[1].setTextSize(textSize);
            mFsmTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 1));
            mFsmDataTextView[1].setTextSize(textSize);
            mFsmTitleTextView[2].setTextSize(textSize);
            mFsmTitleTextView[2].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 2));
            mFsmDataTextView[2].setTextSize(textSize);
            mFsmLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_FSM() == 4) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_3) / screenDensity;
            mFsmTitleTextView[0].setTextSize(textSize);
            mFsmTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 0));
            mFsmDataTextView[0].setTextSize(textSize);
            mFsmTitleTextView[1].setTextSize(textSize);
            mFsmTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 1));
            mFsmDataTextView[1].setTextSize(textSize);
            mFsmTitleTextView[2].setTextSize(textSize);
            mFsmTitleTextView[2].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 2));
            mFsmDataTextView[2].setTextSize(textSize);
            mFsmTitleTextView[3].setTextSize(textSize);
            mFsmTitleTextView[3].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.FINITE_STATE_MACHINE_STR, 3));
            mFsmDataTextView[3].setTextSize(textSize);
        }

        MyMotionData.fsm = 0;
        for (int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_FSM(); i++) {
            MyMotionData.fsm_outs[i] = 0;
            mFsmImageView[i].setImageResource(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, i, MyMotionData.fsm_outs[i]));
            mFsmImageView[i].setTag(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, i, MyMotionData.fsm_outs[i]));
            mFsmDataTextView[i].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.FINITE_STATE_MACHINE_STR, i, MyMotionData.fsm_outs[i]));
        }
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyMotionData.fsm > 0) {
                    for (int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_FSM(); i++) {
                        ImageView imageView;
                        Integer imageViewResource_EVENT, imageViewResource_IDLE;
                        TextView textView;
                        String textViewString_EVENT, textViewString_IDLE;
                        String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.FINITE_STATE_MACHINE_STR, i);
                        if (outputType.contains(AppConfig.MULTIPLE_OUTPUTS_STR)) {
                            imageView = mFsmImageView[0];
                            imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, 0, AppConfig.EVENT);
                            imageViewResource_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, 0, AppConfig.IDLE);
                            textView = mFsmDataTextView[0];
                            textViewString_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.FINITE_STATE_MACHINE_STR, 0, AppConfig.EVENT);
                            textViewString_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.FINITE_STATE_MACHINE_STR, 0, AppConfig.IDLE);
                            mFsmImageView[0].setImageResource(imageViewResource_EVENT);
                            mFsmImageView[0].setTag(imageViewResource_EVENT);
                            mFsmDataTextView[0].setText(textViewString_EVENT);
                            if (mFsmTimer[0] != null) {
                                mFsmTimer[0].cancel();
                            }
                            mFsmTimer[0] = new MyCountDownTimer(1000, imageView, imageViewResource_IDLE, textView, textViewString_IDLE);
                            mFsmTimer[0].start();
                            DemoFragment.getInstance().addEventToCardEvent(textViewString_EVENT);
                        } else {
                            if (MyMotionData.getBit(MyMotionData.fsm, i)) {
                                switch (outputType) {
                                    case AppConfig.CONTINUOUS_STR:
                                        imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, i, MyMotionData.fsm_outs[i]);
                                        textViewString_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.FINITE_STATE_MACHINE_STR, i, MyMotionData.fsm_outs[i]);
                                        mFsmImageView[i].setImageResource(imageViewResource_EVENT);
                                        mFsmImageView[i].setTag(imageViewResource_EVENT);
                                        mFsmDataTextView[i].setText(textViewString_EVENT);
                                        DemoFragment.getInstance().addEventToCardEvent(textViewString_EVENT);
                                        break;
                                    case AppConfig.EVENT_BASED_STR:
                                        imageView = mFsmImageView[i];
                                        imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, i, AppConfig.EVENT);
                                        imageViewResource_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, i, AppConfig.IDLE);
                                        textView = mFsmDataTextView[i];
                                        textViewString_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.FINITE_STATE_MACHINE_STR, i, AppConfig.EVENT);
                                        textViewString_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.FINITE_STATE_MACHINE_STR, i, AppConfig.IDLE);
                                        mFsmImageView[i].setImageResource(imageViewResource_EVENT);
                                        mFsmImageView[i].setTag(imageViewResource_EVENT);
                                        mFsmDataTextView[i].setText(textViewString_EVENT);
                                        if (mFsmTimer[i] != null) {
                                            mFsmTimer[i].cancel();
                                        }
                                        mFsmTimer[i] = new MyCountDownTimer(1000, imageView, imageViewResource_IDLE, textView, textViewString_IDLE);
                                        mFsmTimer[i].start();
                                        DemoFragment.getInstance().addEventToCardEvent(textViewString_EVENT);
                                        break;
                                    case AppConfig.MANY_EVENT_BASED_STR:
                                        imageView = mFsmImageView[i];
                                        imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, i, MyMotionData.fsm_outs[i]);
                                        imageViewResource_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.FINITE_STATE_MACHINE_STR, i, AppConfig.IDLE);
                                        textView = mFsmDataTextView[i];
                                        textViewString_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.FINITE_STATE_MACHINE_STR, i, MyMotionData.fsm_outs[i]);
                                        textViewString_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.FINITE_STATE_MACHINE_STR, i, AppConfig.IDLE);
                                        mFsmImageView[i].setImageResource(imageViewResource_EVENT);
                                        mFsmImageView[i].setTag(imageViewResource_EVENT);
                                        mFsmDataTextView[i].setText(textViewString_EVENT);
                                        if (mFsmTimer[i] != null) {
                                            mFsmTimer[i].cancel();
                                        }
                                        mFsmTimer[i] = new MyCountDownTimer(1000, imageView, imageViewResource_IDLE, textView, textViewString_IDLE);
                                        mFsmTimer[i].start();
                                        DemoFragment.getInstance().addEventToCardEvent(textViewString_EVENT);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                    MyMotionData.fsm = 0;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

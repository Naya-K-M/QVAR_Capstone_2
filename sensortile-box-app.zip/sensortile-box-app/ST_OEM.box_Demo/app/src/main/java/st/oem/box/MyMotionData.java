package st.oem.box;

import java.nio.ByteBuffer;
import java.util.Arrays;

public class MyMotionData {
    public static int HW_FREE_FALL_BIT = 0;
    public static int HW_WAKE_UP_BIT = 1;
    public static int HW_TAP_SINGLE_BIT = 2;
    public static int HW_TAP_DOUBLE_BIT = 3;
    public static int HW_TAP_TRIPLE_BIT = 4;

    static public volatile byte fsm;
    static public volatile byte[] fsm_outs = new byte[4];
    static public volatile byte mlc;
    static public volatile byte[] mlc_src = new byte[4];
    static public volatile short steps;
    static public volatile byte hw_int;
    static public volatile byte emb_func_status;
    static public volatile short lib_data;
    static public volatile short lc;
    static public volatile byte all_int;
    static public volatile byte reserved;   // only for padding
    static public volatile float[] quat = new float[4];
    static public volatile short[] gravity = new short[3];
    static public volatile short[] gbias = new short[3];

    static public volatile ByteBuffer ispu_dout;
    static public volatile byte ispu_new_packet;
    static public volatile byte ispu_new_packet2;

    static public boolean getBit(byte value, int position)
    {
        return (((value >> position) & 1) > 0);
    }

    public static void resetData()
    {
        fsm = 0;
        mlc = 0;
        steps = 0;
        hw_int = 0;
        emb_func_status = 0;
        lib_data = 0;
        lc = 0;
        all_int = 0;
        reserved = 0;

        Arrays.fill(fsm_outs, (byte)0);
        Arrays.fill(mlc_src, (byte)0);
        Arrays.fill(quat, (float)0);
        Arrays.fill(gravity, (short)0);
        Arrays.fill(gbias, (short)0);

        ispu_new_packet = 0;
        ispu_new_packet2 = 0;
    }
}

package st.oem.box;

public interface BluetoothDeviceAdapterCallback {
    void onDeviceSelected(BluetoothDeviceObject device);
    void onDeviceInfoRequested(BluetoothDeviceObject deviceObject);
}

package st.oem.box;

import java.util.ArrayList;

/**
 * Created by s rivolta on 4/12/2018.
 */

public class SingleDemoClass {

    // Data
    public String FEATURE_Name;
    public String DEMO_Name;
    public ArrayList<Byte> values;       // For event-based, 0 is "idle", 1 is "event"
    public ArrayList<String> strings;
    public ArrayList<Integer> imageIDs;

    // it can be EVENT-BASED or CONTINUOUS:
    // if EVENT-BASED
    // - values/strings/imageIDs[0] are referred to IDLE
    // - values/strings/imageIDs[1] are referred to EVENT
    // if CONTINUOUS it searches the corresponding output
    public String outputType;

    // Constructor
    public SingleDemoClass(String featureName, String demoName) {
        FEATURE_Name = featureName;
        DEMO_Name = demoName;
        values = new ArrayList<>();
        strings = new ArrayList<>();
        imageIDs = new ArrayList<>();
    }

    public void clearSingleDemo() {
        values.clear();
        strings.clear();
        imageIDs.clear();
    }

    public String getFeatureName() {
        return FEATURE_Name;
    }

    public void addValuesStringsImagesRelationship(byte value, String string, Integer imageID) {
        values.add(value);
        strings.add(string);
        imageIDs.add(imageID);
    }

    public void setOutputType(String type) {
        outputType = type;
    }

    public String getOutputType() {
        return outputType;
    }

    public Integer getCurrentImageID(Integer value) {
        for(int i = 0; i < values.size(); i++) {
            if (value == values.get(i).intValue()) {
                return imageIDs.get(i);
            }
        }
        return 0;
    }

    public String getCurrentString(Integer value) {
        for(int i = 0; i < values.size(); i++) {
            if (value == values.get(i).intValue()) {
                return strings.get(i);
            }
        }
        return "";
    }
}


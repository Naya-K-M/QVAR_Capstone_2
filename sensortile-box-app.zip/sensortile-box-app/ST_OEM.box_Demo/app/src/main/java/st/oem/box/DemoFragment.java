package st.oem.box;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Objects;
import java.util.zip.GZIPOutputStream;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

public class DemoFragment extends Fragment
{
    private final static String LOG_TAG = DemoFragment.class.getSimpleName();
    public static final int LOAD_FROM_RES = 0;
    private static final int LOAD_FROM_URI = 1;

    private static DemoFragment instance;
    public ProgressDialog mProgressDialog;
    private boolean mConfigurationOngoing;
    public volatile int mConfBytesSent;
    public volatile int mConfBytesTotal;

    // Demo variables
    private final DemoClass mSelectedDemo;
    private final int mLoadFrom;
    private boolean mIsTool;
    private LinearLayout mMainLinearLayout;
    private FrameLayout mFrameLayout;
    private ViewGroup mViewGroup;

    // Led masks
    public byte mlc_ledMask = 0;
    public byte fsm_ledMask = 0;
    public byte emb_ledMask = 0;
    public byte ped_ledMask = 0;
    public byte lib_ledMask = 0;

    // Buz masks
    public byte mlc_buzMask = 0;
    public byte fsm_buzMask = 0;
    public byte emb_buzMask = 0;
    public byte ped_buzMask = 0;
    public byte lib_buzMask = 0;

    // Card views
    private CardView_EVENTS cardView_EVENTS;
    private CardView_QUATERNIONS cardView_QUATERNIONS;
    private CardView_SFLP cardView_SFLP;

    public DemoClass getSelectedDemo() {
        return mSelectedDemo;
    }

    DemoFragment(DemoClass selectedDemo, int loadFrom)
    {
        mSelectedDemo = selectedDemo;
        mLoadFrom = loadFrom;
    }

    public static DemoFragment getInstance(DemoClass selectedDemo, int loadFrom) {
        if (instance == null) {
            instance = new DemoFragment(selectedDemo, loadFrom);
        }
        return instance;
    }

    public static DemoFragment getInstance() {
        return instance;
    }

    public static void destroyInstance()
    {
        instance = null;
    }

    public boolean getConfigurationOngoing()
    {
        return mConfigurationOngoing;
    }

    public void addEventToCardEvent(String name)
    {
        if (cardView_EVENTS != null)
            cardView_EVENTS.addEvent(name);
    }

    public void applyRotationToQuaternionCard(float qx, float qy, float qz, float qw)
    {
        if (cardView_QUATERNIONS != null)
            cardView_QUATERNIONS.applyRotation(qx, qy, qz, qw);

        if (cardView_SFLP != null)
            cardView_SFLP.applyRotation(qx, qy, qz, qw);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(LOG_TAG, "onCreate");

        // Always send empty led and buz mask
        fsm_ledMask = 0;
        mlc_ledMask = 0;
        emb_ledMask = 0;
        ped_ledMask = 0;
        lib_ledMask = 0;
        prepareAndSendLedMask();
        fsm_buzMask = 0;
        mlc_buzMask = 0;
        emb_buzMask = 0;
        ped_buzMask = 0;
        lib_buzMask = 0;
        prepareAndSendBuzMask();

        // Check if the selected card is a tool
        mIsTool = mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_sensors_sd_log));
        mIsTool |= mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_sensors_ble_log));
        mIsTool |= mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_mass_storage));

        // Send configuration
        if (!mIsTool) {
            loadDeviceConfiguration(mSelectedDemo.getConfigurationFileResource());
        } else {
            // Send mass storage
            if (mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_mass_storage))) {
                BLECommands.sendSetMassStorageOn(getContext());
            }
        }
    }

    private View populateView(View view)
    {
        // Get layout to be populated with cards
        mMainLinearLayout = view.findViewById(R.id.mainLinearLayout);

        // Set demo name
        TextView demoNameTextView = view.findViewById(R.id.demoNameTextView);
        demoNameTextView.setText(mSelectedDemo.getDemoName());

        // Populate UI based on the required cards
        if (mSelectedDemo.getNumberOf_MLC() > 0) {
            CardView_MLC cardView_MLC = new CardView_MLC(getContext());
            mMainLinearLayout.addView(cardView_MLC);
        }

        if (mSelectedDemo.getNumberOf_FSM() > 0) {
            CardView_FSM cardView_FSM = new CardView_FSM(getContext());
            mMainLinearLayout.addView(cardView_FSM);
        }

        if (mSelectedDemo.getNumberOf_EMB() > 0) {
            CardView_EMB cardView_EMB = new CardView_EMB(getContext());
            mMainLinearLayout.addView(cardView_EMB);
        }

        if (mSelectedDemo.getNumberOf_PED() > 0) {
            CardView_PED cardView_PED = new CardView_PED(getContext());
            mMainLinearLayout.addView(cardView_PED);
        }

        if (mSelectedDemo.getNumberOf_SFLP() > 0) {
            cardView_SFLP = new CardView_SFLP(getContext());
            mMainLinearLayout.addView(cardView_SFLP);
        }

        if (mSelectedDemo.getNumberOf_LIB() > 0) {
            CardView_LIB cardView_LIB = new CardView_LIB(getContext());
            mMainLinearLayout.addView(cardView_LIB);
        }

        if (mSelectedDemo.getNumberOf_ISPU() > 0) {
            CardView_ISPU cardView_ISPU = new CardView_ISPU(getContext());
            mMainLinearLayout.addView(cardView_ISPU);
        }

        if (mSelectedDemo.getDemoUsage_FusionCard()) {
            cardView_QUATERNIONS = new CardView_QUATERNIONS(getContext());
            mMainLinearLayout.addView(cardView_QUATERNIONS);
        }

        if (mSelectedDemo.getDemoUsage_UnsupervisedOdlCard()) {
            CardView_UNSUPERVISED_ODL cardView_UNSUPERVISED_ODL = new CardView_UNSUPERVISED_ODL(getContext());
            mMainLinearLayout.addView(cardView_UNSUPERVISED_ODL);
        }

        if (mSelectedDemo.getDemoUsage_InBagDetectionCard()) {
            CardView_IN_BAG_DETECTION cardView_IN_BAG_DETECTION = new CardView_IN_BAG_DETECTION(getContext());
            mMainLinearLayout.addView(cardView_IN_BAG_DETECTION);
        }

        if (mSelectedDemo.getDemoUsage_FallHeightEstimationCard()) {
            CardView_FALL_HEIGHT_ESTIMATION cardView_FALL_HEIGHT_ESTIMATION = new CardView_FALL_HEIGHT_ESTIMATION(getContext());
            mMainLinearLayout.addView(cardView_FALL_HEIGHT_ESTIMATION);
        }

        if (mSelectedDemo.getDemoUsage_PedoMobileConfigCard()) {
            CardView_PEDO_MOBILE_CONFIG cardView_PEDO_MOBILE_CONFIG = new CardView_PEDO_MOBILE_CONFIG(getContext());
            mMainLinearLayout.addView(cardView_PEDO_MOBILE_CONFIG);
        }

        if (mSelectedDemo.getDemoUsage_PedoWristConfigCard()) {
            CardView_PEDO_WRIST_CONFIG cardView_PEDO_WRIST_CONFIG = new CardView_PEDO_WRIST_CONFIG(getContext());
            mMainLinearLayout.addView(cardView_PEDO_WRIST_CONFIG);
        }

        if (mSelectedDemo.getDemoUsage_LeftRightConfigCard()) {
            CardView_LEFT_RIGHT_CONFIG cardView_LEFT_RIGHT_CONFIG = new CardView_LEFT_RIGHT_CONFIG(getContext());
            mMainLinearLayout.addView(cardView_LEFT_RIGHT_CONFIG);
        }

        if (mSelectedDemo.getDemoUsage_RamConfigCard() && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            CardView_RAM_CONFIG cardView_RAM_CONFIG = new CardView_RAM_CONFIG(getContext());
            mMainLinearLayout.addView(cardView_RAM_CONFIG);
        }

        if (mSelectedDemo.getDemoUsage_LibConfigCard()) {
            CardView_LIB_CONFIG cardView_LIB_CONFIG = new CardView_LIB_CONFIG(getContext());
            mMainLinearLayout.addView(cardView_LIB_CONFIG);
        }

        // Description card
        CardView_DESCRIPTION cardView_DESCRIPTION = new CardView_DESCRIPTION(getContext());
        mMainLinearLayout.addView(cardView_DESCRIPTION);

        // SD-Log (from tools) card
        if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSOX))) {
            if (mSelectedDemo.getDemoUsage_SDLogCard()) {
                CardView_SENSORS_SD_LOG_SENSORTILEBOX_SUWON25 cardView_SENSORS_SD_LOGSENSORTILEBOX_SUWON25 = new CardView_SENSORS_SD_LOG_SENSORTILEBOX_SUWON25(getContext());
                mMainLinearLayout.addView(cardView_SENSORS_SD_LOGSENSORTILEBOX_SUWON25);
            }
        }
        else if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS))) {
            if (mSelectedDemo.getDemoUsage_SDLogCard()) {
                CardView_SENSORS_SD_LOG_SENSORTILEBOX_SUNCHON cardView_SENSORS_SD_LOGSENSORTILEBOX_SUNCHON = new CardView_SENSORS_SD_LOG_SENSORTILEBOX_SUNCHON(getContext());
                mMainLinearLayout.addView(cardView_SENSORS_SD_LOGSENSORTILEBOX_SUNCHON);
            }
        }
        else if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12))) {
            if (mSelectedDemo.getDemoUsage_SDLogCard()) {
                CardView_SENSORS_SD_LOG_SENSORTILEBOX_PRO_LIS2DUXS12 cardView_SENSORS_SD_LOG_SENSORTILEBOX_PRO_LIS2DUXS12 = new CardView_SENSORS_SD_LOG_SENSORTILEBOX_PRO_LIS2DUXS12(getContext());
                mMainLinearLayout.addView(cardView_SENSORS_SD_LOG_SENSORTILEBOX_PRO_LIS2DUXS12);
            }
        }

        // BLE-Log (from tools) card
        switch(MyCtrlData.board_id)
        {
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                if (mSelectedDemo.getDemoUsage_BLELogCard()) {
                    CardView_SENSORS_BLE_LOG_SENSORTILEBOX_SUWON25 cardView_SENSORS_BLE_LOG_SENSORTILEBOX_SUWON25 = new CardView_SENSORS_BLE_LOG_SENSORTILEBOX_SUWON25(getContext());
                    mMainLinearLayout.addView(cardView_SENSORS_BLE_LOG_SENSORTILEBOX_SUWON25);
                }
                break;
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                if (mSelectedDemo.getDemoUsage_BLELogCard()) {
                    CardView_SENSORS_BLE_LOG_TWSBOX_SWAN3 cardView_SENSORS_BLE_LOG_TWSBOX_SWAN3 = new CardView_SENSORS_BLE_LOG_TWSBOX_SWAN3(getContext());
                    mMainLinearLayout.addView(cardView_SENSORS_BLE_LOG_TWSBOX_SWAN3);
                }
                break;
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                if (mSelectedDemo.getDemoUsage_BLELogCard()) {
                    CardView_SENSORS_BLE_LOG_TWSBOX_SWAN3B cardView_SENSORS_BLE_LOG_TWSBOX_SWAN3B = new CardView_SENSORS_BLE_LOG_TWSBOX_SWAN3B(getContext());
                    mMainLinearLayout.addView(cardView_SENSORS_BLE_LOG_TWSBOX_SWAN3B);
                }
                break;
            default:
                break;
        }

        if (mSelectedDemo.getDemoUsage_BLEStreamCard()) {
            CardView_BLE_STREAM cardView_BLE_STREAM = new CardView_BLE_STREAM(getContext());
            mMainLinearLayout.addView(cardView_BLE_STREAM);
        }

        // Log (from a demo) card
        if (ContainerFragment.appConfig.DEMO_SD_LOG_EN == 1) {
            if (!mIsTool && mSelectedDemo.getDemoUsage_DemoLogCard()) {
                CardView_DEMO_SD_LOG cardView_DEMO_SD_LOG = new CardView_DEMO_SD_LOG(getContext());
                mMainLinearLayout.addView(cardView_DEMO_SD_LOG);
            }
        }

        // Events card (keep as last)
        cardView_EVENTS = null;
        boolean eventsCard = MySharedPreferences.getInstance(getContext()).getEventsCard();
        if (eventsCard) {
            if (!mIsTool) {
                cardView_EVENTS = new CardView_EVENTS(getContext());
                mMainLinearLayout.addView(cardView_EVENTS);
            }
        }

        return view;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(LOG_TAG, "onCreateView");

        mViewGroup = container;
        mFrameLayout = new FrameLayout(getContext());
        //LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.fragment_demo, mViewGroup, false);
        mFrameLayout.addView(populateView(view));

        return mFrameLayout;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(LOG_TAG, "onViewCreated");

        MyMotionData.resetData();
    }

    private void parseJson() {
        InputStream inputStream = null;
        if (mLoadFrom == LOAD_FROM_RES && mSelectedDemo.getJsonFileResource() != 0) {
            inputStream = getContext().getResources().openRawResource(mSelectedDemo.getJsonFileResource());
        }
        else if (mLoadFrom == LOAD_FROM_URI && mSelectedDemo.getJsonFileUri() != null) {
            try {
                inputStream = getContext().getContentResolver().openInputStream(mSelectedDemo.getJsonFileUri());
            } catch (FileNotFoundException e) {
                e.printStackTrace();
                return;
            }
        }
        assert inputStream != null;
        String jsonString = readTextFile(inputStream);

        // this will get you the entire JSON node
        JSONObject object = null;
        try {
            object = new JSONObject(jsonString);
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }

        // put in whatever your JSON data name here, this will get you an array of all the nodes
        JSONArray array = null;
        try {
            assert object != null;
            array = object.getJSONArray("output");
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }

        int byteIndex = 0;
        int nOutputs = Objects.requireNonNull(array).length();
        for(int i = 0; i < nOutputs; i++)
        {
            JSONObject output = null;
            try {
                output = array.getJSONObject(i);
            } catch (JSONException e) {
                e.printStackTrace();
                return;
            }

            String name = "", type = "";
            try {
                assert output != null;
                name = output.getString("name");
                type = output.getString("type");
            } catch (JSONException e) {
                e.printStackTrace();
                return;
            }

            MyJson.addMappedOutput(name, type, byteIndex);
            byteIndex += MyJson.getOutputTypeSize(type);
        }
    }

    private static final Integer mProgressBarLock = 0;

    private void progressBarWait() {
        synchronized (mProgressBarLock) {
            try {
                Log.d(LOG_TAG, "mProgressBarLock: WAIT");
                mProgressBarLock.wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void progressBarNotify() {
        synchronized (mProgressBarLock) {
            Log.d(LOG_TAG, "mProgressBarLock: NOTIFY");
            mProgressBarLock.notify();
        }
    }

    private void startProgressBarUpdate() {

        ((Activity) getContext()).runOnUiThread(() ->
        {
            mMainLinearLayout.setVisibility(View.INVISIBLE);

            mProgressDialog = new ProgressDialog(getContext());
            mProgressDialog.setTitle(getContext().getString(R.string.progress_loading_title));
            mProgressDialog.setMessage(getContext().getString(R.string.progress_demo_loading_message));
            mProgressDialog.setCancelable(false);
            mProgressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            mProgressDialog.setIndeterminate(false);
            mProgressDialog.setProgressNumberFormat(null);
            mProgressDialog.show();
        });

        new Thread() {
            @Override
            public void run() {
                super.run();

                progressBarWait();  // wait for mConfBytesTotal computation

                ((Activity) getContext()).runOnUiThread(() ->
                {
                    mProgressDialog.setMax(mConfBytesTotal);
                });

                do {
                    ((Activity) getContext()).runOnUiThread(() ->
                    {
                        mProgressDialog.setProgress(mConfBytesSent);
                    });
                    progressBarWait();
                } while (mConfBytesSent < mConfBytesTotal);

                try {
                    Thread.sleep(mSelectedDemo.getDemoStartupLatency());
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt(); // restore interrupted status
                    e.printStackTrace();
                }

                ((Activity) getContext()).runOnUiThread(() ->
                {
                    mProgressDialog.dismiss();
                    mProgressDialog = null;
                    mMainLinearLayout.setVisibility(View.VISIBLE);
                });

                mConfBytesSent = 0;
                mConfBytesTotal = 0;
                mConfigurationOngoing = false;
            }
        }.start();
    }

    public void loadDeviceConfiguration(Integer configFileRes) {

        if (ContainerFragment.appConfig.SEND_ZIP_CONFIG_EN == 0)
            loadDeviceConfiguration_STD(configFileRes);
        else
            loadDeviceConfiguration_ZIP(configFileRes);
    }

    private void loadDeviceConfiguration_STD(final Integer configFileRes) {

        mConfigurationOngoing = true;

        if (MyCtrlData.conf == 1)
            BLECommands.sendResetDeviceConfiguration(getContext());

        new Thread() {
            @Override
            public void run() {
                super.run();

                try {
                    int packetLength = BluetoothLeService.mSupportedPacketLength;
                    String myDataRow, myDataRow_len;
                    byte[] config = new byte[packetLength];

                    // Open file
                    InputStream inputStream = null;
                    InputStream inputStream_len = null;
                    if (mLoadFrom == LOAD_FROM_RES) {
                        inputStream = getContext().getResources().openRawResource(configFileRes);
                        inputStream_len = getContext().getResources().openRawResource(configFileRes);
                    } else if (mLoadFrom == LOAD_FROM_URI) {
                        try {
                            inputStream = getContext().getContentResolver().openInputStream(mSelectedDemo.getConfigurationFileUri());
                            inputStream_len = getContext().getContentResolver().openInputStream(mSelectedDemo.getConfigurationFileUri());
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                    assert inputStream != null;
                    BufferedReader myReader = new BufferedReader(new InputStreamReader(inputStream));
                    assert inputStream_len != null;
                    BufferedReader myReader_len = new BufferedReader(new InputStreamReader(inputStream_len));

                    myDataRow = myReader.readLine();
                    if (myDataRow.charAt(0) == '*') {
                        BLECommands.sendGenericCommand(getContext(), myDataRow);
                        mConfigurationOngoing = false;
                    } else {

                        startProgressBarUpdate();

                        // Send json file if ISPU
                        if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                            (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS))) {
                            MyJson.clearMappedOutput();
                            BLECommands.sendJsonReset(getContext());

                            parseJson();

                            for (int i = 0; i < MyJson.getMappedOutputLength(); i++) {
                                String type = MyJson.getOutputType(i);
                                String label = MyJson.getOutputLabel(i);
                                BLECommands.sendJsonEntry(getContext(), type, 1, label);
                            }
                        }

                        // File length to handle progress bar
                        int nRows = 0;
                        try {
                            while ((myDataRow_len = myReader_len.readLine()) != null) {

                                // Make the row lowercase
                                myDataRow_len = myDataRow_len.toUpperCase();

                                if (myDataRow_len.contains("AC ") && myDataRow_len.length() == 8)
                                    nRows++;
                            }
                            myReader_len.close();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        mConfBytesSent = 0;
                        mConfBytesTotal = 2 * nRows;
                        progressBarNotify();    // Unlock progress bar to update the maximum value

                        config[0] = '*';
                        config[1] = 'b';
                        config[2] = 'i';
                        config[3] = 'n';
                        int i = 4;
                        int byteToSend = 0;

                        while (myDataRow != null) {

                            // Discard empty line and comments
                            if (myDataRow.isEmpty() || myDataRow.contains("--")) {
                                myDataRow = myReader.readLine();
                                continue;
                            }

                            // Make the row lowercase
                            myDataRow = myDataRow.toUpperCase();

                            if (myDataRow.contains(getContext().getString(R.string.wait_lowercase_string)) || myDataRow.contains(getContext().getString(R.string.wait_uppercase_string)))  // WAIT = 50 ms
                            {
                                if (byteToSend > 0) {
                                    i = 4;

                                    BLECommands.sendDeviceConfiguration(getContext(), config);
                                    for (int j = 4; j < packetLength; j++)
                                        config[j] = 0x00;

                                    byteToSend = 0;
                                }

                                String[] separated = myDataRow.split("\\s+"); // "\\s+" is the space
                                String wait = separated[1];
                                try {
                                    Thread.sleep(Integer.parseInt(wait));
                                } catch (InterruptedException e) {
                                    Thread.currentThread().interrupt(); // restore interrupted status
                                    e.printStackTrace();
                                }
                            } else if (myDataRow.contains("AC ") && myDataRow.length() == 8) {
                                String[] separated = myDataRow.split("\\s+"); // "\\s+" is the space

                                String regAddress = separated[1];
                                String regValue = separated[2];

                                config[i] = (byte) Integer.parseInt(regAddress, 16);
                                i++;
                                byteToSend++;
                                config[i] = (byte) Integer.parseInt(regValue, 16);
                                i++;
                                byteToSend++;
                            }

                            if (byteToSend == packetLength - 4) {
                                i = 4;
                                BLECommands.sendDeviceConfiguration(getContext(), config);
                                for (int j = 4; j < packetLength; j++)
                                    config[j] = 0x00;

                                byteToSend = 0;
                            }

                            myDataRow = myReader.readLine();
                        }

                        if (byteToSend > 0) {
                            BLECommands.sendDeviceConfiguration(getContext(), config);
                        }
                    }

                    if (mSelectedDemo.getDemoName().equals("3D Spatial Audio")) {
                        BLECommands.sendBleStart(getContext());
                    }

                    myReader.close();
                }  catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    private void loadDeviceConfiguration_ZIP(final Integer configFileRes) {

        mConfigurationOngoing = true;

        if (MyCtrlData.conf == 1)
            BLECommands.sendResetDeviceConfiguration(getContext());

        new Thread() {
            @Override
            public void run() {
                super.run();

                try {
                    int packetLength = BluetoothLeService.mSupportedPacketLength;
                    String myDataRow;
                    byte[] config = new byte[packetLength];

                    // Open file
                    InputStream inputStream = null;
                    if (mLoadFrom == LOAD_FROM_RES) {
                        inputStream = getContext().getResources().openRawResource(configFileRes);
                    } else if (mLoadFrom == LOAD_FROM_URI) {
                        try {
                            inputStream = getContext().getContentResolver().openInputStream(mSelectedDemo.getConfigurationFileUri());
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                    }
                    assert inputStream != null;
                    BufferedReader myReader = new BufferedReader(new InputStreamReader(inputStream));

                    myDataRow = myReader.readLine();
                    if (myDataRow.charAt(0) == '*') {
                        BLECommands.sendGenericCommand(getContext(), myDataRow);
                        mConfigurationOngoing = false;
                    } else {

                        startProgressBarUpdate();

                        // Send json file if ISPU
                        if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS))) {
                            MyJson.clearMappedOutput();
                            BLECommands.sendJsonReset(getContext());

                            parseJson();

                            for (int i = 0; i < MyJson.getMappedOutputLength(); i++) {
                                String type = MyJson.getOutputType(i);
                                String label = MyJson.getOutputLabel(i);
                                BLECommands.sendJsonEntry(getContext(), type, 1, label);
                            }
                        }

                        ArrayList<Byte> dataToCompress_tmp = new ArrayList<>();

                        while (myDataRow != null) {

                            // Discard empty line and comments
                            if (myDataRow.isEmpty() || myDataRow.contains("--")) {
                                myDataRow = myReader.readLine();
                                continue;
                            }

                            // Make the row lowercase
                            myDataRow = myDataRow.toUpperCase();

                            // Parse line
                            if (myDataRow.contains(getContext().getString(R.string.wait_lowercase_string)) || myDataRow.contains(getContext().getString(R.string.wait_uppercase_string)))  // WAIT = 50 ms
                            {
                                String[] separated = myDataRow.split("\\s+"); // "\\s+" is the space
                                String wait = separated[1];
                                short wait_ms = Short.parseShort(wait, 10);
                                byte[] wait_ms_bytes = ByteBuffer.allocate(2).putShort(wait_ms).array();

                                byte cmd = 1;
                                dataToCompress_tmp.add(cmd);                 // comp command wait
                                dataToCompress_tmp.add(wait_ms_bytes[1]);    // comp wait LSB
                                dataToCompress_tmp.add(wait_ms_bytes[0]);    // comp wait MSB
                            } else if (myDataRow.contains("AC ") && myDataRow.length() == 8) {
                                String[] separated = myDataRow.split("\\s+"); // "\\s+" is the space
                                String regAddress = separated[1];
                                String regValue = separated[2];

                                byte cmd = 0;
                                dataToCompress_tmp.add(cmd);                                             // comp command write
                                dataToCompress_tmp.add((byte) Integer.parseInt(regAddress, 16));    // comp address
                                dataToCompress_tmp.add((byte) Integer.parseInt(regValue, 16));      // comp value
                            }

                            myDataRow = myReader.readLine();
                        }

                        // Convert ArrayList<Byte> into byte[]
                        byte[] dataToCompress = new byte[dataToCompress_tmp.size()];
                        for (int j = 0; j < dataToCompress_tmp.size(); j++) {
                            dataToCompress[j] = dataToCompress_tmp.get(j);
                        }

                        // Compress data
                        ByteArrayOutputStream byteStream = new ByteArrayOutputStream(dataToCompress.length);
                        try {
                            try (GZIPOutputStream zipStream = new GZIPOutputStream(byteStream)) {
                                zipStream.write(dataToCompress);
                            }
                        } finally {
                            byteStream.close();
                        }
                        byte[] compressedData = byteStream.toByteArray();

                        // Send compressed data length
                        BLECommands.sendZipSize(getContext(), String.valueOf(compressedData.length));
                        mConfBytesSent = 0;
                        mConfBytesTotal = compressedData.length;
                        progressBarNotify();

                        // Send compressed data
                        config[0] = '*';
                        config[1] = 'z';
                        config[2] = 'i';
                        config[3] = 'p';
                        int k = 4;
                        for (byte compressedDatum : compressedData) {
                            config[k] = compressedDatum;
                            k++;
                            if (k == packetLength) {
                                BLECommands.sendDeviceConfiguration(getContext(), config);
                                k = 4;
                            }
                        }

                        // Send remaining bytes
                        if (k > 4) {
                            BLECommands.sendDeviceConfiguration(getContext(), config);
                        }

                        // Send zip decompress
                        BLECommands.sendZipDecompress(getContext());

                        myReader.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(LOG_TAG, "onDestroy");

        if (mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_mass_storage)))
        {
            BLECommands.sendSetMassStorageOff(getContext());
        }
        else
        {
            // TODO: to check how to handle the TWS.box which seems not sending the *conf
            //if (MyCtrlData.conf == 1 && MyCtrlData.sd_log == 0 && MyCtrlData.ble_log == 0) {
            //    BLECommands.sendResetDeviceConfiguration(getContext());
            //}
            if (MyCtrlData.sd_log == 0 && MyCtrlData.ble_log == 0) {
                BLECommands.sendResetDeviceConfiguration(getContext());
            }
        }

        mMainLinearLayout.removeAllViews();
        mMainLinearLayout = null;
        mFrameLayout.removeAllViews();
        mFrameLayout = null;
    }

    // Converts the input stream into a String
    public static String readTextFile(InputStream inputStream) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        byte[] buf = new byte[16384];
        int len;
        try {
            while ((len = inputStream.read(buf)) != -1) {
                outputStream.write(buf, 0, len);
            }
            outputStream.close();
            inputStream.close();
        } catch (IOException ignored) {

        }
        return outputStream.toString();
    }

    public void prepareAndSendLedMask()
    {
        if (MyCtrlData.isLedSupported())
        {
            String ledMask = String.format("%02X%02X%02X%02X%02X", fsm_ledMask, mlc_ledMask, emb_ledMask, ped_ledMask, lib_ledMask);

            BLECommands.sendSetLedMask(getContext(), ledMask);
        }
    }

    public void prepareAndSendBuzMask()
    {
        if (MyCtrlData.isBuzSupported())
        {
            String buzMask = String.format("%02X%02X%02X%02X%02X", fsm_buzMask, mlc_buzMask, emb_buzMask, ped_buzMask, lib_buzMask);

            BLECommands.sendSetBuzMask(getContext(), buzMask);
        }
    }

    private static void recursivelySaveState(View view) {
        if (view instanceof CardView_FSM) {
            ((CardView_FSM)view).saveState();
        } else if (view instanceof CardView_MLC) {
            ((CardView_MLC)view).saveState();
        } else if (view instanceof CardView_PED) {
            ((CardView_PED)view).saveState();
        } else if (view instanceof CardView_SFLP) {
            ((CardView_SFLP)view).saveState();
        } else if (view instanceof CardView_PEDO_MOBILE_CONFIG) {
            ((CardView_PEDO_MOBILE_CONFIG)view).saveState();
        } else if (view instanceof CardView_PEDO_WRIST_CONFIG) {
            ((CardView_PEDO_WRIST_CONFIG)view).saveState();
        } else if (view instanceof CardView_LEFT_RIGHT_CONFIG) {
            ((CardView_LEFT_RIGHT_CONFIG)view).saveState();
        } else if (view instanceof CardView_LIB) {
            ((CardView_LIB)view).saveState();
        } else if (view instanceof CardView_QUATERNIONS) {
            ((CardView_QUATERNIONS)view).saveState();
        } else if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup)view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                recursivelySaveState(viewGroup.getChildAt(i));
            }
        }
    }

    private static void recursivelyRestoreState(View view) {
        if (view instanceof CardView_FSM) {
            ((CardView_FSM)view).restoreState();
        } else if (view instanceof CardView_MLC) {
            ((CardView_MLC)view).restoreState();
        } else if (view instanceof CardView_PED) {
            ((CardView_PED)view).restoreState();
        } else if (view instanceof CardView_SFLP) {
            ((CardView_SFLP)view).restoreState();
        } else if (view instanceof CardView_PEDO_MOBILE_CONFIG) {
            ((CardView_PEDO_MOBILE_CONFIG)view).restoreState();
        } else if (view instanceof CardView_PEDO_WRIST_CONFIG) {
            ((CardView_PEDO_WRIST_CONFIG)view).restoreState();
        } else if (view instanceof CardView_LEFT_RIGHT_CONFIG) {
            ((CardView_LEFT_RIGHT_CONFIG)view).restoreState();
        } else if (view instanceof CardView_LIB) {
            ((CardView_LIB)view).restoreState();
        } else if (view instanceof CardView_QUATERNIONS) {
            ((CardView_QUATERNIONS)view).restoreState();
        } else if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup)view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                recursivelyRestoreState(viewGroup.getChildAt(i));
            }
        }
    }

    // TODO: check if there is a better way to handle this
    public boolean mBlindSettings;

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        recursivelySaveState(mFrameLayout);

        mFrameLayout.removeAllViews();
        LayoutInflater layoutInflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View newView = layoutInflater.inflate(R.layout.fragment_demo, mViewGroup, false);
        mBlindSettings = true;
        mFrameLayout.addView(populateView(newView));
        mBlindSettings = false;
        mMainLinearLayout.setVisibility(View.VISIBLE);

        recursivelyRestoreState(mFrameLayout);
    }
}
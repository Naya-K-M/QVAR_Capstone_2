package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_SENSORS_BLE_LOG_SENSORTILEBOX_SUWON25 extends CardView {

    private LinearLayout lsm6dsoxAccelConfigLinearLayout;
    private TextView lsm6dsoxAccelConfigTextView;
    private TextView lsm6dsoxAccelOdrTextView;
    private TextView lsm6dsoxAccelFullScaleTextView;
    private TextView lsm6dsoxAccelPowerModeTextView;
    private Spinner lsm6dsoxAccelOdrSpinner;
    private Spinner lsm6dsoxAccelFullScaleSpinner;
    private Spinner lsm6dsoxAccelPowerModeSpinner;
    private LinearLayout lsm6dsoxGyroConfigLinearLayout;
    private TextView lsm6dsoxGyroConfigTextView;
    private TextView lsm6dsoxGyroOdrTextView;
    private TextView lsm6dsoxGyroFullScaleTextView;
    private TextView lsm6dsoxGyroPowerModeTextView;
    private Spinner lsm6dsoxGyroOdrSpinner;
    private Spinner lsm6dsoxGyroFullScaleSpinner;
    private Spinner lsm6dsoxGyroPowerModeSpinner;
    private LinearLayout lps22hhPressConfigLinearLayout;
    private TextView lps22hhPressConfigTextView;
    private TextView lps22hhPressOdrTextView;
    private TextView lps22hhPressLPFTextView;
    private TextView lps22hhPressPowerModeTextView;
    private Spinner lps22hhPressOdrSpinner;
    private Spinner lps22hhPressLPFSpinner;
    private Spinner lps22hhPressPowerModeSpinner;
    private LinearLayout filenameLinearLayout;
    private EditText filenameEditText;
    private TextView loggingTextView;
    private Button startStopBleLogButton;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    // SensorTile.box devices
    private boolean lsm6dsox_xl_pd = true;
    private boolean lsm6dsox_g_pd = true;
    private boolean lps22hh_p_pd = true;
    private boolean lsm6dsox_g_disabled = false;
    private int lsm6dsox_reg_10 = 0x00;
    private int lsm6dsox_reg_11 = 0x00;
    private int lsm6dsox_reg_14 = 0x00;
    private int lsm6dsox_reg_15 = 0x00;
    private int lsm6dsox_reg_16 = 0x00;
    private int lps22hh_reg_10 = 0x00;
    private int lps22hh_reg_11 = 0x00;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_SENSORS_LOG_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        lsm6dsoxAccelConfigLinearLayout = null;
        lsm6dsoxAccelConfigTextView = null;
        lsm6dsoxAccelOdrTextView = null;
        lsm6dsoxAccelFullScaleTextView = null;
        lsm6dsoxAccelPowerModeTextView = null;
        lsm6dsoxAccelOdrSpinner = null;
        lsm6dsoxAccelFullScaleSpinner = null;
        lsm6dsoxAccelPowerModeSpinner = null;
        lsm6dsoxGyroConfigLinearLayout = null;
        lsm6dsoxGyroConfigTextView = null;
        lsm6dsoxGyroOdrTextView = null;
        lsm6dsoxGyroFullScaleTextView = null;
        lsm6dsoxGyroPowerModeTextView = null;
        lsm6dsoxGyroOdrSpinner = null;
        lsm6dsoxGyroFullScaleSpinner = null;
        lsm6dsoxGyroPowerModeSpinner = null;
        lps22hhPressConfigLinearLayout = null;
        lps22hhPressConfigTextView = null;
        lps22hhPressOdrTextView = null;
        lps22hhPressLPFTextView = null;
        lps22hhPressPowerModeTextView = null;
        lps22hhPressOdrSpinner = null;
        lps22hhPressLPFSpinner = null;
        lps22hhPressPowerModeSpinner = null;
        filenameLinearLayout = null;
        filenameEditText = null;
        loggingTextView = null;
        startStopBleLogButton = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_SENSORS_BLE_LOG_SENSORTILEBOX_SUWON25(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_sensors_ble_log_sensortilebox_suwon25, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        lsm6dsox_xl_pd = true;
        lsm6dsox_g_pd = true;
        lps22hh_p_pd = true;
        lsm6dsox_g_disabled = false;
        lsm6dsox_reg_10 = 0x00;
        lsm6dsox_reg_11 = 0x00;
        lsm6dsox_reg_14 = 0x00;
        lsm6dsox_reg_15 = 0x00;
        lsm6dsox_reg_16 = 0x00;
        lps22hh_reg_10 = 0x00;
        lps22hh_reg_11 = 0x00;

        lsm6dsoxAccelConfigTextView = mMainLayout.findViewById(R.id.lsm6dsoxAccelConfigTextView);
        lsm6dsoxAccelOdrTextView = mMainLayout.findViewById(R.id.lsm6dsoxAccelOdrTextView);
        lsm6dsoxAccelFullScaleTextView = mMainLayout.findViewById(R.id.lsm6dsoxAccelFullScaleTextView);
        lsm6dsoxAccelPowerModeTextView = mMainLayout.findViewById(R.id.lsm6dsoxAccelPowerModeTextView);
        lsm6dsoxAccelOdrSpinner = mMainLayout.findViewById(R.id.lsm6dsoxAccelOdrSpinner);
        lsm6dsoxAccelFullScaleSpinner = mMainLayout.findViewById(R.id.lsm6dsoxAccelFullScaleSpinner);
        lsm6dsoxAccelPowerModeSpinner = mMainLayout.findViewById(R.id.lsm6dsoxAccelPowerModeSpinner);

        lsm6dsoxGyroConfigTextView = mMainLayout.findViewById(R.id.lsm6dsoxGyroConfigTextView);
        lsm6dsoxGyroOdrTextView = mMainLayout.findViewById(R.id.lsm6dsoxGyroOdrTextView);
        lsm6dsoxGyroFullScaleTextView = mMainLayout.findViewById(R.id.lsm6dsoxGyroFullScaleTextView);
        lsm6dsoxGyroPowerModeTextView = mMainLayout.findViewById(R.id.lsm6dsoxGyroPowerModeTextView);
        lsm6dsoxGyroOdrSpinner = mMainLayout.findViewById(R.id.lsm6dsoxGyroOdrSpinner);
        lsm6dsoxGyroFullScaleSpinner = mMainLayout.findViewById(R.id.lsm6dsoxGyroFullScaleSpinner);
        lsm6dsoxGyroPowerModeSpinner = mMainLayout.findViewById(R.id.lsm6dsoxGyroPowerModeSpinner);

        lps22hhPressConfigTextView = mMainLayout.findViewById(R.id.lps22hhPressConfigTextView);
        lps22hhPressOdrTextView = mMainLayout.findViewById(R.id.lps22hhPressOdrTextView);
        lps22hhPressLPFTextView = mMainLayout.findViewById(R.id.lps22hhPressLPFTextView);
        lps22hhPressPowerModeTextView = mMainLayout.findViewById(R.id.lps22hhPressPowerModeTextView);
        lps22hhPressOdrSpinner = mMainLayout.findViewById(R.id.lps22hhPressOdrSpinner);
        lps22hhPressLPFSpinner = mMainLayout.findViewById(R.id.lps22hhPressLPFSpinner);
        lps22hhPressPowerModeSpinner = mMainLayout.findViewById(R.id.lps22hhPressPowerModeSpinner);

        lsm6dsoxAccelOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsox_reg_10 &= 0x0F;
                lsm6dsox_reg_10 |= (position << 4);
                lsm6dsox_xl_pd = !(position > 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsoxAccelFullScaleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsox_reg_10 &= 0xF3;
                if (position == 0) // 2g
                    lsm6dsox_reg_10 |= 0x00;
                else if (position == 1) // 4g
                    lsm6dsox_reg_10 |= 0x08;
                else if (position == 2) // 8g
                    lsm6dsox_reg_10 |= 0x0C;
                else if (position == 3) // 16g
                    lsm6dsox_reg_10 |= 0x04;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsoxAccelPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) { // HP
                    lsm6dsox_reg_14 = 0x00;
                    lsm6dsox_reg_15 = 0x00;
                    lsm6dsoxGyroConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsoxGyroOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsoxGyroFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsoxGyroPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsoxGyroOdrSpinner.setEnabled(true);
                    lsm6dsoxGyroFullScaleSpinner.setEnabled(true);
                    lsm6dsoxGyroPowerModeSpinner.setEnabled(true);
                    lsm6dsox_g_disabled = false;
                } else if (position == 1) { // LP
                    lsm6dsox_reg_14 = 0x00;
                    lsm6dsox_reg_15 = 0x10;
                    lsm6dsoxGyroConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsoxGyroOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsoxGyroFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsoxGyroPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dsoxGyroOdrSpinner.setEnabled(true);
                    lsm6dsoxGyroFullScaleSpinner.setEnabled(true);
                    lsm6dsoxGyroPowerModeSpinner.setEnabled(true);
                    lsm6dsox_g_disabled = false;
                } else { // position == 2, ULP
                    lsm6dsox_reg_14 = 0x80;
                    lsm6dsox_reg_15 = 0x00;
                    lsm6dsoxGyroConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dsoxGyroOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dsoxGyroFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dsoxGyroPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dsoxGyroOdrSpinner.setEnabled(false);
                    lsm6dsoxGyroFullScaleSpinner.setEnabled(false);
                    lsm6dsoxGyroPowerModeSpinner.setEnabled(false);
                    lsm6dsox_g_disabled = true;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsoxGyroOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsox_reg_11 &= 0x0F;
                lsm6dsox_reg_11 |= (position << 4);
                lsm6dsox_g_pd = !(position > 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsoxGyroFullScaleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dsox_reg_11 &= 0xF1;
                if (position == 0) // 125dps
                    lsm6dsox_reg_11 |= 0x02;
                else if (position == 1) // 250dps
                    lsm6dsox_reg_11 |= 0x00;
                else if (position == 2) // 500dps
                    lsm6dsox_reg_11 |= 0x04;
                else if (position == 3) // 1000dps
                    lsm6dsox_reg_11 |= 0x08;
                else if (position == 4) // 2000dps
                    lsm6dsox_reg_11 |= 0x0C;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dsoxGyroPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) { // HP
                    lsm6dsox_reg_16 = 0x00;
                } else { // position == 1, LP
                    lsm6dsox_reg_16 = 0x80;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lps22hhPressOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lps22hh_reg_10 &= 0x8F;
                lps22hh_reg_10 |= (position << 4);
                lps22hh_p_pd = !(position > 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lps22hhPressLPFSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lps22hh_reg_10 &= 0xF3;
                //if (position == 0) // ODR/2
                if (position == 1) // ODR/9
                    lps22hh_reg_10 |= 0x08;
                else if (position == 2) // ODR/20
                    lps22hh_reg_10 |= 0x0C;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lps22hhPressPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) { // Low Current
                    lps22hh_reg_11 = 0x00;
                } else {  // position == 1, Low Noise
                    lps22hh_reg_11 = 0x02;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        filenameLinearLayout = mMainLayout.findViewById(R.id.filenameLinearLayout);
        filenameEditText = mMainLayout.findViewById(R.id.filenameEditText);

        loggingTextView = mMainLayout.findViewById(R.id.loggingTextView);
        startStopBleLogButton = mMainLayout.findViewById(R.id.startStopBleLogButton);

        startStopBleLogButton.setOnClickListener((View view) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!BluetoothLeService.mFirstCtrlPacketReceived) {
                    BLECommands.sendGetStatus(getContext());    // Try getting again the status
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_waiting_first_ble_packet_ongoing), Toast.LENGTH_SHORT).show();
                } else {
                    if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                        if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                            if (MyCtrlData.battery_present == 1 && MyCtrlData.battery_level < 30) {
                                AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                                alertDialog.setTitle(getContext().getString(R.string.title_warning));
                                alertDialog.setMessage(getContext().getString(R.string.alert_low_battery_message));
                                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getContext().getString(R.string.yes_string),
                                        (dialog, which) -> {
                                            startLog();
                                            dialog.dismiss();
                                        });
                                alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getContext().getString(R.string.no_string),
                                        (dialog, which) -> dialog.dismiss());
                                alertDialog.show();
                            } else {
                                startLog();
                            }
                        } else if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_LOGGING) {
                            stopLog();
                        }
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void stopLog()
    {
        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STOPPING);
        MyLogging.setLogFileStatus(MyLogging.LOGFILE_STATUS_CLOSING);
        BLECommands.sendBleStop(getContext());
        BLECommands.sendBleLogStop(getContext());
        BLECommands.sendGetBatteryLevel(getContext());
    }

    private void startLog()
    {
        // Reset device if needed
        if (MyCtrlData.conf == 1)
            BLECommands.sendResetDeviceConfiguration(getContext());

        // Configure device
        // Turn off XL and G to handle ULP
        BLECommands.sendWriteLSM6DSOX(getContext(), "10", "00");
        BLECommands.sendWriteLSM6DSOX(getContext(), "11", "00");

        // Configure XL ULP
        String lsm6dsox_reg14 = String.format(Locale.ENGLISH, "%02x", lsm6dsox_reg_14);
        BLECommands.sendWriteLSM6DSOX(getContext(), "14", lsm6dsox_reg14);

        // Configure XL LP/HP
        String lsm6dsox_reg15 = String.format(Locale.ENGLISH, "%02x", lsm6dsox_reg_15);
        BLECommands.sendWriteLSM6DSOX(getContext(), "15", lsm6dsox_reg15);

        if (lsm6dsoxGyroOdrSpinner.isEnabled()) {
            // Configure G LP/HP
            String lsm6dsox_reg16 = String.format(Locale.ENGLISH, "%02x", lsm6dsox_reg_16);
            BLECommands.sendWriteLSM6DSOX(getContext(), "16", lsm6dsox_reg16);

            // Turn on XL
            String lsm6dsox_reg10 = String.format(Locale.ENGLISH, "%02x", lsm6dsox_reg_10);
            BLECommands.sendWriteLSM6DSOX(getContext(), "10", lsm6dsox_reg10);

            // Turn on G
            String lsm6dsox_reg11 = String.format(Locale.ENGLISH, "%02x", lsm6dsox_reg_11);
            BLECommands.sendWriteLSM6DSOX(getContext(), "11", lsm6dsox_reg11);
        } else {
            // Turn on XL
            String lsm6dsox_reg10 = String.format(Locale.ENGLISH, "%02x", lsm6dsox_reg_10);
            BLECommands.sendWriteLSM6DSOX(getContext(), "10", lsm6dsox_reg10);
        }

        // Turn on/off P
        String lps22hh_reg10 = String.format(Locale.ENGLISH, "%02x", lps22hh_reg_10 | 0x02); // BDU
        BLECommands.sendWriteLPS22HH(getContext(), "10", lps22hh_reg10);
        String lps22hh_reg11 = String.format(Locale.ENGLISH, "%02x", lps22hh_reg_11 | 0x10); // IF_ADD_INC
        BLECommands.sendWriteLPS22HH(getContext(), "11", lps22hh_reg11);

        MyLogging.setBleLogHighRate(false);
        MyLogging.setBleLogHighRateAccelAxis("");

        // Just to be sure that the mic is off
        BLECommands.sendAudioOff(getContext());

        // Prepare app for logging data
        String filename = filenameEditText.getText().toString();
        MySharedPreferences.getInstance(getContext()).setLogFilename(filename);
        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STARTING);
        MyLogging.setLogFileStatus(MyLogging.LOGFILE_STATUS_CREATING);
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                switch (MyLogging.getLogStatus())
                {
                    case MyLogging.LOG_STATUS_IDLE:
                        loggingTextView.setEnabled(true);
                        if (lsm6dsox_xl_pd && (lsm6dsox_g_pd || lsm6dsox_g_disabled) && lps22hh_p_pd) {
                            startStopBleLogButton.setEnabled(false);
                            startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                        }
                        else {
                            startStopBleLogButton.setEnabled(true);
                            startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        }
                        loggingTextView.setText(R.string.logging_false_string);
                        startStopBleLogButton.setText(R.string.start_string);
                        if (MyCtrlData.ble_log > 0) {
                            MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                        }
                        break;
                    case MyLogging.LOG_STATUS_STARTING:
                        startStopBleLogButton.setEnabled(false);
                        startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                        startStopBleLogButton.setText(R.string.starting_string);
                        if (MyCtrlData.ble_log > 0) {
                            MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                        }
                        break;
                    case MyLogging.LOG_STATUS_LOGGING:
                        loggingTextView.setText(R.string.logging_true_string);
                        startStopBleLogButton.setEnabled(true);
                        startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        startStopBleLogButton.setText(R.string.stop_string);
                        if (MyCtrlData.ble_log == 0) {
                            MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                        }
                        break;
                    case MyLogging.LOG_STATUS_STOPPING:
                        startStopBleLogButton.setText(R.string.stopping_string);
                        startStopBleLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                        startStopBleLogButton.setEnabled(false);
                        if (MyCtrlData.ble_log == 0) {
                            MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                        }
                        break;
                    default:
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

package st.oem.box;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.Objects;

import st.oem.R;

import static androidx.recyclerview.widget.RecyclerView.VERTICAL;

public class BluetoothScannerFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener, BluetoothDeviceAdapterCallback
{
    private final static String LOG_TAG = BluetoothScannerFragment.class.getSimpleName();

    private static final int BLE_SCANNER_TIMEOUT_MS = 5000;

    private BluetoothLeScanner mBluetoothLeScanner;
    private boolean mScanning;
    private BluetoothDeviceAdapter mBluetoothDeviceAdapter; // adapter which contains the list of available BLE devices, used to fill the UI

    private RecyclerView mRecyclerView;
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private Handler mHandler;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(LOG_TAG, "onCreate");

        if (savedInstanceState == null) {
            mBluetoothDeviceAdapter = new BluetoothDeviceAdapter(getContext(), this);
            BluetoothManager bluetoothManager = (BluetoothManager) (getContext().getSystemService(Context.BLUETOOTH_SERVICE));
            BluetoothAdapter mBluetoothAdapter = bluetoothManager.getAdapter();
            mBluetoothLeScanner = mBluetoothAdapter.getBluetoothLeScanner();
            mScanning = false;
        }
    }

    @Override
    public void onDeviceSelected(BluetoothDeviceObject device) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

        String message;
        if (device.getName() == null) {
            message = String.format(getResources().getString(R.string.alert_connection_message), device.getAddress());
        } else {
            message = String.format(getResources().getString(R.string.alert_connection_message), device.getName());
        }

        builder.setTitle(getString(R.string.alert_connection_title));
        builder.setMessage(message);
        builder.setPositiveButton(getString(R.string.yes_string), new ConnectHandler(device.getBluetoothDevice()));
        builder.setNegativeButton(getString(R.string.no_string), (DialogInterface dialog, int which) -> dialog.dismiss() );

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    @Override
    public void onDeviceInfoRequested(BluetoothDeviceObject deviceObject) {

    }

    private class ConnectHandler implements DialogInterface.OnClickListener
    {
        public ConnectHandler(BluetoothDevice bluetoothDevice) {
            MySharedPreferences.getInstance(getContext()).setNodeName(bluetoothDevice.getName());
            MySharedPreferences.getInstance(getContext()).setNodeAddress(bluetoothDevice.getAddress());
        }

        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss();
            startConnectionAndLoadDemoList();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(LOG_TAG, "onCreateView");

        View v = inflater.inflate(R.layout.fragment_bluetooth_scanner, container, false);

        mRecyclerView = v.findViewById(R.id.device_list_recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.addItemDecoration(new DividerItemDecoration(getContext(), VERTICAL));

        mRecyclerView.setAdapter(mBluetoothDeviceAdapter);
        mRecyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getContext(), mRecyclerView, mBluetoothDeviceAdapter));

        mSwipeRefreshLayout = v.findViewById(R.id.swipe_refresh);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        mSwipeRefreshLayout.setColorSchemeResources(R.color.color_blue, android.R.color.holo_green_dark, android.R.color.holo_orange_dark, android.R.color.holo_blue_dark);

        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        Log.d(LOG_TAG, "onViewCreated");
        super.onViewCreated(view, savedInstanceState);

        mHandler = new Handler();
        
        onRefresh();
    }

    private final ScanCallback leScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            super.onScanResult(callbackType, result);

            if (mBluetoothDeviceAdapter.getDeviceFromAddress(result.getDevice().getAddress()) == null) {
                // Add discovered device if its name is the expected one
                if (result.getDevice().getName() != null) {
                    boolean autoConnect = MySharedPreferences.getInstance(getContext()).getAutoConnect();
                    if (autoConnect) {
                        String nodeName_saved = MySharedPreferences.getInstance(getContext()).getNodeName();
                        String nodeAddr_saved = MySharedPreferences.getInstance(getContext()).getNodeAddress();
                        String nodeName_found = Objects.requireNonNull(result.getScanRecord()).getDeviceName();
                        String nodeAddr_found = result.getDevice().getAddress();
                        assert nodeName_found != null;
                        if (nodeName_found.equals(nodeName_saved) && nodeAddr_found.equals(nodeAddr_saved)) {
                            new ConnectHandler(result.getDevice());
                            startConnectionAndLoadDemoList();
                        }
                    }
                    mBluetoothDeviceAdapter.addItem(new BluetoothDeviceObject(result));
                }
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            super.onScanFailed(errorCode);
            scanLeDeviceStop();
            Toast.makeText(getContext(), getString(R.string.scanner_fragment_scan_failed), Toast.LENGTH_SHORT).show();
        }
    };

    private void startConnectionAndLoadDemoList()
    {
        scanLeDeviceStop();

        // Trigger the bluetooth connection in ScannerActivity
        Intent intent = new Intent(MainActivity.ACTION_BLE_START_CONNECTION);
        getContext().sendBroadcast(intent);
    }

    private final Runnable myRunnable = new Runnable() {
        @Override
        public void run() {
            mScanning = false;
            mBluetoothLeScanner.stopScan(leScanCallback);
            mSwipeRefreshLayout.setRefreshing(false);
        }
    };

    private void scanLeDeviceStart() {
        mScanning = true;
        mBluetoothLeScanner.startScan(leScanCallback);
        mHandler.removeCallbacks(myRunnable);
        mHandler.postDelayed(myRunnable, BLE_SCANNER_TIMEOUT_MS);
    }

    private void scanLeDeviceStop() {
        mScanning = false;
        mBluetoothLeScanner.stopScan(leScanCallback);
        mSwipeRefreshLayout.setRefreshing(false);
        mHandler.removeCallbacks(myRunnable);
    }

    private void loadRecyclerViewData() {
        mBluetoothDeviceAdapter.removeAll();
        mSwipeRefreshLayout.setRefreshing(true);
        scanLeDeviceStart();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "onPause");

        if (mScanning) {
            scanLeDeviceStop();
            mScanning = true;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(LOG_TAG, "onResume");


    }

    @Override
    public void onRefresh() {
        Log.d(LOG_TAG, "onRefresh");
        loadRecyclerViewData();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(LOG_TAG, "onDestroy");

        mRecyclerView.setAdapter(null);
        mRecyclerView = null;
        mBluetoothDeviceAdapter = null;
        mBluetoothLeScanner = null;
        mSwipeRefreshLayout = null;
        mHandler = null;
    }
}
package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_DEMO_SD_LOG extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private Button mDemoStartStopLogButton;
    private TextView mDemoLoggingTextView;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_LOG_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mDemoStartStopLogButton = null;
        mDemoLoggingTextView = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_DEMO_SD_LOG(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_log_demo, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mDemoLoggingTextView = mMainLayout.findViewById(R.id.demoLoggingTextView);
        mDemoStartStopLogButton = mMainLayout.findViewById(R.id.demoStartStopLogButton);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });
        
        mDemoStartStopLogButton.setOnClickListener((View view) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        if (MyCtrlData.battery_present == 1 && MyCtrlData.battery_level < 30) {
                            AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                            alertDialog.setTitle(getContext().getString(R.string.title_warning));
                            alertDialog.setMessage(getContext().getString(R.string.alert_low_battery_message));
                            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getContext().getString(R.string.yes_string),
                                    (dialog, which) -> {
                                        startLog();
                                        dialog.dismiss();
                                    });
                            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getContext().getString(R.string.no_string),
                                    (dialog, which) -> dialog.dismiss());
                            alertDialog.show();
                        } else {
                            startLog();
                        }
                    } else if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_LOGGING) {
                        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STOPPING);
                        BLECommands.sendSdStopLog(getContext());
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startLog()
    {
        String username = MySharedPreferences.getInstance(getContext()).getUsername();
        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STARTING);

        BLECommands.sendSdStartLog(getContext(), username, DemoFragment.getInstance().getSelectedDemo().getDemoLogName(), getContext().getString(R.string.empty_string));
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyCtrlData.sd_err == 1) {
                    mDemoLoggingTextView.setEnabled(false);
                    mDemoStartStopLogButton.setEnabled(false);
                    mDemoLoggingTextView.setText(R.string.logging_error_string);
                }
                else {
                    switch (MyLogging.getLogStatus())
                    {
                        case MyLogging.LOG_STATUS_IDLE:
                            mDemoLoggingTextView.setEnabled(true);
                            mDemoStartStopLogButton.setEnabled(true);
                            mDemoStartStopLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                            mDemoLoggingTextView.setText(R.string.logging_false_string);
                            mDemoStartStopLogButton.setText(R.string.start_string);
                            if (MyCtrlData.sd_log == 1) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                            }
                            break;
                        case MyLogging.LOG_STATUS_STARTING:
                            mDemoStartStopLogButton.setEnabled(false);
                            mDemoStartStopLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                            mDemoStartStopLogButton.setText(R.string.starting_string);
                            if (MyCtrlData.sd_log == 1) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                            }
                            break;
                        case MyLogging.LOG_STATUS_LOGGING:
                            mDemoLoggingTextView.setText(R.string.logging_true_string);
                            mDemoStartStopLogButton.setEnabled(true);
                            mDemoStartStopLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                            mDemoStartStopLogButton.setText(R.string.stop_string);
                            if (MyCtrlData.sd_log == 0) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                            }
                            break;
                        case MyLogging.LOG_STATUS_STOPPING:
                            mDemoStartStopLogButton.setText(R.string.stopping_string);
                            mDemoStartStopLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                            mDemoStartStopLogButton.setEnabled(false);
                            if (MyCtrlData.sd_log == 0) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                            }
                            break;
                        default:
                            break;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

package st.oem.box;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_PEDO_MOBILE_CONFIG extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private Button mPedMobileGenericButton;
    private Button mPedMobileHandButton;
    private Button mPedMobilePocketButton;
    private TextView mPedMobileSelConfigTextView;

    private CardView mMainLayout;

    // State
    private static String mSelectedConfig;

    public void saveState()
    {
        try {
            mSelectedConfig = mPedMobileSelConfigTextView.getText().toString();
        } catch(Exception ignored) { }
    }

    public void restoreState()
    {
        try {
            mPedMobileSelConfigTextView.setText(mSelectedConfig);
            if (mSelectedConfig.equals(getResources().getString(R.string.selected_ped_generic))) {
                mPedMobileGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                mPedMobileHandButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                mPedMobilePocketButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
            } else if (mSelectedConfig.equals(getResources().getString(R.string.selected_ped_hand))) {
                mPedMobileGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                mPedMobileHandButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                mPedMobilePocketButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
            } else if (mSelectedConfig.equals(getResources().getString(R.string.selected_ped_pocket))) {
                mPedMobileGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                mPedMobileHandButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                mPedMobilePocketButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
            }
        } catch(Exception ignored) { }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mPedMobileGenericButton = null;
        mPedMobileHandButton = null;
        mPedMobilePocketButton = null;
        mPedMobileSelConfigTextView = null;

        mMainLayout = null;
    }

    @SuppressLint("InflateParams")
    public CardView_PEDO_MOBILE_CONFIG(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_ped_mobile_config, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mPedMobileGenericButton = mMainLayout.findViewById(R.id.pedMobileGenericButton);
        mPedMobileHandButton = mMainLayout.findViewById(R.id.pedMobileHandButton);
        mPedMobilePocketButton = mMainLayout.findViewById(R.id.pedMobilePocketButton);
        mPedMobileSelConfigTextView = mMainLayout.findViewById(R.id.pedMobileSelConfigTextView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        mPedMobileGenericButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        DemoFragment.getInstance().loadDeviceConfiguration(R.raw.lsm6dsox_smartphone_pedo_generic_configuration);
                        mPedMobileGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mPedMobileHandButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mPedMobilePocketButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mPedMobileSelConfigTextView.setText(getResources().getString(R.string.selected_ped_generic));
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        mPedMobileHandButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        DemoFragment.getInstance().loadDeviceConfiguration(R.raw.lsm6dsox_smartphone_pedo_hand_configuration);
                        mPedMobileGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mPedMobileHandButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mPedMobilePocketButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mPedMobileSelConfigTextView.setText(getResources().getString(R.string.selected_ped_hand));
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        mPedMobilePocketButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        DemoFragment.getInstance().loadDeviceConfiguration(R.raw.lsm6dsox_smartphone_pedo_pocket_configuration);
                        mPedMobileGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mPedMobileHandButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mPedMobilePocketButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mPedMobileSelConfigTextView.setText(R.string.selected_ped_pocket);
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

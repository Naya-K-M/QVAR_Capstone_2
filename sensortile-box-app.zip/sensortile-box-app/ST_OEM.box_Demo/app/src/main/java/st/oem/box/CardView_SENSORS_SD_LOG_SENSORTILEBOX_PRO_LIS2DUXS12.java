package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_SENSORS_SD_LOG_SENSORTILEBOX_PRO_LIS2DUXS12 extends CardView {

    private TextView lis2duxs12AccelConfigTextView;
    private TextView lis2duxs12AccelQvarOdrTextView;
    private Spinner lis2duxs12AccelQvarOdrSpinner;
    private TextView lis2duxs12AccelPowerModeTextView;
    private Spinner lis2duxs12AccelPowerModeSpinner;
    private TextView lis2duxs12AccelFullScaleTextView;
    private Spinner lis2duxs12AccelFullScaleSpinner;
    private TextView lis2duxs12QvarConfigTextView;
    private CheckBox lis2duxs12QvarEnabledCheckBox;
    private TextView lis2duxs12QvarNotchTextView;
    private Spinner lis2duxs12QvarNotchSpinner;
    private TextView lis2duxs12QvarZinTextView;
    private Spinner lis2duxs12QvarZinSpinner;
    private TextView lis2duxs12QvarGainTextView;
    private Spinner lis2duxs12QvarGainSpinner;
    private TextView lis2duxs12QvarMuxDescriptionTextView;
    private TextView lis2duxs12QvarMuxTextView;
    private Spinner lis2duxs12QvarMuxSpinner;
    private EditText applicationEditText;
    private EditText classEditText;

    private TextView loggingTextView;
    private Button startStopSdLogButton;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    private boolean lis2duxs12_odr_pd = true;
    private boolean lis2duxs12_odr_ulp = false;
    private int lis2duxs12_reg_12 = 0x00;
    private int lis2duxs12_reg_14 = 0x00;
    private int lis2duxs12_reg_31 = 0x00;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_SENSORS_LOG_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        lis2duxs12AccelConfigTextView = null;
        lis2duxs12AccelQvarOdrTextView = null;
        lis2duxs12AccelQvarOdrSpinner = null;
        lis2duxs12AccelPowerModeTextView = null;
        lis2duxs12AccelPowerModeSpinner = null;
        lis2duxs12AccelFullScaleTextView = null;
        lis2duxs12AccelFullScaleSpinner = null;
        lis2duxs12QvarConfigTextView = null;
        lis2duxs12QvarEnabledCheckBox = null;
        lis2duxs12QvarNotchTextView = null;
        lis2duxs12QvarNotchSpinner = null;
        lis2duxs12QvarZinTextView = null;
        lis2duxs12QvarZinSpinner = null;
        lis2duxs12QvarGainTextView = null;
        lis2duxs12QvarGainSpinner = null;
        lis2duxs12QvarMuxDescriptionTextView = null;
        lis2duxs12QvarMuxTextView = null;
        lis2duxs12QvarMuxSpinner = null;
        applicationEditText = null;
        classEditText = null;
        loggingTextView = null;
        startStopSdLogButton = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_SENSORS_SD_LOG_SENSORTILEBOX_PRO_LIS2DUXS12(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_sensors_sd_log_sensortilebox_pro_lis2duxs12, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        lis2duxs12_odr_pd = true;
        lis2duxs12_odr_ulp = false;
        lis2duxs12_reg_12 = 0x00;
        lis2duxs12_reg_14 = 0x00;
        lis2duxs12_reg_31 = 0x00;

        lis2duxs12AccelConfigTextView = mMainLayout.findViewById(R.id.lis2duxs12AccelConfigTextView);
        lis2duxs12AccelQvarOdrTextView = mMainLayout.findViewById(R.id.lis2duxs12AccelQvarOdrTextView);
        lis2duxs12AccelQvarOdrSpinner = mMainLayout.findViewById(R.id.lis2duxs12AccelQvarOdrSpinner);
        lis2duxs12AccelFullScaleSpinner = mMainLayout.findViewById(R.id.lis2duxs12AccelFullScaleSpinner);
        lis2duxs12AccelPowerModeSpinner = mMainLayout.findViewById(R.id.lis2duxs12AccelPowerModeSpinner);
        lis2duxs12AccelFullScaleTextView = mMainLayout.findViewById(R.id.lis2duxs12AccelFullScaleTextView);
        lis2duxs12AccelPowerModeTextView = mMainLayout.findViewById(R.id.lis2duxs12AccelPowerModeTextView);

        lis2duxs12QvarConfigTextView = mMainLayout.findViewById(R.id.lis2duxs12QvarConfigTextView);
        lis2duxs12QvarEnabledCheckBox = mMainLayout.findViewById(R.id.lis2duxs12QvarEnabledCheckBox);
        lis2duxs12QvarNotchTextView = mMainLayout.findViewById(R.id.lis2duxs12QvarNotchTextView);
        lis2duxs12QvarNotchSpinner = mMainLayout.findViewById(R.id.lis2duxs12QvarNotchSpinner);
        lis2duxs12QvarZinTextView = mMainLayout.findViewById(R.id.lis2duxs12QvarZinTextView);
        lis2duxs12QvarZinSpinner = mMainLayout.findViewById(R.id.lis2duxs12QvarZinSpinner);
        lis2duxs12QvarGainTextView = mMainLayout.findViewById(R.id.lis2duxs12QvarGainTextView);
        lis2duxs12QvarGainSpinner = mMainLayout.findViewById(R.id.lis2duxs12QvarGainSpinner);
        lis2duxs12QvarMuxDescriptionTextView = mMainLayout.findViewById(R.id.lis2duxs12QvarMuxDescriptionTextView);
        lis2duxs12QvarMuxTextView = mMainLayout.findViewById(R.id.lis2duxs12QvarMuxTextView);
        lis2duxs12QvarMuxSpinner = mMainLayout.findViewById(R.id.lis2duxs12QvarMuxSpinner);

        applicationEditText = mMainLayout.findViewById(R.id.applicationEditText);
        classEditText = mMainLayout.findViewById(R.id.classEditText);

        loggingTextView = mMainLayout.findViewById(R.id.loggingTextView);
        startStopSdLogButton = mMainLayout.findViewById(R.id.startStopSdLogButton);

        lis2duxs12AccelQvarOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lis2duxs12_reg_14 &= 0x0F;
                lis2duxs12_odr_pd = !(position > 0);

                if (!lis2duxs12_odr_pd)
                {
                    if (lis2duxs12_odr_ulp)
                        lis2duxs12_reg_14 |= (position << 4);
                    else
                        lis2duxs12_reg_14 |= ((position + 3) << 4);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lis2duxs12AccelPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int xlOdrSpinner_PreviousPosition = lis2duxs12AccelQvarOdrSpinner.getSelectedItemPosition();
                ArrayAdapter<CharSequence> adapter;

                if (position == 0) { // LP
                    adapter = ArrayAdapter.createFromResource(getContext(), R.array.lis2duxs12_lp_hp_odr_array, android.R.layout.simple_spinner_item);

                    lis2duxs12_reg_12 = 0x00;
                    lis2duxs12_odr_ulp = false;

                    lis2duxs12QvarConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lis2duxs12QvarEnabledCheckBox.setEnabled(true);
                    lis2duxs12QvarNotchTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lis2duxs12QvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lis2duxs12QvarGainTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lis2duxs12QvarNotchSpinner.setEnabled(true);
                    lis2duxs12QvarZinSpinner.setEnabled(true);
                    lis2duxs12QvarGainSpinner.setEnabled(true);
                } else if (position == 1) { // HP
                    adapter = ArrayAdapter.createFromResource(getContext(), R.array.lis2duxs12_lp_hp_odr_array, android.R.layout.simple_spinner_item);

                    lis2duxs12_reg_12 = 0x04;
                    lis2duxs12_odr_ulp = false;

                    lis2duxs12QvarConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lis2duxs12QvarEnabledCheckBox.setEnabled(true);
                    lis2duxs12QvarNotchTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lis2duxs12QvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lis2duxs12QvarGainTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lis2duxs12QvarNotchSpinner.setEnabled(true);
                    lis2duxs12QvarZinSpinner.setEnabled(true);
                    lis2duxs12QvarGainSpinner.setEnabled(true);
                } else { // position == 2, ULP
                    adapter = ArrayAdapter.createFromResource(getContext(), R.array.lis2duxs12_ulp_odr_array, android.R.layout.simple_spinner_item);

                    lis2duxs12_reg_12 = 0x00;
                    lis2duxs12_odr_ulp = true;

                    lis2duxs12QvarConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarEnabledCheckBox.setChecked(false);
                    lis2duxs12QvarEnabledCheckBox.setEnabled(false);
                    lis2duxs12QvarNotchTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarGainTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarNotchSpinner.setEnabled(false);
                    lis2duxs12QvarZinSpinner.setEnabled(false);
                    lis2duxs12QvarGainSpinner.setEnabled(false);
                }

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                lis2duxs12AccelQvarOdrSpinner.setAdapter(adapter);
                if (xlOdrSpinner_PreviousPosition < adapter.getCount()) {
                    lis2duxs12AccelQvarOdrSpinner.setSelection(xlOdrSpinner_PreviousPosition);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lis2duxs12AccelFullScaleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lis2duxs12_reg_14 &= 0xFC;
                if (position == 0) // 2g
                    lis2duxs12_reg_14 |= 0x00;
                else if (position == 1) // 4g
                    lis2duxs12_reg_14 |= 0x01;
                else if (position == 2) // 8g
                    lis2duxs12_reg_14 |= 0x02;
                else if (position == 3) // 16g
                    lis2duxs12_reg_14 |= 0x03;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lis2duxs12QvarEnabledCheckBox.setOnCheckedChangeListener((buttonView, isChecked) ->
        {
            if (!isChecked) {
                lis2duxs12_reg_31 &= 0x7F;
                lis2duxs12QvarNotchTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lis2duxs12QvarNotchSpinner.setEnabled(false);
                lis2duxs12QvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lis2duxs12QvarZinSpinner.setEnabled(false);
                lis2duxs12QvarGainTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lis2duxs12QvarGainSpinner.setEnabled(false);
                lis2duxs12QvarMuxDescriptionTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lis2duxs12QvarMuxTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                lis2duxs12QvarMuxSpinner.setEnabled(false);
            } else {
                lis2duxs12_reg_31 |= 0x80;
                lis2duxs12QvarNotchTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lis2duxs12QvarNotchSpinner.setEnabled(true);
                lis2duxs12QvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lis2duxs12QvarZinSpinner.setEnabled(true);
                lis2duxs12QvarGainTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lis2duxs12QvarGainSpinner.setEnabled(true);
                lis2duxs12QvarMuxDescriptionTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lis2duxs12QvarMuxTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                lis2duxs12QvarMuxSpinner.setEnabled(true);
            }
        });

        lis2duxs12QvarNotchSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lis2duxs12_reg_31 &= 0x9F;
                if (position == 0) // disabled
                    lis2duxs12_reg_31 |= 0x00;
                else if (position == 1) // 50 Hz
                    lis2duxs12_reg_31 |= 0x40;
                else if (position == 2) // 60 Hz
                    lis2duxs12_reg_31 |= 0x60;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lis2duxs12QvarZinSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lis2duxs12_reg_31 &= 0xE7;
                if (position == 0) // 520 MOhm
                    lis2duxs12_reg_31 |= 0x00;
                else if (position == 1) // 310 MOhm
                    lis2duxs12_reg_31 |= 0x10;
                else if (position == 2) // 175 MOhm
                    lis2duxs12_reg_31 |= 0x08;
                else if (position == 3) // 75 MOhm
                    lis2duxs12_reg_31 |= 0x18;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lis2duxs12QvarGainSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lis2duxs12_reg_31 &= 0xF9;
                if (position == 0) // 0.5
                    lis2duxs12_reg_31 |= 0x00;
                else if (position == 1) // 1
                    lis2duxs12_reg_31 |= 0x02;
                else if (position == 2) // 2
                    lis2duxs12_reg_31 |= 0x04;
                else if (position == 3) // 4
                    lis2duxs12_reg_31 |= 0x06;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        startStopSdLogButton.setOnClickListener((View view) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        if (MyCtrlData.battery_present == 1 && MyCtrlData.battery_level < 30) {
                            AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                            alertDialog.setTitle(getContext().getString(R.string.title_warning));
                            alertDialog.setMessage(getContext().getString(R.string.alert_low_battery_message));
                            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getContext().getString(R.string.yes_string),
                                    (dialog, which) -> {
                                        startLog();
                                        dialog.dismiss();
                                    });
                            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getContext().getString(R.string.no_string),
                                    (dialog, which) -> dialog.dismiss());
                            alertDialog.show();
                        } else {
                            startLog();
                        }
                    } else if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_LOGGING) {
                        stopLog();

                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void stopLog()
    {
        boolean status_required = false;

        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STOPPING);
        BLECommands.sendSdStopLog(getContext());
        if (MyCtrlData.afe_channels != 0) {
            BLECommands.sendAfeMux(getContext(), 0, 0);
            status_required = true;
        }
        if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1 && MyCtrlData.audio == 1) {
            BLECommands.sendAudioOff(getContext());
            status_required = true;
        }
        if (status_required)
            BLECommands.sendGetBatteryLevel(getContext());
    }

    private void startLog()
    {
        // Reset board
        BLECommands.sendResetDeviceConfiguration(getContext());

        // Multiplexer configuration
        int mux_channels = 0;
        if (lis2duxs12QvarMuxSpinner.isEnabled())
            mux_channels = lis2duxs12QvarMuxSpinner.getSelectedItemPosition();
        BLECommands.sendAfeMux(getContext(), mux_channels > 0 ? 1 : 0, mux_channels);

        // Device configuration
        BLECommands.sendWriteLSM6DSOX(getContext(), "10", "50");    // INT1 on RES

        String lis2duxs12_reg31 = String.format(Locale.ENGLISH, "%02x", lis2duxs12_reg_31);
        BLECommands.sendWriteLSM6DSOX(getContext(), "31", lis2duxs12_reg31);

        String lis2duxs12_reg12 = String.format(Locale.ENGLISH, "%02x", lis2duxs12_reg_12);
        BLECommands.sendWriteLSM6DSOX(getContext(), "12", lis2duxs12_reg12);

        String lis2duxs12_reg14 = String.format(Locale.ENGLISH, "%02x", lis2duxs12_reg_14);
        BLECommands.sendWriteLSM6DSOX(getContext(), "14", lis2duxs12_reg14);

        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STARTING);

        // Get filename
        String usernameToSend = MySharedPreferences.getInstance(getContext()).getUsername();
        String applicationToSend = applicationEditText.getText().toString();
        String classToSend = classEditText.getText().toString();

        assert usernameToSend != null;
        BLECommands.sendSdStartLog(getContext(), usernameToSend, applicationToSend, classToSend);
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyCtrlData.sd_err == 1) {
                    loggingTextView.setEnabled(false);
                    startStopSdLogButton.setEnabled(false);
                    loggingTextView.setText(R.string.logging_error_string);

                    lis2duxs12AccelConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12AccelQvarOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12AccelFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12AccelPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12AccelQvarOdrSpinner.setEnabled(false);
                    lis2duxs12AccelFullScaleSpinner.setEnabled(false);
                    lis2duxs12AccelPowerModeSpinner.setEnabled(false);

                    lis2duxs12QvarConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarEnabledCheckBox.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarNotchTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarNotchSpinner.setEnabled(false);
                    lis2duxs12QvarZinTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarZinSpinner.setEnabled(false);
                    lis2duxs12QvarGainTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lis2duxs12QvarGainSpinner.setEnabled(false);
                }
                else {
                    switch (MyLogging.getLogStatus())
                    {
                        case MyLogging.LOG_STATUS_IDLE:
                            loggingTextView.setEnabled(true);
                            if (lis2duxs12_odr_pd && MyCtrlData.sd_msc == 0) {
                                startStopSdLogButton.setEnabled(false);
                                startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                            }
                            else {
                                startStopSdLogButton.setEnabled(true);
                                startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                            }
                            loggingTextView.setText(R.string.logging_false_string);
                            startStopSdLogButton.setText(R.string.start_string);
                            if (MyCtrlData.sd_log == 1) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                            }
                            break;
                        case MyLogging.LOG_STATUS_STARTING:
                            startStopSdLogButton.setEnabled(false);
                            startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                            startStopSdLogButton.setText(R.string.starting_string);
                            if (MyCtrlData.sd_log == 1) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                            }
                            break;
                        case MyLogging.LOG_STATUS_LOGGING:
                            loggingTextView.setText(R.string.logging_true_string);
                            startStopSdLogButton.setEnabled(true);
                            startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                            startStopSdLogButton.setText(R.string.stop_string);
                            if (MyCtrlData.sd_log == 0) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                            }
                            break;
                        case MyLogging.LOG_STATUS_STOPPING:
                            startStopSdLogButton.setText(R.string.stopping_string);
                            startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                            startStopSdLogButton.setEnabled(false);
                            if (MyCtrlData.sd_log == 0) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                            }
                            break;
                        default:
                            break;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

package st.oem.box;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import st.oem.R;

@SuppressLint("ViewConstructor")
public class CardView_EVENTS extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private LinearLayout mEventsLinearLayout;
    private TextView mEventsNumberTextView;
    private ScrollView mEventsScrollView;

    private CardView mMainLayout;

    private int n_events;

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mEventsLinearLayout = null;
        mEventsNumberTextView = null;
        mEventsScrollView = null;

        mMainLayout = null;
    }

    @SuppressLint("InflateParams")
    public CardView_EVENTS(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_events, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        n_events = 0;

        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mEventsLinearLayout = mMainLayout.findViewById(R.id.eventsLinearLayout);
        mEventsNumberTextView = mMainLayout.findViewById(R.id.eventsNumberTextView);
        mEventsScrollView = mMainLayout.findViewById(R.id.eventsScrollView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        String count = String.format(getResources().getString(R.string.card_events_number), n_events);
        mEventsNumberTextView.setText(count);
    }

    public void addEvent(String event)
    {
        n_events++;

        String count = String.format(getResources().getString(R.string.card_events_number), n_events);
        mEventsNumberTextView.setText(count);

        // Create horizontal linearLayout
        LayoutInflater inflater = LayoutInflater.from(getContext());
        LinearLayout newEventLinearLayout = (LinearLayout) inflater.inflate(R.layout.event, mEventsLinearLayout, false);

        // Timestamp
        TextView timestampTextView = newEventLinearLayout.findViewById(R.id.timestampTextView);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss.SSS", Locale.getDefault());
        String timestampString = sdf.format(new Date());
        timestampTextView.setText(timestampString);

        // Event string
        TextView eventTextView = newEventLinearLayout.findViewById(R.id.eventTextView);
        eventTextView.setText(event);

        mEventsLinearLayout.addView(newEventLinearLayout);

        mEventsScrollView.post(() -> mEventsScrollView.fullScroll(View.FOCUS_DOWN));
    }
}

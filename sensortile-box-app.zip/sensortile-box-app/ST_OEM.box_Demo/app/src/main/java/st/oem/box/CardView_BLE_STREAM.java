package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.cardview.widget.CardView;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;

@SuppressLint("ViewConstructor")
public class CardView_BLE_STREAM extends CardView {

    private final float VERTICAL_AXIS_MIN_DELTA = 32708.0f * 0.1f;

    private final int LSM6DSOX_ACCEL = 0;
    private final int LSM6DSOX_GYRO = 1;
    private final int LPS22HH_PRESS = 2;
    private final int LSM6DSV16X_ACCEL = 3;
    private final int LSM6DSV16X_GYRO = 4;
    private final int LSM6DSV16X_QVAR = 5;
    private final int LSM6DSV16BX_ACCEL = 6;
    private final int LSM6DSV16BX_GYRO = 7;
    private final int LSM6DSV16BX_QVAR = 8;
    private final int LSM6DSO16IS_ACCEL = 9;
    private final int LSM6DSO16IS_GYRO = 10;

    // Charts variables
    private final int N_CHARTS = 3;
    private static float internalTimestamp = 0.0f;

    private final int CHART_BUFFER_SIZE_MIN = 100;
    private final int CHART_BUFFER_SIZE_MAX = 250;
    private final int CHART_BUFFER_SIZE_DEFAULT = 150;
    private int chartBufferSize = CHART_BUFFER_SIZE_DEFAULT;

    private final int[] SENSORS = new int[N_CHARTS];
    private final ArrayList<CheckBox> sensorNameCheckBox_arr = new ArrayList<>(N_CHARTS);
    private final ArrayList<LineChart> lineChart_arr = new ArrayList<>(N_CHARTS);

    // Charts data
    private static MySafeArrayEntry lsm6dsoxAccelValuesX;
    private static MySafeArrayEntry lsm6dsoxAccelValuesY;
    private static MySafeArrayEntry lsm6dsoxAccelValuesZ;
    private static MySafeArrayEntry lsm6dsoxGyroValuesX;
    private static MySafeArrayEntry lsm6dsoxGyroValuesY;
    private static MySafeArrayEntry lsm6dsoxGyroValuesZ;
    private static MySafeArrayEntry lps22hhPressValues;
    private static MySafeArrayEntry lsm6dsv16xAccelValuesX;
    private static MySafeArrayEntry lsm6dsv16xAccelValuesY;
    private static MySafeArrayEntry lsm6dsv16xAccelValuesZ;
    private static MySafeArrayEntry lsm6dsv16xAccelValuesV;
    private static MySafeArrayEntry lsm6dsv16xGyroValuesX;
    private static MySafeArrayEntry lsm6dsv16xGyroValuesY;
    private static MySafeArrayEntry lsm6dsv16xGyroValuesZ;
    private static MySafeArrayEntry lsm6dsv16xQvarValues;
    private static MySafeArrayEntry lsm6dsv16bxAccelValuesX;
    private static MySafeArrayEntry lsm6dsv16bxAccelValuesY;
    private static MySafeArrayEntry lsm6dsv16bxAccelValuesZ;
    private static MySafeArrayEntry lsm6dsv16bxAccelValuesV;
    private static MySafeArrayEntry lsm6dsv16bxGyroValuesX;
    private static MySafeArrayEntry lsm6dsv16bxGyroValuesY;
    private static MySafeArrayEntry lsm6dsv16bxGyroValuesZ;
    private static MySafeArrayEntry lsm6dsv16bxQvarValues;
    private static MySafeArrayEntry lsm6dso16isAccelValuesX;
    private static MySafeArrayEntry lsm6dso16isAccelValuesY;
    private static MySafeArrayEntry lsm6dso16isAccelValuesZ;
    private static MySafeArrayEntry lsm6dso16isGyroValuesX;
    private static MySafeArrayEntry lsm6dso16isGyroValuesY;
    private static MySafeArrayEntry lsm6dso16isGyroValuesZ;

    private final CardView mMainLayout;
    private Timer mTimerUpdateUI;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_BLE_STREAM_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_BLE_STREAM(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_ble_stream, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        sensorNameCheckBox_arr.add(mMainLayout.findViewById(R.id.sensorName1CheckBox));
        sensorNameCheckBox_arr.add(mMainLayout.findViewById(R.id.sensorName2CheckBox));
        sensorNameCheckBox_arr.add(mMainLayout.findViewById(R.id.sensorName3CheckBox));

        lineChart_arr.add(mMainLayout.findViewById(R.id.lineChart1));
        lineChart_arr.add(mMainLayout.findViewById(R.id.lineChart2));
        lineChart_arr.add(mMainLayout.findViewById(R.id.lineChart3));

        // Initialize chart buffer size
        String chartBufferSizeVal = MySharedPreferences.getInstance(getContext()).getChartBufferSizeVal();
        EditText chartBufferSizeEditText = mMainLayout.findViewById(R.id.chartBufferSizeEditText);
        chartBufferSizeEditText.setText(chartBufferSizeVal);
        chartBufferSize = Integer.parseInt(chartBufferSizeVal);

        switch (MyCtrlData.board_id)
        {
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                lsm6dsoxAccelValuesX = new MySafeArrayEntry(chartBufferSize);
                lsm6dsoxAccelValuesY = new MySafeArrayEntry(chartBufferSize);
                lsm6dsoxAccelValuesZ = new MySafeArrayEntry(chartBufferSize);
                lsm6dsoxGyroValuesX = new MySafeArrayEntry(chartBufferSize);
                lsm6dsoxGyroValuesY = new MySafeArrayEntry(chartBufferSize);
                lsm6dsoxGyroValuesZ = new MySafeArrayEntry(chartBufferSize);
                lps22hhPressValues = new MySafeArrayEntry(chartBufferSize);
                break;
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                lsm6dsv16xAccelValuesX = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16xAccelValuesY = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16xAccelValuesZ = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16xAccelValuesV = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16xGyroValuesX = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16xGyroValuesY = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16xGyroValuesZ = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16xQvarValues = new MySafeArrayEntry(chartBufferSize);
                break;
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                lsm6dsv16bxAccelValuesX = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16bxAccelValuesY = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16bxAccelValuesZ = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16bxAccelValuesV = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16bxGyroValuesX = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16bxGyroValuesY = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16bxGyroValuesZ = new MySafeArrayEntry(chartBufferSize);
                lsm6dsv16bxQvarValues = new MySafeArrayEntry(chartBufferSize);
                break;
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                lsm6dso16isAccelValuesX = new MySafeArrayEntry(chartBufferSize);
                lsm6dso16isAccelValuesY = new MySafeArrayEntry(chartBufferSize);
                lsm6dso16isAccelValuesZ = new MySafeArrayEntry(chartBufferSize);
                lsm6dso16isGyroValuesX = new MySafeArrayEntry(chartBufferSize);
                lsm6dso16isGyroValuesY = new MySafeArrayEntry(chartBufferSize);
                lsm6dso16isGyroValuesZ = new MySafeArrayEntry(chartBufferSize);
                lps22hhPressValues = new MySafeArrayEntry(chartBufferSize);
                break;
            default:
                break;
        }

        Button applyChartBufferSizeButton = mMainLayout.findViewById(R.id.applyChartBufferSizeButton);
        applyChartBufferSizeButton.setOnClickListener(v -> {
            try {
                chartBufferSize = Integer.parseInt(chartBufferSizeEditText.getText().toString());
                if (chartBufferSize < CHART_BUFFER_SIZE_MIN) {
                    chartBufferSize = CHART_BUFFER_SIZE_MIN;
                    chartBufferSizeEditText.setText(String.format(Locale.ENGLISH, "%d", CHART_BUFFER_SIZE_MIN));
                }
                else if (chartBufferSize > CHART_BUFFER_SIZE_MAX) {
                    chartBufferSize = CHART_BUFFER_SIZE_MAX;
                    chartBufferSizeEditText.setText(String.format(Locale.ENGLISH, "%d", CHART_BUFFER_SIZE_MAX));
                }

                switch (MyCtrlData.board_id)
                {
                    case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                        lsm6dsoxAccelValuesX.setLimit(chartBufferSize);
                        lsm6dsoxAccelValuesY.setLimit(chartBufferSize);
                        lsm6dsoxAccelValuesZ.setLimit(chartBufferSize);
                        lsm6dsoxGyroValuesX.setLimit(chartBufferSize);
                        lsm6dsoxGyroValuesY.setLimit(chartBufferSize);
                        lsm6dsoxGyroValuesZ.setLimit(chartBufferSize);
                        lps22hhPressValues.setLimit(chartBufferSize);
                        break;
                    case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                        lsm6dsv16xAccelValuesX.setLimit(chartBufferSize);
                        lsm6dsv16xAccelValuesY.setLimit(chartBufferSize);
                        lsm6dsv16xAccelValuesZ.setLimit(chartBufferSize);
                        lsm6dsv16xAccelValuesV.setLimit(chartBufferSize);
                        lsm6dsv16xGyroValuesX.setLimit(chartBufferSize);
                        lsm6dsv16xGyroValuesY.setLimit(chartBufferSize);
                        lsm6dsv16xGyroValuesZ.setLimit(chartBufferSize);
                        lsm6dsv16xQvarValues.setLimit(chartBufferSize);
                        break;
                    case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                        lsm6dsv16bxAccelValuesX.setLimit(chartBufferSize);
                        lsm6dsv16bxAccelValuesY.setLimit(chartBufferSize);
                        lsm6dsv16bxAccelValuesZ.setLimit(chartBufferSize);
                        lsm6dsv16bxAccelValuesV.setLimit(chartBufferSize);
                        lsm6dsv16bxGyroValuesX.setLimit(chartBufferSize);
                        lsm6dsv16bxGyroValuesY.setLimit(chartBufferSize);
                        lsm6dsv16bxGyroValuesZ.setLimit(chartBufferSize);
                        lsm6dsv16bxQvarValues.setLimit(chartBufferSize);
                        break;
                    case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                        lsm6dso16isAccelValuesX.setLimit(chartBufferSize);
                        lsm6dso16isAccelValuesY.setLimit(chartBufferSize);
                        lsm6dso16isAccelValuesZ.setLimit(chartBufferSize);
                        lsm6dso16isGyroValuesX.setLimit(chartBufferSize);
                        lsm6dso16isGyroValuesY.setLimit(chartBufferSize);
                        lsm6dso16isGyroValuesZ.setLimit(chartBufferSize);
                        lps22hhPressValues.setLimit(chartBufferSize);
                        break;
                    default:
                        break;
                }

                MySharedPreferences.getInstance(getContext()).setChartBufferSizeVal(Integer.toString(chartBufferSize));
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        });

        switch (MyCtrlData.board_id)
        {
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                SENSORS[0] = LSM6DSOX_ACCEL;
                SENSORS[1] = LSM6DSOX_GYRO;
                SENSORS[2] = LPS22HH_PRESS;

                // Set sensors name
                sensorNameCheckBox_arr.get(0).setText(R.string.lsm6dsox_accel_string);
                sensorNameCheckBox_arr.get(1).setText(R.string.lsm6dsox_gyro_string);
                sensorNameCheckBox_arr.get(2).setText(R.string.lps22hh_press_string);

                // Set checkboxes status
                sensorNameCheckBox_arr.get(0).setEnabled(MyCtrlData.lsm6dsoxAccelStream());
                sensorNameCheckBox_arr.get(1).setEnabled(MyCtrlData.lsm6dsoxGyroStream());
                sensorNameCheckBox_arr.get(2).setEnabled(MyCtrlData.lps22hhPressStream());
                sensorNameCheckBox_arr.get(0).setChecked(MyCtrlData.lsm6dsoxAccelStream());
                sensorNameCheckBox_arr.get(1).setChecked(MyCtrlData.lsm6dsoxGyroStream());
                sensorNameCheckBox_arr.get(2).setChecked(MyCtrlData.lps22hhPressStream());
                break;

            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                SENSORS[0] = LSM6DSV16X_ACCEL;
                SENSORS[1] = LSM6DSV16X_GYRO;
                SENSORS[2] = LSM6DSV16X_QVAR;

                // Set sensors name
                sensorNameCheckBox_arr.get(0).setText(R.string.lsm6dsv16x_accel_string);
                sensorNameCheckBox_arr.get(1).setText(R.string.lsm6dsv16x_gyro_string);
                sensorNameCheckBox_arr.get(2).setText(R.string.lsm6dsv16x_qvar_string);

                // Set checkboxes status
                sensorNameCheckBox_arr.get(0).setEnabled(MyCtrlData.lsm6dsv16xAccelStream());
                sensorNameCheckBox_arr.get(1).setEnabled(MyCtrlData.lsm6dsv16xGyroStream());
                sensorNameCheckBox_arr.get(2).setEnabled(MyCtrlData.lsm6dsv16xQvarStream());
                sensorNameCheckBox_arr.get(0).setChecked(MyCtrlData.lsm6dsv16xAccelStream());
                sensorNameCheckBox_arr.get(1).setChecked(MyCtrlData.lsm6dsv16xGyroStream());
                sensorNameCheckBox_arr.get(2).setChecked(MyCtrlData.lsm6dsv16xQvarStream());
                break;

            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                SENSORS[0] = LSM6DSV16BX_ACCEL;
                SENSORS[1] = LSM6DSV16BX_GYRO;
                SENSORS[2] = LSM6DSV16BX_QVAR;

                // Set sensors name
                sensorNameCheckBox_arr.get(0).setText(R.string.lsm6dsv16bx_accel_string);
                sensorNameCheckBox_arr.get(1).setText(R.string.lsm6dsv16bx_gyro_string);
                sensorNameCheckBox_arr.get(2).setText(R.string.lsm6dsv16bx_qvar_string);

                // Set checkboxes status
                sensorNameCheckBox_arr.get(0).setEnabled(MyCtrlData.lsm6dsv16bxAccelStream());
                sensorNameCheckBox_arr.get(1).setEnabled(MyCtrlData.lsm6dsv16bxGyroStream());
                sensorNameCheckBox_arr.get(2).setEnabled(MyCtrlData.lsm6dsv16bxQvarStream());
                sensorNameCheckBox_arr.get(0).setChecked(MyCtrlData.lsm6dsv16bxAccelStream());
                sensorNameCheckBox_arr.get(1).setChecked(MyCtrlData.lsm6dsv16bxGyroStream());
                sensorNameCheckBox_arr.get(2).setChecked(MyCtrlData.lsm6dsv16bxQvarStream());
                break;

            // TODO: add support to BOARD_ID_SENSORTILEBOX_PRO board
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                SENSORS[0] = LSM6DSO16IS_ACCEL;
                SENSORS[1] = LSM6DSO16IS_GYRO;
                SENSORS[2] = LPS22HH_PRESS;

                // Set sensors name
                sensorNameCheckBox_arr.get(0).setText(R.string.lsm6dso16is_accel_string);
                sensorNameCheckBox_arr.get(1).setText(R.string.lsm6dso16is_gyro_string);
                sensorNameCheckBox_arr.get(2).setText(R.string.lps22hh_press_string);

                // Set checkboxes status
                sensorNameCheckBox_arr.get(0).setEnabled(MyCtrlData.lsm6dso16isAccelStream());
                sensorNameCheckBox_arr.get(1).setEnabled(MyCtrlData.lsm6dso16isGyroStream());
                sensorNameCheckBox_arr.get(2).setEnabled(MyCtrlData.lps22hhPressStream());
                sensorNameCheckBox_arr.get(0).setChecked(MyCtrlData.lsm6dso16isAccelStream());
                sensorNameCheckBox_arr.get(1).setChecked(MyCtrlData.lsm6dso16isGyroStream());
                sensorNameCheckBox_arr.get(2).setChecked(MyCtrlData.lps22hhPressStream());
                break;

            default:
                break;
        }

        // Show/hide plots and register onCheckedChangeListener
        for (int i = 0; i < N_CHARTS; i++) {

            int finalI = i;
            sensorNameCheckBox_arr.get(i).setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked)
                    lineChart_arr.get(finalI).setVisibility(VISIBLE);
                else
                    lineChart_arr.get(finalI).setVisibility(GONE);
            });

            if (sensorNameCheckBox_arr.get(i).isChecked())
                lineChart_arr.get(i).setVisibility(VISIBLE);
            else
                lineChart_arr.get(i).setVisibility(GONE);
        }
    }

    // This function is called inside the BLE service
    public static void updateData()
    {
        try {
            float timestampF = (float)MyStreamData.timestamp / 1000.0f;
            if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_LOGGING) {
                switch (MyCtrlData.board_id) {
                    case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                        if (MyCtrlData.lsm6dsoxAccelStream()) {
                            lsm6dsoxAccelData(timestampF, MyStreamData.accX[0], MyStreamData.accY[0], MyStreamData.accZ[0]);
                        }

                        if (MyCtrlData.lsm6dsoxGyroStream()) {
                            lsm6dsoxGyroData(timestampF, MyStreamData.gyrX, MyStreamData.gyrY, MyStreamData.gyrZ);
                        }

                        if (MyCtrlData.lps22hhPressStream()) {
                            lps22hhPressData(timestampF, MyStreamData.press);
                        }
                        break;

                    case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                        if (MyCtrlData.ble_log == 1)
                        {
                            if (MyCtrlData.lsm6dsv16xAccelStream()) {
                                lsm6dsv16xAccelData(timestampF, MyStreamData.accX[0], MyStreamData.accY[0], MyStreamData.accZ[0], MyStreamData.accV[0]);
                            }

                            if (MyCtrlData.lsm6dsv16xGyroStream()) {
                                lsm6dsv16xGyroData(timestampF, MyStreamData.gyrX, MyStreamData.gyrY, MyStreamData.gyrZ);
                            }

                            if (MyCtrlData.lsm6dsv16xQvarStream()) {
                                lsm6dsv16xQvarData(timestampF, MyStreamData.qvar[0]);
                            }
                        }
                        else if (MyCtrlData.getBleHighRate())
                        {
                            // The board is streaming the Accel and the Qvar @ 240 Hz
                            for (int i = 0; i < 5; i++) {
                                lsm6dsv16xAccelData(internalTimestamp, MyStreamData.accX[i], MyStreamData.accY[i], MyStreamData.accZ[i], MyStreamData.accV[i]);
                                lsm6dsv16xQvarData(internalTimestamp, MyStreamData.qvar[i]);
                                internalTimestamp += (1000.0f / 240.0f);
                            }
                        }
                        break;

                    case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                        if (MyCtrlData.ble_log == 1)
                        {
                            if (MyCtrlData.lsm6dsv16bxAccelStream()) {
                                lsm6dsv16bxAccelData(timestampF, MyStreamData.accX[0], MyStreamData.accY[0], MyStreamData.accZ[0], MyStreamData.accV[0]);
                            }

                            if (MyCtrlData.lsm6dsv16bxGyroStream()) {
                                lsm6dsv16bxGyroData(timestampF, MyStreamData.gyrX, MyStreamData.gyrY, MyStreamData.gyrZ);
                            }

                            if (MyCtrlData.lsm6dsv16bxQvarStream()) {
                                lsm6dsv16bxQvarData(timestampF, MyStreamData.qvar[0]);
                            }
                        }
                        else if (MyCtrlData.getBleHighRate())
                        {
                            // The board is streaming the Accel and the Qvar @ 240 Hz
                            for (int i = 0; i < 5; i++) {
                                lsm6dsv16bxAccelData(internalTimestamp, MyStreamData.accX[i], MyStreamData.accY[i], MyStreamData.accZ[i], MyStreamData.accV[i]);
                                lsm6dsv16bxQvarData(internalTimestamp, MyStreamData.qvar[i]);
                                internalTimestamp += (1000.0f / 240.0f);
                            }
                        }
                        break;

                    // TODO: add support to BOARD_ID_SENSORTILEBOX_PRO board
                    case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                        if (MyCtrlData.lsm6dso16isAccelStream()) {
                            lsm6dso16isAccelData(timestampF, MyStreamData.accX[0], MyStreamData.accY[0], MyStreamData.accZ[0]);
                        }

                        if (MyCtrlData.lsm6dso16isGyroStream()) {
                            lsm6dso16isGyroData(timestampF, MyStreamData.gyrX, MyStreamData.gyrY, MyStreamData.gyrZ);
                        }

                        if (MyCtrlData.lps22hhPressStream()) {
                            lps22hhPressData(timestampF, MyStreamData.press);
                        }
                        break;

                    default:
                        break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE)
                    resetChartData();
                else if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_LOGGING && MyCtrlData.ble_log > 0) {
                    boolean[] updateChart = new boolean[N_CHARTS];
                    // add data
                    switch (MyCtrlData.board_id)
                    {
                        case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                            if (MyCtrlData.lsm6dsoxAccelStream()) {
                                updateChart[0] = true;
                                sensorNameCheckBox_arr.get(0).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(0).setEnabled(false);
                                sensorNameCheckBox_arr.get(0).setChecked(false);
                            }

                            if (MyCtrlData.lsm6dsoxGyroStream()) {
                                updateChart[1] = true;
                                sensorNameCheckBox_arr.get(1).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(1).setEnabled(false);
                                sensorNameCheckBox_arr.get(1).setChecked(false);
                            }

                            if (MyCtrlData.lps22hhPressStream()) {
                                updateChart[2] = true;
                                sensorNameCheckBox_arr.get(2).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(2).setEnabled(false);
                                sensorNameCheckBox_arr.get(2).setChecked(false);
                            }
                            break;

                        case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                            if (MyCtrlData.lsm6dsv16xAccelStream()) {
                                updateChart[0] = true;
                                sensorNameCheckBox_arr.get(0).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(0).setEnabled(false);
                                sensorNameCheckBox_arr.get(0).setChecked(false);
                            }

                            if (MyCtrlData.lsm6dsv16xGyroStream()) {
                                updateChart[1] = true;
                                sensorNameCheckBox_arr.get(1).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(1).setEnabled(false);
                                sensorNameCheckBox_arr.get(1).setChecked(false);
                            }

                            if (MyCtrlData.lsm6dsv16xQvarStream()) {
                                updateChart[2] = true;
                                sensorNameCheckBox_arr.get(2).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(2).setEnabled(false);
                                sensorNameCheckBox_arr.get(2).setChecked(false);
                            }
                            break;

                        case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                            if (MyCtrlData.lsm6dsv16bxAccelStream()) {
                                updateChart[0] = true;
                                sensorNameCheckBox_arr.get(0).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(0).setEnabled(false);
                                sensorNameCheckBox_arr.get(0).setChecked(false);
                            }

                            if (MyCtrlData.lsm6dsv16bxGyroStream()) {
                                updateChart[1] = true;
                                sensorNameCheckBox_arr.get(1).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(1).setEnabled(false);
                                sensorNameCheckBox_arr.get(1).setChecked(false);
                            }

                            if (MyCtrlData.lsm6dsv16bxQvarStream()) {
                                updateChart[2] = true;
                                sensorNameCheckBox_arr.get(2).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(2).setEnabled(false);
                                sensorNameCheckBox_arr.get(2).setChecked(false);
                            }
                            break;

                        case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                            if (MyCtrlData.lsm6dso16isAccelStream()) {
                                updateChart[0] = true;
                                sensorNameCheckBox_arr.get(0).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(0).setEnabled(false);
                                sensorNameCheckBox_arr.get(0).setChecked(false);
                            }

                            if (MyCtrlData.lsm6dso16isGyroStream()) {
                                updateChart[1] = true;
                                sensorNameCheckBox_arr.get(1).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(1).setEnabled(false);
                                sensorNameCheckBox_arr.get(1).setChecked(false);
                            }

                            if (MyCtrlData.lps22hhPressStream()) {
                                updateChart[2] = true;
                                sensorNameCheckBox_arr.get(2).setEnabled(true);
                            } else {
                                sensorNameCheckBox_arr.get(2).setEnabled(false);
                                sensorNameCheckBox_arr.get(2).setChecked(false);
                            }
                            break;

                        default:
                            break;
                    }

                    // Update charts
                    for (int i = 0; i < N_CHARTS; i++) {
                        if (updateChart[i])
                            updateChart(lineChart_arr.get(i), SENSORS[i]);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private static void resetChartData()
    {
        internalTimestamp = 0.0f;

        switch (MyCtrlData.board_id)
        {
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                lsm6dsoxAccelValuesX.clear();
                lsm6dsoxAccelValuesY.clear();
                lsm6dsoxAccelValuesZ.clear();
                lsm6dsoxGyroValuesX.clear();
                lsm6dsoxGyroValuesY.clear();
                lsm6dsoxGyroValuesZ.clear();
                lps22hhPressValues.clear();
                break;

            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                lsm6dsv16xAccelValuesX.clear();
                lsm6dsv16xAccelValuesY.clear();
                lsm6dsv16xAccelValuesZ.clear();
                lsm6dsv16xAccelValuesV.clear();
                lsm6dsv16xGyroValuesX.clear();
                lsm6dsv16xGyroValuesY.clear();
                lsm6dsv16xGyroValuesZ.clear();
                lsm6dsv16xQvarValues.clear();
                break;

            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                lsm6dsv16bxAccelValuesX.clear();
                lsm6dsv16bxAccelValuesY.clear();
                lsm6dsv16bxAccelValuesZ.clear();
                lsm6dsv16bxAccelValuesV.clear();
                lsm6dsv16bxGyroValuesX.clear();
                lsm6dsv16bxGyroValuesY.clear();
                lsm6dsv16bxGyroValuesZ.clear();
                lsm6dsv16bxQvarValues.clear();
                break;

            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                lsm6dso16isAccelValuesX.clear();
                lsm6dso16isAccelValuesY.clear();
                lsm6dso16isAccelValuesZ.clear();
                lsm6dso16isGyroValuesX.clear();
                lsm6dso16isGyroValuesY.clear();
                lsm6dso16isGyroValuesZ.clear();
                lps22hhPressValues.clear();
                break;

            default:
                break;
        }
    }

    private static void lsm6dsoxAccelData(float t, float x, float y, float z)
    {
        Entry eX = new Entry(t, x);
        Entry eY = new Entry(t, y);
        Entry eZ = new Entry(t, z);

        lsm6dsoxAccelValuesX.add(eX);
        lsm6dsoxAccelValuesY.add(eY);
        lsm6dsoxAccelValuesZ.add(eZ);
    }

    private static void lsm6dsoxGyroData(float t, float x, float y, float z)
    {
        Entry eX = new Entry(t, x);
        Entry eY = new Entry(t, y);
        Entry eZ = new Entry(t, z);

        lsm6dsoxGyroValuesX.add(eX);
        lsm6dsoxGyroValuesY.add(eY);
        lsm6dsoxGyroValuesZ.add(eZ);
    }

    private static void lps22hhPressData(float t, float val)
    {
        Entry e = new Entry(t, val);

        lps22hhPressValues.add(e);
    }

    private static void lsm6dsv16xAccelData(float t, float x, float y, float z, float v)
    {
        Entry eX = new Entry(t, x);
        Entry eY = new Entry(t, y);
        Entry eZ = new Entry(t, z);
        Entry eV = new Entry(t, v);

        lsm6dsv16xAccelValuesX.add(eX);
        lsm6dsv16xAccelValuesY.add(eY);
        lsm6dsv16xAccelValuesZ.add(eZ);
        lsm6dsv16xAccelValuesV.add(eV);
    }

    private static void lsm6dsv16xGyroData(float t, float x, float y, float z)
    {
        Entry eX = new Entry(t, x);
        Entry eY = new Entry(t, y);
        Entry eZ = new Entry(t, z);

        lsm6dsv16xGyroValuesX.add(eX);
        lsm6dsv16xGyroValuesY.add(eY);
        lsm6dsv16xGyroValuesZ.add(eZ);
    }

    private static void lsm6dsv16xQvarData(float t, float val)
    {
        Entry e = new Entry(t, val);

        lsm6dsv16xQvarValues.add(e);
    }

    private static void lsm6dsv16bxAccelData(float t, float x, float y, float z, float v)
    {
        Entry eX = new Entry(t, x);
        Entry eY = new Entry(t, y);
        Entry eZ = new Entry(t, z);
        Entry eV = new Entry(t, v);

        lsm6dsv16bxAccelValuesX.add(eX);
        lsm6dsv16bxAccelValuesY.add(eY);
        lsm6dsv16bxAccelValuesZ.add(eZ);
        lsm6dsv16bxAccelValuesV.add(eV);
    }

    private static void lsm6dsv16bxGyroData(float t, float x, float y, float z)
    {
        Entry eX = new Entry(t, x);
        Entry eY = new Entry(t, y);
        Entry eZ = new Entry(t, z);

        lsm6dsv16bxGyroValuesX.add(eX);
        lsm6dsv16bxGyroValuesY.add(eY);
        lsm6dsv16bxGyroValuesZ.add(eZ);
    }

    private static void lsm6dsv16bxQvarData(float t, float val)
    {
        Entry e = new Entry(t, val);

        lsm6dsv16bxQvarValues.add(e);
    }

    private static void lsm6dso16isAccelData(float t, float x, float y, float z)
    {
        Entry eX = new Entry(t, x);
        Entry eY = new Entry(t, y);
        Entry eZ = new Entry(t, z);

        lsm6dso16isAccelValuesX.add(eX);
        lsm6dso16isAccelValuesY.add(eY);
        lsm6dso16isAccelValuesZ.add(eZ);
    }

    private static void lsm6dso16isGyroData(float t, float x, float y, float z)
    {
        Entry eX = new Entry(t, x);
        Entry eY = new Entry(t, y);
        Entry eZ = new Entry(t, z);

        lsm6dso16isGyroValuesX.add(eX);
        lsm6dso16isGyroValuesY.add(eY);
        lsm6dso16isGyroValuesZ.add(eZ);
    }

    private void updateChart(LineChart lineChart, int sensor) {
        try {
            assert lineChart != null;
            if (lineChart.getData() != null && lineChart.getData().getDataSetCount() > 0) {

                ArrayList<Entry> valuesX = null;
                ArrayList<Entry> valuesY = null;
                ArrayList<Entry> valuesZ = null;
                ArrayList<Entry> valuesV = null;

                switch (sensor)
                {
                    case LSM6DSOX_ACCEL:
                        valuesX = lsm6dsoxAccelValuesX.get();
                        valuesY = lsm6dsoxAccelValuesY.get();
                        valuesZ = lsm6dsoxAccelValuesZ.get();
                        break;

                    case LSM6DSOX_GYRO:
                        valuesX = lsm6dsoxGyroValuesX.get();
                        valuesY = lsm6dsoxGyroValuesY.get();
                        valuesZ = lsm6dsoxGyroValuesZ.get();
                        break;

                    case LPS22HH_PRESS:
                        valuesX = lps22hhPressValues.get();
                        break;

                    case LSM6DSV16X_ACCEL:
                        valuesX = lsm6dsv16xAccelValuesX.get();
                        valuesY = lsm6dsv16xAccelValuesY.get();
                        valuesZ = lsm6dsv16xAccelValuesZ.get();
                        valuesV = lsm6dsv16xAccelValuesV.get();
                        break;

                    case LSM6DSV16X_GYRO:
                        valuesX = lsm6dsv16xGyroValuesX.get();
                        valuesY = lsm6dsv16xGyroValuesY.get();
                        valuesZ = lsm6dsv16xGyroValuesZ.get();
                        break;

                    case LSM6DSV16X_QVAR:
                        valuesX = lsm6dsv16xQvarValues.get();
                        break;

                    case LSM6DSV16BX_ACCEL:
                        valuesX = lsm6dsv16bxAccelValuesX.get();
                        valuesY = lsm6dsv16bxAccelValuesY.get();
                        valuesZ = lsm6dsv16bxAccelValuesZ.get();
                        valuesV = lsm6dsv16bxAccelValuesV.get();
                        break;

                    case LSM6DSV16BX_GYRO:
                        valuesX = lsm6dsv16bxGyroValuesX.get();
                        valuesY = lsm6dsv16bxGyroValuesY.get();
                        valuesZ = lsm6dsv16bxGyroValuesZ.get();
                        break;

                    case LSM6DSV16BX_QVAR:
                        valuesX = lsm6dsv16bxQvarValues.get();
                        break;

                    default:
                        break;
                }

                boolean xAvailable = valuesX != null && valuesX.size() > 0;
                boolean yAvailable = valuesY != null && valuesY.size() > 0;
                boolean zAvailable = valuesZ != null && valuesZ.size() > 0;
                boolean vAvailable = valuesV != null && valuesV.size() > 0;
                if (xAvailable || yAvailable || zAvailable || vAvailable)
                    updateMinMaxVerticalAxis(lineChart, valuesX, valuesY, valuesZ, valuesV);

                if (xAvailable) {
                    LineDataSet lineDataSetX = (LineDataSet) lineChart.getData().getDataSetByIndex(0);
                    lineDataSetX.setValues(valuesX);
                    lineDataSetX.notifyDataSetChanged();
                }
                if (yAvailable) {
                    LineDataSet lineDataSetY = (LineDataSet) lineChart.getData().getDataSetByIndex(1);
                    lineDataSetY.setValues(valuesY);
                    lineDataSetY.notifyDataSetChanged();
                }
                if (zAvailable) {
                    LineDataSet lineDataSetZ = (LineDataSet) lineChart.getData().getDataSetByIndex(2);
                    lineDataSetZ.setValues(valuesZ);
                    lineDataSetZ.notifyDataSetChanged();
                }
                if (vAvailable) {
                    LineDataSet lineDataSetV = (LineDataSet) lineChart.getData().getDataSetByIndex(3);
                    lineDataSetV.setValues(valuesV);
                    lineDataSetV.notifyDataSetChanged();
                }

                lineChart.getData().notifyDataChanged();
                lineChart.notifyDataSetChanged();

                // draw points over time
                lineChart.animateX(0);
            }
            else
            {
                ArrayList<ILineDataSet> dataSets = new ArrayList<>();
                LineDataSet setX;
                LineDataSet setY;
                LineDataSet setZ;
                LineDataSet setV;
                LineDataSet set;

                switch (sensor)
                {
                    case LSM6DSV16X_ACCEL:
                    case LSM6DSV16BX_ACCEL:
                        // X-axis
                        setX = new LineDataSet(null, "X-axis [LSB]");
                        setX.setColor(getContext().getColor(R.color.color_pink));
                        setX.setLineWidth(1f);
                        setX.setDrawCircles(false);
                        setX.setHighlightEnabled(false);
                        setX.setValueTextSize(0f);

                        // Y-axis
                        setY = new LineDataSet(null, "Y-axis [LSB]");
                        setY.setColor(getContext().getColor(R.color.color_green));
                        setY.setLineWidth(1f);
                        setY.setDrawCircles(false);
                        setY.setHighlightEnabled(false);
                        setY.setValueTextSize(0f);

                        // Z-axis
                        setZ = new LineDataSet(null, "Z-axis [LSB]");
                        setZ.setColor(getContext().getColor(R.color.color_blue));
                        setZ.setLineWidth(1f);
                        setZ.setDrawCircles(false);
                        setZ.setHighlightEnabled(false);
                        setZ.setValueTextSize(0f);

                        // V-axis
                        setV = new LineDataSet(null, "Norm Vector [LSB]");
                        setV.setColor(getContext().getColor(R.color.color_yellow));
                        setV.setLineWidth(1f);
                        setV.setDrawCircles(false);
                        setV.setHighlightEnabled(false);
                        setV.setValueTextSize(0f);

                        dataSets.add(setX);
                        dataSets.add(setY);
                        dataSets.add(setZ);
                        dataSets.add(setV);
                        break;
                    case LSM6DSOX_ACCEL:
                    case LSM6DSOX_GYRO:
                    case LSM6DSV16X_GYRO:
                    case LSM6DSV16BX_GYRO:
                        // X-axis
                        setX = new LineDataSet(null, "X-axis [LSB]");
                        setX.setColor(getContext().getColor(R.color.color_pink));
                        setX.setLineWidth(1f);
                        setX.setDrawCircles(false);
                        setX.setHighlightEnabled(false);
                        setX.setValueTextSize(0f);

                        // Y-axis
                        setY = new LineDataSet(null, "Y-axis [LSB]");
                        setY.setColor(getContext().getColor(R.color.color_green));
                        setY.setLineWidth(1f);
                        setY.setDrawCircles(false);
                        setY.setHighlightEnabled(false);
                        setY.setValueTextSize(0f);

                        // Z-axis
                        setZ = new LineDataSet(null, "Z-axis [LSB]");
                        setZ.setColor(getContext().getColor(R.color.color_blue));
                        setZ.setLineWidth(1f);
                        setZ.setDrawCircles(false);
                        setZ.setHighlightEnabled(false);
                        setZ.setValueTextSize(0f);

                        dataSets.add(setX);
                        dataSets.add(setY);
                        dataSets.add(setZ);
                        break;

                    case LPS22HH_PRESS:
                    case LSM6DSV16X_QVAR:
                    case LSM6DSV16BX_QVAR:
                        // Value
                        set = new LineDataSet(null, "Value [LSB]");
                        set.setColor(getContext().getColor(R.color.color_blue));
                        set.setLineWidth(1f);
                        set.setDrawCircles(false);
                        set.setHighlightEnabled(false);
                        set.setValueTextSize(0f);

                        dataSets.add(set);
                        break;

                    default:
                        break;
                }

                lineChart.setBackgroundColor(Color.WHITE);
                lineChart.getDescription().setEnabled(false);
                lineChart.setTouchEnabled(false);
                lineChart.setDrawGridBackground(false);
                lineChart.setDragEnabled(false);
                lineChart.setScaleEnabled(false);
                lineChart.setPinchZoom(false);
                lineChart.getAxisRight().setEnabled(false);

                AxisBase horizontalAxis;
                horizontalAxis = lineChart.getXAxis();
                horizontalAxis.disableAxisLineDashedLine();
                horizontalAxis.disableGridDashedLine();

                AxisBase verticalAxis;
                verticalAxis = lineChart.getAxisLeft();
                verticalAxis.disableAxisLineDashedLine();
                verticalAxis.disableGridDashedLine();

                LineData data = new LineData(dataSets);
                lineChart.setData(data);

                lineChart.animateX(0);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateMinMaxVerticalAxis(LineChart chart, ArrayList<Entry> valuesX, ArrayList<Entry> valuesY, ArrayList<Entry> valuesZ, ArrayList<Entry> valuesV)
    {
        float max = valuesX.get(0).getY();
        float min = valuesX.get(0).getY();

        for (int i = 1; i < valuesX.size(); i++)
        {
            if (valuesX != null && valuesX.size() > 0)
            {
                if (valuesX.get(i).getY() > max)
                    max = valuesX.get(i).getY();
                if (valuesX.get(i).getY() < min)
                    min = valuesX.get(i).getY();
            }
            if (valuesY != null && valuesY.size() > 0)
            {
                if (valuesY.get(i).getY() > max)
                    max = valuesY.get(i).getY();
                if (valuesY.get(i).getY() < min)
                    min = valuesY.get(i).getY();
            }
            if (valuesZ != null && valuesZ.size() > 0)
            {
                if (valuesZ.get(i).getY() > max)
                    max = valuesZ.get(i).getY();
                if (valuesZ.get(i).getY() < min)
                    min = valuesZ.get(i).getY();
            }
            if (valuesV != null && valuesV.size() > 0)
            {
                if (valuesV.get(i).getY() > max)
                    max = valuesV.get(i).getY();
                if (valuesV.get(i).getY() < min)
                    min = valuesV.get(i).getY();
            }
        }

        max += VERTICAL_AXIS_MIN_DELTA;
        min -= VERTICAL_AXIS_MIN_DELTA;

        AxisBase verticalAxis = chart.getAxisLeft();
        verticalAxis.setAxisMaximum(max);
        verticalAxis.setAxisMinimum(min);
    }
}

package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.opengl.GLSurfaceView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.threed.jpct.Camera;
import com.threed.jpct.FrameBuffer;
import com.threed.jpct.Light;
import com.threed.jpct.Loader;
import com.threed.jpct.Matrix;
import com.threed.jpct.Object3D;
import com.threed.jpct.RGBColor;
import com.threed.jpct.SimpleVector;
import com.threed.jpct.Texture;
import com.threed.jpct.TextureManager;
import com.threed.jpct.World;
import com.threed.jpct.util.BitmapHelper;
import com.threed.jpct.util.MemoryHelper;

import java.io.InputStream;
import java.util.Timer;
import java.util.TimerTask;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import st.oem.R;


@SuppressLint("ViewConstructor")
public class CardView_SFLP extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private Button mResetButton;
    private Button mLeftEarButton;
    private Button mRightEarButton;
    private GLSurfaceView mGLSurfaceView;
    private GlRenderer mGlRenderer;

    private CardView mMainLayout;

    private Timer mTimerUpdateUI;

    private boolean mLeftEar;
    private boolean mReset;

    // Rotation angle
    private Matrix rotM;
    private Matrix rotM_reset;
    private float qx, qy, qz, qw;
    private boolean quatReceived;

    // State
    private static Matrix rotM_reset_State;
    private static boolean mLeftEarState;

    public void saveState()
    {
        rotM_reset_State = rotM_reset;
        mLeftEarState = mLeftEar;
    }

    public void restoreState()
    {
        rotM_reset = rotM_reset_State;
        if (mLeftEarState) {
            mLeftEarButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
            mRightEarButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
            mLeftEar = true;
        } else {
            mLeftEarButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
            mRightEarButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
            mLeftEar = false;
        }
    }

    public void applyRotation(float qx, float qy, float qz, float qw)
    {
        this.qx = qx;
        this.qy = qy;
        this.qz = qz;
        this.qw = qw;
        this.quatReceived = true;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_QUATERNIONS_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mResetButton = null;
        mLeftEarButton = null;
        mRightEarButton = null;
        mGLSurfaceView = null;
        mGlRenderer = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_SFLP(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_sflp, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        quatReceived = false;

        if (!DemoFragment.getInstance().mBlindSettings)
            mReset = true;

        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        mGLSurfaceView = new GLSurfaceView(getContext());
        mGlRenderer = new GlRenderer();
        mGLSurfaceView.setRenderer(mGlRenderer);
        mGLSurfaceView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 600));
        mGLSurfaceView.setVisibility(INVISIBLE);
        
        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mViewLayout.addView(mGLSurfaceView);
        mResetButton = mMainLayout.findViewById(R.id.resetButton);
        mLeftEarButton = mMainLayout.findViewById(R.id.leftEarButton);
        mRightEarButton = mMainLayout.findViewById(R.id.rightEarButton);

        mResetButton.setOnClickListener(view -> mReset = true);

        if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3) ||
            (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B) ||
            (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX)))
        {
            mLeftEarButton.setOnClickListener(view -> {
                mLeftEarButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                mRightEarButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                mLeftEar = true;
                mReset = true;
            });

            mRightEarButton.setOnClickListener(view -> {
                mLeftEarButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                mRightEarButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                mLeftEar = false;
                mReset = true;
            });
        }
        else
        {
            mLeftEarButton.setVisibility(GONE);
            mRightEarButton.setVisibility(GONE);
        }
    }

    public class GlRenderer implements GLSurfaceView.Renderer {

        private FrameBuffer mFrameBuffer;
        private World mWorld;
        private Object3D mObject3D;

        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {

        }

        @Override
        public void onSurfaceChanged(GL10 gl, int width, int height) {
            // Create a FrameBuffer with width w and height h. If FrameBuffer is
            // not NULL, release the resources occupied by fb
            if (mFrameBuffer != null) {
                mFrameBuffer.dispose();
            }
            mFrameBuffer = new FrameBuffer(gl, width, height);

            // Create the World object
            mWorld = new World();

            // Create 3D object
            if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX)))
            {
                Drawable textureDrawable = ContextCompat.getDrawable(getContext(), R.drawable.skin);
                if (textureDrawable != null)
                {
                    Texture texture = new Texture(BitmapHelper.rescale(BitmapHelper.convert(textureDrawable), 256, 256), true);
                    try {
                        TextureManager.getInstance().addTexture("texture", texture);
                    }
                    catch (Exception ignored) { };

                    InputStream objStream = getResources().openRawResource(R.raw.free_head_swan3b_obj);

                    float scale;
                    if (getContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
                        scale = 1.0f;
                    else
                        scale = 0.5f;
                    Object3D[] objects = Loader.loadOBJ(objStream, null, scale);

                    mObject3D = Object3D.mergeAll(objects);
                    mObject3D.setTexture("texture");
                }
                else
                {
                    InputStream objStream = getResources().openRawResource(R.raw.free_head_swan3b_obj);
                    InputStream mtlStream = getResources().openRawResource(R.raw.free_head_swan3b_mtl);

                    float scale;
                    if (getContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
                        scale = 1.0f;
                    else
                        scale = 0.5f;
                    Object3D[] objects = Loader.loadOBJ(objStream, mtlStream, scale);

                    mObject3D = Object3D.mergeAll(objects);
                }
            }
            else
            {
                InputStream objStream = getResources().openRawResource(R.raw.free_robik_obj);
                InputStream mtlStream = getResources().openRawResource(R.raw.free_robik_mtl);

                float scale;
                if (getContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT)
                    scale = 0.05f;
                else
                    scale = 0.025f;
                Object3D[] objects = Loader.loadOBJ(objStream, mtlStream, scale);

                mObject3D = Object3D.mergeAll(objects);
            }

            mObject3D.strip();
            mObject3D.build();

            // Add 3D object to the world
            mWorld.addObject(mObject3D);

            // The Camera represents the position and direction of the Camera/viewer in the current scene, and it also contains information about the current field of view
            // You should remember that the rotation matrix of Camera is actually a rotation matrix of the object applied in World.
            // This is very important. When the camera rotation angle is selected, a Camera (virtual) rotates around w and rotates around World around w,
            // Will have the same effect. Therefore, considering the rotation angle, when the World surrounds the camera, the camera's perspective is static. If you don't like it
            // For this habit, you can use rotateCamera() method
            Camera cam = mWorld.getCamera();
            cam.moveCamera(Camera.CAMERA_MOVEOUT, 3);
            cam.lookAt(mObject3D.getCenter());

            // SimpleVector is a basic class representing three-dimensional vectors, almost every vector is
            // is constructed with SimpleVector or at least a SimpleVector variant (sometimes due to
            // Some reasons such as performance may use (float x, float y, float z), etc.).
            SimpleVector simpleVector = new SimpleVector();
            simpleVector.set(mObject3D.getCenter());
            simpleVector.z -= 100;
            //simpleVector.y -= 100;

            // Set the light source position
            // Create a new light source in World
            Light sun = new Light(mWorld);
            sun.setPosition(simpleVector);

            // Force GC and finalization work to try to release some memory, and write the current memory to the log,
            // This can avoid the inconsistent animation, however, it only reduces the chance of this happening
            MemoryHelper.compact();
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            try {
                if (rotM != null && mObject3D != null && mFrameBuffer != null && mWorld != null) {
                    mObject3D.setRotationMatrix(rotM);

                    // Clear the FrameBuffer with the given color (backColor)
                    RGBColor backColor = new RGBColor(255, 255, 255); // WHITE
                    mFrameBuffer.clear(backColor);

                    // Transform and light all polygons
                    mWorld.renderScene(mFrameBuffer);

                    // draw
                    mWorld.draw(mFrameBuffer);

                    // Render image display
                    mFrameBuffer.display();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (!DemoFragment.getInstance().getConfigurationOngoing() && quatReceived) {

                    // phone frame
                    float i;
                    float j;
                    float k;

                    if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3) ||
                        (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B))
                    {
                        if (mLeftEar) {
                            i = -qy;
                            j = qx;
                            k = -qz;
                        } else {
                            i = qy;
                            j = qx;
                            k = qz;
                        }
                    }
                    else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX))
                    {
                        // 1. phone frame on-table is WNU
                        // 2. align earbud with the ear (user stand-up) and phone like mirror
                        // 3. set the proper mapping:
                        //    - i, j, k are referred to phone (target)
                        //    - qx, qy, qz are referred to earbud (source)
                        // 4. invert signs of q referred to face pitch and face yaw for mirroring
                        if (mLeftEar) {
                            i = qz;
                            j = qy;
                            k = qx;
                        } else {
                            i = -qz;
                            j = qy;
                            k = -qx;
                        }
                    }
                    else
                    {
                        i = -qx;
                        j = qy;
                        k = qz;
                    }

                    float rxx = 1.0f - 2.0f * (j * j + k * k);
                    float rxy = 2.0f * (i * j - k * qw);
                    float rxz = 2.0f * (i * k + j * qw);
                    float ryx = 2.0f * (i * j + k * qw);
                    float ryy = 1.0f - 2.0f * (i * i + k * k);
                    float ryz = 2.0f * (j * k - i * qw);
                    float rzx = 2.0f * (i * k - j * qw);
                    float rzy = 2.0f * (j * k + i * qw);
                    float rzz = 1.0f - 2.0f * (i * i + j * j);

                    Matrix matrix = new Matrix();
                    matrix.set(0, 0, rxx);
                    matrix.set(0, 1, rxy);
                    matrix.set(0, 2, rxz);
                    matrix.set(1, 0, ryx);
                    matrix.set(1, 1, ryy);
                    matrix.set(1, 2, ryz);
                    matrix.set(2, 0, rzx);
                    matrix.set(2, 1, rzy);
                    matrix.set(2, 2, rzz);

                    if (mReset) {
                        mReset = false;

                        float i2 = -i;
                        float j2 = -j;
                        float k2 = -k;

                        float rxx2 = 1.0f - 2.0f * (j2 * j2 + k2 * k2);
                        float rxy2 = 2.0f * (i2 * j2 - k2 * qw);
                        float rxz2 = 2.0f * (i2 * k2 + j2 * qw);
                        float ryx2 = 2.0f * (i2 * j2 + k2 * qw);
                        float ryy2 = 1.0f - 2.0f * (i2 * i2 + k2 * k2);
                        float ryz2 = 2.0f * (j2 * k2 - i2 * qw);
                        float rzx2 = 2.0f * (i2 * k2 - j2 * qw);
                        float rzy2 = 2.0f * (j2 * k2 + i2 * qw);
                        float rzz2 = 1.0f - 2.0f * (i2 * i2 + j2 * j2);

                        Matrix matrix2 = new Matrix();
                        matrix2.set(0, 0, rxx2);
                        matrix2.set(0, 1, rxy2);
                        matrix2.set(0, 2, rxz2);
                        matrix2.set(1, 0, ryx2);
                        matrix2.set(1, 1, ryy2);
                        matrix2.set(1, 2, ryz2);
                        matrix2.set(2, 0, rzx2);
                        matrix2.set(2, 1, rzy2);
                        matrix2.set(2, 2, rzz2);
                        rotM_reset = matrix2.cloneMatrix();
                    }

                    if (rotM_reset != null) {
                        matrix.matMul(rotM_reset);
                    }

                    rotM = matrix.cloneMatrix();

                    mGLSurfaceView.setVisibility(VISIBLE);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

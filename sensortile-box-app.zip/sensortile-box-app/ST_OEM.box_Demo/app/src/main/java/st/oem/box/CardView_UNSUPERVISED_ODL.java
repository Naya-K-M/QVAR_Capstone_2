package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_UNSUPERVISED_ODL extends CardView {

    private static final Short ACTIVITY_ID_REMOVED = -1;
    private static class Activity {
        public Short id;
        public String name;
        public Integer iconResId;
        public Drawable iconDrawable;
        public Short repCount;
    }

    @SuppressLint("StaticFieldLeak")    // TODO: check how to handle it
    private static ImageView customActivityImageView;
    private static Drawable customIconDrawable;

    private TextView unsupervisedOdlActivityNameTextView;
    private ImageView unsupervisedOdlActivityIconImageView;
    private TextView unsupervisedOdlRepCountTextView;
    private CircularProgressBar unsupervisedOdlCircularProgressBar;
    private View unsupervisedOdlMetric0View;
    private View unsupervisedOdlMetric1View;
    private View unsupervisedOdlMetric2View;
    private View unsupervisedOdlMetric3View;
    private Button stopButton;
    private Button inferenceButton;
    private Button repCountButton;
    private Button trainingButton;
    private Button deleteButton;
    private Button eraseButton;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    private short window_counter_old;
    private short erase_status_old;
    private short activity_id_old;
    private short rep_count_old;
    private boolean is_running;

    private ArrayList<Activity> activities = new ArrayList<>();

    public static boolean mIspuPacketReceived = false;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_UNSUPERVISED_ODL_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        unsupervisedOdlActivityNameTextView = null;
        unsupervisedOdlActivityIconImageView = null;
        unsupervisedOdlRepCountTextView = null;
        unsupervisedOdlCircularProgressBar = null;
        unsupervisedOdlMetric0View = null;
        unsupervisedOdlMetric1View = null;
        unsupervisedOdlMetric2View = null;
        unsupervisedOdlMetric3View = null;
        stopButton = null;
        inferenceButton = null;
        repCountButton = null;
        trainingButton = null;
        deleteButton = null;
        eraseButton = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }

        activities.clear();
        activities = null;
    }

    @SuppressLint("InflateParams")
    public CardView_UNSUPERVISED_ODL(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_unsupervised_odl, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        window_counter_old = 0;
        erase_status_old = 0;
        activity_id_old = 0;
        rep_count_old = 0;
        is_running = false;

        inferenceButton = mMainLayout.findViewById(R.id.inferenceButton);
        repCountButton = mMainLayout.findViewById(R.id.repCountButton);
        trainingButton = mMainLayout.findViewById(R.id.trainingButton);
        deleteButton = mMainLayout.findViewById(R.id.deleteButton);
        eraseButton = mMainLayout.findViewById(R.id.eraseButton);
        unsupervisedOdlCircularProgressBar = mMainLayout.findViewById(R.id.unsupervisedOdlCircularProgressBar);
        unsupervisedOdlMetric0View = mMainLayout.findViewById(R.id.metric0View);
        unsupervisedOdlMetric1View = mMainLayout.findViewById(R.id.metric1View);
        unsupervisedOdlMetric2View = mMainLayout.findViewById(R.id.metric2View);
        unsupervisedOdlMetric3View = mMainLayout.findViewById(R.id.metric3View);

        // Configure ProgressBar
        unsupervisedOdlCircularProgressBar.setProgressBarColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
        unsupervisedOdlCircularProgressBar.setBackgroundProgressBarColor(ContextCompat.getColor(getContext(), R.color.color_grey));
        unsupervisedOdlCircularProgressBar.setProgressBarWidth(20f); // in DP
        unsupervisedOdlCircularProgressBar.setBackgroundProgressBarWidth(15f); // in DP

        repCountButton.setVisibility(GONE);

        stopButton = mMainLayout.findViewById(R.id.stopButton);
        unsupervisedOdlActivityIconImageView = mMainLayout.findViewById(R.id.unsupervisedOdlActivityIconImageView);
        unsupervisedOdlActivityNameTextView = mMainLayout.findViewById(R.id.unsupervisedOdlActivityNameTextView);
        unsupervisedOdlRepCountTextView = mMainLayout.findViewById(R.id.unsupervisedOdlRepCountTextView);

        stopButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    BLECommands.sendWriteLSM6DSOX(getContext(), "73", "00");
                    is_running = false;
                    unsupervisedOdlCircularProgressBar.setProgress(0f);
                    resetRepCounts();
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        inferenceButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    boolean activityFound = false;
                    for (short i = 1; i < activities.size(); i++) {
                        if (activities.get(i).id != ACTIVITY_ID_REMOVED) {
                            activityFound = true;
                            break;
                        }
                    }
                    if (activityFound) {
                        BLECommands.sendWriteLSM6DSOX(getContext(), "73", "01");
                        unsupervisedOdlCircularProgressBar.setProgressMax(52f);
                        is_running = true;
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_unsupervised_odl_run_training), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        repCountButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    BLECommands.sendWriteLSM6DSOX(getContext(), "73", "02");
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        trainingButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    BLECommands.sendWriteLSM6DSOX(getContext(), "73", "03");
                    unsupervisedOdlCircularProgressBar.setProgressMax(154f);
                    is_running = true;
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        deleteButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    boolean activityFound = false;
                    for (short i = 1; i < activities.size(); i++) {
                        if (activities.get(i).id != ACTIVITY_ID_REMOVED) {
                            activityFound = true;
                            break;
                        }
                    }
                    if (activityFound) {
                        showDeleteActivityDialog();
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_unsupervised_odl_run_training), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        eraseButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    BLECommands.sendWriteLSM6DSOX(getContext(), "73", "04");
                    is_running = true;
                    resetAlgo();
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        resetAlgo();

        mIspuPacketReceived = false;
        window_counter_old = 0;
        erase_status_old = 0;
        activity_id_old = 0;
        rep_count_old = 0;
    }

    private void methodUITimer() {
        ((android.app.Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (mIspuPacketReceived)
                {
                    mIspuPacketReceived = false;

                    if (is_running) {
                        // Handle training end event and update progress bar
                        short windowCounterCurr = Short.parseShort(MyJson.getConvertedOutput(1));
                        unsupervisedOdlCircularProgressBar.setProgress(windowCounterCurr);
                        if (windowCounterCurr == 0 && window_counter_old > 100) {
                            showActivityNameIconDialog();
                            stopButton.performClick();
                        }
                        window_counter_old = windowCounterCurr;

                        // Handle heatmap
                        float metric0 = Float.parseFloat(MyJson.getConvertedOutput(8));
                        int conv0 = 255 - (int)(192.0F * Math.abs(metric0 - 0.5f) / 0.5f);
                        if (metric0 >= 0.5f) {
                            conv0 = 0xAA00FF00 | (conv0 << 16) | (conv0); // green
                        } else {
                            conv0 = 0xAAFF0000 | (conv0 << 8) | (conv0); // red

                        }
                        unsupervisedOdlMetric0View.setBackgroundColor(conv0);

                        float metric1 = Float.parseFloat(MyJson.getConvertedOutput(9));
                        int conv1 = 255 - (int)(192.0F * Math.abs(metric1 - 0.5f) / 0.5f);
                        if (metric1 >= 0.5f) {
                            conv1 = 0xAA00FF00 | (conv1 << 16) | (conv1); // green
                        } else {
                            conv1 = 0xAAFF0000 | (conv1 << 8) | (conv1); // red

                        }
                        unsupervisedOdlMetric1View.setBackgroundColor(conv1);

                        float metric2 = Float.parseFloat(MyJson.getConvertedOutput(10));
                        int conv2 = 255 - (int)(192.0F * Math.abs(metric2 - 0.5f) / 0.5f);
                        if (metric2 >= 0.5f) {
                            conv2 = 0xAA00FF00 | (conv2 << 16) | (conv2); // green
                        } else {
                            conv2 = 0xAAFF0000 | (conv2 << 8) | (conv2); // red

                        }
                        unsupervisedOdlMetric2View.setBackgroundColor(conv2);

                        float metric3 = Float.parseFloat(MyJson.getConvertedOutput(11));
                        int conv3 = 255 - (int)(192.0F * Math.abs(metric3 - 0.5f) / 0.5f);
                        if (metric3 >= 0.5f) {
                            conv3 = 0xAA00FF00 | (conv3 << 16) | (conv3); // green
                        } else {
                            conv3 = 0xAAFF0000 | (conv3 << 8) | (conv3); // red

                        }
                        unsupervisedOdlMetric3View.setBackgroundColor(conv3);

                        // Handle erase event
                        short eraseStatusCurr = Short.parseShort(MyJson.getConvertedOutput(6));
                        if (eraseStatusCurr == 0 && erase_status_old == 1) {
                            stopButton.performClick();
                        }
                        erase_status_old = eraseStatusCurr;

                        // Update activityId icon / text
                        short activityId = Short.parseShort(MyJson.getConvertedOutput(3));
                        // Get activity index
                        int index;
                        for (index = 0; index < activities.size(); index++) {
                            if (activities.get(index).id == activityId)
                                break;
                        }
                        if (activities.get(index).iconResId == -1)
                            unsupervisedOdlActivityIconImageView.setImageDrawable(activities.get(index).iconDrawable);
                        else
                            unsupervisedOdlActivityIconImageView.setImageResource(activities.get(index).iconResId);
                        unsupervisedOdlActivityNameTextView.setText(activities.get(index).name);

                        // Update repCount
                        short repCountCurr = Short.parseShort(MyJson.getConvertedOutput(2));
                        if (repCountCurr != rep_count_old) {
                            int delta = repCountCurr - rep_count_old;
                            int val = activities.get(index).repCount + delta;
                            activities.get(index).repCount = (short) val;
                        }
                        rep_count_old = repCountCurr;

                        unsupervisedOdlRepCountTextView.setText(String.valueOf(activities.get(index).repCount));

                        // Update event card if shown
                        boolean eventDetected = (activityId != activity_id_old);
                        if (eventDetected) {
                            DemoFragment.getInstance().addEventToCardEvent("Activity ID: " + activityId);
                        }
                        activity_id_old = activityId;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void deleteActivity(short activityId)
    {
        unsupervisedOdlCircularProgressBar.setProgress(0f);

        // Get activity index
        int index;
        for (index = 0; index < activities.size(); index++) {
            if (activities.get(index).id == activityId)
                break;
        }
        activities.get(index).id = ACTIVITY_ID_REMOVED;

        window_counter_old = 0;
        erase_status_old = 0;
        activity_id_old = 0;
        rep_count_old = 0;

        resetUI();
    }

    public void addNewActivity(int id, String name, int iconResId, Drawable iconDrawable, int repCount)
    {
        Activity newActivity = new Activity();
        newActivity.id = (short) id;
        newActivity.name = name;
        newActivity.iconResId = iconResId;
        newActivity.iconDrawable = iconDrawable;
        newActivity.repCount = (short) repCount;

        try {
            activities.set(id, newActivity);
        } catch (Exception e) {
            activities.add(newActivity);
        }
    }

    private void resetAlgo() {
        unsupervisedOdlCircularProgressBar.setProgress(0f);

        activities.clear();
        addNewActivity(0, getContext().getString(R.string.other_string), R.drawable.still, null, 0);

        window_counter_old = 0;
        erase_status_old = 0;
        activity_id_old = 0;
        rep_count_old = 0;

        resetUI();
    }

    private void resetRepCounts() {
        for (int i = 0; i < activities.size(); i++)
            activities.get(i).repCount = 0;
        rep_count_old = 0;

        resetUI();
    }

    private void resetUI() {
        unsupervisedOdlActivityIconImageView.setImageResource(R.drawable.still);
        unsupervisedOdlActivityNameTextView.setText(R.string.other_string);
        unsupervisedOdlRepCountTextView.setText(String.valueOf(0));
    }

    private void showActivityNameIconDialog() {
        Dialog newActivityDialog = new Dialog(getContext(), R.style.SettingsDialog);
        newActivityDialog.setTitle(getContext().getString(R.string.activity_name_icon_title_string));
        newActivityDialog.setContentView(R.layout.dialog_unsupervised_odl_new_activity);
        newActivityDialog.setCancelable(false);

        TextView newActivityIdTextView = newActivityDialog.findViewById(R.id.newActivityIdTextView);
        // Custom activity
        customActivityImageView = newActivityDialog.findViewById(R.id.customActivityImageView);
        EditText customActivityEditText = newActivityDialog.findViewById(R.id.customActivityEditText);
        Button selectCustomActivityButton = newActivityDialog.findViewById(R.id.selectCustomActivityButton);
        // Predefined activity
        Button selectHandCurlButton = newActivityDialog.findViewById(R.id.selectHandCurlButton);
        Button selectWristRotateButton = newActivityDialog.findViewById(R.id.selectWristRotateButton);
        Button selectSquatButton = newActivityDialog.findViewById(R.id.selectSquatButton);
        Button selectLateralRisesButton = newActivityDialog.findViewById(R.id.selectLateralRisesButton);
        Button discardButton = newActivityDialog.findViewById(R.id.discardButton);

        // Set default drawable to NONE
        customIconDrawable = ContextCompat.getDrawable(getContext(), R.drawable.none);
        customActivityImageView.setImageDrawable(customIconDrawable);

        // Launch intent for opening image file picker
        customActivityImageView.setOnClickListener(v -> {
            String EXTRA_KEY_OP_ID_String = getContext().getString(R.string.INTENT_EXTRA_KEY_OP_ID);
            Intent intent = new Intent(DemoListFragment.INTENT_FILE_PICKER_FILTER);
            intent.putExtra(EXTRA_KEY_OP_ID_String, DemoListFragment.MESSAGE_ID_FILE_PICKER_IMAGE);
            getContext().sendBroadcast(intent);
        });

        // Compute activity id
        short idNew = (short)activities.size();
        for (short i = 0; i < activities.size(); i++) {
            if (activities.get(i).id == ACTIVITY_ID_REMOVED) {
                idNew = i;
                break;
            }
        }
        String str = String.format(getResources().getString(R.string.activity_id_string), idNew);
        newActivityIdTextView.setText(str);

        short finalIdNew = idNew;
        selectCustomActivityButton.setOnClickListener(v -> {
            String customActivityName = customActivityEditText.getText().toString().trim();
            if (customActivityName.isEmpty()) {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_set_activity_name), Toast.LENGTH_SHORT).show();
            } else {
                addNewActivity(finalIdNew, customActivityEditText.getText().toString(), -1, customIconDrawable, 0);
                newActivityDialog.dismiss();
            }
        });

        selectHandCurlButton.setOnClickListener(v -> {
            addNewActivity(finalIdNew, getResources().getString(R.string.activity_hand_curl), R.drawable.hand_curl, null,0);
            newActivityDialog.dismiss();
        });

        selectWristRotateButton.setOnClickListener(v -> {
            addNewActivity(finalIdNew, getResources().getString(R.string.activity_wrist_rotate), R.drawable.wrist_rotate, null, 0);
            newActivityDialog.dismiss();
        });

        selectSquatButton.setOnClickListener(v -> {
            addNewActivity(finalIdNew, getResources().getString(R.string.activity_squat), R.drawable.squat_down, null, 0);
            newActivityDialog.dismiss();
        });

        selectLateralRisesButton.setOnClickListener(v -> {
            addNewActivity(finalIdNew, getResources().getString(R.string.activity_lateral_rises), R.drawable.lateral_raises, null, 0);
            newActivityDialog.dismiss();
        });

        discardButton.setOnClickListener(v -> {
            BLECommands.sendWriteLSM6DSOX(getContext(), "73", finalIdNew + "5");
            stopButton.performClick();
            newActivityDialog.dismiss();
        });

        newActivityDialog.show();
    }

    public static void setCustomDrawable(Context context, Uri uri)
    {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(uri);
            customIconDrawable = Drawable.createFromStream(inputStream, uri.toString());
            customActivityImageView.setImageDrawable(customIconDrawable);
        } catch (FileNotFoundException ignored) {

        }
    }

    private void showDeleteActivityDialog() {
        Dialog deleteActivityDialog = new Dialog(getContext(), R.style.SettingsDialog);
        deleteActivityDialog.setTitle(getContext().getString(R.string.delete_activity));
        deleteActivityDialog.setContentView(R.layout.dialog_unsupervised_odl_delete_activity);
        deleteActivityDialog.setCancelable(true);

        LinearLayout unsupervisedOdlDeleteActivityLinearLayout = deleteActivityDialog.findViewById(R.id.unsupervisedOdlDeleteActivityLinearLayout);

        for (short i = 1; i < activities.size(); i++) {
            if (activities.get(i).id != ACTIVITY_ID_REMOVED) {
                View entry = LayoutInflater.from(getContext()).inflate(R.layout.dialog_unsupervised_odl_delete_activity_entry, unsupervisedOdlDeleteActivityLinearLayout, false);

                ImageView image = entry.findViewById(R.id.activityImageView);
                if (activities.get(i).iconResId == -1)
                    image.setImageDrawable(activities.get(i).iconDrawable);
                else
                    image.setImageResource(activities.get(i).iconResId);

                TextView activityIdText = entry.findViewById(R.id.activityIdTextView);
                activityIdText.setText(String.format(getResources().getString(R.string.id_string), activities.get(i).id));

                TextView activityNameText = entry.findViewById(R.id.activityNameTextView);
                activityNameText.setText(activities.get(i).name);

                Button deleteButton = entry.findViewById(R.id.deleteButton);

                short finalI = i;
                deleteButton.setOnClickListener(v -> {
                    if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                        if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                            BLECommands.sendWriteLSM6DSOX(getContext(), "73", finalI + "5");
                            deleteActivity(finalI);
                            stopButton.performClick();
                            deleteActivityDialog.dismiss();
                        } else {
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                    }
                });

                unsupervisedOdlDeleteActivityLinearLayout.addView(entry);
            }
        }

        deleteActivityDialog.show();
    }
}

package st.oem.box;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.le.ScanResult;

import java.util.Objects;

public class BluetoothDeviceObject
{
    private final BluetoothDevice bluetoothDevice;
    private final String name;
    private final String address;
    private final int RSSI;

    public BluetoothDeviceObject(ScanResult result) {
        this.name = Objects.requireNonNull(result.getScanRecord()).getDeviceName();
        this.RSSI = result.getRssi();
        this.address = result.getDevice().getAddress();
        this.bluetoothDevice = result.getDevice();
    }

    public String getName() {
        return name;
    }

    public String getPowerLevel() {
        return Integer.toString(RSSI);
    }

    public BluetoothDevice getBluetoothDevice() {
        return bluetoothDevice;
    }

    public String getAddress() {
        return address;
    }
}

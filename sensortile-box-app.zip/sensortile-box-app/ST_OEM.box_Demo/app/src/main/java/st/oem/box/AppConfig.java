package st.oem.box;

import android.annotation.SuppressLint;
import android.content.Context;

import java.util.ArrayList;
import java.util.Arrays;

import st.oem.R;

/**
 * Created by s rivolta on 4/18/2018.
 */

class AppConfig {

    private final Context mContext;

    // Tabs names
    final static String SMARTPHONE_DEMO_STR = "Smartphone";
    final static String WEARABLE_DEMO_STR = "Wearable";
    final static String PC_DEMO_STR = "Personal Computing";
    final static String AUTOMOTIVE_DEMO_STR = "Automotive";
    final static String EARABLE_DEMO_STR = "Earable";
    final static String GENERIC_DEMO_STR = "Generic";
    final static String SW_LIB_DEMO_STR = "Software Libraries";
    final static String TOOLS_STR = "Tools";

    // Cards names
    final static String FINITE_STATE_MACHINE_STR = "Finite State Machine";
    final static String MACHINE_LEARNING_CORE_STR = "Machine Learning Core";
    final static String EMBEDDED_FUNCTION_STR = "Embedded Function";
    final static String PEDOMETER_2_0_STR = "Pedometer 2.0";
    final static String SENSOR_FUSION_LOW_POWER_STR = "Sensor Fusion Low Power";
    final static String ISPU_STR = "ISPU";
    final static String SW_LIB_STR = "SW Library";

    // Demo customization types
    final static String EVENT_BASED_STR = "EVENT-BASED";
    final static String MANY_EVENT_BASED_STR = "MANY_EVENT_BASED";  // Same FSM with multiple OUTS values
    final static String CONTINUOUS_STR = "CONTINUOUS";
    final static String COUNTER_STR = "COUNTER";
    final static String MULTIPLE_OUTPUTS_STR = "MULTIPLE_OUTPUTS";        // Multiple FSMs with single event
    final static byte IDLE = 0;
    final static byte EVENT = 1;

    // To manage embedded
    final static String FREE_FALL_STR = "FREE-FALL";
    final static String WAKE_UP_STR = "WAKE-UP";
    final static String SINGLE_TAP_STR = "SINGLE-TAP";
    final static String DOUBLE_TAP_STR = "DOUBLE-TAP";
    final static String TRIPLE_TAP_STR = "TRIPLE-TAP";

    // Show/Hide demo categories and features
    public int SMARTPHONE_DEMO_EN;
    public int WEARABLE_DEMO_EN;
    public int PC_DEMO_EN;
    public int AUTOMOTIVE_DEMO_EN;
    public int EARABLE_DEMO_EN;
    public int GENERIC_DEMO_EN;
    public int SW_LIB_DEMO_EN;
    public int TOOLS_EN;

    // Other features
    public int MICROPHONE_LOG_EN;
    public int SEND_ZIP_CONFIG_EN;
    public int DEMO_SD_LOG_EN;

    // Algorithms SMARTPHONE
    private boolean LSM6DSOX_SMARTPHONE_ACTIVITY_RECOGNITION;
    private boolean LSM6DSOX_SMARTPHONE_ACTIVITY_RECOGNITION_CAR;
    private boolean LSM6DSOX_SMARTPHONE_MOTION_INTENSITY;
    private boolean LSM6DSOX_SMARTPHONE_GLANCE_DEGLANCE;
    private boolean LSM6DSOX_SMARTPHONE_PHONE_TO_EAR;
    private boolean LSM6DSOX_SMARTPHONE_PICK_UP;
    private boolean LSM6DSOX_SMARTPHONE_FLIP_UP;
    private boolean LSM6DSOX_SMARTPHONE_FLIP_DOWN;
    private boolean LSM6DSOX_SMARTPHONE_SHAKE;
    private boolean LSM6DSOX_SMARTPHONE_PEDOMETER;

    private boolean LSM6DSV16X_SMARTPHONE_ACTIVITY_RECOGNITION;
    private boolean LSM6DSV16X_SMARTPHONE_GLANCE_DEGLANCE;
    private boolean LSM6DSV16X_SMARTPHONE_PHONE_TO_EAR;
    private boolean LSM6DSV16X_SMARTPHONE_PICK_UP;
    private boolean LSM6DSV16X_SMARTPHONE_FLIP_UP;
    private boolean LSM6DSV16X_SMARTPHONE_FLIP_DOWN;
    private boolean LSM6DSV16X_SMARTPHONE_SHAKE;

    private boolean LSM6DSV32X_SMARTPHONE_ACTIVITY_RECOGNITION;
    private boolean LSM6DSV32X_SMARTPHONE_GLANCE_DEGLANCE;
    private boolean LSM6DSV32X_SMARTPHONE_PHONE_TO_EAR;
    private boolean LSM6DSV32X_SMARTPHONE_PICK_UP;
    private boolean LSM6DSV32X_SMARTPHONE_FLIP_UP;
    private boolean LSM6DSV32X_SMARTPHONE_FLIP_DOWN;
    private boolean LSM6DSV32X_SMARTPHONE_SHAKE;

    private boolean LIS2DUXS12_SMARTPHONE_GLANCE_DEGLANCE;
    private boolean LIS2DUXS12_SMARTPHONE_PICK_UP;
    private boolean LIS2DUXS12_SMARTPHONE_FLIP_UP;
    private boolean LIS2DUXS12_SMARTPHONE_FLIP_DOWN;
    private boolean LIS2DUXS12_SMARTPHONE_SHAKE;

    // Algorithms WEARABLE
    private boolean LSM6DSOX_WEARABLE_ACTIVITY_RECOGNITION;
    private boolean LSM6DSOX_WEARABLE_GYM_ACTIVITY;
    private boolean LSM6DSOX_WEARABLE_WRIST_TILT_XL;
    private boolean LSM6DSOX_WEARABLE_WRIST_TILT_XLG;
    private boolean LSM6DSOX_WEARABLE_WRIST_TILT_ENHANCED;
    private boolean LSM6DSOX_WEARABLE_WRIST_TILT_XL_FACEBOOK;
    private boolean LSM6DSOX_WEARABLE_WRIST_TILT_XLG_FACEBOOK;
    private boolean LSM6DSOX_WEARABLE_WRIST_TILT_ENHANCED_FACEBOOK;
    private boolean LSM6DSOX_WEARABLE_JIGGLE;
    private boolean LSM6DSOX_WEARABLE_WEAROS_NAVIGATION;
    private boolean LSM6DSOX_WEARABLE_SINGLE_TAP;
    private boolean LSM6DSOX_WEARABLE_DOUBLE_TAP;
    private boolean LSM6DSOX_WEARABLE_ENHANCED_TAP;
    private boolean LSM6DSOX_WEARABLE_PEDOMETER;
    private boolean LSM6DSOX_WEARABLE_SLEEP_MONITORING;
    private boolean LSM6DSOX_WEARABLE_MAN_DOWN;

    private boolean LSM6DSV16X_WEARABLE_WEARABLE_PACK;
    private boolean LSM6DSV16X_WEARABLE_QVAR_TOUCH;
    private boolean LSM6DSV16X_WEARABLE_QVAR_SWIPE;
    private boolean LSM6DSV16X_WEARABLE_ACTIVITY_RECOGNITION;
    private boolean LSM6DSV16X_WEARABLE_GYM_ACTIVITY;
    private boolean LSM6DSV16X_WEARABLE_WRIST_TILT_XL;
    private boolean LSM6DSV16X_WEARABLE_WRIST_TILT_XLG;
    private boolean LSM6DSV16X_WEARABLE_JIGGLE;
    private boolean LSM6DSV16X_WEARABLE_WEAROS_NAVIGATION;
    private boolean LSM6DSV16X_WEARABLE_SINGLE_TAP;
    private boolean LSM6DSV16X_WEARABLE_DOUBLE_TAP;
    private boolean LSM6DSV16X_WEARABLE_SINGLE_DOUBLE_TAP;
    private boolean LSM6DSV16X_WEARABLE_DOUBLE_CLENCH;
    private boolean LSM6DSV16X_WEARABLE_HARD_FALL;

    private boolean LSM6DSV32X_WEARABLE_WEARABLE_PACK;
    private boolean LSM6DSV32X_WEARABLE_ACTIVITY_RECOGNITION;
    private boolean LSM6DSV32X_WEARABLE_GYM_ACTIVITY;
    private boolean LSM6DSV32X_WEARABLE_WRIST_TILT_XL;
    private boolean LSM6DSV32X_WEARABLE_WRIST_TILT_XLG;
    private boolean LSM6DSV32X_WEARABLE_JIGGLE;
    private boolean LSM6DSV32X_WEARABLE_WEAROS_NAVIGATION;
    private boolean LSM6DSV32X_WEARABLE_SINGLE_TAP;
    private boolean LSM6DSV32X_WEARABLE_DOUBLE_TAP;
    private boolean LSM6DSV32X_WEARABLE_SINGLE_DOUBLE_TAP;
    private boolean LSM6DSV32X_WEARABLE_DOUBLE_CLENCH;
    private boolean LSM6DSV32X_WEARABLE_HARD_FALL;

    private boolean LSM6DSV16BX_WEARABLE_VAD;
    private boolean LSM6DSV16BX_WEARABLE_SFLP_QUAT;

    private boolean LSM6DSO16IS_WEARABLE_UNSUPERVISED_ODL;
    private boolean LSM6DSO16IS_WEARABLE_ACTIVITY;
    private boolean LSM6DSO16IS_WEARABLE_WRIST_TILT;

    private boolean LIS2DUXS12_WEARABLE_WRIST_TILT_XL;
    private boolean LIS2DUXS12_WEARABLE_JIGGLE;
    private boolean LIS2DUXS12_WEARABLE_WEAROS_NAVIGATION;
    private boolean LIS2DUXS12_WEARABLE_TAP_DETECTION;
    private boolean LIS2DUXS12_WEARABLE_SINGLE_DOUBLE_TAP;
    private boolean LIS2DUXS12_WEARABLE_QVAR_TOUCH;
    private boolean LIS2DUXS12_WEARABLE_QVAR_SWIPE;

    // Algorithms PC
    private boolean LSM6DSOX_PC_IN_BAG_DETECTION;
    private boolean LSM6DSOX_PC_OUT_FROM_BAG_DETECTION;
    private boolean LSM6DSOX_PC_ON_TABLE_DETECTION;
    private boolean LSM6DSOX_PC_PICKUP_DETECTION;
    private boolean LSM6DSOX_PC_LIFTUP;
    private boolean LSM6DSOX_PC_ACTIVITY_RECOGNITION;
    private boolean LSM6DSOX_PC_CARRY_POSITION;

    private boolean LSM6DSV16X_PC_LIFTUP;

    private boolean LSM6DSV32X_PC_LIFTUP;

    private boolean LIS2DUXS12_PC_LIFTUP;

    // Algorithms AUTOMOTIVE
    private boolean LSM6DSOX_AUTOMOTIVE_VEHICLE_STATIONARY_DETECTION;

    // Algorithms EARABLE
    private boolean LSM6DSV16X_LSM6DSV16BX_EARABLE_PEDOMETER;
    private boolean LSM6DSV16X_LSM6DSV16BX_EARABLE_SPATIAL_AUDIO;
    private boolean LSM6DSV16BX_EARABLE_VAD;
    private boolean LSM6DSV16BX_EARABLE_IN_EAR;
    private boolean LSM6DSV16BX_EARABLE_SWIPE;
    private boolean LSM6DSV16BX_EARABLE_TOUCH;
    private boolean LSM6DSV16X_EARABLE_VAD;
    private boolean LSM6DSV16X_EARABLE_IN_EAR;
    private boolean LSM6DSV16X_EARABLE_SWIPE;
    private boolean LSM6DSV16X_EARABLE_TOUCH;

    // Algorithms GENERIC
    private boolean LSM6DSOX_GENERIC_VIBRATION_MONITORING;
    private boolean LSM6DSOX_GENERIC_SIX_D;
    private boolean LSM6DSOX_GENERIC_FOUR_D;
    private boolean LSM6DSOX_GENERIC_MOTION_STATIONARY;
    private boolean LSM6DSOX_GENERIC_FREE_FALL;

    private boolean LSM6DSV16X_GENERIC_SFLP_QUAT;
    private boolean LSM6DSV16X_GENERIC_MOTION_STATIONARY;
    private boolean LSM6DSV16X_GENERIC_FOUR_D;
    private boolean LSM6DSV16X_GENERIC_FREE_FALL;
    private boolean LSM6DSV16X_GENERIC_FREE_FALL_HEIGHT;

    private boolean LSM6DSV32X_GENERIC_SFLP_QUAT;
    private boolean LSM6DSV32X_GENERIC_MOTION_STATIONARY;
    private boolean LSM6DSV32X_GENERIC_FOUR_D;
    private boolean LSM6DSV32X_GENERIC_FREE_FALL;
    private boolean LSM6DSV32X_GENERIC_FREE_FALL_HEIGHT;

    private boolean LSM6DSO16IS_GENERIC_SENSOR_FUSION_6X;
    private boolean LSM6DSO16IS_GENERIC_E_BUBBLE_LEVEL;
    private boolean LSM6DSO16IS_GENERIC_PEDOMETER;
    private boolean LSM6DSO16IS_GENERIC_ACC_CALIBRATION;
    private boolean LSM6DSO16IS_GENERIC_GYR_CALIBRATION;
    private boolean LSM6DSO16IS_GENERIC_NORM;
    private boolean LSM6DSO16IS_GENERIC_CRC8;
    private boolean LSM6DSO16IS_GENERIC_CRC32;

    private boolean LIS2DUXS12_GENERIC_FOUR_D;
    private boolean LIS2DUXS12_GENERIC_MOTION_STATIONARY;
    private boolean LIS2DUXS12_GENERIC_FREE_FALL;
    private boolean LIS2DUXS12_GENERIC_FREE_FALL_HEIGHT;

    // Algorithms SWLIB
    private boolean SW_LIB_MOTION_AW;
    private boolean SW_LIB_MOTION_PW;
    private boolean SW_LIB_MOTION_FA_B;
    private boolean SW_LIB_MOTION_FA_S;
    private boolean SW_LIB_MOTION_FA_P;
    private boolean SW_LIB_MOTION_SM;
    private boolean SW_LIB_MOTION_AH;
    private boolean SW_LIB_MAN_DOWN;
    private boolean SW_LIB_TOUCH;

    // Tools
    private boolean TOOLS_UCF_LOADER;
    private boolean TOOLS_SENSORS_SD_LOG;
    private boolean TOOLS_SENSORS_BLE_LOG;
    private boolean TOOLS_MASS_STORAGE;

    public int getPagesNumber()
    {
        return SMARTPHONE_DEMO_EN + WEARABLE_DEMO_EN
                + PC_DEMO_EN + AUTOMOTIVE_DEMO_EN + EARABLE_DEMO_EN
                + GENERIC_DEMO_EN + SW_LIB_DEMO_EN + TOOLS_EN;
    }

    AppConfig(Context context, int board_id)
    {
        mContext = context;

        switch (board_id)
        {
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                configureSensorTileBox_LSM6DSOX();
                break;
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                configureTWSBox_LSM6DSV16X();
                break;
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                configureTWSBox_LSM6DSV16BX();
                break;
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                configureSensorTileBox_LSM6DSO16IS();
                break;
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO:
                switch (MyCtrlData.device) {
                    case MyCtrlData.DEVICE_LSM6DSOX:
                        configureSensorTileBoxPro_LSM6DSOX();
                        break;
                    case MyCtrlData.DEVICE_LSM6DSV16X:
                        configureSensorTileBoxPro_LSM6DSV16X();
                        break;
                    case MyCtrlData.DEVICE_LSM6DSV32X:
                        configureSensorTileBoxPro_LSM6DSV32X();
                        break;
                    case MyCtrlData.DEVICE_LSM6DSV16BX:
                        configureSensorTileBoxPro_LSM6DSV16BX();
                        break;
                    case MyCtrlData.DEVICE_LSM6DSO16IS:
                        configureSensorTileBoxPro_LSM6DSO16IS();
                        break;
                    case MyCtrlData.DEVICE_LIS2DUXS12:
                        configureSensorTileBoxPro_LIS2DUXS12();
                        break;
                }
            default:
                break;
        }
    }

    // Customize demos
    public void configureSensorTileBox_LSM6DSOX()
    {
        // Tabs
        SMARTPHONE_DEMO_EN = 1;
        WEARABLE_DEMO_EN = 1;
        PC_DEMO_EN = 1;
        AUTOMOTIVE_DEMO_EN = 1;
        GENERIC_DEMO_EN = 1;
        TOOLS_EN = 1;

        SW_LIB_DEMO_EN = 1;

        SW_LIB_MOTION_AW = true;
        SW_LIB_MOTION_PW = true;
        SW_LIB_MOTION_FA_B = true;
        SW_LIB_MOTION_FA_S = true;
        SW_LIB_MOTION_FA_P = true;
        SW_LIB_MOTION_SM = true;
        SW_LIB_MOTION_AH = true;
        SW_LIB_MAN_DOWN = true;
        SW_LIB_TOUCH = true;

        // Algorithms SMARTPHONE
        LSM6DSOX_SMARTPHONE_ACTIVITY_RECOGNITION = true;
        LSM6DSOX_SMARTPHONE_ACTIVITY_RECOGNITION_CAR = true;
        LSM6DSOX_SMARTPHONE_MOTION_INTENSITY = true;
        LSM6DSOX_SMARTPHONE_GLANCE_DEGLANCE = true;
        LSM6DSOX_SMARTPHONE_PHONE_TO_EAR = true;
        LSM6DSOX_SMARTPHONE_PICK_UP = true;
        LSM6DSOX_SMARTPHONE_FLIP_UP = true;
        LSM6DSOX_SMARTPHONE_FLIP_DOWN = true;
        LSM6DSOX_SMARTPHONE_SHAKE = true;
        LSM6DSOX_SMARTPHONE_PEDOMETER = true;

        // Algorithms WEARABLE
        LSM6DSOX_WEARABLE_GYM_ACTIVITY = true;
        LSM6DSOX_WEARABLE_WRIST_TILT_XL_FACEBOOK = true;
        LSM6DSOX_WEARABLE_WRIST_TILT_XLG_FACEBOOK = true;
        LSM6DSOX_WEARABLE_WRIST_TILT_ENHANCED_FACEBOOK = true;
        LSM6DSOX_WEARABLE_JIGGLE = true;
        LSM6DSOX_WEARABLE_WEAROS_NAVIGATION = true;
        LSM6DSOX_WEARABLE_SINGLE_TAP = true;
        LSM6DSOX_WEARABLE_DOUBLE_TAP = true;
        LSM6DSOX_WEARABLE_PEDOMETER = true;
        LSM6DSOX_WEARABLE_SLEEP_MONITORING = true;
        LSM6DSOX_WEARABLE_MAN_DOWN = true;

        // Algorithms PC
        LSM6DSOX_PC_IN_BAG_DETECTION = true;
        LSM6DSOX_PC_OUT_FROM_BAG_DETECTION = true;
        LSM6DSOX_PC_ON_TABLE_DETECTION = true;
        LSM6DSOX_PC_PICKUP_DETECTION = true;
        LSM6DSOX_PC_LIFTUP = true;
        LSM6DSOX_PC_ACTIVITY_RECOGNITION = true;
        LSM6DSOX_PC_CARRY_POSITION = true;

        // Algorithms AUTOMOTIVE
        LSM6DSOX_AUTOMOTIVE_VEHICLE_STATIONARY_DETECTION = true;

        // Algorithms GENERIC
        LSM6DSOX_GENERIC_VIBRATION_MONITORING = true;
        LSM6DSOX_GENERIC_SIX_D = true;
        LSM6DSOX_GENERIC_FOUR_D = true;
        LSM6DSOX_GENERIC_MOTION_STATIONARY = true;
        LSM6DSOX_GENERIC_FREE_FALL = true;

        // Tools
        MICROPHONE_LOG_EN = 1;
        SEND_ZIP_CONFIG_EN = 1;
        DEMO_SD_LOG_EN = 1;
        TOOLS_UCF_LOADER = true;
        TOOLS_SENSORS_BLE_LOG = true;//false;
        TOOLS_SENSORS_SD_LOG = true;
        TOOLS_MASS_STORAGE = true;
    }

    public void configureTWSBox_LSM6DSV16X()
    {
        // Tabs
        EARABLE_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms EARABLE
        LSM6DSV16X_LSM6DSV16BX_EARABLE_PEDOMETER = true;
        LSM6DSV16X_LSM6DSV16BX_EARABLE_SPATIAL_AUDIO = true;
        LSM6DSV16X_EARABLE_VAD = true;
        LSM6DSV16X_EARABLE_TOUCH = true;
        LSM6DSV16X_EARABLE_IN_EAR = true;

        // Tools
        TOOLS_UCF_LOADER = true;
        TOOLS_SENSORS_BLE_LOG = true;
    }

    public void configureTWSBox_LSM6DSV16BX()
    {
        // Tabs
        EARABLE_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms EARABLE
        LSM6DSV16X_LSM6DSV16BX_EARABLE_PEDOMETER = true;
        LSM6DSV16X_LSM6DSV16BX_EARABLE_SPATIAL_AUDIO = true;
        LSM6DSV16BX_EARABLE_VAD = true;
        LSM6DSV16BX_EARABLE_TOUCH = true;
        LSM6DSV16BX_EARABLE_IN_EAR = true;

        // Tools
        TOOLS_UCF_LOADER = true;
        TOOLS_SENSORS_BLE_LOG = true;
    }

    public void configureSensorTileBox_LSM6DSO16IS()
    {
        // Tabs
        WEARABLE_DEMO_EN = 1;
        GENERIC_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms WEARABLE
        LSM6DSO16IS_WEARABLE_UNSUPERVISED_ODL = true;
        LSM6DSO16IS_WEARABLE_ACTIVITY = true;
        LSM6DSO16IS_WEARABLE_WRIST_TILT = true;

        // Algorithms GENERIC
        LSM6DSO16IS_GENERIC_SENSOR_FUSION_6X = true;
        LSM6DSO16IS_GENERIC_E_BUBBLE_LEVEL = true;
        LSM6DSO16IS_GENERIC_PEDOMETER = true;
        LSM6DSO16IS_GENERIC_ACC_CALIBRATION = true;
        LSM6DSO16IS_GENERIC_GYR_CALIBRATION = true;
        LSM6DSO16IS_GENERIC_CRC8 = true;
        LSM6DSO16IS_GENERIC_CRC32 = true;

        // Tools
        MICROPHONE_LOG_EN = 1;
        SEND_ZIP_CONFIG_EN = 1;
        DEMO_SD_LOG_EN = 1;
        TOOLS_UCF_LOADER = true;
        TOOLS_SENSORS_SD_LOG = true;
        TOOLS_MASS_STORAGE = true;
    }

    public void configureSensorTileBoxPro_LSM6DSOX()
    {
        // Tabs
        SMARTPHONE_DEMO_EN = 1;
        WEARABLE_DEMO_EN = 1;
        PC_DEMO_EN = 1;
        AUTOMOTIVE_DEMO_EN = 1;
        GENERIC_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms SMARTPHONE
        LSM6DSOX_SMARTPHONE_ACTIVITY_RECOGNITION = true;
        LSM6DSOX_SMARTPHONE_ACTIVITY_RECOGNITION_CAR = true;
        LSM6DSOX_SMARTPHONE_MOTION_INTENSITY = true;
        LSM6DSOX_SMARTPHONE_GLANCE_DEGLANCE = true;
        LSM6DSOX_SMARTPHONE_PHONE_TO_EAR = true;
        LSM6DSOX_SMARTPHONE_PICK_UP = true;
        LSM6DSOX_SMARTPHONE_FLIP_UP = true;
        LSM6DSOX_SMARTPHONE_FLIP_DOWN = true;
        LSM6DSOX_SMARTPHONE_SHAKE = true;
        LSM6DSOX_SMARTPHONE_PEDOMETER = true;

        // Algorithms WEARABLE
        LSM6DSOX_WEARABLE_GYM_ACTIVITY = true;
        LSM6DSOX_WEARABLE_WRIST_TILT_XL_FACEBOOK = true;
        LSM6DSOX_WEARABLE_WRIST_TILT_XLG_FACEBOOK = true;
        LSM6DSOX_WEARABLE_WRIST_TILT_ENHANCED_FACEBOOK = true;
        LSM6DSOX_WEARABLE_JIGGLE = true;
        LSM6DSOX_WEARABLE_WEAROS_NAVIGATION = true;
        LSM6DSOX_WEARABLE_SINGLE_TAP = true;
        LSM6DSOX_WEARABLE_DOUBLE_TAP = true;
        LSM6DSOX_WEARABLE_PEDOMETER = true;
        LSM6DSOX_WEARABLE_SLEEP_MONITORING = true;
        LSM6DSOX_WEARABLE_MAN_DOWN = true;

        // Algorithms PC
        LSM6DSOX_PC_IN_BAG_DETECTION = true;
        LSM6DSOX_PC_OUT_FROM_BAG_DETECTION = true;
        LSM6DSOX_PC_ON_TABLE_DETECTION = true;
        LSM6DSOX_PC_PICKUP_DETECTION = true;
        LSM6DSOX_PC_LIFTUP = true;
        LSM6DSOX_PC_ACTIVITY_RECOGNITION = true;
        LSM6DSOX_PC_CARRY_POSITION = true;

        // Algorithms AUTOMOTIVE
        LSM6DSOX_AUTOMOTIVE_VEHICLE_STATIONARY_DETECTION = true;

        // Algorithms GENERIC
        LSM6DSOX_GENERIC_VIBRATION_MONITORING = true;
        LSM6DSOX_GENERIC_SIX_D = true;
        LSM6DSOX_GENERIC_FOUR_D = true;
        LSM6DSOX_GENERIC_MOTION_STATIONARY = true;
        LSM6DSOX_GENERIC_FREE_FALL = true;

        // Tools
        SEND_ZIP_CONFIG_EN = 1;
        TOOLS_UCF_LOADER = true;
    }

    public void configureSensorTileBoxPro_LSM6DSO16IS()
    {
        // Tabs
        WEARABLE_DEMO_EN = 1;
        GENERIC_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms WEARABLE
        LSM6DSO16IS_WEARABLE_UNSUPERVISED_ODL = true;
        LSM6DSO16IS_WEARABLE_ACTIVITY = true;
        LSM6DSO16IS_WEARABLE_WRIST_TILT = true;

        // Algorithms GENERIC
        LSM6DSO16IS_GENERIC_SENSOR_FUSION_6X = true;
        LSM6DSO16IS_GENERIC_E_BUBBLE_LEVEL = true;
        LSM6DSO16IS_GENERIC_PEDOMETER = true;
        LSM6DSO16IS_GENERIC_ACC_CALIBRATION = true;
        LSM6DSO16IS_GENERIC_GYR_CALIBRATION = true;
        LSM6DSO16IS_GENERIC_CRC8 = true;
        LSM6DSO16IS_GENERIC_CRC32 = true;

        // Tools
        SEND_ZIP_CONFIG_EN = 1;
        DEMO_SD_LOG_EN = 1;
        TOOLS_UCF_LOADER = true;
    }

    public void configureSensorTileBoxPro_LSM6DSV16X()
    {
        // Tabs
        SMARTPHONE_DEMO_EN = 1;
        WEARABLE_DEMO_EN = 1;
        PC_DEMO_EN = 1;
        GENERIC_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms SMARTPHONE
        LSM6DSV16X_SMARTPHONE_ACTIVITY_RECOGNITION = true;
        LSM6DSV16X_SMARTPHONE_GLANCE_DEGLANCE = true;
        LSM6DSV16X_SMARTPHONE_PHONE_TO_EAR = true;
        LSM6DSV16X_SMARTPHONE_PICK_UP = true;
        LSM6DSV16X_SMARTPHONE_FLIP_UP = true;
        LSM6DSV16X_SMARTPHONE_FLIP_DOWN = true;
        LSM6DSV16X_SMARTPHONE_SHAKE = true;

        // Algorithms WEARABLE
        LSM6DSV16X_WEARABLE_QVAR_TOUCH = true;
        LSM6DSV16X_WEARABLE_QVAR_SWIPE = true;
        LSM6DSV16X_WEARABLE_ACTIVITY_RECOGNITION = true;
        LSM6DSV16X_WEARABLE_GYM_ACTIVITY = true;
        LSM6DSV16X_WEARABLE_WRIST_TILT_XL = true;
        LSM6DSV16X_WEARABLE_WRIST_TILT_XLG = true;
        LSM6DSV16X_WEARABLE_JIGGLE = true;
        LSM6DSV16X_WEARABLE_WEAROS_NAVIGATION = true;
        LSM6DSV16X_WEARABLE_SINGLE_TAP = true;
        LSM6DSV16X_WEARABLE_DOUBLE_TAP = true;
        LSM6DSV16X_WEARABLE_SINGLE_DOUBLE_TAP = true;
        LSM6DSV16X_WEARABLE_DOUBLE_CLENCH = true;
        LSM6DSV16X_WEARABLE_HARD_FALL = true;

        // Algorithms PC
        LSM6DSV16X_PC_LIFTUP = true;

        // Algorithms GENERIC
        LSM6DSV16X_GENERIC_SFLP_QUAT = true;
        LSM6DSV16X_GENERIC_MOTION_STATIONARY = true;
        LSM6DSV16X_GENERIC_FOUR_D = true;
        LSM6DSV16X_GENERIC_FREE_FALL = true;
        LSM6DSV16X_GENERIC_FREE_FALL_HEIGHT = true;

        // Tools
        SEND_ZIP_CONFIG_EN = 1;
        TOOLS_UCF_LOADER = true;
    }

    public void configureSensorTileBoxPro_LSM6DSV32X()
    {
        // Tabs
        SMARTPHONE_DEMO_EN = 1;
        WEARABLE_DEMO_EN = 1;
        PC_DEMO_EN = 1;
        GENERIC_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms SMARTPHONE
        LSM6DSV32X_SMARTPHONE_ACTIVITY_RECOGNITION = true;
        LSM6DSV32X_SMARTPHONE_GLANCE_DEGLANCE = true;
        LSM6DSV32X_SMARTPHONE_PHONE_TO_EAR = true;
        LSM6DSV32X_SMARTPHONE_PICK_UP = true;
        LSM6DSV32X_SMARTPHONE_FLIP_UP = true;
        LSM6DSV32X_SMARTPHONE_FLIP_DOWN = true;
        LSM6DSV32X_SMARTPHONE_SHAKE = true;

        // Algorithms WEARABLE
        LSM6DSV32X_WEARABLE_ACTIVITY_RECOGNITION = true;
        LSM6DSV32X_WEARABLE_GYM_ACTIVITY = true;
        LSM6DSV32X_WEARABLE_WRIST_TILT_XL = true;
        LSM6DSV32X_WEARABLE_WRIST_TILT_XLG = true;
        LSM6DSV32X_WEARABLE_JIGGLE = true;
        LSM6DSV32X_WEARABLE_WEAROS_NAVIGATION = true;
        LSM6DSV32X_WEARABLE_SINGLE_TAP = true;
        LSM6DSV32X_WEARABLE_DOUBLE_TAP = true;
        LSM6DSV32X_WEARABLE_SINGLE_DOUBLE_TAP = true;
        LSM6DSV32X_WEARABLE_DOUBLE_CLENCH = true;
        LSM6DSV32X_WEARABLE_HARD_FALL = true;

        // Algorithms PC
        LSM6DSV32X_PC_LIFTUP = true;

        // Algorithms GENERIC
        LSM6DSV32X_GENERIC_SFLP_QUAT = true;
        LSM6DSV32X_GENERIC_MOTION_STATIONARY = true;
        LSM6DSV32X_GENERIC_FOUR_D = true;
        LSM6DSV32X_GENERIC_FREE_FALL = true;
        LSM6DSV32X_GENERIC_FREE_FALL_HEIGHT = true;

        // Tools
        SEND_ZIP_CONFIG_EN = 1;
        TOOLS_UCF_LOADER = true;
    }

    public void configureSensorTileBoxPro_LSM6DSV16BX()
    {
        // Tabs
        WEARABLE_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms WEARABLE
        LSM6DSV16BX_WEARABLE_VAD = true;
        LSM6DSV16BX_WEARABLE_SFLP_QUAT = true;

        // Tools
        SEND_ZIP_CONFIG_EN = 1;
        DEMO_SD_LOG_EN = 1;
        TOOLS_UCF_LOADER = true;
    }

    public void configureSensorTileBoxPro_LIS2DUXS12()
    {
        // Tabs
        SMARTPHONE_DEMO_EN = 1;
        WEARABLE_DEMO_EN = 1;
        PC_DEMO_EN = 1;
        GENERIC_DEMO_EN = 1;
        TOOLS_EN = 1;

        // Algorithms SMARTPHONE
        LIS2DUXS12_SMARTPHONE_GLANCE_DEGLANCE = true;
        LIS2DUXS12_SMARTPHONE_PICK_UP = true;
        LIS2DUXS12_SMARTPHONE_FLIP_UP = true;
        LIS2DUXS12_SMARTPHONE_FLIP_DOWN = true;
        LIS2DUXS12_SMARTPHONE_SHAKE = true;

        // Algorithms WEARABLE
        LIS2DUXS12_WEARABLE_WRIST_TILT_XL = true;
        LIS2DUXS12_WEARABLE_JIGGLE = true;
        LIS2DUXS12_WEARABLE_WEAROS_NAVIGATION = true;
        LIS2DUXS12_WEARABLE_TAP_DETECTION = true;
        LIS2DUXS12_WEARABLE_QVAR_TOUCH = true;
        LIS2DUXS12_WEARABLE_QVAR_SWIPE = true;

        // Algorithms PC
        LIS2DUXS12_PC_LIFTUP = true;

        // Algorithms GENERIC
        LIS2DUXS12_GENERIC_FOUR_D = true;
        LIS2DUXS12_GENERIC_MOTION_STATIONARY = true;
        LIS2DUXS12_GENERIC_FREE_FALL = true;
        LIS2DUXS12_GENERIC_FREE_FALL_HEIGHT = true;

        // Tools
        SEND_ZIP_CONFIG_EN = 1;
        DEMO_SD_LOG_EN = 1;
        TOOLS_UCF_LOADER = true;
        TOOLS_SENSORS_SD_LOG = true;
    }

    public ArrayList<DemoClass> generateDemoArray(String demoType) {
        ArrayList<DemoClass> DemoClass_array = new ArrayList<>();

        String demoName;
        String demoLogName;
        String demoDescription;
        String demoShortDescription;
        String demoCurrentConsumption;
        int demoIconID;
        int configFile;
        int jsonFile;
        String featureName;
        String singleDemoName;
        ArrayList<Byte> values = new ArrayList<>();
        ArrayList<String> strings = new ArrayList<>();
        ArrayList<Integer> imageIDs = new ArrayList<>();
        String outputType = "";

        switch (demoType) {
            case SMARTPHONE_DEMO_STR:
                if (LSM6DSOX_SMARTPHONE_ACTIVITY_RECOGNITION) {
                    demoName = "Activity Recognition";
                    demoLogName = "MobileActivity";
                    demoDescription = "Detect walking, running and biking user activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd: SENSOR = 7  uA; ALGO = 4 uA";
                    demoIconID = R.drawable.activity;
                    configFile = R.raw.lsm6dsox_smartphone_activity_recognition;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Still");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)1);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)4);
                    strings.add("Running");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)8);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_ACTIVITY_RECOGNITION_CAR) {
                    demoName = "Activity Recognition";
                    demoLogName = "MobileActivity";
                    demoDescription = "Detect walking, running, biking and driving user activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.activity_car;
                    configFile = R.raw.lsm6dsox_smartphone_activity_recognition_car;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Still");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)1);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)4);
                    strings.add("Running");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)8);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    values.add((byte)12);
                    strings.add("Driving");
                    imageIDs.add(R.drawable.driving);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_MOTION_INTENSITY) {
                    demoName = "Motion Intensity";
                    demoLogName = "MotionInt";
                    demoDescription = "Detect up to 8 user motion intensities that can be used for calories computation during user activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Estimate user motion intensity";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 4 uA";
                    demoIconID = R.drawable.motion_intensity_8;
                    configFile = R.raw.lsm6dsox_smartphone_motion_intensity;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Intensity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Level-1");
                    imageIDs.add(R.drawable.motion_intensity_1);
                    values.add((byte)1);
                    strings.add("Level-2");
                    imageIDs.add(R.drawable.motion_intensity_2);
                    values.add((byte)2);
                    strings.add("Level-3");
                    imageIDs.add(R.drawable.motion_intensity_3);
                    values.add((byte)3);
                    strings.add("Level-4");
                    imageIDs.add(R.drawable.motion_intensity_4);
                    values.add((byte)4);
                    strings.add("Level-5");
                    imageIDs.add(R.drawable.motion_intensity_5);
                    values.add((byte)5);
                    strings.add("Level-6");
                    imageIDs.add(R.drawable.motion_intensity_6);
                    values.add((byte)6);
                    strings.add("Level-7");
                    imageIDs.add(R.drawable.motion_intensity_7);
                    values.add((byte)7);
                    strings.add("Level-8");
                    imageIDs.add(R.drawable.motion_intensity_8);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_GLANCE_DEGLANCE) {
                    demoName = "Glance";
                    demoLogName = "Glance";
                    demoDescription = "Detect glance and deglance events using the accelerometer sensor, the Finite State Machine and the Machine Learning Core (filters only).";
                    demoShortDescription = "Detect glance and deglance events";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.smartphone_wake;
                    configFile = R.raw.lsm6dsox_smartphone_glance_deglance;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Glance";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x08);
                    strings.add("Deglance!");
                    imageIDs.add(R.drawable.smartphone_sleep);
                    values.add((byte)0x20);
                    strings.add("Glance!");
                    imageIDs.add(R.drawable.smartphone_wake);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_PHONE_TO_EAR) {
                    demoName = "Phone-to-Ear";
                    demoLogName = "PTE";
                    demoDescription = "Detect phone-to-ear events using the accelerometer sensor, the gyroscope sensor, the Finite State Machine and the Machine Learning Core (filters only).";
                    demoShortDescription = "Detect phone-to-ear gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 280 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.phone_to_ear;
                    configFile = R.raw.lsm6dsox_smartphone_phone_to_ear;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Phone-to-Ear";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Phone-to-Ear!");
                    imageIDs.add(R.drawable.phone_to_ear);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_PICK_UP) {
                    demoName = "Pick-Up";
                    demoLogName = "PickUp";
                    demoDescription = "Detect pick-up events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect pick-up gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 3 uA";
                    demoIconID = R.drawable.pick_up;
                    configFile = R.raw.lsm6dsox_smartphone_pick_up;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Pick-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Picked-Up!");
                    imageIDs.add(R.drawable.pick_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_FLIP_UP) {
                    demoName = "Flip-Up";
                    demoLogName = "FlipUp";
                    demoDescription = "Detect flip-up events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect flip-up gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.flip_up;
                    configFile = R.raw.lsm6dsox_smartphone_flip_up;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flip-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flip-Up!");
                    imageIDs.add(R.drawable.flip_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_FLIP_DOWN) {
                    demoName = "Flip-Down";
                    demoLogName = "FlipDown";
                    demoDescription = "Detect flip-down events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect flip-down gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 3 uA";
                    demoIconID = R.drawable.flip_down;
                    configFile = R.raw.lsm6dsox_smartphone_flip_down;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flip-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flip-Down!");
                    imageIDs.add(R.drawable.flip_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_SHAKE) {
                    demoName = "Shake";
                    demoLogName = "Shake";
                    demoDescription = "Detect shake events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect shake gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 3 uA";
                    demoIconID = R.drawable.shake;
                    configFile = R.raw.lsm6dsox_smartphone_shake;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Shake";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Shake!");
                    imageIDs.add(R.drawable.shake);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_SMARTPHONE_PEDOMETER) {
                    demoName = "Pedometer";
                    demoLogName = "MobilePedo";
                    demoDescription = "Enable embedded pedometer for counting steps, optimized for smartphone devices: it uses accelerometer sensor only and the Pedometer 2.0.";
                    demoShortDescription = "Count number of steps";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 1.5 uA";
                    demoIconID = R.drawable.pedometer;
                    configFile = R.raw.lsm6dsox_smartphone_pedo_generic_configuration;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_PedoMobileConfigCard(true);

                    featureName = PEDOMETER_2_0_STR;
                    singleDemoName = "Step Counter";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.step_left);
                    values.add((byte)1);
                    strings.add("");
                    imageIDs.add(R.drawable.step_right);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_SMARTPHONE_ACTIVITY_RECOGNITION) {
                    demoName = "Activity Recognition";
                    demoLogName = "MobileActivity";
                    demoDescription = "Detect stationary, walking, jogging, biking and driving user activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd: SENSOR = 190 uA; ALGO = 10 uA";
                    demoIconID = R.drawable.activity_car;
                    configFile = R.raw.lsm6dsv16x_smartphone_activity_recognition;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Still");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)1);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)4);
                    strings.add("Jogging");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)8);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    values.add((byte)12);
                    strings.add("Driving");
                    imageIDs.add(R.drawable.driving);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_SMARTPHONE_GLANCE_DEGLANCE) {
                    demoName = "Glance";
                    demoLogName = "Glance";
                    demoDescription = "Detect glance and deglance events using the accelerometer sensor, the Finite State Machine and the Machine Learning Core (filters only).";
                    demoShortDescription = "Detect glance and deglance events";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 5.5 uA";
                    demoIconID = R.drawable.smartphone_wake;
                    configFile = R.raw.lsm6dsv16x_smartphone_glance_deglance;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Glance";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x08);
                    strings.add("Deglance!");
                    imageIDs.add(R.drawable.smartphone_sleep);
                    values.add((byte)0x20);
                    strings.add("Glance!");
                    imageIDs.add(R.drawable.smartphone_wake);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_SMARTPHONE_PHONE_TO_EAR) {
                    demoName = "Phone-to-Ear";
                    demoLogName = "PTE";
                    demoDescription = "Detect phone-to-ear events using the accelerometer sensor, the gyroscope sensor, the Finite State Machine and the Machine Learning Core (filters only).";
                    demoShortDescription = "Detect phone-to-ear gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 294 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.phone_to_ear;
                    configFile = R.raw.lsm6dsv16x_smartphone_phone_to_ear;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Phone-to-Ear";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Phone-to-Ear!");
                    imageIDs.add(R.drawable.phone_to_ear);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_SMARTPHONE_PICK_UP) {
                    demoName = "Pick-Up";
                    demoLogName = "PickUp";
                    demoDescription = "Detect pick-up events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect pick-up gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.pick_up;
                    configFile = R.raw.lsm6dsv16x_smartphone_pick_up;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Pick-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Picked-Up!");
                    imageIDs.add(R.drawable.pick_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_SMARTPHONE_FLIP_UP) {
                    demoName = "Flip-Up";
                    demoLogName = "FlipUp";
                    demoDescription = "Detect flip-up events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect flip-up gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 4.5 uA";
                    demoIconID = R.drawable.flip_up;
                    configFile = R.raw.lsm6dsv16x_smartphone_flip_up;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flip-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flip-Up!");
                    imageIDs.add(R.drawable.flip_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_SMARTPHONE_FLIP_DOWN) {
                    demoName = "Flip-Down";
                    demoLogName = "FlipDown";
                    demoDescription = "Detect flip-down events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect flip-down gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.flip_down;
                    configFile = R.raw.lsm6dsv16x_smartphone_flip_down;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flip-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flip-Down!");
                    imageIDs.add(R.drawable.flip_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_SMARTPHONE_SHAKE) {
                    demoName = "Shake";
                    demoLogName = "Shake";
                    demoDescription = "Detect shake events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect shake gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 4 uA";
                    demoIconID = R.drawable.shake;
                    configFile = R.raw.lsm6dsv16x_smartphone_shake;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Shake";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Shake!");
                    imageIDs.add(R.drawable.shake);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_SMARTPHONE_ACTIVITY_RECOGNITION) {
                    demoName = "Activity Recognition";
                    demoLogName = "MobileActivity";
                    demoDescription = "Detect stationary, walking, jogging, biking and driving user activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd: SENSOR = 190 uA; ALGO = 10 uA";
                    demoIconID = R.drawable.activity_car;
                    configFile = R.raw.lsm6dsv32x_smartphone_activity_recognition;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Still");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)1);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)4);
                    strings.add("Jogging");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)8);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    values.add((byte)12);
                    strings.add("Driving");
                    imageIDs.add(R.drawable.driving);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_SMARTPHONE_GLANCE_DEGLANCE) {
                    demoName = "Glance";
                    demoLogName = "Glance";
                    demoDescription = "Detect glance and deglance events using the accelerometer sensor, the Finite State Machine and the Machine Learning Core (filters only).";
                    demoShortDescription = "Detect glance and deglance events";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 5.5 uA";
                    demoIconID = R.drawable.smartphone_wake;
                    configFile = R.raw.lsm6dsv32x_smartphone_glance_deglance;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Glance";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x08);
                    strings.add("Deglance!");
                    imageIDs.add(R.drawable.smartphone_sleep);
                    values.add((byte)0x20);
                    strings.add("Glance!");
                    imageIDs.add(R.drawable.smartphone_wake);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_SMARTPHONE_PHONE_TO_EAR) {
                    demoName = "Phone-to-Ear";
                    demoLogName = "PTE";
                    demoDescription = "Detect phone-to-ear events using the accelerometer sensor, the gyroscope sensor, the Finite State Machine and the Machine Learning Core (filters only).";
                    demoShortDescription = "Detect phone-to-ear gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 294 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.phone_to_ear;
                    configFile = R.raw.lsm6dsv32x_smartphone_phone_to_ear;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Phone-to-Ear";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Phone-to-Ear!");
                    imageIDs.add(R.drawable.phone_to_ear);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_SMARTPHONE_PICK_UP) {
                    demoName = "Pick-Up";
                    demoLogName = "PickUp";
                    demoDescription = "Detect pick-up events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect pick-up gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.pick_up;
                    configFile = R.raw.lsm6dsv32x_smartphone_pick_up;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Pick-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Picked-Up!");
                    imageIDs.add(R.drawable.pick_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_SMARTPHONE_FLIP_UP) {
                    demoName = "Flip-Up";
                    demoLogName = "FlipUp";
                    demoDescription = "Detect flip-up events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect flip-up gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 4.5 uA";
                    demoIconID = R.drawable.flip_up;
                    configFile = R.raw.lsm6dsv32x_smartphone_flip_up;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flip-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flip-Up!");
                    imageIDs.add(R.drawable.flip_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_SMARTPHONE_FLIP_DOWN) {
                    demoName = "Flip-Down";
                    demoLogName = "FlipDown";
                    demoDescription = "Detect flip-down events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect flip-down gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.flip_down;
                    configFile = R.raw.lsm6dsv32x_smartphone_flip_down;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flip-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flip-Down!");
                    imageIDs.add(R.drawable.flip_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_SMARTPHONE_SHAKE) {
                    demoName = "Shake";
                    demoLogName = "Shake";
                    demoDescription = "Detect shake events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect shake gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 4 uA";
                    demoIconID = R.drawable.shake;
                    configFile = R.raw.lsm6dsv32x_smartphone_shake;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Shake";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Shake!");
                    imageIDs.add(R.drawable.shake);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_SMARTPHONE_GLANCE_DEGLANCE) {
                    demoName = "Glance";
                    demoLogName = "Glance";
                    demoDescription = "Detect glance and deglance events using the accelerometer sensor, the Finite State Machine and the Machine Learning Core (filters only).";
                    demoShortDescription = "Detect glance and deglance events";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 8 uA";
                    demoIconID = R.drawable.smartphone_wake;
                    configFile = R.raw.lis2duxs12_smartphone_glance_deglance;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Glance";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x08);
                    strings.add("Deglance!");
                    imageIDs.add(R.drawable.smartphone_sleep);
                    values.add((byte)0x20);
                    strings.add("Glance!");
                    imageIDs.add(R.drawable.smartphone_wake);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_SMARTPHONE_PICK_UP) {
                    demoName = "Pick-Up";
                    demoLogName = "PickUp";
                    demoDescription = "Detect pick-up events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect pick-up gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 7.10 uA";
                    demoIconID = R.drawable.pick_up;
                    configFile = R.raw.lis2duxs12_smartphone_pick_up;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Pick-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Picked-Up!");
                    imageIDs.add(R.drawable.pick_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_SMARTPHONE_FLIP_UP) {
                    demoName = "Flip-Up";
                    demoLogName = "FlipUp";
                    demoDescription = "Detect flip-up events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect flip-up gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 7.40 uA";
                    demoIconID = R.drawable.flip_up;
                    configFile = R.raw.lis2duxs12_smartphone_flip_up;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flip-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flip-Up!");
                    imageIDs.add(R.drawable.flip_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_SMARTPHONE_FLIP_DOWN) {
                    demoName = "Flip-Down";
                    demoLogName = "FlipDown";
                    demoDescription = "Detect flip-down events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect flip-down gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 7.10 uA";
                    demoIconID = R.drawable.flip_down;
                    configFile = R.raw.lis2duxs12_smartphone_flip_down;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flip-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flip-Down!");
                    imageIDs.add(R.drawable.flip_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_SMARTPHONE_SHAKE) {
                    demoName = "Shake";
                    demoLogName = "Shake";
                    demoDescription = "Detect shake events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect shake gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 7.30 uA";
                    demoIconID = R.drawable.shake;
                    configFile = R.raw.lis2duxs12_smartphone_shake;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Shake";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Shake!");
                    imageIDs.add(R.drawable.shake);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                break;

            case WEARABLE_DEMO_STR:
                if (LSM6DSOX_WEARABLE_ACTIVITY_RECOGNITION) {
                    demoName = "Activity Recognition";
                    demoLogName = "WristActivity";
                    demoDescription = "Detect walking, running and biking user activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd = N/A";
                    demoIconID = R.drawable.activity;
                    configFile = R.raw.lsm6dsox_wearable_activity_recognition;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Still");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)1);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)4);
                    strings.add("Running");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)8);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_GYM_ACTIVITY) {
                    demoName = "Gym Activity";
                    demoLogName = "GymActivity";
                    demoDescription = "Detect bicep curls, lateral raises and squats user gym activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user gym activities";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.gym_activity;
                    configFile = R.raw.lsm6dsox_wearable_gym_activity_left;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsox_wearable_gym_activity_left, R.raw.lsm6dsox_wearable_gym_activity_right);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Gym Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Rest");
                    imageIDs.add(R.drawable.rest);
                    values.add((byte)4);
                    strings.add("Bicep-Curls");
                    imageIDs.add(R.drawable.bicep_up);
                    values.add((byte)8);
                    strings.add("Lateral Raises");
                    imageIDs.add(R.drawable.lateral_raises);
                    values.add((byte)12);
                    strings.add("Squats");
                    imageIDs.add(R.drawable.squat_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_WRIST_TILT_XL) {
                    demoName = "Wrist-Tilt (XL only)";
                    demoLogName = "WristTiltXL";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only). The detection is based on the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 5A";
                    demoIconID = R.drawable.wrist_tilt;
                    configFile = R.raw.lsm6dsox_wearable_wrist_tilt_xl;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_WRIST_TILT_XLG) {
                    demoName = "Wrist-Tilt (XL + G)";
                    demoLogName = "WristTiltXLG";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, gyroscope sensor, Finite State Machine and Machine Learning Core (filters only). The detection is the combination of a trigger given by integrated gyroscope data and a validation of the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 300 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.wrist_tilt_gyro;
                    configFile = R.raw.lsm6dsox_wearable_wrist_tilt_xlg_left;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsox_wearable_wrist_tilt_xlg_left, R.raw.lsm6dsox_wearable_wrist_tilt_xlg_right);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_WRIST_TILT_ENHANCED) {
                    demoName = "Wrist-Tilt MLC-Enhanced";
                    demoLogName = "WristTiltMLC";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, Finite State Machine and Machine Learning Core. The detection is based on a complex algorithm which combines accelerometer filtered data and decision trees.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 17 uA";
                    demoIconID = R.drawable.enhanced_wrist_tilt;
                    configFile = R.raw.lsm6dsox_wearable_wrist_tilt_enhanced_left;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsox_wearable_wrist_tilt_enhanced_left, R.raw.lsm6dsox_wearable_wrist_tilt_enhanced_right);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MULTIPLE_OUTPUTS_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_WRIST_TILT_XL_FACEBOOK) {
                    demoName = "Wrist-Tilt (XL only)";
                    demoLogName = "WristTiltXL";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only). The detection is based on the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 5A";
                    demoIconID = R.drawable.wrist_tilt;
                    configFile = R.raw.lsm6dsox_wearable_wrist_tilt_xl_facebook;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    // Uncomment to enable FSM configuration
                    //demo.setDemoUsage_RamConfigCard(true);

                    // Values are referred to default (typically left) configuration.
                    // If values are different with not-default (typically right) configuration, the value has to be changed in the code
                    demo.addRamConfigItem("ACCELEROMETER Y THRESHOLD [g]", DemoClass.PARAM_TYPE_THRESHOLD, 0.1f, Arrays.asList("406"), "Minimum accelerometer Y-axis threshold for triggering the event.");
                    demo.addRamConfigItem("TIMER EVENT [#samples]", DemoClass.PARAM_TYPE_SHORT_TIMER, 6.0f, Arrays.asList("40C"), "Minimum time above threshold for triggering the event.");
                    demo.addRamConfigItem("TIMER RESET [#samples]", DemoClass.PARAM_TYPE_SHORT_TIMER, 13f, Arrays.asList("40B"), "Minimum time between two consecutive events.");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_WRIST_TILT_XLG_FACEBOOK) {
                    demoName = "Wrist-Tilt (XL + G)";
                    demoLogName = "WristTiltXLG";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, gyroscope sensor, Finite State Machine and Machine Learning Core (filters only). The detection is the combination of a trigger given by integrated gyroscope data and a validation of the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 300 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.wrist_tilt_gyro;
                    configFile = R.raw.lsm6dsox_wearable_wrist_tilt_xlg_left_facebook;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsox_wearable_wrist_tilt_xlg_left_facebook, R.raw.lsm6dsox_wearable_wrist_tilt_xlg_right_facebook);

                    // Uncomment to enable FSM configuration
                    //demo.setDemoUsage_RamConfigCard(true);

                    // Values are referred to default (typically left) configuration.
                    // If values are different with not-default (typically right) configuration, the value has to be changed in the code
                    demo.addRamConfigItem("GYROSCOPE START/STOP THRESHOLD [rad/s]", DemoClass.PARAM_TYPE_THRESHOLD, 0.175f, Arrays.asList("41F"), "Minimum gyroscope X-axis threshold for angle integration.");
                    demo.addRamConfigItem("ANGLE THRESHOLD [rad]", DemoClass.PARAM_TYPE_THRESHOLD, 0.698f, Arrays.asList("428"), "Minimum angle for triggering the event.");
                    demo.addRamConfigItem("ACCELEROMETER X/Y THRESHOLD [g]", DemoClass.PARAM_TYPE_THRESHOLD, -0.5f, Arrays.asList("408"), "Minimum accelerometer X and Y axes threshold, evaluated after the angle integration, for triggering the event.");
                    demo.addRamConfigItem("TIMER [#samples]", DemoClass.PARAM_TYPE_SHORT_TIMER, 8.0f, Arrays.asList("41B"), "Minimum time above accelerometer threshold for triggering the event.");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_WRIST_TILT_ENHANCED_FACEBOOK) {
                    demoName = "Wrist-Tilt MLC-Enhanced";
                    demoLogName = "WristTiltMLC";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, Finite State Machine and Machine Learning Core. The detection is based on a complex algorithm which combines accelerometer filtered data and decision trees.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 17 uA";
                    demoIconID = R.drawable.enhanced_wrist_tilt;
                    configFile = R.raw.lsm6dsox_wearable_wrist_tilt_enhanced_left_facebook;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsox_wearable_wrist_tilt_enhanced_left_facebook, R.raw.lsm6dsox_wearable_wrist_tilt_enhanced_right_facebook);

                    // Uncomment to enable FSM configuration
                    //demo.setDemoUsage_RamConfigCard(true);

                    // Values are referred to default (typically left) configuration.
                    // If values are different with not-default (typically right) configuration, the value has to be changed in the code
                    demo.addRamConfigItem("VERTICAL/NOT-VERTICAL THRESHOLD [g]", DemoClass.PARAM_TYPE_THRESHOLD, 0.707f, Arrays.asList("406", "412"), "Accelerometer X-axis threshold for enabling vertical or not-vertical wrist-tilt logic.");
                    demo.addRamConfigItem("TIMER NOT-VERTICAL [#samples]", DemoClass.PARAM_TYPE_SHORT_TIMER, 2.0f, Arrays.asList("421"), "Minimum time above accelerometer threshold for triggering the event during not-vertical orientation.");
                    demo.addRamConfigItem("TIMER VERTICAL [#samples]", DemoClass.PARAM_TYPE_SHORT_TIMER, 2.0f, Arrays.asList("43B"), "Minimum time above accelerometer threshold for triggering the event during vertical orientation.");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MULTIPLE_OUTPUTS_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_JIGGLE) {
                    demoName = "Jiggle";
                    demoLogName = "Jiggle";
                    demoDescription = "Detect jiggle gesture using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect jiggle gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 4.5 uA";
                    demoIconID = R.drawable.jiggle;
                    configFile = R.raw.lsm6dsox_wearable_jiggle;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Jiggle";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Jiggle!");
                    imageIDs.add(R.drawable.jiggle);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_WEAROS_NAVIGATION) {
                    demoName = "WearOS Navigation";
                    demoLogName = "WearOS";
                    demoDescription = "Detect wearOS gestures using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect wearOS gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 9.5 uA; ALGO = 17 uA";
                    demoIconID = R.drawable.wrist_wearos_navigation;
                    configFile = R.raw.lsm6dsox_wearable_wearos_navigation;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoOtherText("LEFT WRIST");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Push-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Push-Down!");
                    imageIDs.add(R.drawable.push_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Pivot-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Pivot-Up!");
                    imageIDs.add(R.drawable.pivot_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flick-Out";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flick-Out!");
                    imageIDs.add(R.drawable.flick_out);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flick-In";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flick-In!");
                    imageIDs.add(R.drawable.flick_in);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_SINGLE_TAP) {
                    demoName = "Single-Tap";
                    demoLogName = "SingleTap";
                    demoDescription = "Detect single-taps events: it uses the accelerometer sensor and the Embedded Functions.";
                    demoShortDescription = "Detect single-tap events";
                    demoCurrentConsumption = "Idd: SENSOR + ALGO = 170 uA";
                    demoIconID = R.drawable.single_tap;
                    configFile = R.raw.lsm6dsox_wearable_single_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = SINGLE_TAP_STR;
                    singleDemoName = "Single-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_DOUBLE_TAP) {
                    demoName = "Double-Tap";
                    demoLogName = "DoubleTap";
                    demoDescription = "Detect double-tap events: it uses the accelerometer sensor and the Embedded Functions.";
                    demoShortDescription = "Detect double-tap events";
                    demoCurrentConsumption = "Idd: SENSOR + ALGO = 170 uA";
                    demoIconID = R.drawable.double_tap;
                    configFile = R.raw.lsm6dsox_wearable_double_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = DOUBLE_TAP_STR;
                    singleDemoName = "Double-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double-Tap!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_ENHANCED_TAP) {
                    demoName = "Enhanced Tap-Tap";
                    demoLogName = "EnhancedTapTap";
                    demoDescription = "Detect single-tap and double-tap events: it uses the accelerometer sensor, the Finite State Machine and the Machine Learning Core (filters only).";
                    demoShortDescription = "Detect single and double tap events";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 100 uA";
                    demoIconID = R.drawable.enhanced_tap;
                    configFile = R.raw.lsm6dsox_wearable_enhanced_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Single Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double-Tap!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_PEDOMETER) {
                    demoName = "Pedometer";
                    demoLogName = "WristPedo";
                    demoDescription = "Enable embedded pedometer for counting steps, optimized for wrist-worn devices: it uses accelerometer sensor only and the Pedometer 2.0.";
                    demoShortDescription = "Count number of steps";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 1.5 uA/4.5 uA";
                    demoIconID = R.drawable.pedometer;
                    configFile = R.raw.lsm6dsox_wearable_pedo_generic_configuration;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_PedoWristConfigCard(true);

                    featureName = PEDOMETER_2_0_STR;
                    singleDemoName = "Step Counter";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.step_left);
                    values.add((byte)1);
                    strings.add("");
                    imageIDs.add(R.drawable.step_right);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_SLEEP_MONITORING) {
                    demoName = "Sleep Monitoring";
                    demoLogName = "Sleep";
                    demoDescription = "Provides real-time information if the person wearing the device on wrist is sleeping or not. It uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Sleep monitoring detection for wrist-worn devices";
                    demoCurrentConsumption = "Idd: SENSOR = 9 uA; ALGO = 1 uA";
                    demoIconID = R.drawable.sleep;
                    configFile = R.raw.lsm6dsox_wearable_sleep_monitoring;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Sleep Monitoring";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Awake");
                    imageIDs.add(R.drawable.awake);
                    values.add((byte)4);
                    strings.add("Asleep");
                    imageIDs.add(R.drawable.sleep);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_WEARABLE_MAN_DOWN) {
                    demoName = "Man Down";
                    demoLogName = "ManDown";
                    demoDescription = "Provides real-time information if the person wearing the device fell. It uses the accelerometer sensor (Y-axis pointing up), the Finite State Machine and the Machine Learning Core.";
                    demoShortDescription = "Man Down detection for chest / waist devices";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 19 uA";
                    demoIconID = R.drawable.man_down;
                    configFile = R.raw.lsm6dsox_wearable_man_down;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Man Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Fall!");
                    imageIDs.add(R.drawable.man_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }

                if (LSM6DSV16X_WEARABLE_WEARABLE_PACK) {
                    demoName = "Wearable Pack";
                    demoLogName = "WearablePack";
                    demoDescription = "Enable activity recognition (stationary, walking, running, jumping rope and biking) and gesture recognition (wrist-up, wrist-down, jiggle and double clench) in a smartwatch/smartband device: it uses the accelerometer sensor, the Finite State Machine and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities and gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 190 uA; ALGO = 55 uA";
                    demoIconID = R.drawable.wearable_pack;
                    configFile = R.raw.lsm6dsv16x_wearable_wearable_pack;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Unknown");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Other");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)4);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)8);
                    strings.add("Running");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)9);
                    strings.add("Jumping Rope");
                    imageIDs.add(R.drawable.jumping_rope);
                    values.add((byte)12);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-up");
                    imageIDs.add(R.drawable.wrist_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-down");
                    imageIDs.add(R.drawable.wrist_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Jiggle";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Jiggle");
                    imageIDs.add(R.drawable.jiggle);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double clench";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double clench");
                    imageIDs.add(R.drawable.double_clench);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_QVAR_TOUCH) {
                    demoName = "Qvar UI Touch";
                    demoLogName = "QvarUITouch";
                    demoDescription = "Detect touch events using Qvar sensor and Finite State Machine.";
                    demoShortDescription = "Detect Qvar touch events";
                    demoCurrentConsumption = "Idd: SENSOR = 115 uA; ALGO = 80 uA";
                    demoIconID = R.drawable.long_press;
                    configFile = R.raw.lsm6dsv16x_wearable_qvar_touch;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Single Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single Touch!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double Touch!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Triple Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Triple Touch!");
                    imageIDs.add(R.drawable.triple_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Long Press";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Long Press!");
                    imageIDs.add(R.drawable.long_press);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_QVAR_SWIPE) {
                    demoName = "Qvar UI Swipe";
                    demoLogName = "QvarUISwipe";
                    demoDescription = "Detect swipe events using Qvar sensor and Finite State Machine.";
                    demoShortDescription = "Detect Qvar swipe events";
                    demoCurrentConsumption = "Idd: SENSOR = 115 uA; ALGO = 45 uA";
                    demoIconID = R.drawable.swipe;
                    configFile = R.raw.lsm6dsv16x_wearable_qvar_swipe;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Swipe Right";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Swipe Right!");
                    imageIDs.add(R.drawable.swipe_right);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Swipe Left";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Swipe Left!");
                    imageIDs.add(R.drawable.swipe_left);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_ACTIVITY_RECOGNITION) {
                    demoName = "Activity Recognition";
                    demoLogName = "WristActivity";
                    demoDescription = "Detect stationary/other, walking/fast walking and jogging/running user activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 7.5 uA";
                    demoIconID = R.drawable.activity;
                    configFile = R.raw.lsm6dsv16x_wearable_activity_recognition;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Unknown");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Stationary/Other");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)4);
                    strings.add("Walking/Fast walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)8);
                    strings.add("Jogging/Running");
                    imageIDs.add(R.drawable.running);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_GYM_ACTIVITY) {
                    demoName = "Gym Activity";
                    demoLogName = "GymActivity";
                    demoDescription = "Detect bicep curls, lateral raises and squats user gym activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user gym activities";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.gym_activity;
                    configFile = R.raw.lsm6dsv16x_wearable_gym_activity_left;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsv16x_wearable_gym_activity_left, R.raw.lsm6dsv16x_wearable_gym_activity_right);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Gym Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Rest");
                    imageIDs.add(R.drawable.rest);
                    values.add((byte)4);
                    strings.add("Bicep-Curls");
                    imageIDs.add(R.drawable.bicep_up);
                    values.add((byte)8);
                    strings.add("Lateral Raises");
                    imageIDs.add(R.drawable.lateral_raises);
                    values.add((byte)12);
                    strings.add("Squats");
                    imageIDs.add(R.drawable.squat_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_WRIST_TILT_XL) {
                    demoName = "Wrist-Tilt (XL only)";
                    demoLogName = "WristTiltXL";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only). The detection is based on the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.wrist_tilt;
                    configFile = R.raw.lsm6dsv16x_wearable_wrist_tilt_xl;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_WRIST_TILT_XLG) {
                    demoName = "Wrist-Tilt (XL + G)";
                    demoLogName = "WristTiltXLG";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, gyroscope sensor, Finite State Machine and Machine Learning Core (filters only). The detection is the combination of a trigger given by integrated gyroscope data and a validation of the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 315 uA; ALGO = 13 uA";
                    demoIconID = R.drawable.wrist_tilt_gyro;
                    configFile = R.raw.lsm6dsv16x_wearable_wrist_tilt_xlg_left;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsv16x_wearable_wrist_tilt_xlg_left, R.raw.lsm6dsv16x_wearable_wrist_tilt_xlg_right);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_JIGGLE) {
                    demoName = "Jiggle";
                    demoLogName = "Jiggle";
                    demoDescription = "Detect jiggle gesture using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect jiggle gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.jiggle;
                    configFile = R.raw.lsm6dsv16x_wearable_jiggle;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Jiggle";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Jiggle!");
                    imageIDs.add(R.drawable.jiggle);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_WEAROS_NAVIGATION) {
                    demoName = "WearOS Navigation";
                    demoLogName = "WearOS";
                    demoDescription = "Detect wearOS gestures using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect wearOS gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 17 uA; ALGO = 18.5 uA";
                    demoIconID = R.drawable.wrist_wearos_navigation;
                    configFile = R.raw.lsm6dsv16x_wearable_wearos_navigation;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoOtherText("LEFT WRIST");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Push-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Push-Down!");
                    imageIDs.add(R.drawable.push_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Pivot-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Pivot-Up!");
                    imageIDs.add(R.drawable.pivot_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flick-Out";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flick-Out!");
                    imageIDs.add(R.drawable.flick_out);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flick-In";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flick-In!");
                    imageIDs.add(R.drawable.flick_in);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_SINGLE_TAP) {
                    demoName = "Single-Tap";
                    demoLogName = "SingleTap";
                    demoDescription = "Detect single-taps events: it uses the accelerometer sensor and the Embedded Functions.";
                    demoShortDescription = "Detect single-tap events";
                    demoCurrentConsumption = "Idd: SENSOR + ALGO = N/A";
                    demoIconID = R.drawable.single_tap;
                    configFile = R.raw.lsm6dsv16x_wearable_single_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = SINGLE_TAP_STR;
                    singleDemoName = "Single-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_DOUBLE_TAP) {
                    demoName = "Double-Tap";
                    demoLogName = "DoubleTap";
                    demoDescription = "Detect double-tap events: it uses the accelerometer sensor and the Embedded Functions.";
                    demoShortDescription = "Detect double-tap events";
                    demoCurrentConsumption = "Idd: SENSOR + ALGO = N/A";
                    demoIconID = R.drawable.double_tap;
                    configFile = R.raw.lsm6dsv16x_wearable_double_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = DOUBLE_TAP_STR;
                    singleDemoName = "Double-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double-Tap!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_SINGLE_DOUBLE_TAP) {
                    demoName = "Taps Detection";
                    demoLogName = "Taps";
                    demoDescription = "Detect single and double taps using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect single and double taps";
                    demoCurrentConsumption = "Idd: SENSOR = 100 uA; ALGO = 110 uA";
                    demoIconID = R.drawable.single_tap;
                    configFile = R.raw.lsm6dsv16x_wearable_single_double_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Single-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double-Tap");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_DOUBLE_CLENCH) {
                    demoName = "Double Clench";
                    demoLogName = "DoubleClench";
                    demoDescription = "Detect double clench events using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect double clench";
                    demoCurrentConsumption = "Idd: SENSOR = 29.5 uA; ALGO = 25 uA";
                    demoIconID = R.drawable.double_clench;
                    configFile = R.raw.lsm6dsv16x_wearable_double_clench;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double Clench";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double Clench");
                    imageIDs.add(R.drawable.double_clench);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_WEARABLE_HARD_FALL) {
                    demoName = "Hard Fall";
                    demoLogName = "HardFall";
                    demoDescription = "Provides real-time information if the person wearing the device got a hard fall. It uses the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Hard Fall detection";
                    demoCurrentConsumption = "Idd: SENSOR = 100 uA; ALGO = 45 uA";
                    demoIconID = R.drawable.hard_fall;
                    configFile = R.raw.lsm6dsv16x_wearable_hard_fall;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_RamConfigCard(true);
                    demo.addRamConfigItem("Threshold [g]", DemoClass.PARAM_TYPE_THRESHOLD, 20.0f, Arrays.asList("406", "407"), "Hard Fall threshold applied on accelerometer norm signal.");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Hard Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Fall!");
                    imageIDs.add(R.drawable.hard_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }

                if (LSM6DSV32X_WEARABLE_WEARABLE_PACK) {
                    demoName = "Wearable Pack";
                    demoLogName = "WearablePack";
                    demoDescription = "Enable activity recognition (stationary, walking, running, jumping rope and biking) and gesture recognition (wrist-up, wrist-down, jiggle and double clench) in a smartwatch/smartband device: it uses the accelerometer sensor, the Finite State Machine and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities and gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 190 uA; ALGO = 55 uA";
                    demoIconID = R.drawable.wearable_pack;
                    configFile = R.raw.lsm6dsv32x_wearable_wearable_pack;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Unknown");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Other");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)4);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)8);
                    strings.add("Running");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)9);
                    strings.add("Jumping Rope");
                    imageIDs.add(R.drawable.jumping_rope);
                    values.add((byte)12);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-up");
                    imageIDs.add(R.drawable.wrist_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-down");
                    imageIDs.add(R.drawable.wrist_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Jiggle";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Jiggle");
                    imageIDs.add(R.drawable.jiggle);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double clench";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double clench");
                    imageIDs.add(R.drawable.double_clench);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_ACTIVITY_RECOGNITION) {
                    demoName = "Activity Recognition";
                    demoLogName = "WristActivity";
                    demoDescription = "Detect stationary/other, walking/fast walking and jogging/running user activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 7.5 uA";
                    demoIconID = R.drawable.activity;
                    configFile = R.raw.lsm6dsv32x_wearable_activity_recognition;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Unknown");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Stationary/Other");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)4);
                    strings.add("Walking/Fast walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)8);
                    strings.add("Jogging/Running");
                    imageIDs.add(R.drawable.running);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_GYM_ACTIVITY) {
                    demoName = "Gym Activity";
                    demoLogName = "GymActivity";
                    demoDescription = "Detect bicep curls, lateral raises and squats user gym activities: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user gym activities";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.gym_activity;
                    configFile = R.raw.lsm6dsv32x_wearable_gym_activity_left;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsv32x_wearable_gym_activity_left, R.raw.lsm6dsv32x_wearable_gym_activity_right);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Gym Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Rest");
                    imageIDs.add(R.drawable.rest);
                    values.add((byte)4);
                    strings.add("Bicep-Curls");
                    imageIDs.add(R.drawable.bicep_up);
                    values.add((byte)8);
                    strings.add("Lateral Raises");
                    imageIDs.add(R.drawable.lateral_raises);
                    values.add((byte)12);
                    strings.add("Squats");
                    imageIDs.add(R.drawable.squat_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_WRIST_TILT_XL) {
                    demoName = "Wrist-Tilt (XL only)";
                    demoLogName = "WristTiltXL";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only). The detection is based on the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.wrist_tilt;
                    configFile = R.raw.lsm6dsv32x_wearable_wrist_tilt_xl;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_WRIST_TILT_XLG) {
                    demoName = "Wrist-Tilt (XL + G)";
                    demoLogName = "WristTiltXLG";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, gyroscope sensor, Finite State Machine and Machine Learning Core (filters only). The detection is the combination of a trigger given by integrated gyroscope data and a validation of the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 315 uA; ALGO = 13 uA";
                    demoIconID = R.drawable.wrist_tilt_gyro;
                    configFile = R.raw.lsm6dsv32x_wearable_wrist_tilt_xlg_left;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    demo.setDemoUsage_LeftRightConfigCard(R.raw.lsm6dsv32x_wearable_wrist_tilt_xlg_left, R.raw.lsm6dsv32x_wearable_wrist_tilt_xlg_right);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_JIGGLE) {
                    demoName = "Jiggle";
                    demoLogName = "Jiggle";
                    demoDescription = "Detect jiggle gesture using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect jiggle gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 6 uA";
                    demoIconID = R.drawable.jiggle;
                    configFile = R.raw.lsm6dsv32x_wearable_jiggle;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Jiggle";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Jiggle!");
                    imageIDs.add(R.drawable.jiggle);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_WEAROS_NAVIGATION) {
                    demoName = "WearOS Navigation";
                    demoLogName = "WearOS";
                    demoDescription = "Detect wearOS gestures using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect wearOS gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 17 uA; ALGO = 18.5 uA";
                    demoIconID = R.drawable.wrist_wearos_navigation;
                    configFile = R.raw.lsm6dsv32x_wearable_wearos_navigation;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoOtherText("LEFT WRIST");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Push-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Push-Down!");
                    imageIDs.add(R.drawable.push_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Pivot-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Pivot-Up!");
                    imageIDs.add(R.drawable.pivot_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flick-Out";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flick-Out!");
                    imageIDs.add(R.drawable.flick_out);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flick-In";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flick-In!");
                    imageIDs.add(R.drawable.flick_in);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_SINGLE_TAP) {
                    demoName = "Single-Tap";
                    demoLogName = "SingleTap";
                    demoDescription = "Detect single-taps events: it uses the accelerometer sensor and the Embedded Functions.";
                    demoShortDescription = "Detect single-tap events";
                    demoCurrentConsumption = "Idd: SENSOR + ALGO = N/A";
                    demoIconID = R.drawable.single_tap;
                    configFile = R.raw.lsm6dsv32x_wearable_single_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = SINGLE_TAP_STR;
                    singleDemoName = "Single-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_DOUBLE_TAP) {
                    demoName = "Double-Tap";
                    demoLogName = "DoubleTap";
                    demoDescription = "Detect double-tap events: it uses the accelerometer sensor and the Embedded Functions.";
                    demoShortDescription = "Detect double-tap events";
                    demoCurrentConsumption = "Idd: SENSOR + ALGO = N/A";
                    demoIconID = R.drawable.double_tap;
                    configFile = R.raw.lsm6dsv32x_wearable_double_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = DOUBLE_TAP_STR;
                    singleDemoName = "Double-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double-Tap!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_SINGLE_DOUBLE_TAP) {
                    demoName = "Taps Detection";
                    demoLogName = "Taps";
                    demoDescription = "Detect single and double taps using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect single and double taps";
                    demoCurrentConsumption = "Idd: SENSOR = 100 uA; ALGO = 110 uA";
                    demoIconID = R.drawable.single_tap;
                    configFile = R.raw.lsm6dsv32x_wearable_single_double_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Single-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double-Tap");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_DOUBLE_CLENCH) {
                    demoName = "Double Clench";
                    demoLogName = "DoubleClench";
                    demoDescription = "Detect double clench events using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect double clench";
                    demoCurrentConsumption = "Idd: SENSOR = 29.5 uA; ALGO = 25 uA";
                    demoIconID = R.drawable.double_clench;
                    configFile = R.raw.lsm6dsv32x_wearable_double_clench;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double Clench";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double Clench");
                    imageIDs.add(R.drawable.double_clench);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_WEARABLE_HARD_FALL) {
                    demoName = "Hard Fall";
                    demoLogName = "HardFall";
                    demoDescription = "Provides real-time information if the person wearing the device got a hard fall. It uses the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Hard Fall detection";
                    demoCurrentConsumption = "Idd: SENSOR = 100 uA; ALGO = 45 uA";
                    demoIconID = R.drawable.hard_fall;
                    configFile = R.raw.lsm6dsv32x_wearable_hard_fall;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_RamConfigCard(true);
                    demo.addRamConfigItem("Threshold [g]", DemoClass.PARAM_TYPE_THRESHOLD, 20.0f, Arrays.asList("406", "407"), "Hard Fall threshold applied on accelerometer norm signal.");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Hard Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Fall!");
                    imageIDs.add(R.drawable.hard_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }

                if (LSM6DSV16BX_WEARABLE_VAD) {
                    demoName = "Voice Activity Detection";
                    demoLogName = "VAD";
                    demoDescription = "Detect voice activity using accelerometer sensor and Machine Learning Core.";
                    demoShortDescription = "Detect voice activity";
                    demoCurrentConsumption = "Idd: SENSOR = 190 uA; ALGO = 160 uA";
                    demoIconID = R.drawable.speak;
                    configFile = R.raw.lsm6dsv16bx_wearable_voice_activity_detection;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "VAD";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Mute");
                    imageIDs.add(R.drawable.mute);
                    values.add((byte)4);
                    strings.add("Speak");
                    imageIDs.add(R.drawable.speak);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16BX_WEARABLE_SFLP_QUAT)
                {
                    demoName = "Sensor Fusion Low Power";
                    demoLogName = "SFLP";
                    demoDescription = "Run the Sensor Fusion Low Power (SFLP) algorithm providing real-time quaternions data.";
                    demoShortDescription = "Provide SFLP quaternions data.";
                    demoCurrentConsumption = "Idd: SENSOR = 600 uA; ALGO = 28 uA";
                    demoIconID = R.drawable.sensor_fusion;
                    configFile = R.raw.lsm6dsv16bx_wearable_sflp_quat;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = SENSOR_FUSION_LOW_POWER_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "SFLP";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }

                if (LSM6DSO16IS_WEARABLE_UNSUPERVISED_ODL)
                {
                    demoName = "Self-Learning";
                    demoLogName = "SelfLearn";
                    demoDescription = "Self-Learning based on ISPU accelerometer data.";
                    demoShortDescription = "Self-Learning based on ISPU accelerometer data.";
                    demoCurrentConsumption = "Idd: SENSOR = 180 uA; ALGO = 30-340 uA";
                    demoIconID = R.drawable.ispu_unsupervised_odl;
                    configFile = R.raw.lsm6dso16is_wearable_unsupervised_odl;
                    jsonFile = R.raw.lsm6dso16is_wearable_unsupervised_odl_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_UnsupervisedOdlCard(true);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Unsupervised ODL";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSO16IS_WEARABLE_ACTIVITY) {
                    demoName = "Activity Recognition";
                    demoLogName = "WristActivity";
                    demoDescription = "Detect stationary, standing, sitting, lying, walking, fast walking, jogging and biking user activities: it uses the accelerometer sensor.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd: SENSOR = 25 uA; ALGO = 27 uA";
                    demoIconID = R.drawable.activity;
                    configFile = R.raw.lsm6dso16is_wearable_activity_wrist;
                    jsonFile = R.raw.lsm6dso16is_wearable_activity_wrist_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity Recognition";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSO16IS_WEARABLE_WRIST_TILT) {
                    demoName = "Wrist-Tilt";
                    demoLogName = "WristTilt";
                    demoDescription = "Detect wrist-up and wrist-down events using accelerometer sensor.";
                    demoShortDescription = "Detect wrist-up and wrist-down gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 25 uA; ALGO = 4 uA";
                    demoIconID = R.drawable.wrist_tilt;
                    configFile = R.raw.lsm6dso16is_wearable_wrist_tilt;
                    jsonFile = R.raw.lsm6dso16is_wearable_wrist_tilt_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_WEARABLE_WRIST_TILT_XL) {
                    demoName = "Wrist-Tilt (XL only)";
                    demoLogName = "WristTiltXL";
                    demoDescription = "Detect wrist-tilt events using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only). The detection is based on the absolute device orientation given by filtered accelerometer data.";
                    demoShortDescription = "Detect wrist-tilt gesture";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 8.10 uA";
                    demoIconID = R.drawable.wrist_tilt;
                    configFile = R.raw.lis2duxs12_wearable_wrist_tilt_xl;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Wrist-Tilt";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Wrist-Tilt!");
                    imageIDs.add(R.drawable.wrist_tilt);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_WEARABLE_WEAROS_NAVIGATION) {
                    demoName = "WearOS Navigation";
                    demoLogName = "WearOS";
                    demoDescription = "Detect wearOS gestures using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect wearOS gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 5.40 uA; ALGO = 7 uA";
                    demoIconID = R.drawable.wrist_wearos_navigation;
                    configFile = R.raw.lis2duxs12_wearable_wearos_navigation;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoOtherText("LEFT WRIST");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Push-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Push-Down!");
                    imageIDs.add(R.drawable.push_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Pivot-Up";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Pivot-Up!");
                    imageIDs.add(R.drawable.pivot_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flick-Out";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flick-Out!");
                    imageIDs.add(R.drawable.flick_out);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Flick-In";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Flick-In!");
                    imageIDs.add(R.drawable.flick_in);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_WEARABLE_JIGGLE) {
                    demoName = "Jiggle";
                    demoLogName = "Jiggle";
                    demoDescription = "Detect jiggle gesture using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect jiggle gestures";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 8.10 uA";
                    demoIconID = R.drawable.jiggle;
                    configFile = R.raw.lis2duxs12_wearable_jiggle;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Jiggle";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Jiggle!");
                    imageIDs.add(R.drawable.jiggle);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_WEARABLE_TAP_DETECTION) {
                    demoName = "Tap Detection";
                    demoLogName = "TapDetection";
                    demoDescription = "Detect single, double and triple tap events: it uses the accelerometer sensor and the Embedded Functions.";
                    demoShortDescription = "Detect tap events";
                    demoCurrentConsumption = "Idd: SENSOR + ALGO = 9 uA";
                    demoIconID = R.drawable.single_tap;
                    configFile = R.raw.lis2duxs12_wearable_tap_detection;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = SINGLE_TAP_STR;
                    singleDemoName = "Single-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = DOUBLE_TAP_STR;
                    singleDemoName = "Double-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double-Tap!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = EMBEDDED_FUNCTION_STR;
                    outputType = TRIPLE_TAP_STR;
                    singleDemoName = "Triple-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Triple-Tap!");
                    imageIDs.add(R.drawable.triple_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_WEARABLE_SINGLE_DOUBLE_TAP) {
                    demoName = "Taps Detection";
                    demoLogName = "Taps";
                    demoDescription = "Detect single and double taps using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only).";
                    demoShortDescription = "Detect single and double taps";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 52 uA";
                    demoIconID = R.drawable.single_tap;
                    configFile = R.raw.lis2duxs12_wearable_single_double_tap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Single-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double-Tap";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double-Tap");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_WEARABLE_QVAR_TOUCH) {
                    demoName = "Qvar UI Touch";
                    demoLogName = "QvarUITouch";
                    demoDescription = "Detect touch events using Qvar sensor and Finite State Machine.";
                    demoShortDescription = "Detect Qvar touch events";
                    demoCurrentConsumption = "Idd: SENSOR = 12.5 uA; ALGO = 39 uA";
                    demoIconID = R.drawable.long_press;
                    configFile = R.raw.lis2duxs12_wearable_qvar_touch;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Single Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single Touch!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double Touch!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Triple Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Triple Touch!");
                    imageIDs.add(R.drawable.triple_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Long Press";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Long Press!");
                    imageIDs.add(R.drawable.long_press);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_WEARABLE_QVAR_SWIPE) {
                    demoName = "Qvar UI Swipe";
                    demoLogName = "QvarUISwipe";
                    demoDescription = "Detect swipe events using Qvar sensor and Finite State Machine.";
                    demoShortDescription = "Detect Qvar swipe events";
                    demoCurrentConsumption = "Idd: SENSOR = 12.5 uA; ALGO = 23.5 uA";
                    demoIconID = R.drawable.swipe;
                    configFile = R.raw.lis2duxs12_wearable_qvar_swipe;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Swipe Right";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Swipe Right!");
                    imageIDs.add(R.drawable.swipe_right);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Swipe Left";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Swipe Left!");
                    imageIDs.add(R.drawable.swipe_left);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                break;

            case PC_DEMO_STR:
                if (LSM6DSOX_PC_IN_BAG_DETECTION) {
                    demoName = "In-Bag Detection";
                    demoLogName = "PCInBag";
                    demoDescription = "Detect when the laptop is carried inside of a bag: it uses the accelerometer sensor, the gyroscope sensor, the Finite State Machine and the Machine Learning Core.";
                    demoShortDescription = "Detect in-bag events";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.pc_bag;
                    configFile = R.raw.lsm6dsox_pc_in_bag_detection;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_InBagDetectionCard(true);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Context";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0x00);
                    strings.add("Unknown");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)0x01);
                    strings.add("Stationary");
                    imageIDs.add(R.drawable.pc_stationary);
                    values.add((byte)0x04);
                    strings.add("Super-Still");
                    imageIDs.add(R.drawable.notebook);
                    values.add((byte)0x08);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.pc_walking);
                    values.add((byte)0x0C);
                    strings.add("Transport");
                    imageIDs.add(R.drawable.pc_vehicle);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Orientation";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0x00);
                    strings.add("Unknown");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)0x01);
                    strings.add("No-Flat");
                    imageIDs.add(R.drawable.pc_no_flat);
                    values.add((byte)0x04);
                    strings.add("Flat");
                    imageIDs.add(R.drawable.pc_flat);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "In-Bag Flag";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Not In-Bag");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)1);
                    strings.add("In-Bag");
                    imageIDs.add(R.drawable.pc_bag);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_PC_OUT_FROM_BAG_DETECTION) {
                    demoName = "Out-from-Bag Detection";
                    demoLogName = "OutFromBag";
                    demoDescription = "Detect when the laptop is taken out from a bag and positioned on a surface. It uses the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Instant Wakeup detection";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.instant_wakeup;
                    configFile = R.raw.lsm6dsox_pc_out_from_bag_detection;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoStartupLatency(2000);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Out-from-Bag";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add(IDLE);
                    strings.add("");
                    imageIDs.add(R.drawable.notebook);
                    values.add(EVENT);
                    strings.add("Wakeup!");
                    imageIDs.add(R.drawable.instant_wakeup);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_PC_ON_TABLE_DETECTION) {
                    demoName = "On-Table Detection";
                    demoLogName = "OTD";
                    demoDescription = "Detect table stationary condition. It uses the accelerometer sensor, the gyroscope sensor, the Finite State Machine and the Machine Learning Core.";
                    demoShortDescription = "Detect table stationary condition";
                    demoCurrentConsumption = "Idd: SENSOR = 550 uA; ALGO = 14 uA";
                    demoIconID = R.drawable.on_table_detection;
                    configFile = R.raw.lsm6dsox_pc_on_table_detection;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    demo.setDemoUsage_RamConfigCard(true);
                    demo.addRamConfigItem("On-Table latency [#samples]", DemoClass.PARAM_TYPE_LONG_TIMER, 260.0f, Arrays.asList("466"), "Time required to switch from Not-on-Table to On-Table (default is 260 samples, which means 5 seconds).");
                    demo.addRamConfigItem("Not-on-Table latency [#samples]", DemoClass.PARAM_TYPE_LONG_TIMER, 260.0f, Arrays.asList("468"), "Time required to switch from On-Table to Not-on-Table (default is 260 samples, which means 5 seconds).");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "On-Table Detection";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Not-On-Table");
                    imageIDs.add(R.drawable.not_on_table_detection);
                    values.add((byte)1);
                    strings.add("On-Table");
                    imageIDs.add(R.drawable.on_table_detection);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_PC_PICKUP_DETECTION) {
                    demoName = "Pickup Detection";
                    demoLogName = "PCPickup";
                    demoDescription = "Detect pickup events using accelerometer sensor, Finite State Machine and Machine Learning Core (filters only). The pickup detection is automatically enabled after a period of stationarity.";
                    demoShortDescription = "Detect pickup events";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.pc_pickup;
                    configFile = R.raw.lsm6dsox_pc_pickup;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MLC(true);
                    demo.setDemoUsage_RamConfigCard(true);
                    demo.addRamConfigItem("Stationarity timer [#samples]", DemoClass.PARAM_TYPE_LONG_TIMER, 1560.0f, Arrays.asList("76A", "796"), "Number of samples of stationarity to internally enable the pickup algorithm (default is 1560 samples, which means 30 seconds).");

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MULTIPLE_OUTPUTS_STR;
                    singleDemoName = "Pickup";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Pickup!");
                    imageIDs.add(R.drawable.pc_pickup);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_PC_LIFTUP) {
                    demoName = "Lift-Up";
                    demoLogName = "LiftUp";
                    demoDescription = "Detect lift and delift events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect lift and delift events";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.pc_lift;
                    configFile = R.raw.lsm6dsox_pc_lift_delift;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Lift";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x08);
                    strings.add("Delift!");
                    imageIDs.add(R.drawable.pc_lift_sleep);
                    values.add((byte)0x10);
                    strings.add("Lift (landscape up)!");
                    imageIDs.add(R.drawable.pc_lift_wake_landscape_up);
                    values.add((byte)0x20);
                    strings.add("Lift (landscape down)!");
                    imageIDs.add(R.drawable.pc_lift_wake_landscape_down);
                    values.add((byte)0x40);
                    strings.add("Lift (portrait right)!");
                    imageIDs.add(R.drawable.pc_lift_wake_portrait_right);
                    values.add((byte)0x80);
                    strings.add("Lift (portrait left)!");
                    imageIDs.add(R.drawable.pc_lift_wake_portrait_left);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_PC_ACTIVITY_RECOGNITION) {
                    demoName = "Activity Recognition";
                    demoLogName = "PCActivity";
                    demoDescription = "Detect stationary, walking and running user activities, optimized for PC applications: it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect user activities";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.pc_activity;
                    configFile = R.raw.lsm6dsox_pc_activity_recognition;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0x00);
                    strings.add("Still");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)0x04);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.pc_walking);
                    values.add((byte)0x08);
                    strings.add("Running");
                    imageIDs.add(R.drawable.pc_running);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_PC_CARRY_POSITION) {
                    demoName = "Carry Position";
                    demoLogName = "CarryPosition";
                    demoDescription = "Detect the laptop carry position (carry front, carry lateral or carry backpack): it uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Detect the laptop carry position";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 5 uA";
                    demoIconID = R.drawable.pc_carry_position;
                    configFile = R.raw.lsm6dsox_pc_carry_position;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Carry Position";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0x00);
                    strings.add("Still");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)0x04);
                    strings.add("Carry Front");
                    imageIDs.add(R.drawable.pc_carry_front);
                    values.add((byte)0x08);
                    strings.add("Carry Lateral");
                    imageIDs.add(R.drawable.pc_carry_lateral);
                    values.add((byte)0x0C);
                    strings.add("Carry Backpack");
                    imageIDs.add(R.drawable.pc_carry_backpack);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_PC_LIFTUP) {
                    demoName = "Lift";
                    demoLogName = "Lift";
                    demoDescription = "Detect lift and delift events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect lift and delift events";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.pc_lift;
                    configFile = R.raw.lsm6dsv16x_pc_lift_delift;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Lift";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x08);
                    strings.add("Delift!");
                    imageIDs.add(R.drawable.pc_lift_sleep);
                    values.add((byte)0x10);
                    strings.add("Lift (landscape up)!");
                    imageIDs.add(R.drawable.pc_lift_wake_landscape_up);
                    values.add((byte)0x20);
                    strings.add("Lift (landscape down)!");
                    imageIDs.add(R.drawable.pc_lift_wake_landscape_down);
                    values.add((byte)0x40);
                    strings.add("Lift (portrait right)!");
                    imageIDs.add(R.drawable.pc_lift_wake_portrait_right);
                    values.add((byte)0x80);
                    strings.add("Lift (portrait left)!");
                    imageIDs.add(R.drawable.pc_lift_wake_portrait_left);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_PC_LIFTUP) {
                    demoName = "Lift";
                    demoLogName = "Lift";
                    demoDescription = "Detect lift and delift events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect lift and delift events";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.pc_lift;
                    configFile = R.raw.lsm6dsv32x_pc_lift_delift;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Lift";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x08);
                    strings.add("Delift!");
                    imageIDs.add(R.drawable.pc_lift_sleep);
                    values.add((byte)0x10);
                    strings.add("Lift (landscape up)!");
                    imageIDs.add(R.drawable.pc_lift_wake_landscape_up);
                    values.add((byte)0x20);
                    strings.add("Lift (landscape down)!");
                    imageIDs.add(R.drawable.pc_lift_wake_landscape_down);
                    values.add((byte)0x40);
                    strings.add("Lift (portrait right)!");
                    imageIDs.add(R.drawable.pc_lift_wake_portrait_right);
                    values.add((byte)0x80);
                    strings.add("Lift (portrait left)!");
                    imageIDs.add(R.drawable.pc_lift_wake_portrait_left);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_PC_LIFTUP) {
                    demoName = "Lift";
                    demoLogName = "Lift";
                    demoDescription = "Detect lift and delift events using the accelerometer sensor and the Finite State Machine.";
                    demoShortDescription = "Detect lift and delift events";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 7.10 uA";
                    demoIconID = R.drawable.pc_lift;
                    configFile = R.raw.lis2duxs12_pc_lift_delift;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Lift";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x08);
                    strings.add("Delift!");
                    imageIDs.add(R.drawable.pc_lift_sleep);
                    values.add((byte)0x10);
                    strings.add("Lift (landscape up)!");
                    imageIDs.add(R.drawable.pc_lift_wake_landscape_up);
                    values.add((byte)0x20);
                    strings.add("Lift (landscape down)!");
                    imageIDs.add(R.drawable.pc_lift_wake_landscape_down);
                    values.add((byte)0x40);
                    strings.add("Lift (portrait right)!");
                    imageIDs.add(R.drawable.pc_lift_wake_portrait_right);
                    values.add((byte)0x80);
                    strings.add("Lift (portrait left)!");
                    imageIDs.add(R.drawable.pc_lift_wake_portrait_left);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                break;

            case AUTOMOTIVE_DEMO_STR:
                if (LSM6DSOX_AUTOMOTIVE_VEHICLE_STATIONARY_DETECTION) {
                    demoName = "Vehicle Stationary Detection";
                    demoLogName = "VehicleStatDet";
                    demoDescription = "Detect the vehicle Motion or Stationary condition. It uses the accelerometer sensor, the gyroscope sensor and the Machine Learning Core.";
                    demoShortDescription = "Motion / stationary detection for vehicles";
                    demoCurrentConsumption = "Idd: SENSOR = 550 uA; ALGO = 15 uA";
                    demoIconID = R.drawable.vehicle_stationary;
                    configFile = R.raw.lsm6dsox_automotive_vehicle_stationary_detection;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Status";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Motion");
                    imageIDs.add(R.drawable.vehicle_motion);
                    values.add((byte)4);
                    strings.add("Stationary");
                    imageIDs.add(R.drawable.vehicle_stationary);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                break;

            case EARABLE_DEMO_STR:
                if (LSM6DSV16X_EARABLE_VAD) {
                    demoName = "Voice Activity Detection";
                    demoLogName = "VoiceActDet";
                    demoDescription = "Detect if the user is talking or not. It uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Voice activity detection for earable devices";
                    demoCurrentConsumption = "Current consumption:\n- XL = 195 uA\n- MLC = 130 uA (embedded AI)";
                    demoIconID = R.drawable.speak;
                    configFile = R.raw.lsm6dsv16x_earable_voice_activity_detection;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "VAD";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Mute");
                    imageIDs.add(R.drawable.mute);
                    values.add((byte)4);
                    strings.add("Speak");
                    imageIDs.add(R.drawable.speak);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16BX_EARABLE_VAD) {
                    demoName = "Voice Activity Detection";
                    demoLogName = "VoiceActDet";
                    demoDescription = "Detect if the user is talking or not. It uses the accelerometer sensor and the Machine Learning Core.";
                    demoShortDescription = "Voice activity detection for earable devices";
                    demoCurrentConsumption = "Current consumption:\n- XL = 195 uA\n- MLC = 130 uA (embedded AI)";
                    demoIconID = R.drawable.speak;
                    configFile = R.raw.lsm6dsv16bx_earable_voice_activity_detection;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "VAD";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Mute");
                    imageIDs.add(R.drawable.mute);
                    values.add((byte)4);
                    strings.add("Speak");
                    imageIDs.add(R.drawable.speak);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_LSM6DSV16BX_EARABLE_PEDOMETER) {
                    demoName = "Pedometer";
                    demoLogName = "TwsPedo";
                    demoDescription = "Enable embedded pedometer for counting steps, optimized for tws devices: it uses accelerometer sensor only and the Pedometer 2.0.";
                    demoShortDescription = "Count number of steps";
                    demoCurrentConsumption = "Current consumption:\n- XL = 10 uA\n- Embedded Pedometer = 2 uA";
                    demoIconID = R.drawable.pedometer;
                    configFile = R.raw.lsm6dsv16x_lsm6dsv16bx_earable_pedo_configuration;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = PEDOMETER_2_0_STR;
                    singleDemoName = "Step Counter";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.step_left);
                    values.add((byte)1);
                    strings.add("");
                    imageIDs.add(R.drawable.step_right);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_LSM6DSV16BX_EARABLE_SPATIAL_AUDIO) {
                    demoName = "3D Spatial Audio";
                    demoLogName = "SpatialAudio";
                    demoDescription = "Shows a 3D model rotating based on quaternions data.";
                    demoShortDescription = "Shows 3D model";
                    demoCurrentConsumption = "Current consumption:\n- XL + Gyro = 600 uA\n- Embedded Sensor Fusion = 30 uA";
                    demoIconID = R.drawable.spatial_sound;
                    configFile = R.raw.lsm6dsv16x_lsm6dsv16bx_earable_emb_fusion_cmd;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    demo.setDemoUsage_XL(true);
                    demo.setDemoUsage_G(true);
                    demo.setDemoUsage_SFLP(true);
                    demo.setDemoUsage_FusionCard(true);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_EARABLE_IN_EAR)
                {
                    demoName = "In-Ear";
                    demoLogName = "In-Ear";
                    demoDescription = "Detect in-ear events: it uses the Qvar data (Q-) processed by the Finite State Machine (the accelerometer is kept on only to enable the Qvar).";
                    demoShortDescription = "Detect in-ear events";
                    demoCurrentConsumption = "Current consumption:\n- XL = 100 uA\n- Qvar = 15 uA\n- FSM = 4 uA";
                    demoIconID = R.drawable.in_ear;
                    configFile = R.raw.lsm6dsv16x_earable_in_ear_qn;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "In-Ear";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("In-Ear!");
                    imageIDs.add(R.drawable.in_ear);

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16BX_EARABLE_IN_EAR)
                {
                    demoName = "In-Ear";
                    demoLogName = "In-Ear";
                    demoDescription = "Detect in-ear events: it uses the Qvar data (Q+) processed by the Finite State Machine (the accelerometer is kept on only to enable the Qvar).";
                    demoShortDescription = "Detect in-ear events";
                    demoCurrentConsumption = "Current consumption:\n- XL = 100 uA\n- Qvar = 15 uA\n- FSM = 4 uA";
                    demoIconID = R.drawable.in_ear;
                    configFile = R.raw.lsm6dsv16bx_earable_in_ear_qp;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "In-Ear";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("In-Ear!");
                    imageIDs.add(R.drawable.in_ear);

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_EARABLE_TOUCH)
                {
                    demoName = "Touch";
                    demoLogName = "Touch";
                    demoDescription = "Detect single touch, double touch, triple touch and long press events: it uses the Qvar data (Q+) processed by the Finite State Machine (the accelerometer is kept on only to enable the Qvar).";
                    demoShortDescription = "Detect touch events";
                    demoCurrentConsumption = "Current consumption:\n- XL = 100 uA\n- Qvar = 15 uA\n- FSM = 68 uA";
                    demoIconID = R.drawable.long_press;
                    configFile = R.raw.lsm6dsv16x_earable_touch;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Single Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single Touch!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double Touch!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Triple Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Triple Touch!");
                    imageIDs.add(R.drawable.triple_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Long Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Long Touch!");
                    imageIDs.add(R.drawable.long_press);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16BX_EARABLE_TOUCH)
                {
                    demoName = "Touch";
                    demoLogName = "Touch";
                    demoDescription = "Detect single touch, double touch, triple touch and long press events: it uses the Qvar data (Q-) processed by the Finite State Machine (the accelerometer is kept on only to enable the Qvar).";
                    demoShortDescription = "Detect touch events";
                    demoCurrentConsumption = "Current consumption:\n- XL = 100 uA\n- Qvar = 15 uA\n- FSM = 83 uA";
                    demoIconID = R.drawable.long_press;
                    configFile = R.raw.lsm6dsv16bx_earable_touch_qn;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Single Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single Touch!");
                    imageIDs.add(R.drawable.single_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Double Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Double Touch!");
                    imageIDs.add(R.drawable.double_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Triple Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Triple Touch!");
                    imageIDs.add(R.drawable.triple_tap);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Long Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Long Touch!");
                    imageIDs.add(R.drawable.long_press);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_EARABLE_SWIPE)
                {
                    demoName = "Swipe";
                    demoLogName = "Swipe";
                    demoDescription = "Detect swipe events: it uses the Qvar data (Q- and Q+) processed by the Finite State Machine (the accelerometer is kept on only to enable the Qvar).";
                    demoShortDescription = "Detect swipe events";
                    demoCurrentConsumption = "Current consumption:\n- XL = 100 uA\n- Qvar = 15 uA\n- FSM = 4 uA";
                    demoIconID = R.drawable.swipe;
                    configFile = R.raw.lsm6dsv16x_earable_swipe;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Swipe";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Left!");
                    imageIDs.add(R.drawable.swipe_left);
                    values.add((byte)2);
                    strings.add("Right!");
                    imageIDs.add(R.drawable.swipe_right);

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16BX_EARABLE_SWIPE)
                {
                    demoName = "Swipe";
                    demoLogName = "Swipe";
                    demoDescription = "Detect swipe events: it uses the Qvar data (Q- and Q+) processed by the Finite State Machine (the accelerometer is kept on only to enable the Qvar).";
                    demoShortDescription = "Detect swipe events";
                    demoCurrentConsumption = "Current consumption:\n- XL = 100 uA\n- Qvar = 15 uA\n- FSM = 4 uA";
                    demoIconID = R.drawable.swipe;
                    configFile = R.raw.lsm6dsv16bx_earable_swipe;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_DemoLogCard(false);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Swipe";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Left!");
                    imageIDs.add(R.drawable.swipe_left);
                    values.add((byte)2);
                    strings.add("Right!");
                    imageIDs.add(R.drawable.swipe_right);

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                break;

            case GENERIC_DEMO_STR:
                if (LSM6DSOX_GENERIC_VIBRATION_MONITORING) {
                    demoName = "Vibration Monitoring";
                    demoLogName = "Vibration";
                    demoDescription = "Detect three differents vibration levels using the accelerometer sensor and the embedded Machine Learning Core.";
                    demoShortDescription = "Detect levels of accelerometer vibrations";
                    demoCurrentConsumption = "Idd: SENSOR = 170 uA; ALGO = 1.5 uA";
                    demoIconID = R.drawable.vibration_monitoring;
                    configFile = R.raw.lsm6dsox_generic_vibration_monitoring;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoStartupLatency(2000);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Vibration Level";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Level-1");
                    imageIDs.add(R.drawable.vibration_level_1);
                    values.add((byte)1);
                    strings.add("Level-2");
                    imageIDs.add(R.drawable.vibration_level_2);
                    values.add((byte)2);
                    strings.add("Level-3");
                    imageIDs.add(R.drawable.vibration_level_3);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_GENERIC_MOTION_STATIONARY) {
                    demoName = "Motion-Stationary";
                    demoLogName = "MotionStat";
                    demoDescription = "Detect motion and stationary events using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect motion-stationary events";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 3 uA";
                    demoIconID = R.drawable.motion;
                    configFile = R.raw.lsm6dsox_generic_motion_stationary;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Motion-Stationary";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Stationary!");
                    imageIDs.add(R.drawable.stationary);
                    values.add((byte)1);
                    strings.add("Motion!");
                    imageIDs.add(R.drawable.motion);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_GENERIC_SIX_D) {
                    demoName = "6-D Orientation";
                    demoLogName = "SixD";
                    demoDescription = "Detect the orientation of the device using the accelerometer sensor and the embedded Machine Learning Core.";
                    demoShortDescription = "Detect 6-D orientation";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 2.5 uA";
                    demoIconID = R.drawable.six_d;
                    configFile = R.raw.lsm6dsox_generic_six_d;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = MACHINE_LEARNING_CORE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "6-D";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Others");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("X-Up");
                    imageIDs.add(R.drawable.six_d_xp);
                    values.add((byte)2);
                    strings.add("X-Down");
                    imageIDs.add(R.drawable.six_d_xn);
                    values.add((byte)3);
                    strings.add("Y-Up");
                    imageIDs.add(R.drawable.six_d_yp);
                    values.add((byte)4);
                    strings.add("Y-Down");
                    imageIDs.add(R.drawable.six_d_yn);
                    values.add((byte)5);
                    strings.add("Z-Up");
                    imageIDs.add(R.drawable.six_d_zp);
                    values.add((byte)6);
                    strings.add("Z-Down");
                    imageIDs.add(R.drawable.six_d_zn);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_GENERIC_FOUR_D) {
                    demoName = "4-D Orientation";
                    demoLogName = "FourD";
                    demoDescription = "Detect the orientation of the device using the accelerometer sensor and the embedded Finite State Machine.";
                    demoShortDescription = "Detect 4-D orientation";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 3 uA";
                    demoIconID = R.drawable.four_d;
                    configFile = R.raw.lsm6dsox_generic_four_d;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "4-D";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    values.add((byte)0);
                    strings.add("Others");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x10);
                    strings.add("Down!");
                    imageIDs.add(R.drawable.six_d_yn);
                    values.add((byte)0x20);
                    strings.add("Up!");
                    imageIDs.add(R.drawable.six_d_yp);
                    values.add((byte)0x40);
                    strings.add("Right!");
                    imageIDs.add(R.drawable.six_d_xn);
                    values.add((byte)0x80);
                    strings.add("Left!");
                    imageIDs.add(R.drawable.six_d_xp);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSOX_GENERIC_FREE_FALL) {
                    demoName = "Free-Fall";
                    demoLogName = "FreeFall";
                    demoDescription = "Detect free-fall events using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect free-fall events";
                    demoCurrentConsumption = "Idd: SENSOR = 7 uA; ALGO = 4.5 uA";
                    demoIconID = R.drawable.free_fall;
                    configFile = R.raw.lsm6dsox_generic_free_fall;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Free-Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Free-Fall!");
                    imageIDs.add(R.drawable.free_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_GENERIC_SFLP_QUAT)
                {
                    demoName = "Sensor Fusion Low Power";
                    demoLogName = "SFLP";
                    demoDescription = "Run the Sensor Fusion Low Power (SFLP) algorithm providing real-time quaternions data.";
                    demoShortDescription = "Provide SFLP quaternions data.";
                    demoCurrentConsumption = "Idd: SENSOR = 650 uA; ALGO = 28 uA";
                    demoIconID = R.drawable.sensor_fusion;
                    configFile = R.raw.lsm6dsv16x_generic_sflp_quat;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = SENSOR_FUSION_LOW_POWER_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "SFLP";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_GENERIC_MOTION_STATIONARY) {
                    demoName = "Motion-Stationary";
                    demoLogName = "MotionStat";
                    demoDescription = "Detect motion and stationary events using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect motion-stationary events";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.motion;
                    configFile = R.raw.lsm6dsv16x_generic_motion_stationary;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Motion-Stationary";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Stationary!");
                    imageIDs.add(R.drawable.stationary);
                    values.add((byte)1);
                    strings.add("Motion!");
                    imageIDs.add(R.drawable.motion);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_GENERIC_FOUR_D) {
                    demoName = "4-D Orientation";
                    demoLogName = "FourD";
                    demoDescription = "Detect the orientation of the device using the accelerometer sensor and the embedded Finite State Machine.";
                    demoShortDescription = "Detect 4-D orientation";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.four_d;
                    configFile = R.raw.lsm6dsv16x_generic_four_d;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "4-D";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    values.add((byte)0);
                    strings.add("Others");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x10);
                    strings.add("Down!");
                    imageIDs.add(R.drawable.six_d_yn);
                    values.add((byte)0x20);
                    strings.add("Up!");
                    imageIDs.add(R.drawable.six_d_yp);
                    values.add((byte)0x40);
                    strings.add("Right!");
                    imageIDs.add(R.drawable.six_d_xn);
                    values.add((byte)0x80);
                    strings.add("Left!");
                    imageIDs.add(R.drawable.six_d_xp);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_GENERIC_FREE_FALL) {
                    demoName = "Free-Fall";
                    demoLogName = "FreeFall";
                    demoDescription = "Detect free-fall events using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect free-fall events";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 5.5 uA";
                    demoIconID = R.drawable.free_fall;
                    configFile = R.raw.lsm6dsv16x_generic_free_fall;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Free-Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Free-Fall!");
                    imageIDs.add(R.drawable.free_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV16X_GENERIC_FREE_FALL_HEIGHT) {
                    demoName = "Free-Fall Height";
                    demoLogName = "FreeFallH";
                    demoDescription = "Detect free-fall events and provide height estimation using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect free-fall events with height estimation";
                    demoCurrentConsumption = "Idd: SENSOR = 100.0 uA; ALGO = 53.5 uA";
                    demoIconID = R.drawable.free_fall_height;
                    configFile = R.raw.lsm6dsv16x_generic_free_fall_height;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_FallHeightEstimationCard(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Free-Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Free-Fall!");
                    imageIDs.add(R.drawable.free_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_GENERIC_SFLP_QUAT)
                {
                    demoName = "Sensor Fusion Low Power";
                    demoLogName = "SFLP";
                    demoDescription = "Run the Sensor Fusion Low Power (SFLP) algorithm providing real-time quaternions data.";
                    demoShortDescription = "Provide SFLP quaternions data.";
                    demoCurrentConsumption = "Idd: SENSOR = 650 uA; ALGO = 28 uA";
                    demoIconID = R.drawable.sensor_fusion;
                    configFile = R.raw.lsm6dsv32x_generic_sflp_quat;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = SENSOR_FUSION_LOW_POWER_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "SFLP";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_GENERIC_MOTION_STATIONARY) {
                    demoName = "Motion-Stationary";
                    demoLogName = "MotionStat";
                    demoDescription = "Detect motion and stationary events using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect motion-stationary events";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.motion;
                    configFile = R.raw.lsm6dsv32x_generic_motion_stationary;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Motion-Stationary";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Stationary!");
                    imageIDs.add(R.drawable.stationary);
                    values.add((byte)1);
                    strings.add("Motion!");
                    imageIDs.add(R.drawable.motion);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_GENERIC_FOUR_D) {
                    demoName = "4-D Orientation";
                    demoLogName = "FourD";
                    demoDescription = "Detect the orientation of the device using the accelerometer sensor and the embedded Finite State Machine.";
                    demoShortDescription = "Detect 4-D orientation";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.four_d;
                    configFile = R.raw.lsm6dsv32x_generic_four_d;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "4-D";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    values.add((byte)0);
                    strings.add("Others");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x10);
                    strings.add("Down!");
                    imageIDs.add(R.drawable.six_d_yn);
                    values.add((byte)0x20);
                    strings.add("Up!");
                    imageIDs.add(R.drawable.six_d_yp);
                    values.add((byte)0x40);
                    strings.add("Right!");
                    imageIDs.add(R.drawable.six_d_xn);
                    values.add((byte)0x80);
                    strings.add("Left!");
                    imageIDs.add(R.drawable.six_d_xp);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_GENERIC_FREE_FALL) {
                    demoName = "Free-Fall";
                    demoLogName = "FreeFall";
                    demoDescription = "Detect free-fall events using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect free-fall events";
                    demoCurrentConsumption = "Idd: SENSOR = 10.5 uA; ALGO = 5.5 uA";
                    demoIconID = R.drawable.free_fall;
                    configFile = R.raw.lsm6dsv32x_generic_free_fall;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Free-Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Free-Fall!");
                    imageIDs.add(R.drawable.free_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSV32X_GENERIC_FREE_FALL_HEIGHT) {
                    demoName = "Free-Fall Height";
                    demoLogName = "FreeFallH";
                    demoDescription = "Detect free-fall events and provide height estimation using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect free-fall events with height estimation";
                    demoCurrentConsumption = "Idd: SENSOR = 100.0 uA; ALGO = 53.5 uA";
                    demoIconID = R.drawable.free_fall_height;
                    configFile = R.raw.lsm6dsv32x_generic_free_fall_height;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_FallHeightEstimationCard(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Free-Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Free-Fall!");
                    imageIDs.add(R.drawable.free_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSO16IS_GENERIC_SENSOR_FUSION_6X)
                {
                    demoName = "Sensor Fusion 6x";
                    demoLogName = "SensFus6x";
                    demoDescription = "Run the 6x Sensor Fusion algorithm providing real-time quaternions data.";
                    demoShortDescription = "Provide 6x Sensor Fusion quaternions data.";
                    demoCurrentConsumption = "Idd: SENSOR = 595 uA; ALGO = 226 uA";
                    demoIconID = R.drawable.sensor_fusion;
                    configFile = R.raw.lsm6dso16is_generic_sensor_fusion_6x;
                    jsonFile = R.raw.lsm6dso16is_generic_sensor_fusion_6x_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_FusionCard(true);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Sensor Fusion 6x";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSO16IS_GENERIC_E_BUBBLE_LEVEL)
                {
                    demoName = "e-Bubble Level";
                    demoLogName = "eBubbleLevel";
                    demoDescription = "Run the inclinometer algorithm based on runtime accelerometer calibrated data.";
                    demoShortDescription = "Provide calibrated inclinometer data.";
                    demoCurrentConsumption = "Idd: SENSOR = 595 uA; ALGO = 150 uA";
                    demoIconID = R.drawable.e_bubble_level;
                    configFile = R.raw.lsm6dso16is_generic_e_bubble_level;
                    jsonFile = R.raw.lsm6dso16is_generic_e_bubble_level_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "e-Bubble Level";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSO16IS_GENERIC_PEDOMETER) {
                    demoName = "Pedometer";
                    demoLogName = "Pedometer";
                    demoDescription = "Provides real-time information about the number of steps which the user just performed. It is based on accelerometer data only.";
                    demoShortDescription = "Compute number of steps";
                    demoCurrentConsumption = "Idd: SENSOR = 25 uA; ALGO = 16 uA";
                    demoIconID = R.drawable.pedometer;
                    configFile = R.raw.lsm6dso16is_smartphone_pedometer;
                    jsonFile = R.raw.lsm6dso16is_smartphone_pedometer_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Pedometer";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSO16IS_GENERIC_ACC_CALIBRATION)
                {
                    demoName = "Accelerometer Calibration";
                    demoLogName = "AccCal";
                    demoDescription = "Compute the accelerometer offsets and scale factors. The calibration procedure requires acquiring the accelerometer samples at six different orientations with the device steady for a couple of seconds. The six positions can be with every axis towards the ceiling and the ground such that each axis senses about +1 g or -1 g.";
                    demoShortDescription = "Compute the accelerometer calibration parameters.";
                    demoCurrentConsumption = "Idd: SENSOR = 180 uA; ALGO = 11-19 uA";
                    demoIconID = R.drawable.acc_calibration;
                    configFile = R.raw.lsm6dso16is_generic_acc_calibration;
                    jsonFile = R.raw.lsm6dso16is_generic_acc_calibration_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Accelerometer Calibration";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSO16IS_GENERIC_GYR_CALIBRATION)
                {
                    demoName = "Gyroscope Calibration";
                    demoLogName = "GyrCal";
                    demoDescription = "Compute the gyroscope bias. The calibration procedure requires keeping the device steady.";
                    demoShortDescription = "Compute the gyroscope bias.";
                    demoCurrentConsumption = "Idd: SENSOR = 595 uA; ALGO = 26-67 uA";
                    demoIconID = R.drawable.gyr_calibration;
                    configFile = R.raw.lsm6dso16is_generic_gyr_calibration;
                    jsonFile = R.raw.lsm6dso16is_generic_gyr_calibration_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Gyroscope Calibration";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LSM6DSO16IS_GENERIC_NORM)
                {
                    demoName = "Norm";
                    demoLogName = "Norm";
                    demoDescription = "Compute the accelerometer norm signal.";
                    demoShortDescription = "Compute the accelerometer norm signal.";
                    demoCurrentConsumption = "Idd: SENSOR = 180 uA; ALGO = 3.5 uA";
                    demoIconID = R.drawable.six_d;
                    configFile = R.raw.lsm6dso16is_generic_norm;
                    jsonFile = R.raw.lsm6dso16is_generic_norm_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Norm";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if(LSM6DSO16IS_GENERIC_CRC8)
                {
                    demoName = "CRC8";
                    demoLogName = "CRC8";
                    demoDescription = "Compute the 8-bit CRC of the sensor data (12 bytes).";
                    demoShortDescription = "Compute the 8-bit CRC of the sensor data.";
                    demoCurrentConsumption = "Idd: SENSOR = 595 uA; ALGO = 1.5 uA";
                    demoIconID = R.drawable.crc8;
                    configFile = R.raw.lsm6dso16is_generic_crc8;
                    jsonFile = R.raw.lsm6dso16is_generic_crc8_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "CRC8";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if(LSM6DSO16IS_GENERIC_CRC32)
                {
                    demoName = "CRC32";
                    demoLogName = "CRC32";
                    demoDescription = "Compute the 32-bit CRC of the sensor data (12 bytes).";
                    demoShortDescription = "Compute the 32-bit CRC of the sensor data.";
                    demoCurrentConsumption = "Idd: SENSOR = 595 uA; ALGO = 1.5 uA";
                    demoIconID = R.drawable.crc32;
                    configFile = R.raw.lsm6dso16is_generic_crc32;
                    jsonFile = R.raw.lsm6dso16is_generic_crc32_json;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = ISPU_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "CRC8";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_GENERIC_FOUR_D) {
                    demoName = "4-D Orientation";
                    demoLogName = "FourD";
                    demoDescription = "Detect the orientation of the device using the accelerometer sensor and the embedded Finite State Machine.";
                    demoShortDescription = "Detect 4-D orientation";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 7.10 uA";
                    demoIconID = R.drawable.four_d;
                    configFile = R.raw.lis2duxs12_generic_four_d;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "4-D";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();

                    values.add((byte)0);
                    strings.add("Others");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)0x10);
                    strings.add("Down!");
                    imageIDs.add(R.drawable.six_d_yn);
                    values.add((byte)0x20);
                    strings.add("Up!");
                    imageIDs.add(R.drawable.six_d_yp);
                    values.add((byte)0x40);
                    strings.add("Right!");
                    imageIDs.add(R.drawable.six_d_xn);
                    values.add((byte)0x80);
                    strings.add("Left!");
                    imageIDs.add(R.drawable.six_d_xp);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_GENERIC_MOTION_STATIONARY) {
                    demoName = "Motion-Stationary";
                    demoLogName = "MotionStat";
                    demoDescription = "Detect motion and stationary events using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect motion-stationary events";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 7 uA";
                    demoIconID = R.drawable.motion;
                    configFile = R.raw.lis2duxs12_generic_motion_stationary;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Motion-Stationary";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Stationary!");
                    imageIDs.add(R.drawable.stationary);
                    values.add((byte)1);
                    strings.add("Motion!");
                    imageIDs.add(R.drawable.motion);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_GENERIC_FREE_FALL) {
                    demoName = "Free-Fall";
                    demoLogName = "FreeFall";
                    demoDescription = "Detect free-fall events using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect free-fall events";
                    demoCurrentConsumption = "Idd: SENSOR = 3.40 uA; ALGO = 7.80 uA";
                    demoIconID = R.drawable.free_fall;
                    configFile = R.raw.lis2duxs12_generic_free_fall;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Free-Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Free-Fall!");
                    imageIDs.add(R.drawable.free_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (LIS2DUXS12_GENERIC_FREE_FALL_HEIGHT) {
                    demoName = "Free-Fall Height";
                    demoLogName = "FreeFallH";
                    demoDescription = "Detect free-fall events and provide height estimation using accelerometer sensor and Finite State Machine.";
                    demoShortDescription = "Detect free-fall events with height estimation";
                    demoCurrentConsumption = "Idd: SENSOR = 7.0 uA; ALGO = 25 uA";
                    demoIconID = R.drawable.free_fall_height;
                    configFile = R.raw.lis2duxs12_generic_free_fall_height;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_FallHeightEstimationCard(true);

                    featureName = FINITE_STATE_MACHINE_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Free-Fall";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Free-Fall!");
                    imageIDs.add(R.drawable.free_fall);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                break;

            case SW_LIB_DEMO_STR:
                if (SW_LIB_MOTION_AW) {
                    demoName = "MotionAW";
                    demoLogName = "MotionAW";
                    demoDescription = "Provides real-time information on the type of activity performed by the user wearing the device on the wrist including stationary, standing, sitting, lying, walking, fast walking, jogging, or biking. It is based on accelerometer data only.";
                    demoShortDescription = "Activity for Wrist-worn devices";
                    demoCurrentConsumption = "Idd: N/A";
                    demoIconID = R.drawable.activity;
                    configFile = R.raw.swlib_motionaw;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_XL(true);

                    featureName = SW_LIB_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("No Activity");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Stationary");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)2);
                    strings.add("Standing");
                    imageIDs.add(R.drawable.standing);
                    values.add((byte)3);
                    strings.add("Sitting");
                    imageIDs.add(R.drawable.sitting);
                    values.add((byte)4);
                    strings.add("Lying");
                    imageIDs.add(R.drawable.lying);
                    values.add((byte)5);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)6);
                    strings.add("Fast Walking");
                    imageIDs.add(R.drawable.fast_walking);
                    values.add((byte)7);
                    strings.add("Jogging");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)8);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (SW_LIB_MOTION_PW)
                {
                    demoName = "MotionPW";
                    demoLogName = "MotionPW";
                    demoDescription = "Provides real-time information about the number of steps which the user just performed wearing the device on the wrist (e.g. a smart watch). It is based on accelerometer data only.";
                    demoShortDescription = "Pedometer for Wrist-worn devices";
                    demoCurrentConsumption = "Idd: N/A";
                    demoIconID = R.drawable.pedometer;
                    configFile = R.raw.swlib_motionpw;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_XL(true);

                    featureName = SW_LIB_STR;
                    outputType = COUNTER_STR;
                    singleDemoName = "Step Counter";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.step_left);
                    values.add((byte)1);
                    strings.add("");
                    imageIDs.add(R.drawable.step_right);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (SW_LIB_MOTION_FA_B)
                {
                    demoName = "MotionFA (Biceps)";
                    demoLogName = "MotionFABiceps";
                    demoDescription = "Provides real-time information about the repetition quantity of bicep curls performed by the user wearing the device on wrist. It is based on accelerometer and pressure data.";
                    demoShortDescription = "Fitness Activity detection for wrist-worn devices";
                    demoCurrentConsumption = "Idd: N/A";
                    demoIconID = R.drawable.bicep_up;
                    configFile = R.raw.swlib_motionfab;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_XL(true);
                    demo.setDemoUsage_P(true);

                    featureName = SW_LIB_STR;
                    singleDemoName = "Biceps";
                    outputType = COUNTER_STR;
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.bicep_down);
                    values.add((byte)1);
                    strings.add("");
                    imageIDs.add(R.drawable.bicep_up);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (SW_LIB_MOTION_FA_S)
                {
                    demoName = "MotionFA (Squats)";
                    demoLogName = "MotionFASquats";
                    demoDescription = "Provides real-time information about the repetition quantity of squats performed by the user wearing the device on wrist. It is based on accelerometer and pressure data.";
                    demoShortDescription = "Fitness Activity detection for wrist-worn devices";
                    demoCurrentConsumption = "Idd: N/A";
                    demoIconID = R.drawable.squat_down;
                    configFile = R.raw.swlib_motionfas;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_XL(true);
                    demo.setDemoUsage_P(true);

                    featureName = SW_LIB_STR;
                    singleDemoName = "Squats";
                    outputType = COUNTER_STR;
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.squat_up);
                    values.add((byte)1);
                    strings.add("");
                    imageIDs.add(R.drawable.squat_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (SW_LIB_MOTION_FA_P)
                {
                    demoName = "MotionFA (Push-ups)";
                    demoLogName = "MotionFAPushup";
                    demoDescription = "Provides real-time information about the repetition quantity of push-ups performed by the user wearing the device on wrist. It is based on accelerometer and gyroscope data.";
                    demoShortDescription = "Fitness Activity detection for wrist-worn devices";
                    demoCurrentConsumption = "Idd: N/A";
                    demoIconID = R.drawable.pushup_up;
                    configFile = R.raw.swlib_motionfap;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_XL(true);
                    demo.setDemoUsage_G(true);

                    featureName = SW_LIB_STR;
                    singleDemoName = "Push-ups";
                    outputType = COUNTER_STR;
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.pushup_up);
                    values.add((byte)1);
                    strings.add("");
                    imageIDs.add(R.drawable.pushup_down);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (SW_LIB_MOTION_SM)
                {
                    demoName = "MotionSM";
                    demoLogName = "MotionSM";
                    demoDescription = "Provides real-time information if the person wearing the device on wrist is sleeping or not. It is based on accelerometer data only.";
                    demoShortDescription = "Sleep Monitoring detection for wrist-worn devices";
                    demoCurrentConsumption = "Idd: N/A";
                    demoIconID = R.drawable.sleep;
                    configFile = R.raw.swlib_motionsm;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_XL(true);

                    featureName = SW_LIB_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Sleep Monitoring";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Awake");
                    imageIDs.add(R.drawable.awake);
                    values.add((byte)1);
                    strings.add("Sleep");
                    imageIDs.add(R.drawable.sleep);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (SW_LIB_MOTION_AH)
                {
                    demoName = "MotionAH";
                    demoLogName = "MotionAH";
                    demoDescription = "Provides real-time information on the type of activity performed by the user wearing a headlamp: stationary / light movements, walking, jogging or biking. It is based on accelerometer data only.";
                    demoShortDescription = "Activity Recognition for Headlamp";
                    demoCurrentConsumption = "Idd: N/A";
                    demoIconID = R.drawable.activity;
                    configFile = R.raw.swlib_motionah;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_XL(true);

                    featureName = SW_LIB_STR;
                    outputType = CONTINUOUS_STR;
                    singleDemoName = "Activity";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("Unknown");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Still / light movements");
                    imageIDs.add(R.drawable.still);
                    values.add((byte)2);
                    strings.add("Walking");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)3);
                    strings.add("Running");
                    imageIDs.add(R.drawable.running);
                    values.add((byte)4);
                    strings.add("Biking");
                    imageIDs.add(R.drawable.biking);
                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (SW_LIB_MAN_DOWN)
                {
                    demoName = "Man-Down";
                    demoLogName = "ManDown";
                    demoDescription = "Detect man-down events with software library based on accelerometer and pressure data.";
                    demoShortDescription = "Detect man-down events";
                    demoCurrentConsumption = "Idd: N/A";
                    demoIconID = R.drawable.man_down;
                    configFile = R.raw.swlib_mandown;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoStartupLatency(5000);

                    demo.setDemoUsage_XL(true);
                    demo.setDemoUsage_P(true);
                    demo.setDemoSensorsDescription("XL @ 100 Hz, P @ 10 Hz");
                    demo.setDemoUsage_LibConfigCard(true);

                    demo.addLibConfigItem("Alt", 0, -0.2, "Threshold on altitude difference [m].");
                    demo.addLibConfigItem("Shock", 1, 2.5, "Threshold on shock measured by accelerometer [g].");
                    demo.addLibConfigItem("Shock time", 2, 0.05, "Threshold on shock duration [s].");
                    demo.addLibConfigItem("Alt var steady", 3, 0.12, "Altitude variance threshold [m^2].");
                    demo.addLibConfigItem("Acc var steady", 4, 0.0025, "Accelerometer variance threshold [g^2].");
                    demo.addLibConfigItem("Steady time", 5,2.2, "Threshold on steady duration [s].");

                    featureName = SW_LIB_STR;
                    outputType = EVENT_BASED_STR;
                    singleDemoName = "Man-Down";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.walking);
                    values.add((byte)1);
                    strings.add("Fall!");
                    imageIDs.add(R.drawable.man_down);

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                if (SW_LIB_TOUCH)
                {
                    demoName = "Touch";
                    demoLogName = "Touch";
                    demoDescription = "Detect single tap, double tap, triple tap and long press events with software library based on accelerometer and Qvar data.";
                    demoShortDescription = "Detect touch events";
                    demoCurrentConsumption = "Current consumption:\n- XL = 195 uA\n- Qvar = 15 uA\n- MCU = 85 uA (s/w FSM)";
                    demoIconID = R.drawable.long_press;
                    configFile = R.raw.swlib_touch;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_XL(true);
                    demo.setDemoUsage_Q(true);
                    demo.setDemoUsage_DemoLogCard(false);
                    demo.setDemoSensorsDescription("Sensors ODR:\n- XL @ 480 Hz\n- Qvar @ 240 Hz\n");

                    featureName = SW_LIB_STR;
                    outputType = MANY_EVENT_BASED_STR;
                    singleDemoName = "Touch";
                    values.clear();
                    strings.clear();
                    imageIDs.clear();
                    values.add((byte)0);
                    strings.add("");
                    imageIDs.add(R.drawable.none);
                    values.add((byte)1);
                    strings.add("Single-Tap!");
                    imageIDs.add(R.drawable.single_tap);
                    values.add((byte)2);
                    strings.add("Double-Tap!");
                    imageIDs.add(R.drawable.double_tap);
                    values.add((byte)3);
                    strings.add("Triple-Tap!");
                    imageIDs.add(R.drawable.triple_tap);
                    values.add((byte)4);
                    strings.add("Long-Press!");
                    imageIDs.add(R.drawable.long_press);

                    demo.addSingleDemo(featureName, singleDemoName, values, strings, imageIDs, outputType);

                    DemoClass_array.add(demo);
                }
                break;

            case TOOLS_STR:
                if (TOOLS_UCF_LOADER) {
                    demoName = mContext.getString(R.string.tool_name_ucfloader);
                    demoLogName = "";
                    demoDescription = mContext.getString(R.string.tool_description_ucfloader);
                    demoShortDescription = mContext.getString(R.string.tool_short_description_ucfloader);
                    demoCurrentConsumption = mContext.getString(R.string.idd_na_string);
                    demoIconID = R.drawable.ucfloader;
                    configFile = R.raw.empty;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    DemoClass_array.add(demo);
                }
                if (TOOLS_SENSORS_SD_LOG) {
                    demoName = mContext.getString(R.string.tool_name_sensors_sd_log);
                    demoLogName = "";
                    demoDescription = mContext.getString(R.string.tool_description_sensors_sd_log);
                    demoShortDescription = mContext.getString(R.string.tool_short_description_sensors_sd_log);
                    demoCurrentConsumption = mContext.getString(R.string.idd_na_string);
                    demoIconID = R.drawable.sd_log;
                    configFile = R.raw.empty;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_SDLogCard(true);

                    DemoClass_array.add(demo);
                }
                if (TOOLS_SENSORS_BLE_LOG) {
                    demoName = mContext.getString(R.string.tool_name_sensors_ble_log);
                    demoLogName = "";
                    demoDescription = mContext.getString(R.string.tool_description_sensors_ble_log);
                    demoShortDescription = mContext.getString(R.string.tool_short_description_sensors_ble_log);
                    demoCurrentConsumption = mContext.getString(R.string.idd_na_string);
                    demoIconID = R.drawable.ble_log;
                    configFile = R.raw.empty;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_BLELogCard(true);
                    demo.setDemoUsage_BLEStreamCard(true);

                    DemoClass_array.add(demo);
                }
                if (TOOLS_MASS_STORAGE) {
                    demoName = mContext.getString(R.string.tool_name_mass_storage);
                    demoLogName = "";
                    demoDescription = mContext.getString(R.string.tool_description_mass_storage);
                    demoShortDescription = mContext.getString(R.string.tool_short_description_mass_storage);
                    demoCurrentConsumption = mContext.getString(R.string.idd_na_string);
                    demoIconID = R.drawable.mass_storage;
                    configFile = R.raw.empty;
                    jsonFile = R.raw.empty;
                    DemoClass demo = new DemoClass(mContext, demoName, demoLogName, demoDescription, demoShortDescription, demoCurrentConsumption, demoIconID, configFile, jsonFile);

                    demo.setDemoUsage_MassStorage(true);

                    DemoClass_array.add(demo);
                }
                break;
        }

        return DemoClass_array;
    }
}

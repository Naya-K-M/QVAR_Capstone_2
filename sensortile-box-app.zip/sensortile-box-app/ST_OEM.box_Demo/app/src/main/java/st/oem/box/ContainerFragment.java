package st.oem.box;

import static com.google.android.material.tabs.TabLayout.MODE_FIXED;
import static com.google.android.material.tabs.TabLayout.MODE_SCROLLABLE;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

public class ContainerFragment extends Fragment
{
    private final static String LOG_TAG = ContainerFragment.class.getSimpleName();


    private ArrayList<DemoListFragment> mDemoListFragmentArray = new ArrayList<>();
    private ArrayList<String> mDemoListFragmentTitles = new ArrayList<>();

    private TabLayout mTabLayout;
    private ViewPager2 mViewPager2;

    private int nPages;
    private boolean uiLoaded;
    private ProgressDialog mProgressDialog;

    private Timer timerUpdateUI_STATUS;

    public static AppConfig appConfig;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.d(LOG_TAG, "onCreate");
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.d(LOG_TAG, "onCreateView");

        assert container != null;
        container.removeAllViews();

        View view = inflater.inflate(R.layout.fragment_container, container, false);

        mTabLayout = view.findViewById(R.id.tabLayout);
        mViewPager2 = view.findViewById(R.id.viewPager2);
        mViewPager2.setVisibility(View.GONE);

        //mTabLayout.setVisibility(View.GONE);

        mProgressDialog = new ProgressDialog(getContext());
        mProgressDialog.setTitle(getContext().getString(R.string.progress_loading_title));
        mProgressDialog.setMessage(getContext().getString(R.string.progress_ui_loading_message));
        mProgressDialog.setCancelable(false);
        mProgressDialog.show();

        uiLoaded = false;

        return view;
    }

    public void refreshContentView()
    {
        // This method is used to refresh the mViewPager2 due to a known bug
        // https://issuetracker.google.com/issues/175796502?pli=1
        int curPage = mViewPager2.getCurrentItem();

        if (curPage == 0) {
            mViewPager2.setCurrentItem(curPage + 1, false);
            mViewPager2.setCurrentItem(curPage, false);
        } else if (curPage > 0 && curPage < nPages - 1) {
            mViewPager2.setCurrentItem(curPage + 1, false);
            mViewPager2.setCurrentItem(curPage, false);
            mViewPager2.beginFakeDrag();
            mViewPager2.fakeDragBy(1.0f);
            mViewPager2.endFakeDrag();
        } else if (curPage == nPages - 1) {
            mViewPager2.setCurrentItem(curPage - 1, false);
            mViewPager2.setCurrentItem(curPage, false);
        }
    }

    private void prepareFragmentArrays()
    {
        appConfig = new AppConfig(getContext(), MyCtrlData.board_id);
        nPages = appConfig.getPagesNumber();

        int indexes = 0;
        if (appConfig.SMARTPHONE_DEMO_EN == 1) {
            ArrayList<DemoClass> smartphoneDemosArray = appConfig.generateDemoArray(AppConfig.SMARTPHONE_DEMO_STR);
            mDemoListFragmentTitles.add(AppConfig.SMARTPHONE_DEMO_STR);
            mDemoListFragmentArray.add(new DemoListFragment(indexes, AppConfig.SMARTPHONE_DEMO_STR, smartphoneDemosArray));
            indexes++;
        }
        if (appConfig.WEARABLE_DEMO_EN == 1) {
            ArrayList<DemoClass> wearableDemosArray = appConfig.generateDemoArray(AppConfig.WEARABLE_DEMO_STR);
            mDemoListFragmentTitles.add(AppConfig.WEARABLE_DEMO_STR);
            mDemoListFragmentArray.add(new DemoListFragment(indexes, AppConfig.WEARABLE_DEMO_STR, wearableDemosArray));
            indexes++;
        }
        if (appConfig.PC_DEMO_EN == 1) {
            ArrayList<DemoClass> pcDemosArray = appConfig.generateDemoArray(AppConfig.PC_DEMO_STR);
            mDemoListFragmentTitles.add(AppConfig.PC_DEMO_STR);
            mDemoListFragmentArray.add(new DemoListFragment(indexes, AppConfig.PC_DEMO_STR, pcDemosArray));
            indexes++;
        }
        if (appConfig.AUTOMOTIVE_DEMO_EN == 1) {
            ArrayList<DemoClass> automotiveDemosArray = appConfig.generateDemoArray(AppConfig.AUTOMOTIVE_DEMO_STR);
            mDemoListFragmentTitles.add(AppConfig.AUTOMOTIVE_DEMO_STR);
            mDemoListFragmentArray.add(new DemoListFragment(indexes, AppConfig.AUTOMOTIVE_DEMO_STR, automotiveDemosArray));
            indexes++;
        }
        if (appConfig.EARABLE_DEMO_EN == 1) {
            ArrayList<DemoClass> earableDemosArray = appConfig.generateDemoArray(AppConfig.EARABLE_DEMO_STR);
            mDemoListFragmentTitles.add(AppConfig.EARABLE_DEMO_STR);
            mDemoListFragmentArray.add(new DemoListFragment(indexes, AppConfig.EARABLE_DEMO_STR, earableDemosArray));
            indexes++;
        }
        if (appConfig.GENERIC_DEMO_EN == 1) {
            ArrayList<DemoClass> genericDemosArray = appConfig.generateDemoArray(AppConfig.GENERIC_DEMO_STR);
            mDemoListFragmentTitles.add(AppConfig.GENERIC_DEMO_STR);
            mDemoListFragmentArray.add(new DemoListFragment(indexes, AppConfig.GENERIC_DEMO_STR, genericDemosArray));
            indexes++;
        }
        if (appConfig.SW_LIB_DEMO_EN == 1) {
            ArrayList<DemoClass> swlibDemosArray = appConfig.generateDemoArray(AppConfig.SW_LIB_DEMO_STR);
            mDemoListFragmentTitles.add(AppConfig.SW_LIB_DEMO_STR);
            mDemoListFragmentArray.add(new DemoListFragment(indexes, AppConfig.SW_LIB_DEMO_STR, swlibDemosArray));
            indexes++;
        }
        if (appConfig.TOOLS_EN == 1) {
            ArrayList<DemoClass> toolsArray = appConfig.generateDemoArray(AppConfig.TOOLS_STR);
            mDemoListFragmentTitles.add(AppConfig.TOOLS_STR);
            mDemoListFragmentArray.add(new DemoListFragment(indexes, AppConfig.TOOLS_STR, toolsArray));
        }
    }
    private void loadUI()
    {
        if (isAdded()) {
            prepareFragmentArrays();

            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            Lifecycle lifecycle = getLifecycle();
            MyFragmentStateAdapter mMyFragmentStateAdapter = new MyFragmentStateAdapter(fragmentManager, lifecycle);

            mViewPager2.setAdapter(mMyFragmentStateAdapter);
            mViewPager2.setVisibility(View.VISIBLE);
            mViewPager2.setOffscreenPageLimit(nPages);

            mViewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
                    MySharedPreferences.getInstance(getContext()).setSelPage(position);
                }
            });

            int firstPage = MySharedPreferences.getInstance(getContext()).getSelPage();
            try {
                mViewPager2.setCurrentItem(firstPage, false);
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (nPages <= 3) {
                mTabLayout.setTabMode(MODE_FIXED);
            } else {
                mTabLayout.setTabMode(MODE_SCROLLABLE);
            }
            new TabLayoutMediator(mTabLayout, mViewPager2,
                    (tab, position) -> tab.setText(mDemoListFragmentTitles.get(position))
            ).attach();
        }
    }

    private void showAlertDialog(String message)
    {
        AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
        alertDialog.setTitle(getContext().getString(R.string.title_warning));
        alertDialog.setMessage(message);
        alertDialog.setCancelable(false);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, getContext().getString(R.string.ok_string),
                (dialog, which) -> {
                    requireActivity().finish();
                    dialog.dismiss();
                });
        alertDialog.show();
    }

    private void methodUITimer_STATUS() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                    if (BluetoothLeService.mFirstCtrlPacketReceived) {
                        if (!MyCtrlData.isBoardSupported()) {
                            mProgressDialog.dismiss();
                            showAlertDialog(getContext().getString(R.string.unsupported_board));
                            timerUpdateUI_STATUS.cancel();
                        }
                        else {
                            if (!MyCtrlData.isVersionSupported()) {
                                mProgressDialog.dismiss();
                                showAlertDialog(getContext().getString(R.string.unsupported_version));
                                timerUpdateUI_STATUS.cancel();
                            }
                            else {
                                if (!uiLoaded) {
                                    uiLoaded = true;
                                    loadUI();
                                    MyLogging.startLogFileThread(getContext());
                                } else {
                                    mProgressDialog.dismiss();
                                    timerUpdateUI_STATUS.cancel();
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private class MyFragmentStateAdapter extends FragmentStateAdapter {

        public MyFragmentStateAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle) {
            super(fragmentManager, lifecycle);
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            return mDemoListFragmentArray.get(position);
        }

        @Override
        public int getItemCount() {
            return nPages;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(LOG_TAG, "onStart");

        if (timerUpdateUI_STATUS == null) {
            timerUpdateUI_STATUS = new Timer();
            timerUpdateUI_STATUS.schedule(new TimerTask() {
                @Override
                public void run() {
                    methodUITimer_STATUS();
                }
            }, 0, MyTiming.UPDATE_UI_STATUS_TIMER);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "onPause");

        if (timerUpdateUI_STATUS != null) {
            timerUpdateUI_STATUS.cancel();
            timerUpdateUI_STATUS = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(LOG_TAG, "onDestroy");

        MyLogging.stopLogFileThread();

        if (timerUpdateUI_STATUS != null) {
            timerUpdateUI_STATUS.cancel();
            timerUpdateUI_STATUS = null;
        }

        mDemoListFragmentArray.clear();
        mDemoListFragmentArray = null;
        mDemoListFragmentTitles.clear();
        mDemoListFragmentTitles = null;
        mTabLayout.removeAllTabs();
        mTabLayout.removeAllViews();
        mTabLayout.removeAllViewsInLayout();
        mTabLayout = null;
        mViewPager2.removeAllViews();
        mViewPager2.removeAllViewsInLayout();
        mViewPager2 = null;
    }
}
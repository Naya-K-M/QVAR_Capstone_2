package st.oem.box;

import static androidx.test.InstrumentationRegistry.getContext;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.Priority;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;

import java.io.IOException;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

public class MainActivity extends AppCompatActivity
{
    private final static String LOG_TAG = MainActivity.class.getSimpleName();

    private final static int PERMISSION_REQUEST_ALL = 1;
    private final static int LOCATION_REQUEST_CHECK_SETTINGS = 2;
    public final static String ACTION_BLE_START_CONNECTION = "st.oem.box.ACTION_BLE_START_CONNECTION";
    public final static String ACTION_BLE_STOP_CONNECTION = "st.oem.box.ACTION_BLE_STOP_CONNECTION";

    private BluetoothLeService mBluetoothLeService;
    private String mDeviceAddress;
    private ActivityResultLauncher<Intent> enableBleRequest;

    private final FragmentManager mFragmentManager = getSupportFragmentManager();

    // Status bar objects
    private ConstraintLayout statusBarConstraintLayout;
    private ImageView connectionImageView;
    private TextView nodeNameTextView;
    private TextView verTextView;
    private TextView devTextView;
    private ImageView micImageView;
    private ImageView sdStatusImageView;
    private ImageView bleLogImageView;
    private ImageView muxEnabledImageView;
    private ImageView batteryImageView;
    private TextView batteryTextView;
    private Timer timerUpdateUI_BATTERY;
    private Timer timerUpdateUI_STATUS;

    static int mScreenOrientation;


    private boolean isBluetoothEnabled() {
        final BluetoothManager bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        if (bluetoothManager == null) {
            Toast.makeText(this, getString(R.string.quit_app_no_bluetooth_message), Toast.LENGTH_SHORT).show();
            finish();
        }

        boolean adapterIsEnabled = false;
        if (bluetoothManager != null) {
            adapterIsEnabled = bluetoothManager.getAdapter().isEnabled();
        }

        return adapterIsEnabled;
    }

    private void handle_enableBleRequest(ActivityResult result)
    {
        if (result.getResultCode() == Activity.RESULT_OK) {
            Log.d(LOG_TAG, "bluetooth is enabled");
            loadBluetoothScannerFragment();
        } else {
            Log.d(LOG_TAG, "bluetooth is not enabled yet");
            Toast.makeText(getBaseContext(), getString(R.string.quit_app_bluetooth_disable_message), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == LOCATION_REQUEST_CHECK_SETTINGS)
        {
            if (resultCode == RESULT_OK) {
                Log.d(LOG_TAG, "location is enabled, check for bluetooth status");
                if (isBluetoothEnabled()) {
                    loadBluetoothScannerFragment();
                } else {
                    Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                    enableBleRequest.launch(enableBtIntent);
                }
            } else {
                Log.d(LOG_TAG, "location is not enabled yet");
                Toast.makeText(getBaseContext(), getString(R.string.quit_app_location_disable_message), Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_ALL)
        {
            boolean permissionsGranted = true;

            for (int i = 0; i < grantResults.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(LOG_TAG, permissions[i] + ": permissions granted");
                } else {
                    Log.e(LOG_TAG, permissions[i] + ": permissions denied. Exiting App");
                    Toast.makeText(this, getString(R.string.quit_app_permissions_denied_message), Toast.LENGTH_LONG).show();
                    permissionsGranted = false;
                    finish();
                }
            }

            if (permissionsGranted)
                checkLocationAndBluetooth();
        }
    }

    private boolean hasPermissions() {

        String[] myPermissionList;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            myPermissionList = new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
            };
        } else {
            myPermissionList = new String[]{
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION,
            };
        }

        for (String permission : myPermissionList) {
            if (ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, myPermissionList, PERMISSION_REQUEST_ALL);
                return false;
            }
        }

        return true;
    }

    private void checkLocationAndBluetooth()
    {
        LocationRequest.Builder locationRequestBuilder = new LocationRequest.Builder(Priority.PRIORITY_PASSIVE);
        LocationRequest locationRequest = locationRequestBuilder.build();

        LocationSettingsRequest.Builder locationSettingsRequestBuilder = new LocationSettingsRequest.Builder();
        locationSettingsRequestBuilder.addLocationRequest(locationRequest);
        locationSettingsRequestBuilder.setAlwaysShow(true);

        SettingsClient settingsClient = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = settingsClient.checkLocationSettings(locationSettingsRequestBuilder.build());

        // Location settings (GPS) is ON
        task.addOnSuccessListener(this, locationSettingsResponse -> {
            if (isBluetoothEnabled()) {
                loadBluetoothScannerFragment();
            } else {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                enableBleRequest.launch(enableBtIntent);
            }
        });

        // Location settings (GPS) is OFF
        task.addOnFailureListener(this, e -> {
            if (e instanceof ResolvableApiException){
                try {
                    ResolvableApiException resolvableApiException = (ResolvableApiException) e;
                    resolvableApiException.startResolutionForResult(MainActivity.this, LOCATION_REQUEST_CHECK_SETTINGS);
                } catch (IntentSender.SendIntentException sendIntentException) {
                    sendIntentException.printStackTrace();
                }
            }
        });
    }

    private void updateStatusBar(boolean status)
    {
        runOnUiThread(() ->
        {
            if (status && BluetoothLeService.mFirstCtrlPacketReceived) {
                // Node Name TextView
                nodeNameTextView.setText(MySharedPreferences.getInstance(getBaseContext()).getNodeName());
                nodeNameTextView.setVisibility(View.VISIBLE);

                // Ver TextView
                verTextView.setText(String.format(getResources().getString(R.string.ver_string), MyCtrlData.major, MyCtrlData.minor, MyCtrlData.patch));
                verTextView.setVisibility(View.VISIBLE);

                // Dev TextView
                devTextView.setText(String.format(getResources().getString(R.string.dev_string), MyCtrlData.device));
                devTextView.setVisibility(View.VISIBLE);

                // SD-Card ImageView
                if (MyCtrlData.sd_log == 1) {
                    sdStatusImageView.setImageResource(R.drawable.status_sd_log);
                    sdStatusImageView.setVisibility(View.VISIBLE);
                } else if (MyCtrlData.sd_msc == 1) {
                    sdStatusImageView.setImageResource(R.drawable.status_sd_msc);
                    sdStatusImageView.setVisibility(View.VISIBLE);
                } else if (MyCtrlData.sd_err == 1) {
                    sdStatusImageView.setImageResource(R.drawable.status_sd_err);
                    sdStatusImageView.setVisibility(View.VISIBLE);
                } else {
                    sdStatusImageView.setVisibility(View.GONE);
                }

                // BLE log ImageView
                if (MyCtrlData.ble_log > 0) {
                    bleLogImageView.setImageResource(R.drawable.status_ble_log);
                    bleLogImageView.setVisibility(View.VISIBLE);
                } else {
                    bleLogImageView.setVisibility(View.GONE);
                }

                // MUX enabled ImageView
                if (MyCtrlData.afe_channels > 0) {
                    muxEnabledImageView.setImageResource(R.drawable.status_mux_enabled);
                    muxEnabledImageView.setVisibility(View.VISIBLE);
                } else {
                    muxEnabledImageView.setVisibility(View.GONE);
                }

                if (MyCtrlData.audio == 1) {
                    // Show mic icon
                    micImageView.setVisibility(View.VISIBLE);

                    // Hide battery icons
                    batteryTextView.setVisibility(View.GONE);
                    batteryImageView.setVisibility(View.GONE);
                } else {
                    // Hide mic icon
                    micImageView.setVisibility(View.GONE);

                    // Show battery icons
                    int batteryImage = MyCtrlData.getBatteryImageID();
                    String batteryText = MyCtrlData.getBatteryText(getBaseContext());
                    batteryImageView.setImageResource(batteryImage);
                    batteryImageView.setVisibility(View.VISIBLE);
                    batteryTextView.setText(batteryText);
                    batteryTextView.setVisibility(View.VISIBLE);
                }
            } else {
                nodeNameTextView.setVisibility(View.GONE);
                verTextView.setVisibility(View.GONE);
                devTextView.setVisibility(View.GONE);
                micImageView.setVisibility(View.GONE);
                sdStatusImageView.setVisibility(View.GONE);
                bleLogImageView.setVisibility(View.GONE);
                muxEnabledImageView.setVisibility(View.GONE);
                batteryTextView.setVisibility(View.GONE);
                batteryImageView.setVisibility(View.GONE);
            }
        });
    }

    private void updateBleConnectionIcon(boolean connected)
    {
        runOnUiThread(() ->
        {
            if (connected) {
                connectionImageView.setImageResource(R.drawable.status_ble_connected);
            } else {
                connectionImageView.setImageResource(R.drawable.status_ble_disconnected);
            }
        });
    }

    private void updateBattery()
    {
        runOnUiThread(() ->
        {
            int batteryImage = MyCtrlData.getBatteryImageID();
            String batteryText = MyCtrlData.getBatteryText(getBaseContext());
            batteryImageView.setImageResource(batteryImage);
            batteryTextView.setText(batteryText);
        });
    }

    private void methodUITimer_STATUS() {
        try {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                updateBleConnectionIcon(true);
                updateStatusBar(BluetoothLeService.mFirstCtrlPacketReceived);
            } else {
                updateBleConnectionIcon(false);
                updateStatusBar(false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void methodUITimer_BATTERY() {
        try {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED &&
                BluetoothLeService.mFirstCtrlPacketReceived &&
                MyCtrlData.audio == 0 &&
                MyCtrlData.ble_log == 0)
            {
                if (!(DemoFragment.getInstance() != null && DemoFragment.getInstance().getConfigurationOngoing()))
                {
                    BLECommands.sendGetBatteryLevel(getBaseContext());

                    try {
                        Thread.sleep(MyTiming.UPDATE_UI_BATTERY_SLEEP);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt(); // restore interrupted status
                        e.printStackTrace();
                    }

                    updateBattery();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    private void createFile() {

        InputStream inputStream = new ByteArrayInputStream("PIPPO".getBytes(StandardCharsets.UTF_8));

        boolean logFolderAvailable = true;

        String fileName = "test.txt";

        File logFolder = getExternalFilesDir(MyLogging.GetInternalFolderName());
        if (!logFolder.exists()) {
            try {
                logFolder.createNewFile();
                logFolderAvailable = true;
            } catch (IOException e) {
                e.printStackTrace();
                logFolderAvailable = false;
            }
        }

        if (logFolderAvailable) {
            String filePath = logFolder.getAbsolutePath() + File.separator + fileName;

            // Create file
            File logFile = new File(filePath);
            if (!logFile.exists()) {
                boolean ok;
                try {
                    ok = logFile.createNewFile();
                    if (!ok) {
                        Toast.makeText(this, "Cannot create file", Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    Toast.makeText(this, "Cannot create file, exception: " + e, Toast.LENGTH_SHORT).show();
                }
            }

            FileOutputStream stream = null;
            try {
                stream = new FileOutputStream(filePath, true);
                Objects.requireNonNull(stream);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                byte[] buf = new byte[1024];
                int len;
                while ((len = inputStream.read(buf)) > 0) {

                    stream.write(buf, 0, len);
                }

                stream.close();
                inputStream.close();
                stream.flush();
                stream.close();
            } catch (Exception e) {
                Log.d("TAG", "Exception" + e.getMessage());
                e.printStackTrace();
            }
        }
    }
    */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(LOG_TAG, "onCreate");

        setContentView(R.layout.activity_main);

        //createFile();

        // Set screen orientation
        String screenOrientation = MySharedPreferences.getInstance(this).getScreenOrientationVal();
        switch (screenOrientation)
        {
            case "Dynamic":
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                break;
            case "Portrait":
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                break;
            case "Landscape":
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                break;
        }
        mScreenOrientation = getResources().getConfiguration().orientation;

        int pid = android.os.Process.myPid();
        String whiteList = "logcat -P '" + pid + "'";
        try {
            Runtime.getRuntime().exec(whiteList).waitFor();
        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        statusBarConstraintLayout = findViewById(R.id.statusBarConstraintLayout);
        connectionImageView = findViewById(R.id.connectionImageView);
        nodeNameTextView = findViewById(R.id.nodeNameTextView);
        verTextView = findViewById(R.id.verTextView);
        devTextView = findViewById(R.id.devTextView);
        micImageView = findViewById(R.id.micImageView);
        sdStatusImageView = findViewById(R.id.sdStatusImageView);
        bleLogImageView = findViewById(R.id.bleLogImageView);
        muxEnabledImageView = findViewById(R.id.muxEnabledImageView);
        batteryImageView = findViewById(R.id.batteryImageView);
        batteryTextView = findViewById(R.id.batteryTextView);

        enableBleRequest = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), this::handle_enableBleRequest);

        if (hasPermissions())
            checkLocationAndBluetooth();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_scanner, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent wrist_activity_recognition in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_about)
        {
            String aboutMsg = this.getString(R.string.empty_string);
            aboutMsg = aboutMsg.concat(getString(R.string.about_copyright));
            aboutMsg = aboutMsg.concat("\n");
            aboutMsg = aboutMsg.concat(getString(R.string.about_version_message));
            aboutMsg = aboutMsg.concat(": ");
            aboutMsg = aboutMsg.concat(getString(R.string.about_version));
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(aboutMsg);
            AlertDialog dialog = builder.create();
            dialog.setTitle(this.getString(R.string.about_string));
            dialog.show();
        }
        else if (id == R.id.action_settings)
        {
            Dialog settingsDialog = new Dialog(this, R.style.SettingsDialog);
            settingsDialog.setTitle(this.getString(R.string.settings_string));
            settingsDialog.setContentView(R.layout.dialog_settings);

            TextInputLayout nodeNameTextInputLayout = settingsDialog.findViewById(R.id.nodeNameTextInputLayout);
            TextInputLayout usernameTextInputLayout = settingsDialog.findViewById(R.id.usernameTextInputLayout);
            LinearLayout fSyncLinearLayout = settingsDialog.findViewById(R.id.fSyncLinearLayout);

            // Customize settings based on connected board
            EditText nodeNameEditText;
            EditText usernameEditText;
            EditText fSyncEditText;

            nodeNameEditText = settingsDialog.findViewById(R.id.nodeNameEditText);
            usernameEditText = settingsDialog.findViewById(R.id.usernameEditText);
            fSyncEditText = settingsDialog.findViewById(R.id.fSyncEditText);

            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED &&
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25)) {
                nodeNameTextInputLayout.setVisibility(View.VISIBLE);

                // Initialize node name
                String nodeName = MySharedPreferences.getInstance(this).getNodeName();
                nodeNameEditText.setText(nodeName);
                if (BluetoothLeService.mConnectionState != BluetoothLeService.STATE_CONNECTED || MyCtrlData.sd_log == 1 || MyCtrlData.ble_log > 0) {
                    nodeNameEditText.setEnabled(false);
                    nodeNameEditText.setTextColor(ContextCompat.getColor(this, R.color.color_grey));
                }
            } else {
                nodeNameTextInputLayout.setVisibility(View.GONE);
            }

            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED &&
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25 ||
                 MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON ||
                 MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO)) {
                usernameTextInputLayout.setVisibility(View.VISIBLE);
                fSyncLinearLayout.setVisibility(View.VISIBLE);

                // Initialize username
                String userName = MySharedPreferences.getInstance(this).getUsername();
                usernameEditText.setText(userName);

                // Initialize fSyncVal
                String fSyncVal = MySharedPreferences.getInstance(this).getFSyncVal();
                fSyncEditText.setText(fSyncVal);

                // fSyncCheckbox
                CheckBox fSyncCheckbox = settingsDialog.findViewById(R.id.fSyncCheckbox);
                boolean fSyncEn = MySharedPreferences.getInstance(this).getFSyncEn();
                fSyncCheckbox.setChecked(fSyncEn);
                fSyncEditText.setEnabled(fSyncEn);
                if (fSyncEn) {
                    fSyncEditText.setTextColor(ContextCompat.getColor(this, R.color.color_pink));
                } else {
                    fSyncEditText.setTextColor(ContextCompat.getColor(this, R.color.color_grey));
                }
                fSyncCheckbox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                    MySharedPreferences.getInstance(this).setFSyncEn(isChecked);
                    fSyncEditText.setEnabled(isChecked);
                    if (isChecked) {
                        fSyncEditText.setTextColor(ContextCompat.getColor(this, R.color.color_pink));
                    } else {
                        fSyncEditText.setTextColor(ContextCompat.getColor(this, R.color.color_grey));
                    }
                });
            } else {
                usernameTextInputLayout.setVisibility(View.GONE);
                fSyncLinearLayout.setVisibility(View.GONE);
            }

            // Username, node name and fSyncVal update when dialog is closed
            settingsDialog.setOnDismissListener(dialog -> {
                if (nodeNameEditText.isEnabled()) {
                    String nodeName_new = nodeNameEditText.getText().toString();
                    MySharedPreferences.getInstance(this).setNodeName(nodeName_new);
                    BLECommands.sendSetNodeName(this, nodeName_new);
                }

                String username_new = Objects.requireNonNull(usernameEditText.getText()).toString();
                MySharedPreferences.getInstance(this).setUsername(username_new);

                String fSyncVal_new = Objects.requireNonNull(fSyncEditText.getText()).toString();
                MySharedPreferences.getInstance(this).setFSyncVal(fSyncVal_new);
            });

            // Initialize screen orientation
            String screenOrientation = MySharedPreferences.getInstance(this).getScreenOrientationVal();
            Spinner screenOrientationSpinner = settingsDialog.findViewById(R.id.screenOrientationSpinner);
            ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.orientation_array, android.R.layout.simple_spinner_item);
            screenOrientationSpinner.setSelection(adapter.getPosition(screenOrientation));
            screenOrientationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String screenOrientationNew = screenOrientationSpinner.getSelectedItem().toString();
                    switch (screenOrientationNew)
                    {
                        case "Dynamic":
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                            MySharedPreferences.getInstance(getBaseContext()).setScreenOrientationVal("Dynamic");
                            break;
                        case "Portrait":
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                            MySharedPreferences.getInstance(getBaseContext()).setScreenOrientationVal("Portrait");
                            break;
                        case "Landscape":
                            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                            MySharedPreferences.getInstance(getBaseContext()).setScreenOrientationVal("Landscape");
                            break;
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            // Auto-connect update
            CheckBox autoConnectCheckBox = settingsDialog.findViewById(R.id.autoConnectCheckBox);
            boolean autoConnect = MySharedPreferences.getInstance(this).getAutoConnect();
            autoConnectCheckBox.setChecked(autoConnect);
            autoConnectCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> MySharedPreferences.getInstance(this).setAutoConnect(isChecked));

            // Auto-connect runtime update
            CheckBox autoConnectRuntimeCheckBox = settingsDialog.findViewById(R.id.autoConnectRuntimeCheckBox);
            boolean autoConnectRuntime = MySharedPreferences.getInstance(this).getAutoConnectRuntime();
            autoConnectRuntimeCheckBox.setChecked(autoConnectRuntime);
            autoConnectRuntimeCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> MySharedPreferences.getInstance(this).setAutoConnectRuntime(isChecked));

            // Events card
            CheckBox eventsCardCheckBox = settingsDialog.findViewById(R.id.eventsCardCheckBox);
            boolean eventsCards = MySharedPreferences.getInstance(this).getEventsCard();
            eventsCardCheckBox.setChecked(eventsCards);
            eventsCardCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> MySharedPreferences.getInstance(this).setEventsCard(isChecked));

            settingsDialog.show();
        }
        return super.onOptionsItemSelected(item);
    }

    private final ServiceConnection mBleServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            Log.d(LOG_TAG, "mBleServiceConnection: onServiceConnected");
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e("TAG", "Unable to initialize Bluetooth");
                finish();
            }

            // Get device address
            mDeviceAddress = MySharedPreferences.getInstance(MainActivity.this).getNodeAddress();

            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            // This method is called only in case the service crashes or is killed
            Log.d(LOG_TAG, "mBleServiceConnection: onServiceDisconnected");
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(LOG_TAG, "onResume");

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ACTION_BLE_START_CONNECTION);
        intentFilter.addAction(ACTION_BLE_STOP_CONNECTION);
        registerReceiver(mBleStartConnectionReceiver, intentFilter);

        if (mBluetoothLeService != null) {
            boolean result = mBluetoothLeService.connect(mDeviceAddress);
            Log.d(LOG_TAG, "onResume: reconnecting request result = " + result);
        }

        if (timerUpdateUI_STATUS == null) {
            timerUpdateUI_STATUS = new Timer();
            timerUpdateUI_STATUS.schedule(new TimerTask() {
                @Override
                public void run() {
                    methodUITimer_STATUS();
                }
            }, 0, MyTiming.UPDATE_UI_STATUS_TIMER);
        }

        if (timerUpdateUI_BATTERY == null) {
            timerUpdateUI_BATTERY = new Timer();
            timerUpdateUI_BATTERY.schedule(new TimerTask() {
                @Override
                public void run() {
                    methodUITimer_BATTERY();
                }
            }, 0, MyTiming.UPDATE_UI_BATTERY_TIMER);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(LOG_TAG, "onPause");

        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        unregisterReceiver(mBleStartConnectionReceiver);

        if (timerUpdateUI_STATUS != null) {
            timerUpdateUI_STATUS.cancel();
            timerUpdateUI_STATUS = null;
        }

        if (timerUpdateUI_BATTERY != null) {
            timerUpdateUI_BATTERY.cancel();
            timerUpdateUI_BATTERY = null;
        }
    }

    // Handles various events fired by the Service.
    // ACTION_BLE_START_CONNECTION: bind BLE service and load container fragment
    private final BroadcastReceiver mBleStartConnectionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
        final String action = intent.getAction();
        if (action.equals(ACTION_BLE_START_CONNECTION)) {
            Log.d(LOG_TAG, "mBleStartConnectionReceiver: onReceive ACTION_BLE_START_CONNECTION");
            loadContainerFragment();
            Intent gattServiceIntent = new Intent(getApplicationContext(), BluetoothLeService.class);
            bindService(gattServiceIntent, mBleServiceConnection, BIND_AUTO_CREATE);
        } else if (action.equals(ACTION_BLE_STOP_CONNECTION)) {
            Log.d(LOG_TAG, "mBleStartConnectionReceiver: onReceive ACTION_BLE_STOP_CONNECTION");
            unbindService(mBleServiceConnection);
            mBluetoothLeService.disconnect();
            mBluetoothLeService = null;
        }
        }
    };

    private void loadBluetoothScannerFragment() {
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout_container, new BluetoothScannerFragment(), "BluetoothScannerFragment");
        fragmentTransaction.commit();

        statusBarConstraintLayout.setVisibility(View.GONE);
    }

    private void loadContainerFragment() {
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout_container, new ContainerFragment(), "ContainerFragment");
        fragmentTransaction.commit();

        statusBarConstraintLayout.setVisibility(View.VISIBLE);
        updateStatusBar(false);
    }

    private Fragment getFragmentLoaded()
    {
        return mFragmentManager.findFragmentById(R.id.frame_layout_container);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        Log.d(LOG_TAG, "onKeyDown");
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Fragment fragmentLoaded = getFragmentLoaded();
            if (fragmentLoaded instanceof ContainerFragment) {
                Intent intent = new Intent(ACTION_BLE_STOP_CONNECTION);
                getBaseContext().sendBroadcast(intent);

                loadBluetoothScannerFragment();
                return false;
            } else if (fragmentLoaded instanceof DemoFragment) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                ContainerFragment containerFragment = (ContainerFragment) fragmentManager.findFragmentByTag("ContainerFragment");
                DemoFragment demoFragment = (DemoFragment) fragmentManager.findFragmentByTag("DemoFragment");
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.show(containerFragment);
                fragmentTransaction.remove(demoFragment);
                fragmentTransaction.commit();
                DemoFragment.destroyInstance();
                return false;
            }
            //else if (fragmentLoaded instanceof ScannerActivityFragment) {
            //    finish();
            //}
        }

        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.d(LOG_TAG, "onConfigurationChanged");

        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE || newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            mScreenOrientation = newConfig.orientation;
            if (getFragmentLoaded() instanceof ContainerFragment)
                ((ContainerFragment)getFragmentLoaded()).refreshContentView();
        }
    }
}
package st.oem.box;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;

public class MyLogging {
    private final static String LOG_TAG = MyLogging.class.getSimpleName();

    // Log status
    public static final int LOG_STATUS_IDLE = 0;
    public static final int LOG_STATUS_STARTING = 1;
    public static final int LOG_STATUS_LOGGING = 2;
    public static final int LOG_STATUS_STOPPING = 3;
    public static int logStatus = LOG_STATUS_IDLE;
    private static boolean bleLogHighRate = false;
    public static String bleLogHighRateAccelAxis = "";

    private static final MySafeArrayString logLines = new MySafeArrayString();

    private static File logFolder;
    private static File logFile;
    private static String fileName = "";
    private static String filePath = "";
    private static FileOutputStream stream;

    public static final int LOGFILE_STATUS_IDLE = 0;
    public static final int LOGFILE_STATUS_CREATING = 1;
    public static final int LOGFILE_STATUS_BOARD_READY = 2;
    public static final int LOGFILE_STATUS_ATTACHING = 3;
    public static final int LOGFILE_STATUS_CREATED = 4;
    public static final int LOGFILE_STATUS_CLOSING = 5;
    public static final int LOGFILE_STATUS_CLOSED = 6;
    private static int logFileStatus = LOGFILE_STATUS_IDLE;

    private static Context myContext;
    private static Timer timerUpdateLogFile;

    public static void setLogStatus(int status)
    {
        logStatus = status;
    }
    public static int getLogStatus()
    {
        return logStatus;
    }

    public static void setLogFileStatus(int status)
    {
        logFileStatus = status;
    }

    public static void setBleLogHighRate(boolean highRate) { bleLogHighRate = highRate; }
    public static boolean getBleLogHighRate()
    {
        return bleLogHighRate;
    }

    public static void setBleLogHighRateAccelAxis(String accelAxis) { bleLogHighRateAccelAxis = accelAxis; }

    public static void appendLogFile(ArrayList<String> lines) {
        logLines.add(lines);
    }

    public static String GetInternalFolderName() {
        String folderName = "";
        switch (MyCtrlData.board_id)
        {
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                folderName = "logs/sensortile.box";
                break;
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                folderName = "logs/earable";
                break;
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                folderName = "logs/sensortile.box-ispu";
                break;
            default:
                break;
        }
        return folderName;
    }

    public static void startLogFileThread(Context context)
    {
        myContext = context;
        logFolder = myContext.getExternalFilesDir(MyLogging.GetInternalFolderName());

        // BLE logging variables
        timerUpdateLogFile = new Timer();
        timerUpdateLogFile.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUpdateLogFile();
            }
        }, 0, MyTiming.UPDATE_LOGFILE_TIMER);
    }

    public static void stopLogFileThread()
    {
        if (timerUpdateLogFile != null) {
            timerUpdateLogFile.cancel();
            timerUpdateLogFile = null;
        }
    }

    private static void methodUpdateLogFile() {

        ((Activity) myContext).runOnUiThread(() ->
        {
            //Log.d(LOG_TAG, "methodUpdateLogFile");
            try {
                switch (logFileStatus)
                {
                    case LOGFILE_STATUS_CREATING:
                        try {
                            // Create folder
                            if (!logFolder.exists()) {
                                try {
                                    logFolder.createNewFile();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                            // Check if file exists and append number
                            fileName = MySharedPreferences.getInstance(myContext).getLogFilename();
                            String extension = "";
                            try {
                                extension = fileName.substring(fileName.lastIndexOf("."));
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                            }
                            String fileNameTmp = fileName;
                            int n = 1;
                            do {
                                filePath = logFolder.getAbsolutePath() + File.separator + fileNameTmp;
                                logFile = new File(filePath);
                                if (!logFile.exists()) {
                                    break;
                                }
                                n++;
                                if (TextUtils.isEmpty(extension))
                                    fileNameTmp = fileName.concat(String.valueOf(n));
                                else
                                    fileNameTmp = fileName.replace(extension, n + extension);
                            } while (logFile.exists());
                            MySharedPreferences.getInstance(myContext).setLogFilename(fileNameTmp);

                            // Create file
                            try {
                                boolean ok = logFile.createNewFile();
                                if (!ok) {
                                    Toast.makeText(myContext, "Cannot create logfile: " + GetInternalFolderName() + File.separator + logFile.getName(), Toast.LENGTH_SHORT).show();
                                }
                            } catch (FileNotFoundException e) { e.printStackTrace(); }

                            MyLogging.setLogFileStatus(LOGFILE_STATUS_BOARD_READY);
                            BLECommands.sendBleLogStart(myContext);
                            BLECommands.sendBleStart(myContext);

                        } catch (Exception e) {
                            String message = myContext.getString(R.string.toast_create_ble_log_error);
                            Toast.makeText(myContext, message, Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                            MyLogging.setLogFileStatus(LOGFILE_STATUS_IDLE);
                        }
                        break;
                    case LOGFILE_STATUS_BOARD_READY:
                        MyStreamData.resetData();
                        logLines.clear();
                        if (MyCtrlData.ble_log == 1 || MyCtrlData.getBleHighRate()) {
                            // Create header
                            switch (MyCtrlData.board_id)
                            {
                                case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                                case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                                    logLines.add("Timestamp[ms]\taccX[LSB]\taccY[LSB]\taccZ[LSB]\tgyrX[LSB]\tgyrY[LSB]\tgyrZ[LSB]\tpress[LSB]\r\n");
                                    break;
                                case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                                case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                                    if (MyCtrlData.ble_log == 1)
                                        logLines.add("Timestamp[ms]\taccX[LSB]\taccY[LSB]\taccZ[LSB]\tgyrX[LSB]\tgyrY[LSB]\tgyrZ[LSB]\tqvar[LSB]\r\n");
                                    else if (MyCtrlData.getAccelAxisX())    // high-rate on X axis
                                        logLines.add("accX[LSB]\tqvar[LSB]\r\n");
                                    else if (MyCtrlData.getAccelAxisY())    // high-rate on Y axis
                                        logLines.add("accY[LSB]\tqvar[LSB]\r\n");
                                    else if (MyCtrlData.getAccelAxisZ())    // high-rate on Z axis
                                        logLines.add("accZ[LSB]\tqvar[LSB]\r\n");
                                    else if (MyCtrlData.getAccelAxisV())    // high-rate on V axis
                                        logLines.add("accV[LSB]\tqvar[LSB]\r\n");
                                    break;
                                default:
                                    break;
                            }
                            MyLogging.setLogFileStatus(LOGFILE_STATUS_ATTACHING);
                        }
                        break;
                    case LOGFILE_STATUS_ATTACHING:
                        // Check if file exists
                        fileName = MySharedPreferences.getInstance(myContext).getLogFilename();
                        filePath = logFolder.getAbsolutePath() + File.separator + fileName;
                        logFile = new File(filePath);
                        if (!logFile.exists()) {
                            String message = myContext.getString(R.string.toast_stopping_ble_log);
                            Toast.makeText(myContext, message, Toast.LENGTH_LONG).show();
                            BLECommands.sendBleLogStop(myContext);
                            BLECommands.sendBleStop(myContext);
                            MyLogging.setLogFileStatus(LOGFILE_STATUS_IDLE);
                        } else {
                            String message = String.format(myContext.getString(R.string.toast_attach_ble_log), GetInternalFolderName() + File.separator + logFile.getName());
                            Toast.makeText(myContext, message, Toast.LENGTH_LONG).show();
                            MyLogging.setLogFileStatus(LOGFILE_STATUS_CREATED);
                        }
                        break;

                    case LOGFILE_STATUS_CREATED:
                        // Create a stream
                        try
                        {
                            if (stream == null)
                                stream = new FileOutputStream(logFile, true);
                        }
                        catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }

                        // Append lines to file
                        try {
                            while (logLines.size() > 0)
                            {
                                assert stream != null;
                                stream.write(logLines.getAndRemove(0).getBytes());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;

                    case LOGFILE_STATUS_CLOSING:
                        // Append remaining lines to file
                        try {
                            while (logLines.size() > 0)
                            {
                                assert stream != null;
                                stream.write(logLines.getAndRemove(0).getBytes());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        // Close log file
                        assert stream != null;
                        stream.flush();
                        stream.close();
                        stream = null;
                        MyLogging.setLogFileStatus(LOGFILE_STATUS_CLOSED);
                        break;

                    case LOGFILE_STATUS_CLOSED:
                        String message = String.format(myContext.getResources().getString(R.string.toast_completed_ble_log), GetInternalFolderName() + File.separator + logFile.getName());
                        Toast.makeText(myContext, message, Toast.LENGTH_LONG).show();
                        MyLogging.setLogFileStatus(LOGFILE_STATUS_IDLE);
                        MyStreamData.resetData();
                        logLines.clear();
                        break;

                    case LOGFILE_STATUS_IDLE:
                    default:
                        break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

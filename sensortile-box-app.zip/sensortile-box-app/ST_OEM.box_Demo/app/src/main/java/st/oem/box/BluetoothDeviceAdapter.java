package st.oem.box;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Objects;

import st.oem.R;

public class BluetoothDeviceAdapter extends RecyclerView.Adapter<BluetoothDeviceAdapter.ViewHolder> implements RecyclerItemClickListener.OnItemClickListener
{
    class ViewHolder extends RecyclerView.ViewHolder {
        TextView deviceName, devicePowerLevel, deviceAddress;
        ImageView bluetoothImageView;

        ViewHolder(View v) {
            super(v);
            deviceName = v.findViewById(R.id.deviceName_TextView);
            devicePowerLevel = v.findViewById(R.id.devicePowerLevel_TextView);
            deviceAddress = v.findViewById(R.id.deviceAddress_TextView);
            bluetoothImageView = v.findViewById(R.id.bluetooth_ImageView);
            bluetoothImageView.setColorFilter(ResourcesCompat.getColor(context.getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        }
    }

    private ArrayList<BluetoothDeviceObject> deviceList = new ArrayList<>();
    private BluetoothDeviceAdapterCallback callbackEvents;
    private Context context;

    BluetoothDeviceAdapter(Context context, BluetoothDeviceAdapterCallback callback) {
        this.context = context;
        this.callbackEvents = callback;
    }

    @Override
    public @NonNull ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.bluetooth_device_element, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        BluetoothDeviceObject deviceObject = deviceList.get(position);

        if (deviceObject.getName() != null) {
            holder.deviceName.setText(String.format(context.getString(R.string.scanner_fragment_device_name_string), deviceObject.getName()));
        } else {
            holder.deviceName.setText(String.format(context.getString(R.string.scanner_fragment_device_name_string), context.getString(R.string.na_string)));
        }

        holder.devicePowerLevel.setText(String.format(context.getString(R.string.scanner_fragment_RSSI_string), deviceObject.getPowerLevel()));
        holder.deviceAddress.setText(String.format(context.getString(R.string.scanner_fragment_address_string), deviceObject.getAddress()));
    }

    @Override
    public int getItemCount() {
        return deviceList.size();
    }

    void addItem(BluetoothDeviceObject device) {
        deviceList.add(device);
        notifyItemInserted(deviceList.indexOf(device));
    }

    void removeAll() {
        deviceList.clear();
        notifyDataSetChanged();
    }

    BluetoothDeviceObject getDeviceFromAddress(String address) {
        for (BluetoothDeviceObject device : deviceList) {
            if (Objects.equals(address, device.getAddress())) {
                return device;
            }
        }

        return null;
    }

    @Override
    public void onItemClick(View view, int position) {
        callbackEvents.onDeviceSelected(deviceList.get(position));
    }

    @Override
    public void onLongItemClick(View view, int position) {
        callbackEvents.onDeviceInfoRequested(deviceList.get(position));
    }
}

package st.oem.box;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_PEDO_WRIST_CONFIG extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private Button mPedWristGenericButton;
    private Button mPedWristGenericFprButton;
    private TextView mPedWristSelConfigTextView;

    private CardView mMainLayout;

    // State
    private static String mSelectedConfig;

    public void saveState()
    {
        try {
            mSelectedConfig = mPedWristSelConfigTextView.getText().toString();
        } catch(Exception ignored) { }
    }

    public void restoreState()
    {
        try {
            mPedWristSelConfigTextView.setText(mSelectedConfig);
            if (mSelectedConfig.equals(getResources().getString(R.string.selected_ped_generic))) {
                mPedWristGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                mPedWristGenericFprButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
            } else if (mSelectedConfig.equals(getResources().getString(R.string.selected_ped_generic_fpr))) {
                mPedWristGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                mPedWristGenericFprButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
            }
        } catch(Exception ignored) { }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mPedWristGenericButton = null;
        mPedWristGenericFprButton = null;
        mPedWristSelConfigTextView = null;

        mMainLayout = null;
    }

    @SuppressLint("InflateParams")
    public CardView_PEDO_WRIST_CONFIG(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_ped_wrist_config, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mPedWristGenericButton = mMainLayout.findViewById(R.id.pedWristGenericButton);
        mPedWristGenericFprButton = mMainLayout.findViewById(R.id.pedWristGenericFprButton);
        mPedWristSelConfigTextView = mMainLayout.findViewById(R.id.pedWristSelConfigTextView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        mPedWristGenericButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        DemoFragment.getInstance().loadDeviceConfiguration(R.raw.lsm6dsox_wearable_pedo_generic_configuration);
                        mPedWristGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mPedWristGenericFprButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mPedWristSelConfigTextView.setText(getResources().getString(R.string.selected_ped_generic));
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        mPedWristGenericFprButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        DemoFragment.getInstance().loadDeviceConfiguration(R.raw.lsm6dsox_wearable_pedo_fpr_configuration);
                        mPedWristGenericButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mPedWristGenericFprButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mPedWristSelConfigTextView.setText(getResources().getString(R.string.selected_ped_generic_fpr));
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

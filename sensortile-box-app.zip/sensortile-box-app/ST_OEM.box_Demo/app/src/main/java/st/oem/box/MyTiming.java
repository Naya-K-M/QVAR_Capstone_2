package st.oem.box;

public class MyTiming {

    public static final int UPDATE_UI_MLC_TIMER = 50;
    public static final int UPDATE_UI_FSM_TIMER = 50;
    public static final int UPDATE_UI_EMB_TIMER = 50;
    public static final int UPDATE_UI_PED_TIMER = 50;
    public static final int UPDATE_UI_LIB_TIMER = 50;

    public static final int UPDATE_UI_ISPU_TIMER = 50;
    public static final int UPDATE_UI_UNSUPERVISED_ODL_TIMER = 50;
    public static final int UPDATE_UI_IN_BAG_DETECTION_TIMER = 150;
    public static final int UPDATE_UI_FALL_HEIGHT_ESTIMATION_TIMER = 50;
    public static final int UPDATE_UI_QUATERNIONS_TIMER = 50;

    public static final int UPDATE_UI_BATTERY_SLEEP = 250;
    public static final int UPDATE_UI_BATTERY_TIMER = 10000;
    public static final int UPDATE_UI_STATUS_TIMER = 500;

    public static final int UPDATE_UI_LOG_TIMER = 250;
    public static final int UPDATE_UI_SENSORS_LOG_TIMER = 250;
    public static final int UPDATE_UI_BLE_STREAM_TIMER = 15;    // should be kept < 1 / 60Hz (max BLE rate from TWS.box)

    public static final int UPDATE_LOGFILE_TIMER = 5;

    public static int getSleepTimeBetweenCommands()
    {
        int sleepTime;

        switch (MyCtrlData.board_id)
        {
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
            case MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO:
                sleepTime = 40;
                break;
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
            case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                sleepTime = 75;
                break;
            default:
                sleepTime = 100;
                break;
        }

        return sleepTime;
    }
}

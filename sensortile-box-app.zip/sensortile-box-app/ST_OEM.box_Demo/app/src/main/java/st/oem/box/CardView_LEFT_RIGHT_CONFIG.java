package st.oem.box;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.AppCompatEditText;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.Locale;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_LEFT_RIGHT_CONFIG extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private Button mLeftConfigButton;
    private Button mRightConfigButton;
    private TextView mLeftRightSelConfigTextView;

    private CardView mMainLayout;

    // State
    private static String mSelectedConfig;

    public void saveState()
    {
        try {
            mSelectedConfig = mLeftRightSelConfigTextView.getText().toString();
        } catch(Exception ignored) { }
    }

    public void restoreState()
    {
        try {
            mLeftRightSelConfigTextView.setText(mSelectedConfig);
            if (mSelectedConfig.equals(getResources().getString(R.string.selected_left_wrist))) {
                mLeftConfigButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                mRightConfigButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
            } else if (mSelectedConfig.equals(getResources().getString(R.string.selected_right_wrist))) {
                mLeftConfigButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                mRightConfigButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
            }
        } catch(Exception ignored) { }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mLeftConfigButton = null;
        mRightConfigButton = null;
        mLeftRightSelConfigTextView = null;

        mMainLayout = null;
    }

    @SuppressLint("InflateParams")
    public CardView_LEFT_RIGHT_CONFIG(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_left_right_config, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mLeftConfigButton = mMainLayout.findViewById(R.id.leftConfigButton);
        mRightConfigButton = mMainLayout.findViewById(R.id.rightConfigButton);
        mLeftRightSelConfigTextView = mMainLayout.findViewById(R.id.leftRightSelConfigTextView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        mLeftConfigButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        DemoFragment.getInstance().loadDeviceConfiguration(DemoFragment.getInstance().getSelectedDemo().getDemoUsage_LeftConfig());
                        mLeftConfigButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mRightConfigButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mLeftRightSelConfigTextView.setText(getResources().getString(R.string.selected_left_wrist));

                        // Restore embedded configuration values if supported
                        if (DemoFragment.getInstance().getSelectedDemo().getDemoUsage_RamConfigCard())
                        {
                            View viewParent = (View) mMainLayout.getParent().getParent();
                            LinearLayout ramConfigLinearLayout = viewParent.findViewById(R.id.ramConfigLinearLayout);
                            for (int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_RamConfigItems(); i++)
                            {
                                AppCompatEditText edit = ramConfigLinearLayout.findViewById(i);
                                String text = getContext().getString(R.string.empty_string);
                                if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_THRESHOLD)) {
                                    text = String.format(Locale.ENGLISH, "%.3f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                                }
                                else if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_SHORT_TIMER)) {
                                    text = String.format(Locale.ENGLISH, "%.0f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                                }
                                else if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_LONG_TIMER)) {
                                    text = String.format(Locale.ENGLISH, "%.0f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                                }
                                edit.setText(text);
                            }
                        }
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        mRightConfigButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        DemoFragment.getInstance().loadDeviceConfiguration(DemoFragment.getInstance().getSelectedDemo().getDemoUsage_RightConfig());
                        mLeftConfigButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mRightConfigButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mLeftRightSelConfigTextView.setText(getResources().getString(R.string.selected_right_wrist));

                        // Restore embedded configuration values if supported
                        if (DemoFragment.getInstance().getSelectedDemo().getDemoUsage_RamConfigCard())
                        {
                            View viewParent = (View) mMainLayout.getParent().getParent();
                            LinearLayout ramConfigLinearLayout = viewParent.findViewById(R.id.ramConfigLinearLayout);
                            for (int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_RamConfigItems(); i++)
                            {
                                AppCompatEditText edit = ramConfigLinearLayout.findViewById(i);
                                String text = getContext().getString(R.string.empty_string);
                                if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_THRESHOLD)) {
                                    if (DemoFragment.getInstance().getSelectedDemo().getDemoName().equals("Wrist-Tilt MLC-Enhanced") && DemoFragment.getInstance().getSelectedDemo().getRamConfigParamName(i).equals("VERTICAL/NOT-VERTICAL THRESHOLD [g]"))
                                        text = String.format(Locale.ENGLISH, "%.3f", -DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                                    else
                                        text = String.format(Locale.ENGLISH, "%.3f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                                }
                                else if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_SHORT_TIMER)) {
                                    text = String.format(Locale.ENGLISH, "%.0f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                                }
                                else if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_LONG_TIMER)) {
                                    text = String.format(Locale.ENGLISH, "%.0f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                                }
                                edit.setText(text);
                            }
                        }
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

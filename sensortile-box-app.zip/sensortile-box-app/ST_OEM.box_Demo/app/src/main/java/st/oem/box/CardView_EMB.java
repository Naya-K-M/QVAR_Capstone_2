package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;

import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_EMB extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private LinearLayout[] mEmbLinearLayout = new LinearLayout[4];
    private TextView[] mEmbTitleTextView = new TextView[4];
    private ImageView[] mEmbImageView = new ImageView[4];
    private TextView[] mEmbDataTextView = new TextView[4];
    private LinearLayout[] mEmbLedLinearLayout = new LinearLayout[4];
    private SwitchCompat[] mEmbLedSwitchCompat = new SwitchCompat[4];
    private LinearLayout[] mEmbBuzLinearLayout = new LinearLayout[4];
    private SwitchCompat[] mEmbBuzSwitchCompat = new SwitchCompat[4];
    private MyCountDownTimer[] mEmbTimer = new MyCountDownTimer[4];

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_EMB_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mEmbLinearLayout = null;
        mEmbTitleTextView = null;
        mEmbImageView = null;
        mEmbDataTextView = null;
        mEmbLedLinearLayout = null;
        mEmbLedSwitchCompat = null;
        mEmbBuzLinearLayout = null;
        mEmbBuzSwitchCompat = null;
        mEmbTimer = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_EMB(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_emb, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mEmbLinearLayout[0] = mMainLayout.findViewById(R.id.emb0LinearLayout);
        mEmbTitleTextView[0] = mMainLayout.findViewById(R.id.emb0TitleTextView);
        mEmbImageView[0] = mMainLayout.findViewById(R.id.emb0ImageView);
        mEmbImageView[0].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_white, null), PorterDuff.Mode.SRC_IN);
        mEmbDataTextView[0] = mMainLayout.findViewById(R.id.emb0DataTextView);

        mEmbLinearLayout[1] = mMainLayout.findViewById(R.id.emb1LinearLayout);
        mEmbTitleTextView[1] = mMainLayout.findViewById(R.id.emb1TitleTextView);
        mEmbImageView[1] = mMainLayout.findViewById(R.id.emb1ImageView);
        mEmbImageView[1].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_white, null), PorterDuff.Mode.SRC_IN);
        mEmbDataTextView[1] = mMainLayout.findViewById(R.id.emb1DataTextView);

        mEmbLinearLayout[2] = mMainLayout.findViewById(R.id.emb2LinearLayout);
        mEmbTitleTextView[2] = mMainLayout.findViewById(R.id.emb2TitleTextView);
        mEmbImageView[2] = mMainLayout.findViewById(R.id.emb2ImageView);
        mEmbImageView[2].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_white, null), PorterDuff.Mode.SRC_IN);
        mEmbDataTextView[2] = mMainLayout.findViewById(R.id.emb2DataTextView);

        mEmbLinearLayout[3] = mMainLayout.findViewById(R.id.emb3LinearLayout);
        mEmbTitleTextView[3] = mMainLayout.findViewById(R.id.emb3TitleTextView);
        mEmbImageView[3] = mMainLayout.findViewById(R.id.emb3ImageView);
        mEmbImageView[3].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_white, null), PorterDuff.Mode.SRC_IN);
        mEmbDataTextView[3] = mMainLayout.findViewById(R.id.emb3DataTextView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        if (MyCtrlData.isLedSupported())
        {
            mEmbLedSwitchCompat[0] = mMainLayout.findViewById(R.id.embLed0SwitchCompat);
            mEmbLedSwitchCompat[1] = mMainLayout.findViewById(R.id.embLed1SwitchCompat);
            mEmbLedSwitchCompat[2] = mMainLayout.findViewById(R.id.embLed2SwitchCompat);
            mEmbLedSwitchCompat[3] = mMainLayout.findViewById(R.id.embLed3SwitchCompat);
            for(int j = 0; j < 4; j++)
            {
                final int k = j;
                mEmbLedSwitchCompat[j].setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
                {
                    if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                        if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                            byte b_true = (byte)0x00;
                            byte b_false = (byte)0x00;

                            switch (DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.EMBEDDED_FUNCTION_STR, k))
                            {
                                case (AppConfig.WAKE_UP_STR):
                                    b_true = (byte)0x01;
                                    b_false = (byte)0xFE;
                                    break;
                                case (AppConfig.FREE_FALL_STR):
                                    b_true = (byte)0x02;
                                    b_false = (byte)0xFD;
                                    break;
                                case (AppConfig.SINGLE_TAP_STR):
                                    b_true = (byte)0x04;
                                    b_false = (byte)0xFB;
                                    break;
                                case (AppConfig.DOUBLE_TAP_STR):
                                    b_true = (byte)0x08;
                                    b_false = (byte)0xF7;
                                    break;
                                case (AppConfig.TRIPLE_TAP_STR):
                                    b_true = (byte)0x10;
                                    b_false = (byte)0xEF;
                                    break;
                            }

                            if (b)
                                DemoFragment.getInstance().emb_ledMask = (byte)(DemoFragment.getInstance().emb_ledMask | b_true);
                            else
                                DemoFragment.getInstance().emb_ledMask = (byte)(DemoFragment.getInstance().emb_ledMask & b_false);

                            DemoFragment.getInstance().prepareAndSendLedMask();
                        } else {
                            mEmbLedSwitchCompat[k].setChecked(!b);
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        mEmbLedSwitchCompat[k].setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            mEmbLedLinearLayout[0] = mMainLayout.findViewById(R.id.embLed0LinearLayout);
            mEmbLedLinearLayout[1] = mMainLayout.findViewById(R.id.embLed1LinearLayout);
            mEmbLedLinearLayout[2] = mMainLayout.findViewById(R.id.embLed2LinearLayout);
            mEmbLedLinearLayout[3] = mMainLayout.findViewById(R.id.embLed3LinearLayout);
            for (int i = 0; i < 4; i++) {
                mEmbLedLinearLayout[i].setVisibility(GONE);
            }
        }

        if (MyCtrlData.isBuzSupported())
        {
            mEmbBuzSwitchCompat[0] = mMainLayout.findViewById(R.id.embBuz0SwitchCompat);
            mEmbBuzSwitchCompat[1] = mMainLayout.findViewById(R.id.embBuz1SwitchCompat);
            mEmbBuzSwitchCompat[2] = mMainLayout.findViewById(R.id.embBuz2SwitchCompat);
            mEmbBuzSwitchCompat[3] = mMainLayout.findViewById(R.id.embBuz3SwitchCompat);
            for(int j = 0; j < 4; j++)
            {
                final int k = j;
                mEmbBuzSwitchCompat[j].setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
                {
                    if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                        if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                            byte b_true = (byte)0x00;
                            byte b_false = (byte)0x00;

                            switch (DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.EMBEDDED_FUNCTION_STR, k))
                            {
                                case (AppConfig.WAKE_UP_STR):
                                    b_true = (byte)0x01;
                                    b_false = (byte)0xFE;
                                    break;
                                case (AppConfig.FREE_FALL_STR):
                                    b_true = (byte)0x02;
                                    b_false = (byte)0xFD;
                                    break;
                                case (AppConfig.SINGLE_TAP_STR):
                                    b_true = (byte)0x04;
                                    b_false = (byte)0xFB;
                                    break;
                                case (AppConfig.DOUBLE_TAP_STR):
                                    b_true = (byte)0x08;
                                    b_false = (byte)0xF7;
                                    break;
                                case (AppConfig.TRIPLE_TAP_STR):
                                    b_true = (byte)0x10;
                                    b_false = (byte)0xEF;
                                    break;
                            }

                            if (b)
                                DemoFragment.getInstance().emb_buzMask = (byte)(DemoFragment.getInstance().emb_buzMask | b_true);
                            else
                                DemoFragment.getInstance().emb_buzMask = (byte)(DemoFragment.getInstance().emb_buzMask & b_false);

                            DemoFragment.getInstance().prepareAndSendBuzMask();
                        } else {
                            mEmbBuzSwitchCompat[k].setChecked(!b);
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        mEmbBuzSwitchCompat[k].setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            mEmbBuzLinearLayout[0] = mMainLayout.findViewById(R.id.embBuz0LinearLayout);
            mEmbBuzLinearLayout[1] = mMainLayout.findViewById(R.id.embBuz1LinearLayout);
            mEmbBuzLinearLayout[2] = mMainLayout.findViewById(R.id.embBuz2LinearLayout);
            mEmbBuzLinearLayout[3] = mMainLayout.findViewById(R.id.embBuz3LinearLayout);
            for (int i = 0; i < 4; i++) {
                mEmbBuzLinearLayout[i].setVisibility(GONE);
            }
        }

        // Manage layouts
        float screenDensity = getResources().getDisplayMetrics().density;
        if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_EMB() == 1) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_1) / screenDensity;
            mEmbTitleTextView[0].setTextSize(textSize);
            mEmbTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 0));
            mEmbDataTextView[0].setTextSize(textSize);
            mEmbLinearLayout[1].setVisibility(View.GONE);
            mEmbLinearLayout[2].setVisibility(View.GONE);
            mEmbLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_EMB() == 2) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_2) / screenDensity;
            mEmbTitleTextView[0].setTextSize(textSize);
            mEmbTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 0));
            mEmbDataTextView[0].setTextSize(textSize);
            mEmbTitleTextView[1].setTextSize(textSize);
            mEmbTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 1));
            mEmbDataTextView[1].setTextSize(textSize);
            mEmbLinearLayout[2].setVisibility(View.GONE);
            mEmbLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_EMB() == 3) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_3) / screenDensity;
            mEmbTitleTextView[0].setTextSize(textSize);
            mEmbTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 0));
            mEmbDataTextView[0].setTextSize(textSize);
            mEmbTitleTextView[1].setTextSize(textSize);
            mEmbTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 1));
            mEmbDataTextView[1].setTextSize(textSize);
            mEmbTitleTextView[2].setTextSize(textSize);
            mEmbTitleTextView[2].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 2));
            mEmbDataTextView[2].setTextSize(textSize);
            mEmbLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_EMB() == 4) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_3) / screenDensity;
            mEmbTitleTextView[0].setTextSize(textSize);
            mEmbTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 0));
            mEmbDataTextView[0].setTextSize(textSize);
            mEmbTitleTextView[1].setTextSize(textSize);
            mEmbTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 1));
            mEmbDataTextView[1].setTextSize(textSize);
            mEmbTitleTextView[2].setTextSize(textSize);
            mEmbTitleTextView[2].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 2));
            mEmbDataTextView[2].setTextSize(textSize);
            mEmbTitleTextView[3].setTextSize(textSize);
            mEmbTitleTextView[3].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.EMBEDDED_FUNCTION_STR, 3));
            mEmbDataTextView[3].setTextSize(textSize);
        }
    }

    public void forceUpdateUI()
    {
        MyMotionData.hw_int = 0;
        for (int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_EMB(); i++) {
            mEmbImageView[i].setImageResource(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.EMBEDDED_FUNCTION_STR, i, AppConfig.IDLE));
            mEmbDataTextView[i].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.EMBEDDED_FUNCTION_STR, i, AppConfig.IDLE));
        }
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyMotionData.hw_int > 0) {
                    for (int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_EMB(); i++) {
                        String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.EMBEDDED_FUNCTION_STR, i);
                        boolean eventDetected =
                                (outputType.equals(AppConfig.WAKE_UP_STR) && MyMotionData.getBit(MyMotionData.hw_int, MyMotionData.HW_WAKE_UP_BIT)) ||
                                (outputType.equals(AppConfig.FREE_FALL_STR) && MyMotionData.getBit(MyMotionData.hw_int, MyMotionData.HW_FREE_FALL_BIT)) ||
                                (outputType.equals(AppConfig.SINGLE_TAP_STR) && MyMotionData.getBit(MyMotionData.hw_int, MyMotionData.HW_TAP_SINGLE_BIT)) ||
                                (outputType.equals(AppConfig.DOUBLE_TAP_STR) && MyMotionData.getBit(MyMotionData.hw_int, MyMotionData.HW_TAP_DOUBLE_BIT)) ||
                                (outputType.equals(AppConfig.TRIPLE_TAP_STR) && MyMotionData.getBit(MyMotionData.hw_int, MyMotionData.HW_TAP_TRIPLE_BIT));
                        if (eventDetected) {
                            ImageView imageView = mEmbImageView[i];
                            Integer imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.EMBEDDED_FUNCTION_STR, i, AppConfig.EVENT);
                            Integer imageViewResource_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.EMBEDDED_FUNCTION_STR, i, AppConfig.IDLE);
                            TextView textView = mEmbDataTextView[i];
                            String textViewString_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.EMBEDDED_FUNCTION_STR, i, AppConfig.EVENT);
                            String textViewString_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.EMBEDDED_FUNCTION_STR, i, AppConfig.IDLE);
                            mEmbImageView[i].setImageResource(imageViewResource_EVENT);
                            mEmbDataTextView[i].setText(textViewString_EVENT);
                            if (mEmbTimer[i] != null) {
                                mEmbTimer[i].cancel();
                            }
                            mEmbTimer[i] = new MyCountDownTimer(1000, imageView, imageViewResource_IDLE, textView, textViewString_IDLE);
                            mEmbTimer[i].start();
                            DemoFragment.getInstance().addEventToCardEvent(textViewString_EVENT);
                        }
                    }
                    MyMotionData.hw_int = 0;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

package st.oem.box;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Build;
import android.text.InputType;
import android.util.Half;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.List;
import java.util.Locale;
import java.util.Objects;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_RAM_CONFIG extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private LinearLayout mRamConfigLinearLayout;
    private Button mSendRamConfigButton;

    private CardView mMainLayout;

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mRamConfigLinearLayout = null;
        mSendRamConfigButton = null;

        mMainLayout = null;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @SuppressLint("InflateParams")
    public CardView_RAM_CONFIG(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_ram_config, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mRamConfigLinearLayout = mMainLayout.findViewById(R.id.ramConfigLinearLayout);
        mSendRamConfigButton = mMainLayout.findViewById(R.id.sendRamConfigButton);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });
        
        // Populate linear layout
        for (int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_RamConfigItems(); i++)
        {
            LinearLayout row = new LinearLayout(getContext());
            row.setLayoutParams(new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            row.setOrientation(LinearLayout.VERTICAL);

            // Create TextView name
            TextView paramNameTextView = new TextView(getContext());
            paramNameTextView.setText(DemoFragment.getInstance().getSelectedDemo().getRamConfigParamName(i));
            paramNameTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));

            // Create TextView description
            TextView paramDescriptionTextView = new TextView(getContext());
            paramDescriptionTextView.setText(DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDescription(i));
            paramDescriptionTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
            int dp = (int) (getResources().getDimension(R.dimen.single_demo_textsize_4) / getResources().getDisplayMetrics().density);
            paramDescriptionTextView.setTextSize(dp);

            // Create AppCompatEditText
            LinearLayout.LayoutParams editTextLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i != (DemoFragment.getInstance().getSelectedDemo().getNumberOf_RamConfigItems() - 1)) {
                editTextLayoutParams.setMargins(0, -20, 0, 50);
            }
            AppCompatEditText paramValueEditText = new AppCompatEditText(getContext());
            paramValueEditText.setId(i);
            paramValueEditText.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
            paramValueEditText.setLayoutParams(editTextLayoutParams);
            String text = getContext().getString(R.string.empty_string);
            if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_THRESHOLD)) {
                text = String.format(Locale.ENGLISH, "%.3f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                paramValueEditText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
                paramValueEditText.setOnFocusChangeListener((v, hasFocus) -> {
                    if (!hasFocus) {
                        try {
                            String str = Objects.requireNonNull(paramValueEditText.getText()).toString();
                            Float.parseFloat(str);
                        } catch (Exception e) { paramValueEditText.setText(getResources().getString(R.string.card_fsm_config_min_value)); e.printStackTrace(); }
                    }
                });
            }
            else if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_SHORT_TIMER)) {
                text = String.format(Locale.ENGLISH, "%.0f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                paramValueEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
                paramValueEditText.setOnFocusChangeListener((v, hasFocus) -> {
                    if (!hasFocus) {
                        try {
                            String str = Objects.requireNonNull(paramValueEditText.getText()).toString();
                            float val = Float.parseFloat(str);
                            if (val > getResources().getInteger(R.integer.max_reg_value_int_dec))
                                paramValueEditText.setText(getResources().getString(R.string.card_fsm_config_max_value));
                        } catch (Exception e) { paramValueEditText.setText(getResources().getString(R.string.card_fsm_config_min_value)); e.printStackTrace(); }
                    }
                });
            }
            else if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_LONG_TIMER)) {
                text = String.format(Locale.ENGLISH, "%.0f", DemoFragment.getInstance().getSelectedDemo().getRamConfigParamDefault(i));
                paramValueEditText.setInputType(InputType.TYPE_CLASS_NUMBER);
                paramValueEditText.setOnFocusChangeListener((v, hasFocus) -> {
                    if (!hasFocus) {
                        try { String str = Objects.requireNonNull(paramValueEditText.getText()).toString();
                            float val = Float.parseFloat(str);
                            if (val > getResources().getInteger(R.integer.max_reg_value_int_dec))
                                paramValueEditText.setText(getResources().getString(R.string.card_fsm_config_max_value));
                        } catch (Exception e) { paramValueEditText.setText(getResources().getString(R.string.card_fsm_config_min_value)); e.printStackTrace(); }
                    }
                });
            }
            paramValueEditText.setText(text);

            // Add TextView name
            row.addView(paramNameTextView);
            // Add TextView description
            row.addView(paramDescriptionTextView);
            // Add AppCompatEditText
            row.addView(paramValueEditText);
            // Add new layout to main layout
            mRamConfigLinearLayout.addView(row);
        }

        mSendRamConfigButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        for (int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_RamConfigItems(); i++)
                        {
                            AppCompatEditText paramValueEditText = mRamConfigLinearLayout.findViewById(i);

                            List<String> addressList = DemoFragment.getInstance().getSelectedDemo().getRamConfigParamRamAddress(i);
                            String paramValue = Objects.requireNonNull(paramValueEditText.getText()).toString();
                            float val;
                            try {
                                val = Float.parseFloat(paramValue);
                            } catch (Exception e) {
                                val = getResources().getInteger(R.integer.min_reg_value_int_dec);
                                paramValueEditText.setText(getResources().getString(R.string.card_fsm_config_min_value));
                                e.printStackTrace();
                            }

                            if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_THRESHOLD))
                            {
                                //MyHalf hval = new MyHalf(val); // use MyHalf to make app run on API < 26
                                Half hval = new Half(val);
                                @SuppressLint("HalfFloat") Short hval_short = hval.halfValue();
                                String hval_str = String.format("%04X", hval_short);

                                for (int address = 0; address < addressList.size(); address += 2) {
                                    String ramAddress = addressList.get(address);

                                    // Low
                                    String ramValue = hval_str.substring(2, 4);
                                    BLECommands.sendRamConfig(getContext(), ramAddress, ramValue);

                                    // Increase RAM address
                                    int add = Integer.parseInt(ramAddress, 16);
                                    add++;
                                    ramAddress = String.format("%3X", add);

                                    // High
                                    ramValue = hval_str.substring(0, 2);
                                    BLECommands.sendRamConfig(getContext(), ramAddress, ramValue);
                                }
                            }
                            else if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_LONG_TIMER))
                            {
                                String timer_str = String.format("%04X", (int)val);

                                for (int address = 0; address < addressList.size(); address++) {
                                    String ramAddress = addressList.get(address);

                                    // Low
                                    String ramValue = timer_str.substring(2, 4);
                                    BLECommands.sendRamConfig(getContext(), ramAddress, ramValue);

                                    // Increase RAM address
                                    int add = Integer.parseInt(ramAddress, 16);
                                    add++;
                                    ramAddress = String.format("%03X", add);

                                    // High
                                    ramValue = timer_str.substring(0, 2);
                                    BLECommands.sendRamConfig(getContext(), ramAddress, ramValue);
                                }
                            }
                            else if (DemoFragment.getInstance().getSelectedDemo().getRamConfigParamType(i).equals(DemoClass.PARAM_TYPE_SHORT_TIMER))
                            {
                                for (int address = 0; address < addressList.size(); address++) {
                                    String ramAddress = addressList.get(address);

                                    String ramValue = String.format("%02X", (int) val);
                                    BLECommands.sendRamConfig(getContext(), ramAddress, ramValue);
                                }
                            }
                        }
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }
}

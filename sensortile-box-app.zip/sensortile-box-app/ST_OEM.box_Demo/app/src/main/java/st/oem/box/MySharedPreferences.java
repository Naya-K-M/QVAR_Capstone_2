package st.oem.box;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;

public class MySharedPreferences {

    private static final String NODE_NAME_DEFAULT = "OEM.box";

    private static final String PREF_NAME = "st_oem_demo_prefs";
    private static final String NODE_NAME_ID = "node_name";
    private static final String NODE_ADDR_ID = "node_addr";
    private static final String SEL_PAGE_ID = "sel_page";
    private static final String USERNAME_ID = "username";
    private static final String AUTO_CONNECT_ID = "auto_connect";
    private static final String AUTO_CONNECT_RUNTIME_ID = "auto_connect_runtime";
    private static final String EVENTS_CARD_ID = "events_conn_card";
    private static final String F_SYNC_EN_ID = "f_sync_en";
    private static final String F_SYNC_VAL_ID = "f_sync_val";
    private static final String LOG_FILENAME_ID = "log_filename_val";
    private static final String CHART_BUFFER_SIZE_ID = "chart_buffer_size_val";
    //private static final String BLE_LOG_HIGH_RATE_ID = "ble_log_high_rate_val";
    //private static final String BLE_LOG_ACC_AXIS_ID = "ble_log_acc_axis_val";
    private static final String SCREEN_ORIENTATION_ID = "screen_orientation_val";

    private static MySharedPreferences instance;
    private final SharedPreferences preferences;
    private final SharedPreferences.Editor editor;

    @SuppressLint("CommitPrefEdits")
    private MySharedPreferences(Context context) {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = preferences.edit();
    }

    public static MySharedPreferences getInstance(Context context) {
        if (instance == null) {
            instance = new MySharedPreferences(context);
        }
        return instance;
    }

    public void setUsername(String val) {
        editor.putString(USERNAME_ID, val).apply();
    }
    public String getUsername() {
        return preferences.getString(USERNAME_ID, "user");
    }

    public void setAutoConnect(boolean val) {
        editor.putBoolean(AUTO_CONNECT_ID, val).apply();
    }
    public boolean getAutoConnect() {
        return preferences.getBoolean(AUTO_CONNECT_ID, false);
    }

    public void setAutoConnectRuntime(boolean val) {
        editor.putBoolean(AUTO_CONNECT_RUNTIME_ID, val).apply();
    }
    public boolean getAutoConnectRuntime() {
        return preferences.getBoolean(AUTO_CONNECT_RUNTIME_ID, true);
    }

    public void setEventsCard(boolean val) {
        editor.putBoolean(EVENTS_CARD_ID, val).apply();
    }
    public boolean getEventsCard() {
        return preferences.getBoolean(EVENTS_CARD_ID, false);
    }

    public void setSelPage(int val) {
        editor.putInt(SEL_PAGE_ID, val).apply();
    }
    public int getSelPage() {
        return preferences.getInt(SEL_PAGE_ID, 0);
    }

    public void setNodeName(String val) {
        editor.putString(NODE_NAME_ID, val).apply();
    }
    public String getNodeName() {
        return preferences.getString(NODE_NAME_ID, NODE_NAME_DEFAULT);
    }

    public void setNodeAddress(String val) {
        editor.putString(NODE_ADDR_ID, val).apply();
    }
    public String getNodeAddress() {
        return preferences.getString(NODE_ADDR_ID, "");
    }

    public void setFSyncEn(boolean val) {
        editor.putBoolean(F_SYNC_EN_ID, val).apply();
    }
    public boolean getFSyncEn() {
        return preferences.getBoolean(F_SYNC_EN_ID, false);
    }

    public void setFSyncVal(String val) {
        editor.putString(F_SYNC_VAL_ID, val).apply();
    }
    public String getFSyncVal() {
        return preferences.getString(F_SYNC_VAL_ID, "0");
    }

    public void setLogFilename(String val) {
        editor.putString(LOG_FILENAME_ID, val).apply();
    }
    public String getLogFilename() {
        return preferences.getString(LOG_FILENAME_ID, "log.txt");
    }

    public void setChartBufferSizeVal(String val) {
        editor.putString(CHART_BUFFER_SIZE_ID, val).apply();
    }
    public String getChartBufferSizeVal() {
        return preferences.getString(CHART_BUFFER_SIZE_ID, "150");
    }

    public void setScreenOrientationVal(String val) {
        editor.putString(SCREEN_ORIENTATION_ID, val).apply();
    }
    public String getScreenOrientationVal() {
        return preferences.getString(SCREEN_ORIENTATION_ID, "Portrait");
    }
}

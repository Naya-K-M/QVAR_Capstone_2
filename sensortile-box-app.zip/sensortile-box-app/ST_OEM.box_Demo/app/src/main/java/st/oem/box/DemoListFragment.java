package st.oem.box;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.core.content.res.ResourcesCompat;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.provider.OpenableColumns;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.threed.jpct.util.BitmapHelper;

import java.util.ArrayList;
import java.util.Objects;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

public class DemoListFragment extends Fragment
{
    private final static String LOG_TAG = DemoListFragment.class.getSimpleName();

    private FrameLayout mFrameLayout;
    private View mPortraitView;
    private View mLandscapeView;

    public static final String INTENT_FILE_PICKER_FILTER = "INTENT_FILTER_FILE_PICKER";
    public static final int LOAD_FROM_RES = 0;
    private static final int LOAD_FROM_URI = 1;
    public static final int MESSAGE_ID_FILE_PICKER_UCF = 1;
    public static final int MESSAGE_ID_FILE_PICKER_UCF_JSON = 2;
    public static final int MESSAGE_ID_FILE_PICKER_IMAGE = 3;

    private int mFilePickerType = 0;
    private static FragmentManager mFragmentManager;

    private ArrayList<DemoClass> mDemosArray = new ArrayList<>();
    private DemoClass mSelectedDemo;

    DemoListFragment(int page, String title, ArrayList<DemoClass> demosArray) {
        Bundle args = new Bundle();
        args.putInt("PAGE", page);
        args.putString("TITLE", title);
        args.putParcelableArrayList("DEMOS", demosArray);
        this.setArguments(args);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mFragmentManager = getActivity().getSupportFragmentManager();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        mFragmentManager = null;
        mFrameLayout = null;
        mPortraitView = null;
        mLandscapeView = null;

        mDemosArray.clear();
        mDemosArray = null;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.d(LOG_TAG, "onCreateView");

        Bundle args = getArguments();
        if (args != null) {
            mDemosArray = args.getParcelableArrayList("DEMOS");
        }

        mFrameLayout = new FrameLayout(getContext());

        mPortraitView = inflater.inflate(R.layout.fragment_demo_list, container, false);
        mLandscapeView = inflater.inflate(R.layout.fragment_demo_list, container, false);

        int currentOrientation = getResources().getConfiguration().orientation;
        if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            new Thread() {
                @Override
                public void run() {
                    super.run();

                    populateView(mPortraitView, Configuration.ORIENTATION_PORTRAIT);
                }
            }.start();

            populateView(mLandscapeView, Configuration.ORIENTATION_LANDSCAPE);
            mFrameLayout.addView(mLandscapeView);

        } else {
            new Thread() {
                @Override
                public void run() {
                    super.run();

                    populateView(mLandscapeView, Configuration.ORIENTATION_LANDSCAPE);
                }
            }.start();

            populateView(mPortraitView, Configuration.ORIENTATION_PORTRAIT);
            mFrameLayout.addView(mPortraitView);
        }

        return mFrameLayout;
    }

    private final BroadcastReceiver mFilePickerCommandReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle != null) {
            mFilePickerType = bundle.getInt(getString(R.string.INTENT_EXTRA_KEY_OP_ID), 0);
            if (mFilePickerType > 0) {
                Intent newIntent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                newIntent.addCategory(Intent.CATEGORY_OPENABLE);
                newIntent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

                switch (mFilePickerType) {
                    case MESSAGE_ID_FILE_PICKER_UCF:
                        newIntent.setType("*/*");
                        break;

                    case MESSAGE_ID_FILE_PICKER_UCF_JSON:
                        newIntent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                        newIntent.setType("*/*");
                        break;

                    case MESSAGE_ID_FILE_PICKER_IMAGE:
                        newIntent.setType("image/*");
                        break;
                }
                someActivityResultLauncher.launch(newIntent);
            }
        }
        }
    };

    @Override
    public void onResume() {
        super.onResume();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(INTENT_FILE_PICKER_FILTER);
        getContext().registerReceiver(mFilePickerCommandReceiver, intentFilter);
    }

    @Override
    public void onPause() {
        super.onPause();

        getContext().unregisterReceiver(mFilePickerCommandReceiver);
    }

    private void populateView(View view, int currentOrientation)
    {
        int mod = -1;

        LinearLayout mainLinearLayout = view.findViewById(R.id.mainLinearLayout);
        LinearLayout tmpLinearLayout = null;

        // Used to get the first package and sync the UI
        for (int demoIndex = 0; demoIndex < mDemosArray.size(); demoIndex++) {

            CardView demoCardView = (CardView) View.inflate(getContext(), R.layout.cardview_demo, null);
            demoCardView.setId(demoIndex);

            demoCardView.setOnClickListener((View v) ->
            {
                if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                    if (!BluetoothLeService.mFirstCtrlPacketReceived) {
                        BLECommands.sendGetStatus(getContext());    // Try getting again the status
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_waiting_first_ble_packet_ongoing), Toast.LENGTH_SHORT).show();
                    } else {
                        CardView cardView = (CardView) v;

                        int buttonId = cardView.getId();
                        mSelectedDemo = mDemosArray.get(buttonId);

                        if (MyLogging.logStatus == MyLogging.LOG_STATUS_LOGGING && MyCtrlData.sd_log == 1 && !mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_sensors_sd_log))) {
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_board_is_logging_sd), Toast.LENGTH_SHORT).show();
                        } else if (MyLogging.logStatus == MyLogging.LOG_STATUS_LOGGING && MyCtrlData.ble_log == 1 && !mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_sensors_ble_log))) {
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_board_is_logging_ble), Toast.LENGTH_SHORT).show();
                        } else if (MyCtrlData.sd_msc == 1 && !mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_mass_storage))) {
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_mass_storage_enabled), Toast.LENGTH_SHORT).show();
                        } else {
                            if (mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_ucfloader))) {
                                String EXTRA_KEY_OP_ID_String = getContext().getString(R.string.INTENT_EXTRA_KEY_OP_ID);
                                Intent intent = new Intent(INTENT_FILE_PICKER_FILTER);
                                if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                                        (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS))) {
                                    Toast.makeText(getContext(), getContext().getString(R.string.toast_file_picker_ispu), Toast.LENGTH_SHORT).show();
                                    intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_FILE_PICKER_UCF_JSON);
                                    getContext().sendBroadcast(intent);
                                } else {
                                    Toast.makeText(getContext(), getContext().getString(R.string.toast_file_picker_standard), Toast.LENGTH_SHORT).show();
                                    intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_FILE_PICKER_UCF);
                                    getContext().sendBroadcast(intent);
                                }
                            } else if (mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_mass_storage)) && MyCtrlData.sd_err == 1) {
                                Toast.makeText(getContext(), getContext().getString(R.string.toast_sd_card_error), Toast.LENGTH_SHORT).show();
                            } else if (mSelectedDemo.getDemoName().equals(getResources().getString(R.string.tool_name_sensors_sd_log)) && MyCtrlData.sd_err == 1) {
                                Toast.makeText(getContext(), getContext().getString(R.string.toast_sd_card_error), Toast.LENGTH_SHORT).show();
                            } else if (DemoFragment.getInstance() == null) {
                                loadDemoFragment(LOAD_FROM_RES);
                            }
                        }
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                }
            });

            ImageView demoImageView = demoCardView.findViewById(R.id.media_image);
            Drawable demoDrawable = ResourcesCompat.getDrawable(getResources(), mDemosArray.get(demoIndex).getDemoIconID(), null);
            assert demoDrawable != null;
            Bitmap demoBitmap = BitmapHelper.rescale(BitmapHelper.convert(demoDrawable), 256, 256);
            demoImageView.setImageBitmap(demoBitmap);
            demoImageView.setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);

            TextView demoPrimaryTextView = demoCardView.findViewById(R.id.primary_text);
            demoPrimaryTextView.setText(mDemosArray.get(demoIndex).getDemoName());

            TextView demoSecondaryTextView = demoCardView.findViewById(R.id.sub_text);
            demoSecondaryTextView.setText(mDemosArray.get(demoIndex).getDemoShortDescription());

            TextView demoOtherTextView = demoCardView.findViewById(R.id.other_text);
            demoOtherTextView.setText(mDemosArray.get(demoIndex).getDemoOtherText());

            TextView xlTextView = demoCardView.findViewById(R.id.xl_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_XL()) {
                xlTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_green, null));
                xlTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                xlTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                xlTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView gTextView = demoCardView.findViewById(R.id.g_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_G()) {
                gTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_green, null));
                gTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                gTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                gTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView qTextView = demoCardView.findViewById(R.id.q_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_Q()) {
                qTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_green, null));
                qTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                qTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                qTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView pTextView = demoCardView.findViewById(R.id.p_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_P()) {
                pTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_green, null));
                pTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                pTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                pTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView mlcTextView = demoCardView.findViewById(R.id.mlc_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_MLC()) {
                mlcTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_pink, null));
                mlcTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                mlcTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                mlcTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView fsmTextView = demoCardView.findViewById(R.id.fsm_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_FSM()) {
                fsmTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_yellow, null));
                fsmTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                fsmTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                fsmTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView embTextView = demoCardView.findViewById(R.id.emb_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_EMB()) {
                embTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_blue, null));
                embTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_white, null));
            } else {
                embTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                embTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView pedTextView = demoCardView.findViewById(R.id.ped_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_PED()) {
                pedTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_cyan, null));
                pedTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                pedTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                pedTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView sflpTextView = demoCardView.findViewById(R.id.sflp_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_SFLP()) {
                sflpTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_pink, null));
                sflpTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                sflpTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                sflpTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView ispuTextView = demoCardView.findViewById(R.id.ispu_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_ISPU()) {
                ispuTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_cyan, null));
                ispuTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            } else {
                ispuTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                ispuTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            TextView libTextView = demoCardView.findViewById(R.id.lib_image);
            if (mDemosArray.get(demoIndex).getDemoUsage_LIB()) {
                libTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_purple, null));
                libTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_white, null));
            } else {
                libTextView.setBackground(ResourcesCompat.getDrawable(getResources(), R.drawable.icon_grey, null));
                libTextView.setTextColor(ResourcesCompat.getColor(getResources(), R.color.color_blue, null));
            }

            // Update patent icon
            ImageView patentImageView = demoCardView.findViewById(R.id.patent_image);
            if (Objects.equals(mDemosArray.get(demoIndex).getDemoPatent(), DemoClass.PATENT_NONE))
                patentImageView.setVisibility(View.GONE);
            else if (Objects.equals(mDemosArray.get(demoIndex).getDemoPatent(), DemoClass.PATENT_DONE))
                patentImageView.setImageResource(R.drawable.patent_done);
            else if (Objects.equals(mDemosArray.get(demoIndex).getDemoPatent(), DemoClass.PATENT_PENDING))
                patentImageView.setImageResource(R.drawable.patent_pending);

            // Hide P and LIB images for demos based on embedded functions
            if ((mDemosArray.get(demoIndex).getDemoUsage_MLC()) ||
                    (mDemosArray.get(demoIndex).getDemoUsage_FSM()) ||
                    (mDemosArray.get(demoIndex).getDemoUsage_EMB()) ||
                    (mDemosArray.get(demoIndex).getDemoUsage_PED()) ||
                    (mDemosArray.get(demoIndex).getDemoUsage_SFLP()) ||
                    (mDemosArray.get(demoIndex).getDemoUsage_ISPU())) {
                pTextView.setVisibility(View.GONE);
                libTextView.setVisibility(View.GONE);
            }

            // Hide G icon
            if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12))
                gTextView.setVisibility(View.GONE);

            // Hide Q icon
            if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSOX)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV32X)))
                qTextView.setVisibility(View.GONE);

            // Hide P icon
            if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSOX)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16X)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV32X)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12)))
                pTextView.setVisibility(View.GONE);

            // Hide ISPU icon
            if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSOX)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16X)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV32X)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX)) ||
                    (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12)))
                ispuTextView.setVisibility(View.GONE);

            // Hide EMB, MLC, FSM, PED and SFLP images for LIB demos
            if ((mDemosArray.get(demoIndex).getDemoUsage_ISPU() ||
                    mDemosArray.get(demoIndex).getDemoUsage_LIB())) {
                embTextView.setVisibility(View.GONE);
                mlcTextView.setVisibility(View.GONE);
                fsmTextView.setVisibility(View.GONE);
                pedTextView.setVisibility(View.GONE);
                sflpTextView.setVisibility(View.GONE);
            }

            // Hide all icons if TOOLS
            boolean isTool = mDemosArray.get(demoIndex).getDemoName().equals(getContext().getString(R.string.tool_name_ucfloader));
            isTool |= mDemosArray.get(demoIndex).getDemoName().equals(getContext().getString(R.string.tool_name_sensors_sd_log));
            isTool |= mDemosArray.get(demoIndex).getDemoName().equals(getContext().getString(R.string.tool_name_sensors_ble_log));
            isTool |= mDemosArray.get(demoIndex).getDemoName().equals(getContext().getString(R.string.tool_name_mass_storage));
            if (isTool) {
                xlTextView.setVisibility(View.GONE);
                gTextView.setVisibility(View.GONE);
                qTextView.setVisibility(View.GONE);
                pTextView.setVisibility(View.GONE);
                embTextView.setVisibility(View.GONE);
                mlcTextView.setVisibility(View.GONE);
                fsmTextView.setVisibility(View.GONE);
                pedTextView.setVisibility(View.GONE);
                sflpTextView.setVisibility(View.GONE);
                ispuTextView.setVisibility(View.GONE);
                libTextView.setVisibility(View.GONE);
            }

            if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.weight = 0.5f;
                demoCardView.setLayoutParams(lp);

                mod = demoIndex % 2;
                if (mod == 0) {
                    tmpLinearLayout = new LinearLayout(getContext());
                    tmpLinearLayout.setLayoutParams(new LinearLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
                    tmpLinearLayout.setOrientation(LinearLayout.HORIZONTAL);

                    tmpLinearLayout.addView(demoCardView);
                } else {
                    tmpLinearLayout.addView(demoCardView);
                    mainLinearLayout.addView(tmpLinearLayout);
                }
            }
            else {
                mainLinearLayout.addView(demoCardView);
            }
        }

        if (mod == 0) {
            CardView demoCardView_dummy = (CardView) View.inflate(getContext(), R.layout.cardview_demo, null);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.weight = 0.5f;
            demoCardView_dummy.setLayoutParams(lp);
            demoCardView_dummy.setVisibility(View.INVISIBLE);
            tmpLinearLayout.addView(demoCardView_dummy);
            mainLinearLayout.addView(tmpLinearLayout);
        }
    }

    private void loadDemoFragment(int loadFrom) {
        ContainerFragment containerFragment = (ContainerFragment) mFragmentManager.findFragmentByTag("ContainerFragment");
        FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.frame_layout_container, DemoFragment.getInstance(mSelectedDemo, loadFrom), "DemoFragment");
        fragmentTransaction.hide(containerFragment);
        fragmentTransaction.commit();
    }

    // Called in case a demo is shown but the board (for some
    // reason) is no more configured
    public static void forceDismissDemoFragment()
    {
        if (DemoFragment.getInstance() != null && MyCtrlData.conf == 0 && MyCtrlData.sd_msc == 0)
        {
            ContainerFragment containerFragment = (ContainerFragment) mFragmentManager.findFragmentByTag("ContainerFragment");
            DemoFragment demoFragment = (DemoFragment) mFragmentManager.findFragmentByTag("DemoFragment");
            FragmentTransaction fragmentTransaction = mFragmentManager.beginTransaction();
            fragmentTransaction.remove(demoFragment);
            fragmentTransaction.show(containerFragment);
            fragmentTransaction.commit();

            DemoFragment.destroyInstance();
        }
    }

    // You can do the assignment inside onAttach or onCreate, i.e, before the activity is displayed
    ActivityResultLauncher<Intent> someActivityResultLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        new ActivityResultCallback<ActivityResult>() {
            @Override
            public void onActivityResult(ActivityResult result) {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent resultData = result.getData();
                    // The document selected by the user won't be returned in the intent.
                    // Instead, a URI to that document will be contained in the return intent
                    // provided to this method as a parameter.
                    // Pull that URI using resultData.getData().
                    if (resultData != null) {

                        if (mFilePickerType > 0) {

                            ClipData clip = resultData.getClipData();
                            Activity activity = getActivity();
                            if (activity != null) {
                                ClipData.Item item1, item2;
                                Uri uri1, uri2;
                                String file1, file2;
                                String ext1, ext2;
                                Cursor cursor1, cursor2;

                                switch (mFilePickerType) {
                                    case MESSAGE_ID_FILE_PICKER_UCF:
                                        uri1 = resultData.getData();
                                        cursor1 = activity.getContentResolver().query(uri1, null, null, null, null, null);
                                        if (cursor1 != null && cursor1.moveToFirst()) {
                                            file1 = cursor1.getString(cursor1.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                                            ext1 = file1.substring(file1.lastIndexOf("."));
                                            if (ext1.equals(".ucf")) {
                                                mSelectedDemo.setConfigurationFileUri(uri1);
                                                mSelectedDemo.setJsonFileUri(Uri.EMPTY);
                                                loadDemoFragment(LOAD_FROM_URI);
                                            } else {
                                                Toast.makeText(getContext(), getContext().getString(R.string.toast_invalid_selected_file), Toast.LENGTH_SHORT).show();
                                            }
                                        } else {
                                            Toast.makeText(getContext(), getContext().getString(R.string.toast_invalid_selected_file), Toast.LENGTH_SHORT).show();
                                        }
                                        break;

                                    case MESSAGE_ID_FILE_PICKER_UCF_JSON:
                                        if (clip.getItemCount() == 2) {
                                            item1 = clip.getItemAt(0);
                                            item2 = clip.getItemAt(1);
                                            uri1 = item1.getUri();
                                            uri2 = item2.getUri();
                                            cursor1 = activity.getContentResolver().query(uri1, null, null, null, null, null);
                                            cursor2 = activity.getContentResolver().query(uri2, null, null, null, null, null);
                                            if (cursor1 != null && cursor2 != null && cursor1.moveToFirst() && cursor2.moveToFirst()) {
                                                file1 = cursor1.getString(cursor1.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                                                file2 = cursor2.getString(cursor2.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                                                ext1 = file1.substring(file1.lastIndexOf("."));
                                                ext2 = file2.substring(file2.lastIndexOf("."));
                                                if ((ext1.equals(".ucf") && ext2.equals(".json")) || (ext1.equals(".json") && ext2.equals(".ucf"))) {
                                                    if (ext1.equals(".ucf")) {
                                                        mSelectedDemo.setConfigurationFileUri(uri1);
                                                        mSelectedDemo.setJsonFileUri(uri2);
                                                    } else {
                                                        mSelectedDemo.setConfigurationFileUri(uri2);
                                                        mSelectedDemo.setJsonFileUri(uri1);
                                                    }
                                                    loadDemoFragment(LOAD_FROM_URI);
                                                } else {
                                                    Toast.makeText(getContext(), getContext().getString(R.string.toast_invalid_selected_file), Toast.LENGTH_SHORT).show();
                                                }
                                            } else {
                                                Toast.makeText(getContext(), getContext().getString(R.string.toast_invalid_selected_file), Toast.LENGTH_SHORT).show();
                                            }
                                        } else {
                                            Toast.makeText(getContext(), getContext().getString(R.string.toast_invalid_selected_file), Toast.LENGTH_SHORT).show();
                                        }
                                        break;

                                    case MESSAGE_ID_FILE_PICKER_IMAGE:
                                        uri1 = resultData.getData();
                                        CardView_UNSUPERVISED_ODL.setCustomDrawable(getContext(), uri1);
                                        break;
                                }
                            }
                        }
                    }
                }
            }
        });

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        mFrameLayout.removeAllViews();
        int currentOrientation = getResources().getConfiguration().orientation;
        if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            mFrameLayout.addView(mLandscapeView);
        }
        else {
            mFrameLayout.addView(mPortraitView);
        }
    }
}
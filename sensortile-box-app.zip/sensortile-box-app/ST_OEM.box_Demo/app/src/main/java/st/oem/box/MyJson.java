package st.oem.box;

import java.util.ArrayList;
import java.util.Locale;

public class MyJson {

    private static class MappedOutput
    {
        String name;
        String type;
        int byteIndex;
    }
    private static final ArrayList<MappedOutput> mappedOutputs = new ArrayList<>();
    private static boolean jsonFound = false;

    public static void clearMappedOutput()
    {
        mappedOutputs.clear();
        jsonFound = false;
    }

    public static void addMappedOutput(String name, String type, int byteIndex)
    {
        MappedOutput newMappedOutput = new MappedOutput();

        newMappedOutput.name = name;
        newMappedOutput.type = type;
        newMappedOutput.byteIndex = byteIndex;

        mappedOutputs.add(newMappedOutput);

        jsonFound = true;
    }

    public static boolean isJsonFound() {
        return jsonFound;
    }

    public static int getMappedOutputLength() {
        return mappedOutputs.size();
    }

    public static String getOutputLabel(int i) {
        return mappedOutputs.get(i).name;
    }
    public static String getOutputType(int i) {
        return mappedOutputs.get(i).type;
    }

    public static int getOutputTypeSize(String type) {
        int size;
        switch (type) {
            case "char":
            case "uint8_t":
            case "int8_t": {
                size = 1;
                break;
            }
            case "uint16_t":
            case "int16_t": {
                size = 2;
                break;
            }
            case "uint32_t":
            case "int32_t":
            case "float": {
                size = 4;
                break;
            }
            default: {
                size = 0;
                break;
            }
        }

        return size;
    }

    public static int getOutputTypeEnum(String type) {
        int enumerator;
        switch (type) {
            case "char":
                enumerator = 1;
                break;
            case "uint8_t":
                enumerator = 2;
                break;
            case "uint16_t":
                enumerator = 3;
                break;
            case "uint32_t":
                enumerator = 4;
                break;
            case "int8_t":
                enumerator = 5;
                break;
            case "int16_t":
                enumerator = 6;
                break;
            case "int32_t":
                enumerator = 7;
                break;
            case "float":
                enumerator = 8;
                break;
            default:
                enumerator = 0;
                break;
        }

        return enumerator;
    }

    public static Object getConvertedOutputObject(int i) {
        Object data;
        int byteIndex = mappedOutputs.get(i).byteIndex;

        switch (mappedOutputs.get(i).type) {
            case "char": {
                data = MyMotionData.ispu_dout.getChar(byteIndex);
                break;
            }
            case "uint8_t":
            case "int8_t": {
                data = MyMotionData.ispu_dout.get(byteIndex);
                break;
            }
            case "uint16_t":
            case "int16_t": {
                data = MyMotionData.ispu_dout.getShort(byteIndex);
                break;
            }
            case "uint32_t":
            case "int32_t": {
                data = MyMotionData.ispu_dout.getInt(byteIndex);
                break;
            }
            case "float": {
                data = MyMotionData.ispu_dout.getFloat(byteIndex);
                break;
            }
            default: {
                data = 0;
                break;
            }
        }

        return data;
    }

    public static String getConvertedOutput(int i) {
        String out = "";
        int byteIndex = mappedOutputs.get(i).byteIndex;

        switch (mappedOutputs.get(i).type) {
            case "char": {
                char data = MyMotionData.ispu_dout.getChar(byteIndex);
                out = String.format(Locale.getDefault(), "%c", data);
                break;
            }
            case "uint8_t": {
                byte data = MyMotionData.ispu_dout.get(byteIndex);
                int data_tmp = Byte.toUnsignedInt(data);
                out = Integer.toUnsignedString(data_tmp);
                break;
            }
            case "int8_t": {
                byte data = MyMotionData.ispu_dout.get(byteIndex);
                out = Integer.toUnsignedString(data);
                break;
            }
            case "uint16_t": {
                short data = MyMotionData.ispu_dout.getShort(byteIndex);
                out = Integer.toUnsignedString(data);
                break;
            }
            case "int16_t": {
                short data = MyMotionData.ispu_dout.getShort(byteIndex);
                out = Integer.toString(data);
                break;
            }
            case "uint32_t": {
                int data = MyMotionData.ispu_dout.getInt(byteIndex);
                out = Integer.toUnsignedString(data);
                break;
            }
            case "int32_t": {
                int data = MyMotionData.ispu_dout.getInt(byteIndex);
                out = Integer.toString(data);
                break;
            }
            case "float": {
                float data = MyMotionData.ispu_dout.getFloat(byteIndex);
                out = String.format(Locale.US, "%.3f", data);
                break;
            }
        }

        return out;
    }
}

package st.oem.box;

public class MyStreamData {

    public static volatile int timestamp;
    public static volatile short[] accX = new short[5];
    public static volatile short[] accY = new short[5];
    public static volatile short[] accZ = new short[5];
    public static volatile short[] accV = new short[5];
    public static volatile short gyrX;
    public static volatile short gyrY;
    public static volatile short gyrZ;

    public static volatile int press;
    public static volatile short[] qvar = new short[5];

    public static void resetData()
    {
        timestamp = 0;
        gyrX = 0;
        gyrY = 0;
        gyrZ = 0;
        press = 0;

        for(int i = 0; i < 5; i++) {
            accX[i] = 0;
            accY[i] = 0;
            accZ[i] = 0;
            accV[i] = 0;
            qvar[i] = 0;
        }
    }
}

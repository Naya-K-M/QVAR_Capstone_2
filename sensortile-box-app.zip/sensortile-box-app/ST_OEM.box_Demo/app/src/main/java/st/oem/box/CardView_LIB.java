package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;

import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_LIB extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private TextView mLibTitleTextView;
    private ImageView mLibImageView;
    private TextView mLibDataTextView;
    private SwitchCompat mLibLedSwitchCompat;
    private LinearLayout mLibLedLinearLayout;
    private SwitchCompat mLibBuzSwitchCompat;
    private LinearLayout mLibBuzLinearLayout;
    private MyCountDownTimer mLibTimer;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    private short lib_data_old;

    // State
    private static boolean mLibLedSwitchCompatState;
    private static boolean mLibBuzSwitchCompatState;
    private static String mLibDataTextViewString;
    private static Integer mLibImageViewResource;

    public void saveState()
    {
        try {
            mLibLedSwitchCompatState = mLibLedSwitchCompat.isChecked();
        } catch(Exception ignored) { }

        try {
            mLibBuzSwitchCompatState = mLibBuzSwitchCompat.isChecked();
        } catch(Exception ignored) { }

        try {
            String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.SW_LIB_STR, 0);
            if (outputType.equals(AppConfig.CONTINUOUS_STR) || outputType.equals(AppConfig.COUNTER_STR))
            {
                mLibImageViewResource = (Integer)mLibImageView.getTag();
            }
        } catch(Exception ignored) { }

        try {
            String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.SW_LIB_STR, 0);
            if (outputType.equals(AppConfig.CONTINUOUS_STR) || outputType.equals(AppConfig.COUNTER_STR))
            {
                mLibDataTextViewString = mLibDataTextView.getText().toString();
            }
        } catch(Exception ignored) { }
    }

    public void restoreState()
    {
        try {
            mLibLedSwitchCompat.setChecked(mLibLedSwitchCompatState);
        } catch(Exception ignored) { }

        try {
            mLibBuzSwitchCompat.setChecked(mLibBuzSwitchCompatState);
        } catch(Exception ignored) { }

        try {
            String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.SW_LIB_STR, 0);
            if (outputType.equals(AppConfig.CONTINUOUS_STR) || outputType.equals(AppConfig.COUNTER_STR))
            {
                mLibImageView.setImageResource(mLibImageViewResource);
                mLibImageView.setTag(mLibImageViewResource);
            }
        } catch(Exception ignored) { }

        try {
            String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.SW_LIB_STR, 0);
            if (outputType.equals(AppConfig.CONTINUOUS_STR) || outputType.equals(AppConfig.COUNTER_STR))
            {
                mLibDataTextView.setText(mLibDataTextViewString);
            }
        } catch(Exception ignored) { }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_LIB_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mLibTitleTextView = null;
        mLibImageView = null;
        mLibDataTextView = null;
        mLibLedSwitchCompat = null;
        mLibLedLinearLayout = null;
        mLibBuzSwitchCompat = null;
        mLibBuzLinearLayout = null;
        mLibTimer = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_LIB(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_lib, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        lib_data_old = -1;

        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mLibTitleTextView = mMainLayout.findViewById(R.id.lib0TitleTextView);
        mLibImageView = mMainLayout.findViewById(R.id.lib0ImageView);
        mLibImageView.setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_white, null), PorterDuff.Mode.SRC_IN);
        mLibDataTextView = mMainLayout.findViewById(R.id.lib0DataTextView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });
        
        if (MyCtrlData.isLedSupported())
        {
            mLibLedSwitchCompat = mMainLayout.findViewById(R.id.libLed0SwitchCompat);
            mLibLedSwitchCompat.setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
            {
                if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                    if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                        if (b)
                            DemoFragment.getInstance().lib_ledMask = (byte)(DemoFragment.getInstance().lib_ledMask | 0x01);
                        else
                            DemoFragment.getInstance().lib_ledMask = (byte)(DemoFragment.getInstance().lib_ledMask & 0xFE);

                        DemoFragment.getInstance().prepareAndSendLedMask();
                    } else {
                        mLibLedSwitchCompat.setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    mLibLedSwitchCompat.setChecked(!b);
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            mLibLedLinearLayout = mMainLayout.findViewById(R.id.libLed0LinearLayout);
            mLibLedLinearLayout.setVisibility(GONE);
        }

        if (MyCtrlData.isBuzSupported())
        {
            mLibBuzSwitchCompat = mMainLayout.findViewById(R.id.libBuz0SwitchCompat);
            mLibBuzSwitchCompat.setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
            {
                if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                    if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                        if (b)
                            DemoFragment.getInstance().lib_buzMask = (byte)(DemoFragment.getInstance().lib_buzMask | 0x01);
                        else
                            DemoFragment.getInstance().lib_buzMask = (byte)(DemoFragment.getInstance().lib_buzMask & 0xFE);

                        DemoFragment.getInstance().prepareAndSendBuzMask();
                    } else {
                        mLibBuzSwitchCompat.setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    mLibBuzSwitchCompat.setChecked(!b);
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            mLibBuzLinearLayout = mMainLayout.findViewById(R.id.libBuz0LinearLayout);
            mLibBuzLinearLayout.setVisibility(GONE);
        }

        float screenDensity = getResources().getDisplayMetrics().density;
        float textSize = getResources().getDimension(R.dimen.single_demo_textsize_1) / screenDensity;
        mLibTitleTextView.setTextSize(textSize);
        mLibTitleTextView.setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.SW_LIB_STR, 0));
        mLibDataTextView.setTextSize(textSize);

        // Initialize UI
        String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.SW_LIB_STR, 0);
        String count = getContext().getString(R.string.empty_string);

        mLibImageView.setImageResource(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, (byte) MyMotionData.lib_data));
        mLibImageView.setTag(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, (byte) MyMotionData.lib_data));
        switch (outputType) {
            case AppConfig.EVENT_BASED_STR:
            case AppConfig.CONTINUOUS_STR:
                mLibDataTextView.setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.SW_LIB_STR, 0, (byte) MyMotionData.lib_data));
                break;
            case AppConfig.COUNTER_STR:
                switch (DemoFragment.getInstance().getSelectedDemo().getDemoName()) {
                    case ("MotionPW"):
                        count = String.format(getResources().getString(R.string.steps_number), 0);
                        break;
                    case ("MotionFA (Biceps)"):
                        count = String.format(getResources().getString(R.string.biceps_number), 0);
                        break;
                    case ("MotionFA (Squats)"):
                        count = String.format(getResources().getString(R.string.squats_number), 0);
                        break;
                    case ("MotionFA (Push-ups)"):
                        count = String.format(getResources().getString(R.string.pushups_number), 0);
                        break;
                    default:
                        break;
                }
                mLibDataTextView.setText(count);
                break;
            default:
                break;
        }
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                String outputType = DemoFragment.getInstance().getSelectedDemo().getSingleDemoOutputType(AppConfig.SW_LIB_STR, 0);
                String count = getContext().getString(R.string.empty_string);

                if (MyMotionData.lib_data > 0) {
                    ImageView imageView;
                    Integer imageViewResource_EVENT, imageViewResource_IDLE;
                    TextView textView;
                    String textViewString_EVENT, textViewString_IDLE;
                    switch (outputType) {
                        case AppConfig.CONTINUOUS_STR:
                            imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, (byte) MyMotionData.lib_data);
                            textViewString_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.SW_LIB_STR, 0, (byte) MyMotionData.lib_data);
                            mLibImageView.setImageResource(imageViewResource_EVENT);
                            mLibImageView.setTag(imageViewResource_EVENT);
                            mLibDataTextView.setText(textViewString_EVENT);
                            DemoFragment.getInstance().addEventToCardEvent(count);
                            break;
                        case AppConfig.COUNTER_STR:
                            if (lib_data_old != MyMotionData.lib_data)
                            {
                                lib_data_old = MyMotionData.lib_data;
                                imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, AppConfig.EVENT);
                                imageViewResource_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, AppConfig.IDLE);
                                switch (DemoFragment.getInstance().getSelectedDemo().getDemoName()) {
                                    case ("MotionPW"):
                                        count = String.format(getResources().getString(R.string.steps_number), MyMotionData.lib_data);
                                        break;
                                    case ("MotionFA (Biceps)"):
                                        count = String.format(getResources().getString(R.string.biceps_number), MyMotionData.lib_data);
                                        break;
                                    case ("MotionFA (Squats)"):
                                        count = String.format(getResources().getString(R.string.squats_number), MyMotionData.lib_data);
                                        break;
                                    case ("MotionFA (Push-ups)"):
                                        count = String.format(getResources().getString(R.string.pushups_number), MyMotionData.lib_data);
                                        break;
                                    default:
                                        break;
                                }
                                mLibImageView.setImageResource(imageViewResource_EVENT);
                                mLibImageView.setTag(imageViewResource_EVENT);
                                if (mLibTimer != null) {
                                    mLibTimer.cancel();
                                }
                                mLibTimer = new MyCountDownTimer(500, mLibImageView, imageViewResource_IDLE);
                                mLibTimer.start();
                                mLibDataTextView.setText(count);
                                DemoFragment.getInstance().addEventToCardEvent(count);
                            }
                            break;
                        case AppConfig.EVENT_BASED_STR:
                            imageView = mLibImageView;
                            imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, AppConfig.EVENT);
                            imageViewResource_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, AppConfig.IDLE);
                            textView = mLibDataTextView;
                            textViewString_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.SW_LIB_STR, 0, AppConfig.EVENT);
                            textViewString_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.SW_LIB_STR, 0, AppConfig.IDLE);
                            mLibImageView.setImageResource(imageViewResource_EVENT);
                            mLibImageView.setTag(imageViewResource_EVENT);
                            mLibDataTextView.setText(textViewString_EVENT);
                            if (mLibTimer != null) {
                                mLibTimer.cancel();
                            }
                            mLibTimer = new MyCountDownTimer(1000, imageView, imageViewResource_IDLE, textView, textViewString_IDLE);
                            mLibTimer.start();
                            DemoFragment.getInstance().addEventToCardEvent(textViewString_EVENT);
                            break;
                        case AppConfig.MANY_EVENT_BASED_STR:
                            imageView = mLibImageView;
                            imageViewResource_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, (byte)MyMotionData.lib_data);
                            imageViewResource_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.SW_LIB_STR, 0, AppConfig.IDLE);
                            textView = mLibDataTextView;
                            textViewString_EVENT = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.SW_LIB_STR, 0, (byte)MyMotionData.lib_data);
                            textViewString_IDLE = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.SW_LIB_STR, 0, AppConfig.IDLE);
                            mLibImageView.setImageResource(imageViewResource_EVENT);
                            mLibImageView.setTag(imageViewResource_EVENT);
                            mLibDataTextView.setText(textViewString_EVENT);
                            if (mLibTimer != null) {
                                mLibTimer.cancel();
                            }
                            mLibTimer = new MyCountDownTimer(1000, imageView, imageViewResource_IDLE, textView, textViewString_IDLE);
                            mLibTimer.start();
                            DemoFragment.getInstance().addEventToCardEvent(textViewString_EVENT);
                            break;
                        default:
                            break;
                    }
                    MyMotionData.lib_data = 0;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

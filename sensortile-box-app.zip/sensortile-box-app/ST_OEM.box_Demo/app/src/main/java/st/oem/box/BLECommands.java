package st.oem.box;

import static st.oem.services.ble.BluetoothLeService.INTENT_BLE_FILTER;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_AUDIO_OFF;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_AUDIO_ON;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_BLE_LOG_START;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_BLE_LOG_START_HIGH_RATE;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_BLE_LOG_STOP;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_BLE_START;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_BLE_STOP;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_CLEAR_CLASS;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_CLEAR_DEMO;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_CLEAR_USER;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_DEVICE_CONFIG;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_GENERIC_COMMAND;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_GET_BATTERY_LEVEL;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_GET_STATUS;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_JSON_ENTRY;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_JSON_RESET;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_LIB_CONFIG;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_RAM_WRITE;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_RESET_DEVICE_CONFIG;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SD_START;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SD_STOP;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_BUZ_MASK;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_CLASS;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_DEMO;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_FSYNC;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_LED_MASK;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_MASS_STORAGE_OFF;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_MASS_STORAGE_ON;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_NODE_NAME;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_RTC_DATE;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_SET_USER;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_WRITE_LPS22HH;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_WRITE_LSM6DSOX;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_ZIP_DECOMPRESS;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_ZIP_SIZE;
import static st.oem.services.ble.BluetoothLeService.MESSAGE_ID_SEND_AFE_MUX_CONFIG;

import android.content.Context;
import android.content.Intent;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import st.oem.R;

public class BLECommands
{
    private final static String LOG_TAG = BLECommands.class.getSimpleName();

    public static void sendRamConfig(Context ctx, String ramAddress, String ramValue) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_RAM_WRITE_String = ctx.getString(R.string.INTENT_EXTRA_KEY_RAM_WRITE);

        String params;

        params = " " + ramAddress + " " + ramValue;

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_RAM_WRITE);
        intent.putExtra(EXTRA_KEY_RAM_WRITE_String, params);
        ctx.sendBroadcast(intent);
    }

    public static void sendLibConfig(Context ctx, Integer paramIndex, Double paramValue) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_LIB_CONFIG_String = ctx.getString(R.string.INTENT_EXTRA_KEY_LIB_CONFIG);

        DecimalFormat df = new DecimalFormat("0", DecimalFormatSymbols.getInstance(Locale.ENGLISH));
        df.setMaximumFractionDigits(340); // Equal to DecimalFormat.DOUBLE_FRACTION_DIGITS

        // The lib configuration command is:
        // *conf %d %f
        String params = " " + paramIndex + " " + df.format(paramValue);

        if (params.length() > 15)
            params = params.substring(1, 15);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_LIB_CONFIG);
        intent.putExtra(EXTRA_KEY_LIB_CONFIG_String, params);
        ctx.sendBroadcast(intent);
    }

    public static void sendSetLedMask(Context ctx, String ledMask) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_LED_MASK_String = ctx.getString(R.string.INTENT_EXTRA_KEY_LED_MASK);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_LED_MASK);
        intent.putExtra(EXTRA_KEY_LED_MASK_String, ledMask);
        ctx.sendBroadcast(intent);
    }

    public static void sendSetBuzMask(Context ctx, String buzMask) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_BUZ_MASK_String = ctx.getString(R.string.INTENT_EXTRA_KEY_BUZ_MASK);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_BUZ_MASK);
        intent.putExtra(EXTRA_KEY_BUZ_MASK_String, buzMask);
        ctx.sendBroadcast(intent);
    }

    public static void sendAudioOn(Context ctx) {

        if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1)
        {
            String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

            Intent intent = new Intent(INTENT_BLE_FILTER);
            intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_AUDIO_ON);
            ctx.sendBroadcast(intent);
        }
    }

    public static void sendAudioOff(Context ctx) {
        if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25 && ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1)
        {
            String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

            Intent intent = new Intent(INTENT_BLE_FILTER);
            intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_AUDIO_OFF);
            ctx.sendBroadcast(intent);
        }
    }

    public static void sendSdStartLog(Context ctx, String userStr, String demoStr, String classStr) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        sendSetFSync(ctx);

        sendSetRTCDate(ctx);

        if (userStr.equals(ctx.getString(R.string.empty_string)))
            sendClearUser(ctx);
        else
            sendSetUser(ctx, userStr);

        if (demoStr.equals(ctx.getString(R.string.empty_string)))
            sendClearDemo(ctx);
        else
            sendSetDemo(ctx, demoStr);

        if (classStr.equals(ctx.getString(R.string.empty_string)))
            sendClearClass(ctx);
        else
            sendSetClass(ctx, classStr);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SD_START);
        ctx.sendBroadcast(intent);
    }

    public static void sendSdStopLog(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SD_STOP);
        ctx.sendBroadcast(intent);
    }

    public static void sendBleLogStart(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_ACCEL_AXIS_String = ctx.getString(R.string.INTENT_EXTRA_KEY_ACCEL_AXIS);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        if (MyLogging.getBleLogHighRate())
        {
            intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_BLE_LOG_START_HIGH_RATE);
            intent.putExtra(EXTRA_KEY_ACCEL_AXIS_String, MyLogging.bleLogHighRateAccelAxis);
        }
        else
        {
            intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_BLE_LOG_START);
        }

        ctx.sendBroadcast(intent);
    }

    public static void sendBleLogStop(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_BLE_LOG_STOP);
        ctx.sendBroadcast(intent);
    }

    public static void sendBleStart(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_BLE_START);
        ctx.sendBroadcast(intent);
    }

    public static void sendBleStop(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_BLE_STOP);
        ctx.sendBroadcast(intent);
    }

    public static void sendResetDeviceConfiguration(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_RESET_DEVICE_CONFIG);
        ctx.sendBroadcast(intent);
    }

    public static void sendJsonReset(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_JSON_RESET);
        ctx.sendBroadcast(intent);
    }

    public static void sendJsonEntry(Context ctx, String type, int type_size, String label) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_JSON_TYPE_String = ctx.getString(R.string.INTENT_EXTRA_KEY_JSON_TYPE);
        String EXTRA_KEY_JSON_TYPE_SIZE_String = ctx.getString(R.string.INTENT_EXTRA_KEY_JSON_TYPE_SIZE);
        String EXTRA_KEY_JSON_LABEL_String = ctx.getString(R.string.INTENT_EXTRA_KEY_JSON_LABEL);

        String enumerator = String.valueOf(MyJson.getOutputTypeEnum(type));

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_JSON_ENTRY);
        intent.putExtra(EXTRA_KEY_JSON_TYPE_String, enumerator);
        intent.putExtra(EXTRA_KEY_JSON_TYPE_SIZE_String, "1");
        intent.putExtra(EXTRA_KEY_JSON_LABEL_String, label);
        ctx.sendBroadcast(intent);
    }

    public static void sendGenericCommand(Context ctx, String string) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_DEV_CONFIG_String = ctx.getString(R.string.INTENT_EXTRA_KEY_GENERIC_COMMAND);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_GENERIC_COMMAND);
        intent.putExtra(EXTRA_KEY_DEV_CONFIG_String, string);
        ctx.sendBroadcast(intent);
    }

    public static void sendDeviceConfiguration(Context ctx, byte[] bytes) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_DEV_CONFIG_String = ctx.getString(R.string.INTENT_EXTRA_KEY_DEV_CONFIG);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_DEVICE_CONFIG);
        intent.putExtra(EXTRA_KEY_DEV_CONFIG_String, bytes);
        ctx.sendBroadcast(intent);
    }

    public static void sendWriteLSM6DSOX(Context ctx, String add, String val) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_WRITE_LSM6DSOX_String = ctx.getString(R.string.INTENT_EXTRA_KEY_WRITE_LSM6DSOX);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_WRITE_LSM6DSOX);
        intent.putExtra(EXTRA_KEY_WRITE_LSM6DSOX_String, add + val);
        ctx.sendBroadcast(intent);
    }

    public static void sendWriteLPS22HH(Context ctx, String add, String val) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_WRITE_LPS22HH_String = ctx.getString(R.string.INTENT_EXTRA_KEY_WRITE_LPS22HH);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_WRITE_LPS22HH);
        intent.putExtra(EXTRA_KEY_WRITE_LPS22HH_String, add + val);
        ctx.sendBroadcast(intent);
    }

    public static void sendSetFSync(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_FSYNC_String = ctx.getString(R.string.INTENT_EXTRA_KEY_FSYNC);

        String params;
        // The fsync command is:
        // *fsync %d %d
        // *fsync 0 %d --> disabled
        // *fsync 1 %d --> enabled every %d seconds
        boolean fSyncEn = MySharedPreferences.getInstance(ctx).getFSyncEn();
        if (!fSyncEn)
            params = " 0 0";
        else {
            params = " 1 " + MySharedPreferences.getInstance(ctx).getFSyncVal();
        }

        if (params.length() > 14)
            params = params.substring(1, 14);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_FSYNC);
        intent.putExtra(EXTRA_KEY_FSYNC_String, params);
        ctx.sendBroadcast(intent);
    }

    private static void sendSetRTCDate(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_RTC_DATE_String = ctx.getString(R.string.INTENT_EXTRA_KEY_RTC_DATE);

        Date currentTime = Calendar.getInstance().getTime();
        String locale_str = ctx.getResources().getConfiguration().locale.getCountry();
        Locale locale = new Locale.Builder().setLanguageTag(locale_str).build();
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss", locale);
        String date = format.format(currentTime);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_RTC_DATE);
        intent.putExtra(EXTRA_KEY_RTC_DATE_String, date);
        ctx.sendBroadcast(intent);
    }

    private static void sendSetUser(Context ctx, String userStr) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_USER_String = ctx.getString(R.string.INTENT_EXTRA_KEY_USER);

        // The set user command is:
        // *user %s
        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_USER);
        intent.putExtra(EXTRA_KEY_USER_String, " " + userStr);
        ctx.sendBroadcast(intent);
    }

    private static void sendSetDemo(Context ctx, String demoStr) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_DEMO_String = ctx.getString(R.string.INTENT_EXTRA_KEY_DEMO);

        // The set demo command is:
        // *demo %s
        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_DEMO);
        intent.putExtra(EXTRA_KEY_DEMO_String, " " + demoStr);
        ctx.sendBroadcast(intent);
    }

    private static void sendSetClass(Context ctx, String classStr) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_CLASS_String = ctx.getString(R.string.INTENT_EXTRA_KEY_CLASS);

        // The set class command is:
        // *class %s
        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_CLASS);
        intent.putExtra(EXTRA_KEY_CLASS_String, " " + classStr);
        ctx.sendBroadcast(intent);
    }

    public static void sendSetNodeName(Context ctx, String nodeNameStr) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_NODE_NAME_String = ctx.getString(R.string.INTENT_EXTRA_KEY_NODE_NAME);

        // The set class command is:
        // *class %s
        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_NODE_NAME);
        intent.putExtra(EXTRA_KEY_NODE_NAME_String, " " + nodeNameStr);
        ctx.sendBroadcast(intent);
    }

    private static void sendClearUser(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_CLEAR_USER);
        ctx.sendBroadcast(intent);
    }

    private static void sendClearDemo(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_CLEAR_DEMO);
        ctx.sendBroadcast(intent);
    }

    private static void sendClearClass(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_CLEAR_CLASS);
        ctx.sendBroadcast(intent);
    }

    public static void sendSetMassStorageOn(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_MASS_STORAGE_ON);
        ctx.sendBroadcast(intent);
    }

    public static void sendSetMassStorageOff(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_SET_MASS_STORAGE_OFF);
        ctx.sendBroadcast(intent);
    }

    public static void sendGetBatteryLevel(Context ctx) {

        // Avoid sending *battery command when the Sunchon is streaming
        // data because the battery measurement is blocker
        if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) && DemoFragment.getInstance() != null)
            return;

        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_GET_BATTERY_LEVEL);
        ctx.sendBroadcast(intent);
    }

    public static void sendGetStatus(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_GET_STATUS);
        ctx.sendBroadcast(intent);
    }

    public static void sendZipSize(Context ctx, String zipSize) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_ZIP_SIZE_String = ctx.getString(R.string.INTENT_EXTRA_KEY_ZIP_SIZE);

        // The set class command is:
        // *class %s
        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_ZIP_SIZE);
        intent.putExtra(EXTRA_KEY_ZIP_SIZE_String, " " + zipSize);
        ctx.sendBroadcast(intent);
    }

    public static void sendZipDecompress(Context ctx) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_ZIP_DECOMPRESS);
        ctx.sendBroadcast(intent);
    }

    public static void sendAfeMux(Context ctx, int enabled, int n_channels) {
        String EXTRA_KEY_OP_ID_String = ctx.getString(R.string.INTENT_EXTRA_KEY_OP_ID);
        String EXTRA_KEY_AFE_MUX_ENABLED_String = ctx.getString(R.string.INTENT_EXTRA_KEY_AFE_MUX_ENABLED);
        String EXTRA_KEY_AFE_MUX_CHANNELS_String = ctx.getString(R.string.INTENT_EXTRA_KEY_AFE_MUX_CHANNELS);

        Intent intent = new Intent(INTENT_BLE_FILTER);
        intent.putExtra(EXTRA_KEY_OP_ID_String, MESSAGE_ID_SEND_AFE_MUX_CONFIG);
        intent.putExtra(EXTRA_KEY_AFE_MUX_ENABLED_String, enabled);
        intent.putExtra(EXTRA_KEY_AFE_MUX_CHANNELS_String, n_channels);
        ctx.sendBroadcast(intent);
    }
}
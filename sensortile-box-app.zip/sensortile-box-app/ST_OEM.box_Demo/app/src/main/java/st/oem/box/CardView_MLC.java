package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;

import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_MLC extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private LinearLayout[] mMlcLinearLayout = new LinearLayout[4];
    private TextView[] mMlcTitleTextView = new TextView[4];
    private ImageView[] mMlcImageView = new ImageView[4];
    private TextView[] mMlcDataTextView = new TextView[4];
    private LinearLayout[] mMlcLedLinearLayout = new LinearLayout[4];
    private SwitchCompat[] mMlcLedSwitchCompat = new SwitchCompat[4];
    private LinearLayout[] mMlcBuzLinearLayout = new LinearLayout[4];
    private SwitchCompat[] mMlcBuzSwitchCompat = new SwitchCompat[4];

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    // State
    private final static boolean[] mMlcLedSwitchCompatState = new boolean[4];
    private final static boolean[] mMlcBuzSwitchCompatState = new boolean[4];
    private final static String[] mMlcDataTextViewString = new String[4];
    private final static Integer[] mMlcImageViewResource = new Integer[4];

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_MLC_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mMlcLinearLayout = null;
        mMlcTitleTextView = null;
        mMlcImageView = null;
        mMlcDataTextView = null;
        mMlcLedLinearLayout = null;
        mMlcLedSwitchCompat = null;
        mMlcBuzLinearLayout = null;
        mMlcBuzSwitchCompat = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    public void saveState()
    {
        for (int i = 0; i < 4; i++)
        {
            try {
                mMlcLedSwitchCompatState[i] = mMlcLedSwitchCompat[i].isChecked();
            } catch(Exception ignored) { }

            try {
                mMlcBuzSwitchCompatState[i] = mMlcBuzSwitchCompat[i].isChecked();
            } catch(Exception ignored) { }

            try {
                mMlcImageViewResource[i] = (Integer)mMlcImageView[i].getTag();
            } catch(Exception ignored) { }

            try {
                mMlcDataTextViewString[i] = mMlcDataTextView[i].getText().toString();
            } catch(Exception ignored) { }
        }
    }

    public void restoreState()
    {
        for (int i = 0; i < 4; i++)
        {
            try {
                mMlcLedSwitchCompat[i].setChecked(mMlcLedSwitchCompatState[i]);
            } catch(Exception ignored) { }

            try {
                mMlcBuzSwitchCompat[i].setChecked(mMlcBuzSwitchCompatState[i]);
            } catch(Exception ignored) { }

            try {
                mMlcImageView[i].setImageResource(mMlcImageViewResource[i]);
                mMlcImageView[i].setTag(mMlcImageViewResource[i]);
            } catch(Exception ignored) { }

            try {
                mMlcDataTextView[i].setText(mMlcDataTextViewString[i]);
            } catch(Exception ignored) { }
        }
    }

    @SuppressLint("InflateParams")
    public CardView_MLC(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_mlc, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mMlcLinearLayout[0] = mMainLayout.findViewById(R.id.mlc0LinearLayout);
        mMlcTitleTextView[0] = mMainLayout.findViewById(R.id.mlc0TitleTextView);
        mMlcImageView[0] = mMainLayout.findViewById(R.id.mlc0ImageView);
        mMlcImageView[0].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mMlcDataTextView[0] = mMainLayout.findViewById(R.id.mlc0DataTextView);

        mMlcLinearLayout[1] = mMainLayout.findViewById(R.id.mlc1LinearLayout);
        mMlcTitleTextView[1] = mMainLayout.findViewById(R.id.mlc1TitleTextView);
        mMlcImageView[1] = mMainLayout.findViewById(R.id.mlc1ImageView);
        mMlcImageView[1].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mMlcDataTextView[1] = mMainLayout.findViewById(R.id.mlc1DataTextView);

        mMlcLinearLayout[2] = mMainLayout.findViewById(R.id.mlc2LinearLayout);
        mMlcTitleTextView[2] = mMainLayout.findViewById(R.id.mlc2TitleTextView);
        mMlcImageView[2] = mMainLayout.findViewById(R.id.mlc2ImageView);
        mMlcImageView[2].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mMlcDataTextView[2] = mMainLayout.findViewById(R.id.mlc2DataTextView);

        mMlcLinearLayout[3] = mMainLayout.findViewById(R.id.mlc3LinearLayout);
        mMlcTitleTextView[3] = mMainLayout.findViewById(R.id.mlc3TitleTextView);
        mMlcImageView[3] = mMainLayout.findViewById(R.id.mlc3ImageView);
        mMlcImageView[3].setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mMlcDataTextView[3] = mMainLayout.findViewById(R.id.mlc3DataTextView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        if (MyCtrlData.isLedSupported())
        {
            mMlcLedSwitchCompat[0] = mMainLayout.findViewById(R.id.mlcLed0SwitchCompat);
            mMlcLedSwitchCompat[1] = mMainLayout.findViewById(R.id.mlcLed1SwitchCompat);
            mMlcLedSwitchCompat[2] = mMainLayout.findViewById(R.id.mlcLed2SwitchCompat);
            mMlcLedSwitchCompat[3] = mMainLayout.findViewById(R.id.mlcLed3SwitchCompat);
            for(int j = 0; j < 4; j++)
            {
                final int k = j;
                mMlcLedSwitchCompat[j].setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
                {
                    if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                        if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                            if (b)
                                DemoFragment.getInstance().mlc_ledMask = (byte)(DemoFragment.getInstance().mlc_ledMask | (1 << k));
                            else
                                DemoFragment.getInstance().mlc_ledMask = (byte)(DemoFragment.getInstance().mlc_ledMask & (~(1 << k)));

                            DemoFragment.getInstance().prepareAndSendLedMask();
                        } else {
                            mMlcLedSwitchCompat[k].setChecked(!b);
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        mMlcLedSwitchCompat[k].setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            mMlcLedLinearLayout[0] = mMainLayout.findViewById(R.id.mlcLed0LinearLayout);
            mMlcLedLinearLayout[1] = mMainLayout.findViewById(R.id.mlcLed1LinearLayout);
            mMlcLedLinearLayout[2] = mMainLayout.findViewById(R.id.mlcLed2LinearLayout);
            mMlcLedLinearLayout[3] = mMainLayout.findViewById(R.id.mlcLed3LinearLayout);
            for (int i = 0; i < 4; i++) {
                mMlcLedLinearLayout[i].setVisibility(GONE);
            }
        }

        if (MyCtrlData.isBuzSupported())
        {
            mMlcBuzSwitchCompat[0] = mMainLayout.findViewById(R.id.mlcBuz0SwitchCompat);
            mMlcBuzSwitchCompat[1] = mMainLayout.findViewById(R.id.mlcBuz1SwitchCompat);
            mMlcBuzSwitchCompat[2] = mMainLayout.findViewById(R.id.mlcBuz2SwitchCompat);
            mMlcBuzSwitchCompat[3] = mMainLayout.findViewById(R.id.mlcBuz3SwitchCompat);
            for(int j = 0; j < 4; j++)
            {
                final int k = j;
                mMlcBuzSwitchCompat[j].setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
                {
                    if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                        if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                            if (b)
                                DemoFragment.getInstance().mlc_buzMask = (byte)(DemoFragment.getInstance().mlc_buzMask | (1 << k));
                            else
                                DemoFragment.getInstance().mlc_buzMask = (byte)(DemoFragment.getInstance().mlc_buzMask & (~(1 << k)));

                            DemoFragment.getInstance().prepareAndSendBuzMask();
                        } else {
                            mMlcBuzSwitchCompat[k].setChecked(!b);
                            Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        mMlcBuzSwitchCompat[k].setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        } else {
            mMlcBuzLinearLayout[0] = mMainLayout.findViewById(R.id.mlcBuz0LinearLayout);
            mMlcBuzLinearLayout[1] = mMainLayout.findViewById(R.id.mlcBuz1LinearLayout);
            mMlcBuzLinearLayout[2] = mMainLayout.findViewById(R.id.mlcBuz2LinearLayout);
            mMlcBuzLinearLayout[3] = mMainLayout.findViewById(R.id.mlcBuz3LinearLayout);
            for (int i = 0; i < 4; i++) {
                mMlcBuzLinearLayout[i].setVisibility(GONE);
            }
        }

        // Manage layouts
        float screenDensity = getResources().getDisplayMetrics().density;
        if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_MLC() == 1) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_1) / screenDensity;
            mMlcTitleTextView[0].setTextSize(textSize);
            mMlcTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 0));
            mMlcDataTextView[0].setTextSize(textSize);
            mMlcLinearLayout[1].setVisibility(View.GONE);
            mMlcLinearLayout[2].setVisibility(View.GONE);
            mMlcLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_MLC() == 2) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_2) / screenDensity;
            mMlcTitleTextView[0].setTextSize(textSize);
            mMlcTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 0));
            mMlcDataTextView[0].setTextSize(textSize);
            mMlcTitleTextView[1].setTextSize(textSize);
            mMlcTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 1));
            mMlcDataTextView[1].setTextSize(textSize);
            mMlcLinearLayout[2].setVisibility(View.GONE);
            mMlcLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_MLC() == 3) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_3) / screenDensity;
            mMlcTitleTextView[0].setTextSize(textSize);
            mMlcTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 0));
            mMlcDataTextView[0].setTextSize(textSize);
            mMlcTitleTextView[1].setTextSize(textSize);
            mMlcTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 1));
            mMlcDataTextView[1].setTextSize(textSize);
            mMlcTitleTextView[2].setTextSize(textSize);
            mMlcTitleTextView[2].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 2));
            mMlcDataTextView[2].setTextSize(textSize);
            mMlcLinearLayout[3].setVisibility(View.GONE);
        }
        else if (DemoFragment.getInstance().getSelectedDemo().getNumberOf_MLC() == 4) {
            float textSize = getResources().getDimension(R.dimen.single_demo_textsize_3) / screenDensity;
            mMlcTitleTextView[0].setTextSize(textSize);
            mMlcTitleTextView[0].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 0));
            mMlcDataTextView[0].setTextSize(textSize);
            mMlcTitleTextView[1].setTextSize(textSize);
            mMlcTitleTextView[1].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 1));
            mMlcDataTextView[1].setTextSize(textSize);
            mMlcTitleTextView[2].setTextSize(textSize);
            mMlcTitleTextView[2].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 2));
            mMlcDataTextView[2].setTextSize(textSize);
            mMlcTitleTextView[3].setTextSize(textSize);
            mMlcTitleTextView[3].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.MACHINE_LEARNING_CORE_STR, 3));
            mMlcDataTextView[3].setTextSize(textSize);
        }

        // Initialize UI
        MyMotionData.mlc = 0;
        for(int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_MLC(); i++) {
            MyMotionData.mlc_src[i] = 0;
            mMlcImageView[i].setImageResource(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.MACHINE_LEARNING_CORE_STR, i, MyMotionData.mlc_src[i]));
            mMlcImageView[i].setTag(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.MACHINE_LEARNING_CORE_STR, i, MyMotionData.mlc_src[i]));
            mMlcDataTextView[i].setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.MACHINE_LEARNING_CORE_STR, i, MyMotionData.mlc_src[i]));
        }
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyMotionData.mlc > 0) {
                    for(int i = 0; i < DemoFragment.getInstance().getSelectedDemo().getNumberOf_MLC(); i++) {
                        if (MyMotionData.getBit(MyMotionData.mlc, i)) {
                            int imageId = DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.MACHINE_LEARNING_CORE_STR, i, MyMotionData.mlc_src[i]);
                            String output = DemoFragment.getInstance().getSelectedDemo().getSingleDemoString(AppConfig.MACHINE_LEARNING_CORE_STR, i, MyMotionData.mlc_src[i]);
                            mMlcImageView[i].setImageResource(imageId);
                            mMlcImageView[i].setTag(imageId);
                            mMlcDataTextView[i].setText(output);
                            DemoFragment.getInstance().addEventToCardEvent(output);
                        }
                    }
                    MyMotionData.mlc = 0;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;

@SuppressLint("ViewConstructor")
public class CardView_FALL_HEIGHT_ESTIMATION extends CardView {

    private final float GRAVITY = 9.80665f;
    private final float M_TO_CM = 100.0f;

    private TextView mLcValueTextView;
    private TextView mHeightValueTextView;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    private float delta_time_s;
    private int ff_duration_samples;
    private float extra_time_s;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_FALL_HEIGHT_ESTIMATION_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mLcValueTextView = null;
        mHeightValueTextView = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_FALL_HEIGHT_ESTIMATION(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_fall_height_estimation, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mLcValueTextView = mMainLayout.findViewById(R.id.lcValueTextView);
        mHeightValueTextView = mMainLayout.findViewById(R.id.heightValueTextView);

        switch (MyCtrlData.device)
        {
            case MyCtrlData.DEVICE_LIS2DUXS12:
                delta_time_s = 1.0f / 400.0f;
                ff_duration_samples = 0x28 - 0x08;
                extra_time_s = 0.025f;
                break;
            case MyCtrlData.DEVICE_LSM6DSV16X:
            case MyCtrlData.DEVICE_LSM6DSV32X:
                delta_time_s = 1.0f / 480.0f;
                ff_duration_samples = 0x30 - 0x09;
                extra_time_s = 0.025f;
                break;
            default:
                break;
        }
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyMotionData.lc > 1)
                {
                    String lc_str, height_str;

                    lc_str = String.format(Locale.getDefault(), "%d", MyMotionData.lc);
                    mLcValueTextView.setText(lc_str);

                    int lc_comp = MyMotionData.lc + ff_duration_samples;
                    float height_cm = (M_TO_CM * 0.5f * GRAVITY * (lc_comp * delta_time_s + extra_time_s) * (lc_comp * delta_time_s + extra_time_s));
                    height_str = String.format(Locale.getDefault(), "%.1f", height_cm);
                    mHeightValueTextView.setText(height_str);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

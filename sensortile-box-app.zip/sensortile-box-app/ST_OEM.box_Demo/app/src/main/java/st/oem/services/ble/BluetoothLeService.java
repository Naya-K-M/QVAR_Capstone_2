/*
 * Copyright (C) 2013 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package st.oem.services.ble;

import static android.bluetooth.BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import st.oem.R;
import st.oem.box.BLECommands;
import st.oem.box.CardView_ISPU;
import st.oem.box.CardView_UNSUPERVISED_ODL;
import st.oem.box.CardView_BLE_STREAM;
import st.oem.box.CardView_QUATERNIONS;
import st.oem.box.DemoFragment;
import st.oem.box.DemoListFragment;
import st.oem.box.MyCtrlData;
import st.oem.box.MyLogging;
import st.oem.box.MyMotionData;
import st.oem.box.MySharedPreferences;
import st.oem.box.MyStreamData;
import st.oem.box.MyTiming;

/**
 * Service for managing connection and data communication with a GATT server hosted on a
 * given Bluetooth LE device.
 */
public class BluetoothLeService extends Service {
    private final static String LOG_TAG = BluetoothLeService.class.getSimpleName();

    public static final String INTENT_BLE_FILTER = "INTENT_FILTER_BLE";

    public static final int MESSAGE_ID_SEND_SD_START = 1;
    public static final int MESSAGE_ID_SEND_SD_STOP = 2;
    public static final int MESSAGE_ID_SEND_RESET_DEVICE_CONFIG = 3;
    public static final int MESSAGE_ID_SEND_DEVICE_CONFIG = 4;
    public static final int MESSAGE_ID_SEND_SET_RTC_DATE = 5;
    public static final int MESSAGE_ID_SEND_SET_LED_MASK = 6;
    public static final int MESSAGE_ID_SEND_GET_BATTERY_LEVEL = 7;
    public static final int MESSAGE_ID_SEND_SET_MASS_STORAGE_ON = 8;
    public static final int MESSAGE_ID_SEND_SET_MASS_STORAGE_OFF = 9;
    public static final int MESSAGE_ID_SEND_RAM_WRITE = 10;
    public static final int MESSAGE_ID_SEND_AUDIO_ON = 11;
    public static final int MESSAGE_ID_SEND_AUDIO_OFF = 12;
    public static final int MESSAGE_ID_SEND_LIB_CONFIG = 13;
    public static final int MESSAGE_ID_SEND_SET_USER = 14;
    public static final int MESSAGE_ID_SEND_SET_DEMO = 15;
    public static final int MESSAGE_ID_SEND_SET_CLASS = 16;
    public static final int MESSAGE_ID_SEND_WRITE_LSM6DSOX = 17;
    public static final int MESSAGE_ID_SEND_WRITE_LPS22HH = 18;
    public static final int MESSAGE_ID_SEND_CLEAR_USER = 19;
    public static final int MESSAGE_ID_SEND_CLEAR_DEMO = 20;
    public static final int MESSAGE_ID_SEND_CLEAR_CLASS = 21;
    public static final int MESSAGE_ID_SEND_GET_STATUS = 22;
    public static final int MESSAGE_ID_SEND_SET_FSYNC = 23;
    public static final int MESSAGE_ID_SEND_SET_NODE_NAME = 24;
    public static final int MESSAGE_ID_SEND_CLEAR_NODE_NAME = 25;
    public static final int MESSAGE_ID_SEND_BLE_START = 26;
    public static final int MESSAGE_ID_SEND_BLE_STOP = 27;
    public static final int MESSAGE_ID_SEND_BLE_LOG_START = 28;
    public static final int MESSAGE_ID_SEND_BLE_LOG_STOP = 29;
    public static final int MESSAGE_ID_SEND_BLE_LOG_START_HIGH_RATE = 30;
    public static final int MESSAGE_ID_SEND_ZIP_SIZE = 31;
    public static final int MESSAGE_ID_SEND_ZIP_DECOMPRESS = 32;
    public static final int MESSAGE_ID_SEND_JSON_ENTRY = 33;
    public static final int MESSAGE_ID_SEND_JSON_RESET = 34;
    public static final int MESSAGE_ID_SEND_SET_BUZ_MASK = 35;
    public static final int MESSAGE_ID_SEND_GENERIC_COMMAND = 36;
    public static final int MESSAGE_ID_SEND_AFE_MUX_CONFIG = 37;

    public static final int STATE_DISCONNECTED = BluetoothProfile.STATE_DISCONNECTED;
    public static final int STATE_CONNECTING = BluetoothProfile.STATE_CONNECTING;
    public static final int STATE_CONNECTED = BluetoothProfile.STATE_CONNECTED;
    public static final int STATE_DISCONNECTING = BluetoothProfile.STATE_DISCONNECTING;

    public static int mSupportedPacketLength;

    private BluetoothManager mBluetoothManager;
    private BluetoothAdapter mBluetoothAdapter;
    private String mBluetoothDeviceAddress;
    private BluetoothGatt mBluetoothGatt;
    public static int mConnectionState;
    public static boolean mFirstCtrlPacketReceived;

    // Semaphore
    private Integer connectionLock = 0;


    private BluetoothGattCharacteristic commCharacteristic;
    private BluetoothGattCharacteristic ctrlCharacteristic;
    private BluetoothGattCharacteristic motionCharacteristic;
    private BluetoothGattCharacteristic streamCharacteristic;

    private int ctrlCharacteristicNotifyStatus;
    private int motionCharacteristicNotifyStatus;
    private int streamCharacteristicNotifyStatus;

    // Command queue and thread
    private static class Command {
        String comm_str;
        byte[] comm_bytes;
        int type;   // 0 string, 1 byte[]
    }
    private final ArrayList<Command> commQueue = new ArrayList<>();
    private int commQueueAttempts;
    private final Handler commHandler = new Handler();
    private boolean commRunnableStarted = false;

    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }


    private final Runnable commRunnable = new Runnable() {
        @Override
        public void run() {
            commRunnableStarted = true;

            if (!commQueue.isEmpty()) {
                if (commCharacteristic != null) {
                    commCharacteristic.setWriteType(WRITE_TYPE_NO_RESPONSE);

                    Command comm = commQueue.get(0);
                    if (comm.type == 0) {  // String
                        commCharacteristic.setValue(comm.comm_str);
                    } else {    // byte[]
                        commCharacteristic.setValue(comm.comm_bytes);
                    }

                    if (mBluetoothGatt.writeCharacteristic(commCharacteristic)) {
                        if (comm.type == 0) {  // String
                            Log.d(LOG_TAG, "Sent command success: " + comm.comm_str);
                        } else {    // byte[]
                            Log.d(LOG_TAG, "Sent command success: " + bytesToHex(comm.comm_bytes));

                            // Handle packet sent for progress bar
                            if (DemoFragment.getInstance().mProgressDialog != null) {
                                if ((comm.comm_bytes[0] == '*' && comm.comm_bytes[1] == 'b' && comm.comm_bytes[2] == 'i' && comm.comm_bytes[3] == 'n') ||
                                    (comm.comm_bytes[0] == '*' && comm.comm_bytes[1] == 'z' && comm.comm_bytes[2] == 'i' && comm.comm_bytes[3] == 'p')) {
                                    int confBytesSent_old = DemoFragment.getInstance().mConfBytesSent;
                                    int confBytesSent_new = confBytesSent_old + (mSupportedPacketLength - 4);
                                    DemoFragment.getInstance().mConfBytesSent = confBytesSent_new;
                                    DemoFragment.getInstance().progressBarNotify();
                                }
                            }
                        }

                        commQueue.remove(0);
                        commQueueAttempts = 0;
                    } else {
                        commQueueAttempts++;
                        if (commQueueAttempts <= 10) {
                            if (comm.type == 0) {  // String
                                Log.e(LOG_TAG, "Sent command fail, try again: " + comm.comm_str);
                            } else {    // byte[]
                                Log.e(LOG_TAG, "Sent command fail, try again: " + Arrays.toString(comm.comm_bytes));
                            }
                        } else {
                            Log.e(LOG_TAG, "Sent command fail, discarded");
                            commQueue.remove(0);
                        }
                    }
                }
            }

            commHandler.postDelayed(this, MyTiming.getSleepTimeBetweenCommands());
        }
    };

    private final BroadcastReceiver mBleSendCommandReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

            // Start the initial runnable task by posting through the handler
            if (!commRunnableStarted)
                commHandler.post(commRunnable);

            if (commCharacteristic != null) {
                commCharacteristic.setWriteType(WRITE_TYPE_NO_RESPONSE);

                Bundle bundle = intent.getExtras();
                Command command = new Command();

                int operationId = 0;
                if (bundle != null) {
                    operationId = bundle.getInt(getString(R.string.INTENT_EXTRA_KEY_OP_ID));
                }
                switch (operationId) {
                    case MESSAGE_ID_SEND_SD_START:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_SD_START);
                        break;

                    case MESSAGE_ID_SEND_SD_STOP:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_SD_STOP);
                        break;

                    case MESSAGE_ID_SEND_BLE_START:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_BLE_START);
                        break;

                    case MESSAGE_ID_SEND_BLE_STOP:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_BLE_STOP);
                        break;

                    case MESSAGE_ID_SEND_BLE_LOG_START:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_BLE_LOG_START);
                        break;

                    case MESSAGE_ID_SEND_BLE_LOG_STOP:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_BLE_LOG_STOP);
                        break;

                    case MESSAGE_ID_SEND_BLE_LOG_START_HIGH_RATE:
                        command.type = 0;
                        String accelAxis = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_ACCEL_AXIS));
                        command.comm_str = getString(R.string.CMD_BLE_LOG_START_HIGH_RATE) + accelAxis;
                        break;

                    case MESSAGE_ID_SEND_ZIP_SIZE:
                        command.type = 0;
                        String zipSize = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_ZIP_SIZE));
                        command.comm_str = getString(R.string.CMD_ZIP_SIZE) + zipSize;
                        break;

                    case MESSAGE_ID_SEND_ZIP_DECOMPRESS:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_ZIP_DECOMPRESS);
                        break;

                    case MESSAGE_ID_SEND_RESET_DEVICE_CONFIG:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_RESET_DEVICE_CONFIG);
                        break;

                    case MESSAGE_ID_SEND_DEVICE_CONFIG:
                        // it supports both *bin and *zip commands, which are set into the
                        // loadDeviceConfiguration() and loadDeviceConfiguration_ZIP() functions
                        command.type = 1;
                        command.comm_bytes = bundle.getByteArray(getString(R.string.INTENT_EXTRA_KEY_DEV_CONFIG));
                        break;

                    case MESSAGE_ID_SEND_WRITE_LSM6DSOX:
                        command.type = 0;
                        String lsm6dsox_add_val = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_WRITE_LSM6DSOX));
                        command.comm_str = getString(R.string.CMD_SET_WRITE_LSM6DSOX) + lsm6dsox_add_val;
                        break;

                    case MESSAGE_ID_SEND_WRITE_LPS22HH:
                        command.type = 0;
                        String lps22hh_add_val = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_WRITE_LPS22HH));
                        command.comm_str = getString(R.string.CMD_SET_WRITE_LPS22HH) + lps22hh_add_val;
                        break;

                    case MESSAGE_ID_SEND_SET_LED_MASK:
                        command.type = 0;
                        String ledMask = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_LED_MASK));
                        command.comm_str = getString(R.string.CMD_SET_LED_MASK) + ledMask;
                        break;

                    case MESSAGE_ID_SEND_AUDIO_ON:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_SET_AUDIO_ON);
                        break;

                    case MESSAGE_ID_SEND_AUDIO_OFF:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_SET_AUDIO_OFF);
                        break;

                    case MESSAGE_ID_SEND_RAM_WRITE:
                        command.type = 0;
                        String params_ram_write = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_RAM_WRITE));
                        command.comm_str = getString(R.string.CMD_RAM_WRITE) + params_ram_write;
                        break;

                    case MESSAGE_ID_SEND_LIB_CONFIG:
                        command.type = 0;
                        String params_lib_config = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_LIB_CONFIG));
                        command.comm_str = getString(R.string.CMD_LIB_CONFIG) + params_lib_config;
                        break;

                    case MESSAGE_ID_SEND_SET_RTC_DATE:
                        command.type = 0;
                        String date = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_RTC_DATE));
                        command.comm_str = getString(R.string.CMD_SET_RTC_DATE) + date;
                        break;

                    case MESSAGE_ID_SEND_SET_USER:
                        command.type = 0;
                        String user = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_USER));
                        command.comm_str = getString(R.string.CMD_SET_USER) + user;
                        break;

                    case MESSAGE_ID_SEND_SET_DEMO:
                        command.type = 0;
                        String demo = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_DEMO));
                        command.comm_str = getString(R.string.CMD_SET_DEMO) + demo;
                        break;

                    case MESSAGE_ID_SEND_SET_CLASS:
                        command.type = 0;
                        String classStr = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_CLASS));
                        command.comm_str = getString(R.string.CMD_SET_CLASS) + classStr;
                        break;

                    case MESSAGE_ID_SEND_SET_NODE_NAME:
                        command.type = 0;
                        String nodeNameStr = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_NODE_NAME));
                        command.comm_str = getString(R.string.CMD_SET_NODE_NAME) + nodeNameStr;
                        break;

                    case MESSAGE_ID_SEND_SET_FSYNC:
                        command.type = 0;
                        String fsync = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_FSYNC));
                        command.comm_str = getString(R.string.CMD_SET_FSYNC) + fsync;
                        break;

                    case MESSAGE_ID_SEND_GET_BATTERY_LEVEL:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_GET_BATTERY_LEVEL);
                        break;

                    case MESSAGE_ID_SEND_GET_STATUS:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_GET_STATUS);
                        break;

                    case MESSAGE_ID_SEND_SET_MASS_STORAGE_ON:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_SET_MASS_STORAGE_ON);
                        break;

                    case MESSAGE_ID_SEND_SET_MASS_STORAGE_OFF:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_SET_MASS_STORAGE_OFF);
                        break;

                    case MESSAGE_ID_SEND_CLEAR_USER:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_CLEAR_USER);
                        break;

                    case MESSAGE_ID_SEND_CLEAR_DEMO:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_CLEAR_DEMO);
                        break;

                    case MESSAGE_ID_SEND_CLEAR_CLASS:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_CLEAR_CLASS);
                        break;

                    case MESSAGE_ID_SEND_JSON_ENTRY:
                        command.type = 0;
                        String enumerator = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_JSON_TYPE));
                        String type_size = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_JSON_TYPE_SIZE));
                        String label = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_JSON_LABEL));
                        command.comm_str = getString(R.string.CMD_JSON_ENTRY) + " " + enumerator + " " + type_size + " " + label;
                        break;

                    case MESSAGE_ID_SEND_JSON_RESET:
                        command.type = 0;
                        command.comm_str = getString(R.string.CMD_JSON_RESET);
                        break;

                    case MESSAGE_ID_SEND_SET_BUZ_MASK:
                        command.type = 0;
                        String buzMask = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_BUZ_MASK));
                        command.comm_str = getString(R.string.CMD_SET_BUZ_MASK) + buzMask;
                        break;

                    case MESSAGE_ID_SEND_GENERIC_COMMAND:
                        command.type = 0;
                        command.comm_str = bundle.getString(getString(R.string.INTENT_EXTRA_KEY_GENERIC_COMMAND));
                        break;

                    case MESSAGE_ID_SEND_AFE_MUX_CONFIG:
                        command.type = 0;
                        int enabled = bundle.getInt(getString(R.string.INTENT_EXTRA_KEY_AFE_MUX_ENABLED));
                        int channels = bundle.getInt(getString(R.string.INTENT_EXTRA_KEY_AFE_MUX_CHANNELS));
                        command.comm_str = getString(R.string.CMD_AFE_MUX) + " " + enabled + " " + channels;
                        break;

                    default:
                        Log.e(LOG_TAG, "operation ID not valid");
                        break;
                }

                commQueue.add(command);
            }
        }
    };

    public class LocalBinder extends Binder {
        public BluetoothLeService getService() {
            return BluetoothLeService.this;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        // After using a given device, you should make sure that BluetoothGatt.close() is called
        // such that resources are cleaned up properly.  In this particular example, close() is
        // invoked when the UI is disconnected from the Service.
        close();
        return super.onUnbind(intent);
    }

    private final IBinder mBinder = new LocalBinder();

    /**
     * Initializes a reference to the local Bluetooth adapter.
     *
     * @return Return true if the initialization is successful.
     */
    public boolean initialize() {
        // For API level 18 and above, get a reference to BluetoothAdapter through
        // BluetoothManager.
        if (mBluetoothManager == null) {
            mBluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
            if (mBluetoothManager == null) {
                Log.e(LOG_TAG, "Unable to initialize BluetoothManager.");
                return false;
            }
        }

        mBluetoothAdapter = mBluetoothManager.getAdapter();
        if (mBluetoothAdapter == null) {
            Log.e(LOG_TAG, "Unable to obtain a BluetoothAdapter.");
            return false;
        }

        return true;
    }

    /**
     * Connects to the GATT server hosted on the Bluetooth LE device.
     *
     * @param address The device address of the destination device.
     *
     * @return Return true if the connection is initiated successfully. The connection result
     *         is reported asynchronously through the
     *         {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     *         callback.
     */
    public boolean connect(final String address) {
        if (mBluetoothAdapter == null || address == null) {
            Log.w(LOG_TAG, "BluetoothAdapter not initialized or unspecified address.");
            return false;
        }

        // Previously connected device.  Try to reconnect.
        if (address.equals(mBluetoothDeviceAddress) && mBluetoothGatt != null) {
            Log.d(LOG_TAG, "Trying to use an existing mBluetoothGatt for connection.");
            if (mBluetoothGatt.connect()) {
                //mConnectionState = STATE_CONNECTING;
                return true;
            } else {
                return false;
            }
        }

        final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        if (device == null) {
            Log.w(LOG_TAG, "Device not found.  Unable to connect.");
            return false;
        }
        // We want to directly connect to the device, so we are setting the autoConnect
        // parameter to false.
        boolean autoConnectRuntime =  MySharedPreferences.getInstance(this).getAutoConnectRuntime();
        mBluetoothGatt = device.connectGatt(this, autoConnectRuntime, mGattCallback);
        Log.d(LOG_TAG, "Trying to create a new connection.");
        mBluetoothDeviceAddress = address;
        //mConnectionState = STATE_CONNECTING;

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(INTENT_BLE_FILTER);
        registerReceiver(mBleSendCommandReceiver, intentFilter);

        return true;
    }

    /**
     * After using a given BLE device, the app must call this method to ensure resources are
     * released properly.
     */
    public void close() {
        if (mBluetoothGatt == null) {
            return;
        }
        mBluetoothGatt.close();
        mBluetoothGatt = null;
    }

    /**
     * Enables or disables notification on a give characteristic.
     *
     * @param characteristic Characteristic to act on.
     * @param enabled If true, enable notification.  False otherwise.
     */
    public void setCharacteristicNotification(BluetoothGattCharacteristic characteristic,
                                              boolean enabled) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(LOG_TAG, "BluetoothAdapter not initialized");
            return;
        }

        mBluetoothGatt.setCharacteristicNotification(characteristic, enabled);

        // This is specific to Heart Rate Measurement.
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(UUID.fromString(getString(R.string.CLIENT_CHARACTERISTIC_CONFIG)));
        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
        mBluetoothGatt.writeDescriptor(descriptor);
    }

    /**
     * Disconnects an existing connection or cancel a pending connection. The disconnection result
     * is reported asynchronously through the
     * {@code BluetoothGattCallback#onConnectionStateChange(android.bluetooth.BluetoothGatt, int, int)}
     * callback.
     */
    public void disconnect() {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(LOG_TAG, "BluetoothAdapter not initialized");
            return;
        }

        unregisterReceiver(mBleSendCommandReceiver);

        mBluetoothGatt.disconnect();
    }

    /**
     * Request a read on a given {@code BluetoothGattCharacteristic}. The read result is reported
     * asynchronously through the {@code BluetoothGattCallback#onCharacteristicRead(android.bluetooth.BluetoothGatt, android.bluetooth.BluetoothGattCharacteristic, int)}
     * callback.
     *
     * @param characteristic The characteristic to read from.
     */
    public void readCharacteristic(BluetoothGattCharacteristic characteristic) {
        if (mBluetoothAdapter == null || mBluetoothGatt == null) {
            Log.w(LOG_TAG, "BluetoothAdapter not initialized");
            return;
        }
        mBluetoothGatt.readCharacteristic(characteristic);
    }

    /**
     * Retrieves a list of supported GATT services on the connected device. This should be
     * invoked only after {@code BluetoothGatt#discoverServices()} completes successfully.
     *
     * @return A {@code List} of supported services.
     */
    public List<BluetoothGattService> getSupportedGattServices() {
        if (mBluetoothGatt == null) return null;

        return mBluetoothGatt.getServices();
    }

    private void connectionWait() {
        synchronized (connectionLock) {
            try {
                Log.d(LOG_TAG, "connectionLock: WAIT");
                connectionLock.wait(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private void connectionNotify() {
        synchronized (connectionLock) {
            Log.d(LOG_TAG, "connectionLock: NOTIFY");
            connectionLock.notify();
        }
    }

    // Implements callback methods for GATT events that the app cares about.  For example,
    // connection change and services discovered.
    private final BluetoothGattCallback mGattCallback = new BluetoothGattCallback() {
        @Override
        public void onMtuChanged(BluetoothGatt gatt, int mtu, int status) {
            super.onMtuChanged(gatt, mtu, status);

            mSupportedPacketLength = mtu - 3;

            Log.d(LOG_TAG, "Requested MTU: " + mtu + ", packet length: " + mSupportedPacketLength + ", status: " + status);
        }

        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                mConnectionState = STATE_CONNECTED;
                mFirstCtrlPacketReceived = false;
                commQueue.clear();
                Log.i(LOG_TAG, "onConnectionStateChange: connected to GATT server.");
                Log.i(LOG_TAG, "Attempting to start service discovery");
                Log.d("TESTTEST", "CONNECTED");
                mBluetoothGatt.discoverServices();
            } else if (newState == STATE_CONNECTING) {
                mConnectionState = STATE_CONNECTING;
                mFirstCtrlPacketReceived = false;
                commQueue.clear();
                Log.i(LOG_TAG, "onConnectionStateChange: connecting to GATT server.");
                Log.d("TESTTEST", "CONNECTING");
            } else if (newState == STATE_DISCONNECTED) {
                mConnectionState = STATE_DISCONNECTED;
                mFirstCtrlPacketReceived = false;
                commQueue.clear();
                Log.i(LOG_TAG, "onConnectionStateChange: disconnected from GATT server.");
                Log.d("TESTTEST", "DISCONNECTED");
            } else if (newState == STATE_DISCONNECTING) {
                mConnectionState = STATE_DISCONNECTING;
                mFirstCtrlPacketReceived = false;
                commQueue.clear();
                Log.i(LOG_TAG, "onConnectionStateChange: disconnecting from GATT server.");
                Log.d("TESTTEST", "DISCONNECTING");
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                BluetoothGattService gattService = gatt.getService(UUID.fromString(getString(R.string.GATT_SENSORTILE_UUID_SERVICE)));
                if (gattService != null) {

                    new Thread() {
                        @Override
                        public void run() {
                            super.run();

                            Log.d("TESTTEST", "0");

                            commQueueAttempts = 0;
                            connectionLock = 0;

                            int nAttempt;
                            ctrlCharacteristicNotifyStatus = BluetoothGatt.GATT_FAILURE;
                            motionCharacteristicNotifyStatus = BluetoothGatt.GATT_FAILURE;
                            streamCharacteristicNotifyStatus = BluetoothGatt.GATT_FAILURE;
                            mFirstCtrlPacketReceived = false;
                            MyCtrlData.resetData();

                            commCharacteristic = gattService.getCharacteristic(UUID.fromString(getString(R.string.GATT_CHARACTERISTIC_UUID_COMM)));
                            ctrlCharacteristic = gattService.getCharacteristic(UUID.fromString(getString(R.string.GATT_CHARACTERISTIC_UUID_CTRL)));
                            motionCharacteristic = gattService.getCharacteristic(UUID.fromString(getString(R.string.GATT_CHARACTERISTIC_UUID_MOTION)));
                            streamCharacteristic = gattService.getCharacteristic(UUID.fromString(getString(R.string.GATT_CHARACTERISTIC_UUID_STREAM)));

                            Log.d("TESTTEST", "1");

                            nAttempt = 10;
                            do {
                                setCharacteristicNotification(ctrlCharacteristic, true);
                                connectionWait();
                                nAttempt--;
                            } while (ctrlCharacteristicNotifyStatus != BluetoothGatt.GATT_SUCCESS && nAttempt > 0);
                            if (ctrlCharacteristicNotifyStatus != BluetoothGatt.GATT_SUCCESS) {
                                Log.d(LOG_TAG, "Cannot enable CTRL characteristic notification");
                            }

                            Log.d("TESTTEST", "2");

                            nAttempt = 10;
                            do {
                                setCharacteristicNotification(motionCharacteristic, true);
                                connectionWait();
                                nAttempt--;
                            } while (motionCharacteristicNotifyStatus != BluetoothGatt.GATT_SUCCESS && nAttempt > 0);
                            if (motionCharacteristicNotifyStatus != BluetoothGatt.GATT_SUCCESS) {
                                Log.d(LOG_TAG, "Cannot enable MOTION characteristic notification");
                            }

                            Log.d("TESTTEST", "3");
                            try {
                                Thread.sleep(250);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }

                            nAttempt = 10;
                            do {
                                BLECommands.sendGetStatus(getBaseContext());   // Get both CTRL and MOTION chars
                                connectionWait();
                                nAttempt--;
                            } while (!mFirstCtrlPacketReceived && nAttempt > 0);
                            if (!mFirstCtrlPacketReceived) {
                                Log.d(LOG_TAG, "Cannot received first status packet");
                            }

                            Log.d("TESTTEST", "4");

                            nAttempt = 10;
                            do {
                                setCharacteristicNotification(streamCharacteristic, true);
                                connectionWait();
                                nAttempt--;
                            } while (streamCharacteristicNotifyStatus != BluetoothGatt.GATT_SUCCESS && nAttempt > 0);
                            if (streamCharacteristicNotifyStatus != BluetoothGatt.GATT_SUCCESS) {
                                Log.d(LOG_TAG, "Cannot enable STREAM characteristic notification");
                            }

                            Log.d("TESTTEST", "5");

                            // Request MTU
                            // TODO: for the future, move the requestMtu at the beginning in order to support CTRL char > 20 bytes
                            switch(MyCtrlData.board_id) {
                                case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                                    mBluetoothGatt.requestMtu(MyCtrlData.SENSORTILEBOX_SUWON25_PACKET_LENGTH + 3);
                                    break;
                                case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                                    mBluetoothGatt.requestMtu(MyCtrlData.TWSBOX_SWAN3_PACKET_LENGTH + 3);
                                    break;
                                case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                                    mBluetoothGatt.requestMtu(MyCtrlData.TWSBOX_SWAN3B_PACKET_LENGTH + 3);
                                    break;
                                case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON:
                                    mBluetoothGatt.requestMtu(MyCtrlData.SENSORTILEBOX_SUNCHON_PACKET_LENGTH + 3);
                                    break;
                                case MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO:
                                    mBluetoothGatt.requestMtu(MyCtrlData.SENSORTILEBOX_PRO_PACKET_LENGTH + 3);
                                    break;
                            }

                            Log.d("TESTTEST", "6");
                        }
                    }.start();
                }

            } else {
                Log.w(LOG_TAG, "onServicesDiscovered received: " + status);
            }
        }

        @Override
        public void onDescriptorWrite(BluetoothGatt gatt, BluetoothGattDescriptor descriptor, int status) {
            // TODO: is it required?
            //  super.onDescriptorWrite(gatt, descriptor, status);
            //Log.d(LOG_TAG, "onDescriptorWrite: " + descriptor);

            if (descriptor.getCharacteristic() == ctrlCharacteristic) {
                ctrlCharacteristicNotifyStatus = status;
                Log.d(LOG_TAG, "CTRL notification enabled");
            } else if (descriptor.getCharacteristic() == motionCharacteristic) {
                motionCharacteristicNotifyStatus = status;
                Log.d(LOG_TAG, "MOTION notification enabled");
            } else if (descriptor.getCharacteristic() == streamCharacteristic) {
                streamCharacteristicNotifyStatus = status;
                Log.d(LOG_TAG, "STREAM notification enabled");
            }

            connectionNotify();
        }

        @Override
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            //Log.d(LOG_TAG, "onCharacteristicRead: " + characteristic);
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt,
                                            BluetoothGattCharacteristic characteristic) {
            //Log.d(LOG_TAG, "onCharacteristicChanged: " + characteristic);

            byte[] data = characteristic.getValue();

            if (characteristic == ctrlCharacteristic) {
                parseCtrlPacket(data);
            } else if (characteristic == motionCharacteristic) {
                parseMotionPacket(data);
            } else if (characteristic == streamCharacteristic) {
                parseStreamPacket(data);
            }
        }
    };

    private void parseMotionPacket(byte[] data) {
        //Log.d(LOG_TAG, "Received new MOTION packet");

        ByteBuffer bb = ByteBuffer.wrap(data);
        bb.order(ByteOrder.LITTLE_ENDIAN);

        if ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS)))
        {
            MyMotionData.ispu_dout = bb;
            CardView_ISPU.mIspuPacketReceived = true;
            CardView_UNSUPERVISED_ODL.mIspuPacketReceived = true;
        }
        else
        {
            MyMotionData.fsm = bb.get(0);
            MyMotionData.fsm_outs[0] = bb.get(1);
            MyMotionData.fsm_outs[1] = bb.get(2);
            MyMotionData.fsm_outs[2] = bb.get(3);
            MyMotionData.fsm_outs[3] = bb.get(4);

            MyMotionData.mlc = bb.get(5);
            MyMotionData.mlc_src[0] = bb.get(6);
            MyMotionData.mlc_src[1] = bb.get(7);
            MyMotionData.mlc_src[2] = bb.get(8);
            MyMotionData.mlc_src[3] = bb.get(9);

            MyMotionData.steps = bb.getShort(10);
            MyMotionData.hw_int = bb.get(12);
            MyMotionData.emb_func_status = bb.get(13);
            MyMotionData.lib_data = bb.getShort(14);
            MyMotionData.lc = bb.getShort(16);

            MyMotionData.all_int = bb.get(18);
            MyMotionData.reserved = bb.get(19);   // only for padding

            MyMotionData.quat[0] = bb.getFloat(20);
            MyMotionData.quat[1] = bb.getFloat(24);
            MyMotionData.quat[2] = bb.getFloat(28);
            MyMotionData.quat[3] = bb.getFloat(32);
            MyMotionData.gravity[0] = bb.getShort(36);
            MyMotionData.gravity[1] = bb.getShort(38);
            MyMotionData.gravity[2] = bb.getShort(40);
            MyMotionData.gbias[0] = bb.getShort(42);
            MyMotionData.gbias[1] = bb.getShort(44);
            MyMotionData.gbias[2] = bb.getShort(46);

            DemoFragment.getInstance().applyRotationToQuaternionCard(MyMotionData.quat[0], MyMotionData.quat[1], MyMotionData.quat[2], MyMotionData.quat[3]);

            Log.d("PACKET", "MOTION\tfsm:\t" + MyMotionData.fsm);
            Log.d("PACKET", "MOTION\tfsm_outs:\t" + MyMotionData.fsm_outs[0] + "\t" + MyMotionData.fsm_outs[1] + "\t" + MyMotionData.fsm_outs[2] + "\t" + MyMotionData.fsm_outs[3]);
            Log.d("PACKET", "MOTION\tmlc:\t" + MyMotionData.mlc);
            Log.d("PACKET", "MOTION\tmlc_outs:\t" + MyMotionData.mlc_src[0] + "\t" + MyMotionData.mlc_src[1] + "\t" + MyMotionData.mlc_src[2] + "\t" + MyMotionData.mlc_src[3]);
            Log.d("PACKET", "MOTION\tsteps:\t" + MyMotionData.steps);
            Log.d("PACKET", "MOTION\thw_int:\t" + MyMotionData.hw_int);
            Log.d("PACKET", "MOTION\temb_func_status:\t" + MyMotionData.emb_func_status);
            Log.d("PACKET", "MOTION\tlib_data:\t" + MyMotionData.lib_data);
            Log.d("PACKET", "MOTION\tlc:\t" + MyMotionData.lc);
            Log.d("PACKET", "MOTION\tall_int:\t" + MyMotionData.all_int);
            Log.d("PACKET", "MOTION\tquat[0]:\t" + MyMotionData.quat[0]);
            Log.d("PACKET", "MOTION\tquat[1]:\t" + MyMotionData.quat[1]);
            Log.d("PACKET", "MOTION\tquat[2]:\t" + MyMotionData.quat[2]);
            Log.d("PACKET", "MOTION\tquat[3]:\t" + MyMotionData.quat[3]);
            Log.d("PACKET", "MOTION\tgravity[0]:\t" + MyMotionData.gravity[0]);
            Log.d("PACKET", "MOTION\tgravity[1]:\t" + MyMotionData.gravity[1]);
            Log.d("PACKET", "MOTION\tgravity[2]:\t" + MyMotionData.gravity[2]);
            Log.d("PACKET", "MOTION\tgbias[0]:\t" + MyMotionData.gbias[0]);
            Log.d("PACKET", "MOTION\tgbias[1]:\t" + MyMotionData.gbias[1]);
            Log.d("PACKET", "MOTION\tgbias[2]:\t" + MyMotionData.gbias[2]);
        }
    }

    private void parseCtrlPacket(byte[] data) {
        Log.d(LOG_TAG, "Received new CTRL packet");

        ByteBuffer bb = ByteBuffer.wrap(data);
        bb.order(ByteOrder.LITTLE_ENDIAN);

        MyCtrlData.battery = bb.getShort(0);
        MyCtrlData.battery_level = bb.get(2);
        MyCtrlData.battery_present = bb.get(3);
        MyCtrlData.charging = bb.get(4);
        MyCtrlData.sd_err = bb.get(5);
        MyCtrlData.sd_msc = bb.get(6);
        MyCtrlData.sd_log = bb.get(7);
        MyCtrlData.conf = bb.get(8);
        MyCtrlData.audio = bb.get(9);
        MyCtrlData.ble_log = bb.get(10);
        MyCtrlData.ble_sens_en = bb.get(11);
        MyCtrlData.dil24_whoami = bb.get(12);
        MyCtrlData.dil24_rev = bb.get(13);
        MyCtrlData.afe_channels = bb.get(14);
        MyCtrlData.board_id = bb.get(16);
        MyCtrlData.major = bb.get(17);
        MyCtrlData.minor = bb.get(18);
        MyCtrlData.patch = bb.get(19);

        if (!mFirstCtrlPacketReceived) {
            Log.d("TESTTEST", "mFirstCtrlPacketReceived = true");
            mFirstCtrlPacketReceived = true;
            connectionNotify();

            // Initialize device when first packet is received
            MyCtrlData.updateDevice();

            // Initialize logStatus when first packet is received
            if (MyLogging.getLogStatus() != MyLogging.LOG_STATUS_LOGGING && (MyCtrlData.sd_log > 0 || MyCtrlData.ble_log > 0)) {
                MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);

                if (MyCtrlData.ble_log > 0) {
                    MyLogging.setLogFileStatus(MyLogging.LOGFILE_STATUS_ATTACHING);
                }
            }

            // Force closing demo if needed
            if (DemoFragment.getInstance() != null && MyCtrlData.conf == 0 && MyCtrlData.sd_msc == 0) {
                DemoListFragment.forceDismissDemoFragment();
            }
        }

        Log.d("PACKET", "CTRL\tbattery [mV]:\t" + MyCtrlData.battery);
        Log.d("PACKET", "CTRL\tbattery_level:\t" + MyCtrlData.battery_level);
        Log.d("PACKET", "CTRL\tbattery_present:\t" + MyCtrlData.battery_present);
        Log.d("PACKET", "CTRL\tcharging:\t" + MyCtrlData.charging);
        Log.d("PACKET", "CTRL\tsd_err:\t" + MyCtrlData.sd_err);
        Log.d("PACKET", "CTRL\tsd_msc:\t" + MyCtrlData.sd_msc);
        Log.d("PACKET", "CTRL\tsd_log:\t" + MyCtrlData.sd_log);
        Log.d("PACKET", "CTRL\tconf:\t" + MyCtrlData.conf);
        Log.d("PACKET", "CTRL\taudio:\t" + MyCtrlData.audio);
        Log.d("PACKET", "CTRL\tble_log:\t" + MyCtrlData.ble_log);
        Log.d("PACKET", "CTRL\tble_sens_en:\t" + MyCtrlData.ble_sens_en);
        Log.d("PACKET", "CTRL\tdil24_whoami:\t" + MyCtrlData.dil24_whoami);
        Log.d("PACKET", "CTRL\tdil24_rev:\t" + MyCtrlData.dil24_rev);
        Log.d("PACKET", "CTRL\tafe_channels:\t" + MyCtrlData.afe_channels);
        Log.d("PACKET", "CTRL\tboard_id:\t" + MyCtrlData.board_id);
        Log.d("PACKET", "CTRL\tver:\t" + MyCtrlData.major + "." + MyCtrlData.minor + "." + MyCtrlData.patch);
    }

    private void parseStreamPacket(byte[] data) {
        Log.d(LOG_TAG, "Received new STREAM packet");

        ArrayList<String> lines = new ArrayList<>();

        ByteBuffer bb = ByteBuffer.wrap(data);
        bb.order(ByteOrder.LITTLE_ENDIAN);

        if (MyCtrlData.lsm6dsv16xQuatStream() || MyCtrlData.lsm6dsv16bxQuatStream())
        {
            //int timestamp = bb.getInt(0);
            float qx = bb.getFloat(4);
            float qy = bb.getFloat(8);
            float qz = bb.getFloat(12);
            float qw = bb.getFloat(16);

            DemoFragment.getInstance().applyRotationToQuaternionCard(qx, qy, qz, qw);
        }

        if (MyCtrlData.ble_log > 0)
        {
            switch (MyCtrlData.board_id)
            {
                case MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25:
                    MyStreamData.timestamp = bb.getInt(0);
                    MyStreamData.accX[0] = bb.getShort(4);
                    MyStreamData.accY[0] = bb.getShort(6);
                    MyStreamData.accZ[0] = bb.getShort(8);
                    MyStreamData.gyrX = bb.getShort(10);
                    MyStreamData.gyrY = bb.getShort(12);
                    MyStreamData.gyrZ = bb.getShort(14);
                    MyStreamData.press = bb.getInt(16);

                    lines.add(MyStreamData.timestamp + "\t" + MyStreamData.accX[0] + "\t" + MyStreamData.accY[0] + "\t" + MyStreamData.accZ[0] + "\t" + MyStreamData.gyrX + "\t" + MyStreamData.gyrY + "\t" + MyStreamData.gyrZ + "\t" + MyStreamData.press + "\r\n");
                    MyLogging.appendLogFile(lines);
                    CardView_BLE_STREAM.updateData();
                    break;

                case MyCtrlData.BOARD_ID_TWSBOX_SWAN3:
                case MyCtrlData.BOARD_ID_TWSBOX_SWAN3B:
                    if (!MyCtrlData.getBleHighRate()) {
                        MyStreamData.timestamp = bb.getInt(0);
                        MyStreamData.accX[0] = bb.getShort(4);
                        MyStreamData.accY[0] = bb.getShort(6);
                        MyStreamData.accZ[0] = bb.getShort(8);
                        MyStreamData.gyrX = bb.getShort(10);
                        MyStreamData.gyrY = bb.getShort(12);
                        MyStreamData.gyrZ = bb.getShort(14);
                        MyStreamData.qvar[0] = bb.getShort(16);

                        lines.add(MyStreamData.timestamp + "\t" + MyStreamData.accX[0] + "\t" + MyStreamData.accY[0] + "\t" + MyStreamData.accZ[0] + "\t" + MyStreamData.gyrX + "\t" + MyStreamData.gyrY + "\t" + MyStreamData.gyrZ + "\t" + MyStreamData.qvar[0] + "\r\n");

                        MyLogging.appendLogFile(lines);
                        CardView_BLE_STREAM.updateData();
                    }
                    else {
                        MyStreamData.timestamp = 0;
                        MyStreamData.qvar[0] = bb.getShort(10);
                        MyStreamData.qvar[1] = bb.getShort(12);
                        MyStreamData.qvar[2] = bb.getShort(14);
                        MyStreamData.qvar[3] = bb.getShort(16);
                        MyStreamData.qvar[4] = bb.getShort(18);
                        if (MyCtrlData.getAccelAxisX()) {
                            for (int i = 0; i < 5; i++) {
                                MyStreamData.accX[i] = bb.getShort(2 * i);
                            }

                            lines.add(MyStreamData.accX[0] + "\t" + MyStreamData.qvar[0] + "\r\n");
                            lines.add(MyStreamData.accX[1] + "\t" + MyStreamData.qvar[1] + "\r\n");
                            lines.add(MyStreamData.accX[2] + "\t" + MyStreamData.qvar[2] + "\r\n");
                            lines.add(MyStreamData.accX[3] + "\t" + MyStreamData.qvar[3] + "\r\n");
                            lines.add(MyStreamData.accX[4] + "\t" + MyStreamData.qvar[4] + "\r\n");
                            MyLogging.appendLogFile(lines);
                        }
                        else if (MyCtrlData.getAccelAxisY()) {
                            for (int i = 0; i < 5; i++) {
                                MyStreamData.accY[i] = bb.getShort(2 * i);
                            }

                            lines.add(MyStreamData.accY[0] + "\t" + MyStreamData.qvar[0] + "\r\n");
                            lines.add(MyStreamData.accY[1] + "\t" + MyStreamData.qvar[1] + "\r\n");
                            lines.add(MyStreamData.accY[2] + "\t" + MyStreamData.qvar[2] + "\r\n");
                            lines.add(MyStreamData.accY[3] + "\t" + MyStreamData.qvar[3] + "\r\n");
                            lines.add(MyStreamData.accY[4] + "\t" + MyStreamData.qvar[4] + "\r\n");
                            MyLogging.appendLogFile(lines);
                        }
                        else if (MyCtrlData.getAccelAxisZ()) {
                            for (int i = 0; i < 5; i++) {
                                MyStreamData.accZ[i] = bb.getShort(2 * i);
                            }

                            lines.add(MyStreamData.accZ[0] + "\t" + MyStreamData.qvar[0] + "\r\n");
                            lines.add(MyStreamData.accZ[1] + "\t" + MyStreamData.qvar[1] + "\r\n");
                            lines.add(MyStreamData.accZ[2] + "\t" + MyStreamData.qvar[2] + "\r\n");
                            lines.add(MyStreamData.accZ[3] + "\t" + MyStreamData.qvar[3] + "\r\n");
                            lines.add(MyStreamData.accZ[4] + "\t" + MyStreamData.qvar[4] + "\r\n");
                            MyLogging.appendLogFile(lines);
                        }
                        else if (MyCtrlData.getAccelAxisV()) {
                            for (int i = 0; i < 5; i++) {
                                MyStreamData.accV[i] = bb.getShort(2 * i);
                                if (MyStreamData.accV[i] < 0)
                                    MyStreamData.accV[i] = Short.MAX_VALUE;
                            }

                            lines.add(MyStreamData.accV[0] + "\t" + MyStreamData.qvar[0] + "\r\n");
                            lines.add(MyStreamData.accV[1] + "\t" + MyStreamData.qvar[1] + "\r\n");
                            lines.add(MyStreamData.accV[2] + "\t" + MyStreamData.qvar[2] + "\r\n");
                            lines.add(MyStreamData.accV[3] + "\t" + MyStreamData.qvar[3] + "\r\n");
                            lines.add(MyStreamData.accV[4] + "\t" + MyStreamData.qvar[4] + "\r\n");
                            MyLogging.appendLogFile(lines);
                        }

                        CardView_BLE_STREAM.updateData();
                    }
                    break;
                default:
                    break;
            }
        }
    }
}

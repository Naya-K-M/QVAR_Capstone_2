package st.oem.box;

import android.os.CountDownTimer;
import android.widget.ImageView;
import android.widget.TextView;

public class MyCountDownTimer extends CountDownTimer{

    private final ImageView imageView;
    private final Integer imageViewResource;
    private final TextView textView;
    private final String textViewString;

    public MyCountDownTimer(long countDownInterval, ImageView imageView, Integer imageViewResource, TextView textView, String textViewString) {
        super(countDownInterval, countDownInterval);

        this.imageView = imageView;
        this.imageViewResource = imageViewResource;
        this.textView = textView;
        this.textViewString = textViewString;
    }

    public MyCountDownTimer(long countDownInterval, ImageView imageView, Integer imageViewResource) {
        super(countDownInterval, countDownInterval);

        this.imageView = imageView;
        this.imageViewResource = imageViewResource;
        this.textView = null;
        this.textViewString = null;
    }

    public void onTick(long millisUntilFinished) { }

    public void onFinish() {
        imageView.setImageResource(imageViewResource);
        if (textView != null)
            textView.setText(textViewString);

        this.cancel();
    }
}

package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.mikhaellopez.circularprogressbar.CircularProgressBar;

import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_IN_BAG_DETECTION extends CardView {

    private final int IN_BAG_DETECTION_MAX_TIMER_MS = 20000;

    private CircularProgressBar mInBagCircularProgressBar;
    private ImageView mInBagImageView;
    private Button mLidOpenButton;
    private Button mLidClosedButton;
    private TextView mLidStatusTextView;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    private boolean lid_closed;
    private int in_bag_timer_ms;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_IN_BAG_DETECTION_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mInBagCircularProgressBar = null;
        mInBagImageView = null;
        mLidOpenButton = null;
        mLidClosedButton = null;
        mLidStatusTextView = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_IN_BAG_DETECTION(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_in_bag_detection, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        lid_closed = false;
        in_bag_timer_ms = 0;

        mInBagImageView = mMainLayout.findViewById(R.id.inBagImageView);
        mInBagCircularProgressBar = mMainLayout.findViewById(R.id.inBagCircularProgressBar);
        mLidOpenButton = mMainLayout.findViewById(R.id.lidOpenButton);
        mLidClosedButton = mMainLayout.findViewById(R.id.lidClosedButton);
        mLidStatusTextView = mMainLayout.findViewById(R.id.lidStatusTextView);

        // Configure ProgressBar
        mInBagCircularProgressBar.setProgressBarColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
        mInBagCircularProgressBar.setBackgroundProgressBarColor(ContextCompat.getColor(getContext(), R.color.color_grey));
        mInBagCircularProgressBar.setProgressBarWidth(20f); // in DP
        mInBagCircularProgressBar.setBackgroundProgressBarWidth(15f); // in DP
        mInBagCircularProgressBar.setProgressMax(IN_BAG_DETECTION_MAX_TIMER_MS);
        mInBagCircularProgressBar.setProgress(0f);

        mLidOpenButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        mLidOpenButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mLidClosedButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mLidStatusTextView.setText(String.format(getResources().getString(R.string.lid_status), mLidOpenButton.getText().toString().toUpperCase()));
                        lid_closed = false;
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        mLidClosedButton.setOnClickListener((View v) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        mLidOpenButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_cyan));
                        mLidClosedButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                        mLidStatusTextView.setText(String.format(getResources().getString(R.string.lid_status), mLidClosedButton.getText().toString().toUpperCase()));
                        lid_closed = true;
                    } else {
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_logging_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });

        lid_closed = false;
        in_bag_timer_ms = 0;
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (lid_closed && MyMotionData.fsm_outs[0] == 1)
                {
                    if (in_bag_timer_ms < IN_BAG_DETECTION_MAX_TIMER_MS) {
                        in_bag_timer_ms += MyTiming.UPDATE_UI_IN_BAG_DETECTION_TIMER;
                        mInBagCircularProgressBar.setProgress(in_bag_timer_ms);
                    }
                    if (in_bag_timer_ms >= IN_BAG_DETECTION_MAX_TIMER_MS)
                        mInBagImageView.setImageResource(R.drawable.pc_bag);
                }
                else
                {
                    in_bag_timer_ms = 0;
                    mInBagCircularProgressBar.setProgress(0f);
                    mInBagImageView.setImageResource(R.drawable.still);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

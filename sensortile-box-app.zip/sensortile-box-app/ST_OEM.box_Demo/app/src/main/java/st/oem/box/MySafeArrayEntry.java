package st.oem.box;

import com.github.mikephil.charting.data.Entry;

import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

public class MySafeArrayEntry {

    private final ArrayList<Entry> values;
    private int maxSize;
    public ReentrantLock lock = new ReentrantLock();

    public void setLimit(int maxSize)
    {
        this.maxSize = maxSize;
    }

    public MySafeArrayEntry(int maxSize)
    {
        values = new ArrayList<>();
        this.maxSize = maxSize;
    }

    public void add(Entry entry)
    {
        lock.lock();
        values.add(entry);
        lock.unlock();
    }

    public void clear()
    {
        lock.lock();
        values.clear();
        lock.unlock();
    }

    public ArrayList<Entry> get()
    {
        lock.lock();
        if (values.size() >= maxSize) {
            int delta = values.size() - maxSize;
            values.subList(0, delta).clear();
        }
        ArrayList<Entry> tmp = new ArrayList<>(values);
        lock.unlock();

        return tmp;
    }
}

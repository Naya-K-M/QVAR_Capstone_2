package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_SENSORS_SD_LOG_SENSORTILEBOX_SUNCHON extends CardView {

    private TextView lsm6dso16isAccelConfigTextView;
    private TextView lsm6dso16isAccelOdrTextView;
    private TextView lsm6dso16isAccelFullScaleTextView;
    private TextView lsm6dso16isAccelPowerModeTextView;
    private Spinner lsm6dso16isAccelOdrSpinner;
    private Spinner lsm6dso16isAccelFullScaleSpinner;
    private Spinner lsm6dso16isAccelPowerModeSpinner;
    private TextView lsm6dso16isGyroConfigTextView;
    private TextView lsm6dso16isGyroOdrTextView;
    private TextView lsm6dso16isGyroFullScaleTextView;
    private TextView lsm6dso16isGyroPowerModeTextView;
    private Spinner lsm6dso16isGyroOdrSpinner;
    private Spinner lsm6dso16isGyroFullScaleSpinner;
    private Spinner lsm6dso16isGyroPowerModeSpinner;
    private TextView lps22hhPressConfigTextView;
    private TextView lps22hhPressOdrTextView;
    private TextView lps22hhPressLPFTextView;
    private TextView lps22hhPressPowerModeTextView;
    private Spinner lps22hhPressOdrSpinner;
    private Spinner lps22hhPressLPFSpinner;
    private Spinner lps22hhPressPowerModeSpinner;
    private TextView mp23abs1MicConfigTextView;
    private CheckBox mp23abs1MicEnabledCheckBox;
    private LinearLayout applicationLinearLayout;
    private Spinner applicationSpinner;
    private EditText applicationEditText;
    private LinearLayout classLinearLayout;
    private Spinner classSpinner;
    private EditText classEditText;
    private TextView loggingTextView;
    private Button startStopSdLogButton;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    private boolean lsm6dso16is_xl_pd;
    private boolean lsm6dso16is_g_pd;
    private boolean lps22hh_p_pd;
    private boolean mp23abs1_mic_pd;
    private int lsm6dso16is_reg_10;
    private int lsm6dso16is_reg_11;
    private int lsm6dso16is_reg_15;
    private int lsm6dso16is_reg_16;
    private int lps22hh_reg_10;
    private int lps22hh_reg_11;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_SENSORS_LOG_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        lsm6dso16isAccelConfigTextView = null;
        lsm6dso16isAccelOdrTextView = null;
        lsm6dso16isAccelFullScaleTextView = null;
        lsm6dso16isAccelPowerModeTextView = null;
        lsm6dso16isAccelOdrSpinner = null;
        lsm6dso16isAccelFullScaleSpinner = null;
        lsm6dso16isAccelPowerModeSpinner = null;
        lsm6dso16isGyroConfigTextView = null;
        lsm6dso16isGyroOdrTextView = null;
        lsm6dso16isGyroFullScaleTextView = null;
        lsm6dso16isGyroPowerModeTextView = null;
        lsm6dso16isGyroOdrSpinner = null;
        lsm6dso16isGyroFullScaleSpinner = null;
        lsm6dso16isGyroPowerModeSpinner = null;
        lps22hhPressConfigTextView = null;
        lps22hhPressOdrTextView = null;
        lps22hhPressLPFTextView = null;
        lps22hhPressPowerModeTextView = null;
        lps22hhPressOdrSpinner = null;
        lps22hhPressLPFSpinner = null;
        lps22hhPressPowerModeSpinner = null;
        mp23abs1MicConfigTextView = null;
        mp23abs1MicEnabledCheckBox = null;
        applicationLinearLayout = null;
        applicationSpinner = null;
        applicationEditText = null;
        classLinearLayout = null;
        classSpinner = null;
        classEditText = null;
        loggingTextView = null;
        startStopSdLogButton = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    @SuppressLint("InflateParams")
    public CardView_SENSORS_SD_LOG_SENSORTILEBOX_SUNCHON(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_sensors_sd_log_sensortilebox_sunchon, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        lsm6dso16is_xl_pd = true;
        lsm6dso16is_g_pd = true;
        lps22hh_p_pd = true;
        mp23abs1_mic_pd = true;
        lsm6dso16is_reg_10 = 0x00;
        lsm6dso16is_reg_11 = 0x00;
        lsm6dso16is_reg_15 = 0x00;
        lsm6dso16is_reg_16 = 0x00;
        lps22hh_reg_10 = 0x00;
        lps22hh_reg_11 = 0x00;

        lsm6dso16isAccelConfigTextView = mMainLayout.findViewById(R.id.lsm6dso16isAccelConfigTextView);
        lsm6dso16isAccelOdrTextView = mMainLayout.findViewById(R.id.lsm6dso16isAccelOdrTextView);
        lsm6dso16isAccelFullScaleTextView = mMainLayout.findViewById(R.id.lsm6dso16isAccelFullScaleTextView);
        lsm6dso16isAccelPowerModeTextView = mMainLayout.findViewById(R.id.lsm6dso16isAccelPowerModeTextView);
        lsm6dso16isAccelOdrSpinner = mMainLayout.findViewById(R.id.lsm6dso16isAccelOdrSpinner);
        lsm6dso16isAccelFullScaleSpinner = mMainLayout.findViewById(R.id.lsm6dso16isAccelFullScaleSpinner);
        lsm6dso16isAccelPowerModeSpinner = mMainLayout.findViewById(R.id.lsm6dso16isAccelPowerModeSpinner);

        lsm6dso16isGyroConfigTextView = mMainLayout.findViewById(R.id.lsm6dso16isGyroConfigTextView);
        lsm6dso16isGyroOdrTextView = mMainLayout.findViewById(R.id.lsm6dso16isGyroOdrTextView);
        lsm6dso16isGyroFullScaleTextView = mMainLayout.findViewById(R.id.lsm6dso16isGyroFullScaleTextView);
        lsm6dso16isGyroPowerModeTextView = mMainLayout.findViewById(R.id.lsm6dso16isGyroPowerModeTextView);
        lsm6dso16isGyroOdrSpinner = mMainLayout.findViewById(R.id.lsm6dso16isGyroOdrSpinner);
        lsm6dso16isGyroFullScaleSpinner = mMainLayout.findViewById(R.id.lsm6dso16isGyroFullScaleSpinner);
        lsm6dso16isGyroPowerModeSpinner = mMainLayout.findViewById(R.id.lsm6dso16isGyroPowerModeSpinner);

        lps22hhPressConfigTextView = mMainLayout.findViewById(R.id.lps22hhPressConfigTextView);
        lps22hhPressOdrTextView = mMainLayout.findViewById(R.id.lps22hhPressOdrTextView);
        lps22hhPressLPFTextView = mMainLayout.findViewById(R.id.lps22hhPressLPFTextView);
        lps22hhPressPowerModeTextView = mMainLayout.findViewById(R.id.lps22hhPressPowerModeTextView);
        lps22hhPressOdrSpinner = mMainLayout.findViewById(R.id.lps22hhPressOdrSpinner);
        lps22hhPressLPFSpinner = mMainLayout.findViewById(R.id.lps22hhPressLPFSpinner);
        lps22hhPressPowerModeSpinner = mMainLayout.findViewById(R.id.lps22hhPressPowerModeSpinner);

        mp23abs1MicConfigTextView = mMainLayout.findViewById(R.id.mp23abs1MicConfigTextView);
        mp23abs1MicEnabledCheckBox = mMainLayout.findViewById(R.id.mp23abs1MicEnabledCheckBox);
        if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 0)
        {
            mp23abs1MicConfigTextView.setVisibility(View.GONE);
            mp23abs1MicEnabledCheckBox.setVisibility(View.GONE);
            mp23abs1_mic_pd = true;
        }

        applicationLinearLayout = mMainLayout.findViewById(R.id.applicationLinearLayout);
        applicationLinearLayout.setVisibility(View.GONE);
        applicationSpinner = mMainLayout.findViewById(R.id.applicationSpinner);
        applicationEditText = mMainLayout.findViewById(R.id.applicationEditText);

        classLinearLayout = mMainLayout.findViewById(R.id.classLinearLayout);
        classLinearLayout.setVisibility(View.GONE);
        classSpinner = mMainLayout.findViewById(R.id.classSpinner);
        classEditText = mMainLayout.findViewById(R.id.classEditText);
        classSpinner.setEnabled(false);

        loggingTextView = mMainLayout.findViewById(R.id.loggingTextView);
        startStopSdLogButton = mMainLayout.findViewById(R.id.startStopSdLogButton);

        lsm6dso16isAccelOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dso16is_reg_10 &= 0x0F;
                lsm6dso16is_reg_10 |= (position << 4);
                lsm6dso16is_xl_pd = !(position > 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dso16isAccelFullScaleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dso16is_reg_10 &= 0xF3;
                if (position == 0) // 2g
                    lsm6dso16is_reg_10 |= 0x00;
                else if (position == 1) // 4g
                    lsm6dso16is_reg_10 |= 0x08;
                else if (position == 2) // 8g
                    lsm6dso16is_reg_10 |= 0x0C;
                else if (position == 3) // 16g
                    lsm6dso16is_reg_10 |= 0x04;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dso16isAccelPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int xlOdrSpinner_PreviousPosition = lsm6dso16isAccelOdrSpinner.getSelectedItemPosition();
                ArrayAdapter<CharSequence> adapter;

                if (position == 0) { // HP
                    if (!mp23abs1_mic_pd)
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_clamped_odr_array, android.R.layout.simple_spinner_item);
                    else
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_odr_array, android.R.layout.simple_spinner_item);

                    lsm6dso16is_reg_15 = 0x00;
                    lsm6dso16isGyroConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dso16isGyroOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dso16isGyroFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dso16isGyroPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dso16isGyroOdrSpinner.setEnabled(true);
                    lsm6dso16isGyroFullScaleSpinner.setEnabled(true);
                    lsm6dso16isGyroPowerModeSpinner.setEnabled(true);
                } else { // position == 1, LP
                    if (!mp23abs1_mic_pd)
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_clamped_odr_array, android.R.layout.simple_spinner_item);
                    else
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_lp_odr_array, android.R.layout.simple_spinner_item);

                    lsm6dso16is_reg_15 = 0x10;
                    lsm6dso16isGyroConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dso16isGyroOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dso16isGyroFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dso16isGyroPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_blue));
                    lsm6dso16isGyroOdrSpinner.setEnabled(true);
                    lsm6dso16isGyroFullScaleSpinner.setEnabled(true);
                    lsm6dso16isGyroPowerModeSpinner.setEnabled(true);
                }

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                lsm6dso16isAccelOdrSpinner.setAdapter(adapter);
                if (xlOdrSpinner_PreviousPosition < adapter.getCount()) {
                    lsm6dso16isAccelOdrSpinner.setSelection(xlOdrSpinner_PreviousPosition);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dso16isGyroOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dso16is_reg_11 &= 0x0F;
                lsm6dso16is_reg_11 |= (position << 4);
                lsm6dso16is_g_pd = !(position > 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dso16isGyroFullScaleSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lsm6dso16is_reg_11 &= 0xF1;
                if (position == 0) // 125dps
                    lsm6dso16is_reg_11 |= 0x02;
                else if (position == 1) // 250dps
                    lsm6dso16is_reg_11 |= 0x00;
                else if (position == 2) // 500dps
                    lsm6dso16is_reg_11 |= 0x04;
                else if (position == 3) // 1000dps
                    lsm6dso16is_reg_11 |= 0x08;
                else if (position == 4) // 2000dps
                    lsm6dso16is_reg_11 |= 0x0C;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lsm6dso16isGyroPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int gOdrSpinner_PreviousPosition = lsm6dso16isGyroOdrSpinner.getSelectedItemPosition();
                ArrayAdapter<CharSequence> adapter;

                if (position == 0) { // HP
                    if (!mp23abs1_mic_pd)
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_clamped_odr_array, android.R.layout.simple_spinner_item);
                    else
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_odr_array, android.R.layout.simple_spinner_item);

                    lsm6dso16is_reg_16 = 0x00;
                } else { // position == 1, LP
                    if (!mp23abs1_mic_pd)
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_clamped_odr_array, android.R.layout.simple_spinner_item);
                    else
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_lp_odr_array, android.R.layout.simple_spinner_item);

                    lsm6dso16is_reg_16 = 0x80;
                }

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                lsm6dso16isGyroOdrSpinner.setAdapter(adapter);
                if (gOdrSpinner_PreviousPosition < adapter.getCount()) {
                    lsm6dso16isGyroOdrSpinner.setSelection(gOdrSpinner_PreviousPosition);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lps22hhPressOdrSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lps22hh_reg_10 &= 0x8F;
                lps22hh_reg_10 |= (position << 4);
                lps22hh_p_pd = !(position > 0);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lps22hhPressLPFSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                lps22hh_reg_10 &= 0xF3;
                //if (position == 0) // ODR/2
                if (position == 1) // ODR/9
                    lps22hh_reg_10 |= 0x08;
                else if (position == 2) // ODR/20
                    lps22hh_reg_10 |= 0x0C;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        lps22hhPressPowerModeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int pOdrSpinner_PreviousPosition = lps22hhPressOdrSpinner.getSelectedItemPosition();
                ArrayAdapter<CharSequence> adapter;
                if (position == 0) { // Low Current
                    if (!mp23abs1_mic_pd)
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lps22hh_clamped_odr_array, android.R.layout.simple_spinner_item);
                    else
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lps22hh_lp_odr_array, android.R.layout.simple_spinner_item);

                    lps22hh_reg_11 = 0x00;
                } else {  // position == 1, Low Noise
                    if (!mp23abs1_mic_pd)
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lps22hh_clamped_odr_array, android.R.layout.simple_spinner_item);
                    else
                        adapter = ArrayAdapter.createFromResource(getContext(), R.array.lps22hh_odr_array, android.R.layout.simple_spinner_item);

                    lps22hh_reg_11 = 0x02;
                }

                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                lps22hhPressOdrSpinner.setAdapter(adapter);
                if (pOdrSpinner_PreviousPosition < adapter.getCount()) {
                    lps22hhPressOdrSpinner.setSelection(pOdrSpinner_PreviousPosition);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) {
            mp23abs1MicEnabledCheckBox.setOnCheckedChangeListener((buttonView, isChecked) ->
            {
                mp23abs1_mic_pd = !isChecked;
                int xlOdrSpinner_PreviousPosition = lsm6dso16isAccelOdrSpinner.getSelectedItemPosition();
                int gOdrSpinner_PreviousPosition = lsm6dso16isGyroOdrSpinner.getSelectedItemPosition();
                int pOdrSpinner_PreviousPosition = lps22hhPressOdrSpinner.getSelectedItemPosition();
                ArrayAdapter<CharSequence> xlAdapter;
                ArrayAdapter<CharSequence> gAdapter;
                ArrayAdapter<CharSequence> pAdapter;

                if (mp23abs1_mic_pd) {
                    String xlPowerModeString = lsm6dso16isAccelPowerModeSpinner.getSelectedItem().toString();
                    String gPowerModeString = lsm6dso16isGyroPowerModeSpinner.getSelectedItem().toString();
                    String pPowerModeString = lps22hhPressPowerModeSpinner.getSelectedItem().toString();

                    if (xlPowerModeString.equals("High Performance")) {
                        xlAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_odr_array, android.R.layout.simple_spinner_item);
                    } else {
                        xlAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_lp_odr_array, android.R.layout.simple_spinner_item);
                    }

                    if (gPowerModeString.equals("High Performance")) {
                        gAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_odr_array, android.R.layout.simple_spinner_item);
                    } else {
                        gAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_lp_odr_array, android.R.layout.simple_spinner_item);
                    }

                    if (pPowerModeString.equals("Low Noise")) {
                        pAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lps22hh_odr_array, android.R.layout.simple_spinner_item);
                    } else {
                        pAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lps22hh_lp_odr_array, android.R.layout.simple_spinner_item);
                    }
                } else {
                    xlAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_clamped_odr_array, android.R.layout.simple_spinner_item);
                    gAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lsm6dso16is_clamped_odr_array, android.R.layout.simple_spinner_item);
                    pAdapter = ArrayAdapter.createFromResource(getContext(), R.array.lps22hh_clamped_odr_array, android.R.layout.simple_spinner_item);
                }

                xlAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                lsm6dso16isAccelOdrSpinner.setAdapter(xlAdapter);
                if (xlOdrSpinner_PreviousPosition < xlAdapter.getCount()) {
                    lsm6dso16isAccelOdrSpinner.setSelection(xlOdrSpinner_PreviousPosition);
                }

                gAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                lsm6dso16isGyroOdrSpinner.setAdapter(gAdapter);
                if (gOdrSpinner_PreviousPosition < gAdapter.getCount()) {
                    lsm6dso16isGyroOdrSpinner.setSelection(gOdrSpinner_PreviousPosition);
                }

                pAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                lps22hhPressOdrSpinner.setAdapter(pAdapter);
                if (pOdrSpinner_PreviousPosition < pAdapter.getCount()) {
                    lps22hhPressOdrSpinner.setSelection(pOdrSpinner_PreviousPosition);
                }
            });
        }

        applicationSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String application = applicationSpinner.getSelectedItem().toString();
                classSpinner.setEnabled(true);
                applicationLinearLayout.setVisibility(View.GONE);

                // Spinner elements are
                // <item>NA</item>
                // <item>Activity Recognition</item>
                // <item>Acoustic Scene Recognition</item>
                // <item>Sleep Monitoring</item>
                // <item>Hand-Wash Detection</item>
                // <item>Campaign</item>
                // <item>Other</item>
                if (application.equals(getContext().getString(R.string.na_string))) {
                    classSpinner.setEnabled(false);
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.classes_other_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    classSpinner.setAdapter(adapter);
                }
                else if (application.equals(getContext().getString(R.string.other_string))) {
                    applicationLinearLayout.setVisibility(View.VISIBLE);

                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.classes_other_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    classSpinner.setAdapter(adapter);
                }
                else if (application.equals(getContext().getString(R.string.activity_recognition_string))) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.classes_activity_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    classSpinner.setAdapter(adapter);

                    lsm6dso16isAccelOdrSpinner.setSelection(3);   // xl 52hz
                    lsm6dso16isAccelPowerModeSpinner.setSelection(0);   // xl HP
                    lsm6dso16isAccelFullScaleSpinner.setSelection(2);   // xl 8g

                    lsm6dso16isGyroOdrSpinner.setSelection(3);   // g 52hz
                    lsm6dso16isGyroPowerModeSpinner.setSelection(0);   // g HP
                    lsm6dso16isGyroFullScaleSpinner.setSelection(4);   // g 2000dps

                    lps22hhPressOdrSpinner.setSelection(0);   // p PD
                    lps22hhPressPowerModeSpinner.setSelection(0);
                    lps22hhPressLPFSpinner.setSelection(0);

                    if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) {
                        mp23abs1MicEnabledCheckBox.setChecked(false);   // mic disabled
                    }
                }
                else if (application.equals(getContext().getString(R.string.airplane_mode_detection_string))) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.classes_airplane_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    classSpinner.setAdapter(adapter);

                    lsm6dso16isAccelOdrSpinner.setSelection(4);   // xl 104hz
                    lsm6dso16isAccelPowerModeSpinner.setSelection(0);   // gxl HP
                    lsm6dso16isAccelFullScaleSpinner.setSelection(2);   // xl 8g

                    lsm6dso16isGyroOdrSpinner.setSelection(4);   // g 104hz
                    lsm6dso16isGyroPowerModeSpinner.setSelection(0);   // g HP
                    lsm6dso16isGyroFullScaleSpinner.setSelection(4);   // g 2000dps

                    lps22hhPressOdrSpinner.setSelection(5);   // p 75hz
                    lps22hhPressPowerModeSpinner.setSelection(1);   // p Low-Noise
                    lps22hhPressLPFSpinner.setSelection(0);         // LPF default

                    if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) {
                        mp23abs1MicEnabledCheckBox.setChecked(false);   // mic disabled
                    }
                }
                else if (application.equals(getContext().getString(R.string.acoustic_scene_recognition_string))) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.classes_acoustic_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    classSpinner.setAdapter(adapter);

                    lsm6dso16isAccelOdrSpinner.setSelection(0);   // xl PD

                    lsm6dso16isGyroOdrSpinner.setSelection(0);   // g PD

                    lps22hhPressOdrSpinner.setSelection(0);   // p PD

                    if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) {
                        mp23abs1MicEnabledCheckBox.setChecked(true);   // mic enabled
                    }
                }
                else if (application.equals(getContext().getString(R.string.sleep_monitoring_string))) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.classes_sleep_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    classSpinner.setAdapter(adapter);

                    lsm6dso16isAccelOdrSpinner.setSelection(3);   // xl 52hz
                    lsm6dso16isAccelPowerModeSpinner.setSelection(1);   // xl LP
                    lsm6dso16isAccelFullScaleSpinner.setSelection(2);   // xl 8g

                    lsm6dso16isGyroOdrSpinner.setSelection(0);   // g PD

                    lps22hhPressOdrSpinner.setSelection(0);   // p PD

                    if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) {
                        mp23abs1MicEnabledCheckBox.setChecked(false);   // mic disabled
                    }
                }
                else if (application.equals(getContext().getString(R.string.hand_wash_recognition_string))) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.classes_handwash_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    classSpinner.setAdapter(adapter);

                    lsm6dso16isAccelOdrSpinner.setSelection(3);   // xl 52hz
                    lsm6dso16isAccelPowerModeSpinner.setSelection(1);   // xl LP
                    lsm6dso16isAccelFullScaleSpinner.setSelection(2);   // xl 8g

                    lsm6dso16isGyroOdrSpinner.setSelection(3);   // g 52hz
                    lsm6dso16isGyroPowerModeSpinner.setSelection(1);   // g LP
                    lsm6dso16isGyroFullScaleSpinner.setSelection(4);   // g 2000dps

                    lps22hhPressOdrSpinner.setSelection(0);   // p PD

                    if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) {
                        mp23abs1MicEnabledCheckBox.setChecked(true);   // mic enabled
                    }
                }
                else if (application.equals(getContext().getString(R.string.campaign_string))) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(), R.array.classes_campaign_array, android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    classSpinner.setAdapter(adapter);

                    lsm6dso16isAccelOdrSpinner.setSelection(3);   // xl 52hz
                    lsm6dso16isAccelPowerModeSpinner.setSelection(1);   // xl LP
                    lsm6dso16isAccelFullScaleSpinner.setSelection(2);   // xl 8g

                    lsm6dso16isGyroOdrSpinner.setSelection(3);   // g 52hz
                    lsm6dso16isGyroPowerModeSpinner.setSelection(1);   // g LP
                    lsm6dso16isGyroFullScaleSpinner.setSelection(4);   // g 2000dps

                    lps22hhPressOdrSpinner.setSelection(2);   // p 10hz
                    lps22hhPressPowerModeSpinner.setSelection(0);  // p low-current
                    lps22hhPressLPFSpinner.setSelection(2);    // p lpf ODR/20

                    if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) {
                        mp23abs1MicEnabledCheckBox.setChecked(true);   // mic enabled
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        classSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String clas = classSpinner.getSelectedItem().toString();

                // Spinner elements are dynamic, these can be
                // <item>NA</item>
                // <item>....</item>
                // <item>Other</item>
                if (clas.equals(getContext().getString(R.string.other_string))) {
                    classLinearLayout.setVisibility(View.VISIBLE);
                }
                else {
                    classLinearLayout.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        startStopSdLogButton.setOnClickListener((View view) ->
        {
            if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                    if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_IDLE) {
                        if (MyCtrlData.battery_present == 1 && MyCtrlData.battery_level < 30) {
                            AlertDialog alertDialog = new AlertDialog.Builder(getContext()).create();
                            alertDialog.setTitle(getContext().getString(R.string.title_warning));
                            alertDialog.setMessage(getContext().getString(R.string.alert_low_battery_message));
                            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getContext().getString(R.string.yes_string),
                                    (dialog, which) -> {
                                        startLog();
                                        dialog.dismiss();
                                    });
                            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getContext().getString(R.string.no_string),
                                    (dialog, which) -> dialog.dismiss());
                            alertDialog.show();
                        } else {
                            startLog();
                        }
                    } else if (MyLogging.getLogStatus() == MyLogging.LOG_STATUS_LOGGING) {
                        stopLog();

                    }
                } else {
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void stopLog()
    {
        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STOPPING);
        BLECommands.sendSdStopLog(getContext());
        if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1 && MyCtrlData.audio == 1) {
            BLECommands.sendAudioOff(getContext());
            BLECommands.sendGetBatteryLevel(getContext());
        }
    }

    private void startLog()
    {
        // Reset board
        if (MyCtrlData.conf == 1)
            BLECommands.sendResetDeviceConfiguration(getContext());

        // Configure XL LP/HP
        String lsm6dso16is_reg15 = String.format(Locale.ENGLISH, "%02x", lsm6dso16is_reg_15);
        BLECommands.sendWriteLSM6DSOX(getContext(), "15", lsm6dso16is_reg15);

        // Configure G LP/HP
        String lsm6dso16is_reg16 = String.format(Locale.ENGLISH, "%02x", lsm6dso16is_reg_16);
        BLECommands.sendWriteLSM6DSOX(getContext(), "16", lsm6dso16is_reg16);

        // Turn on/off XL
        String lsm6dso16is_reg10 = String.format(Locale.ENGLISH, "%02x", lsm6dso16is_reg_10);
        BLECommands.sendWriteLSM6DSOX(getContext(), "10", lsm6dso16is_reg10);

        // Turn on/off G
        String lsm6dso16is_reg11 = String.format(Locale.ENGLISH, "%02x", lsm6dso16is_reg_11);
        BLECommands.sendWriteLSM6DSOX(getContext(), "11", lsm6dso16is_reg11);

        // Turn on/off P
        String lps22hh_reg10 = String.format(Locale.ENGLISH, "%02x", lps22hh_reg_10 | 0x02); // BDU
        BLECommands.sendWriteLPS22HH(getContext(), "10", lps22hh_reg10);
        String lps22hh_reg11 = String.format(Locale.ENGLISH, "%02x", lps22hh_reg_11 | 0x10); // IF_ADD_INC
        BLECommands.sendWriteLPS22HH(getContext(), "11", lps22hh_reg11);

        if ((ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) && (mp23abs1MicEnabledCheckBox.isChecked())) {
            BLECommands.sendAudioOn(getContext());
        }

        MyLogging.setLogStatus(MyLogging.LOG_STATUS_STARTING);

        // Get username
        String usernameToSend = MySharedPreferences.getInstance(getContext()).getUsername();
        String applicationToSend = applicationSpinner.getSelectedItem().toString();
        String classToSend = classSpinner.getSelectedItem().toString();

        // Both application and class are NA
        if (applicationToSend.equals(getContext().getString(R.string.na_string))) {
            applicationToSend = getContext().getString(R.string.empty_string);
            classToSend = getContext().getString(R.string.empty_string);
        }
        // Application is not NA
        else {
            // Get application
            if (applicationToSend.equals(getContext().getString(R.string.other_string))) {
                applicationToSend = applicationEditText.getText().toString();
                if (applicationToSend.length() == 0)
                    applicationToSend = getContext().getString(R.string.other_string);
            } else if (applicationToSend.equals(getContext().getString(R.string.activity_recognition_string))) {
                applicationToSend = getContext().getString(R.string.activity_recognition_to_send_string);
            } else if (applicationToSend.equals(getContext().getString(R.string.acoustic_scene_recognition_string))) {
                applicationToSend = getContext().getString(R.string.acoustic_scene_recognition_to_send_string);
            } else if (applicationToSend.equals(getContext().getString(R.string.airplane_mode_detection_string))) {
                applicationToSend = getContext().getString(R.string.airplane_mode_detection_to_send_string);
            } else if (applicationToSend.equals(getContext().getString(R.string.sleep_monitoring_string))) {
                applicationToSend = getContext().getString(R.string.sleep_monitoring_to_send_string);
            } else if (applicationToSend.equals(getContext().getString(R.string.hand_wash_recognition_string))) {
                applicationToSend = getContext().getString(R.string.hand_wash_recognition_to_send_string);
            } else if (applicationToSend.equals(getContext().getString(R.string.campaign_string))) {
                applicationToSend = getContext().getString(R.string.campaign_to_send_string);
            }

            if (classToSend.equals(getContext().getString(R.string.na_string))) {
                classToSend = getContext().getString(R.string.empty_string);
            } else {
                // Get class
                if (classToSend.equals(getContext().getString(R.string.other_string))) {
                    classToSend = classEditText.getText().toString();
                    if (classToSend.length() == 0)
                        classToSend = getContext().getString(R.string.other_string);
                }
            }
        }

        assert usernameToSend != null;
        BLECommands.sendSdStartLog(getContext(), usernameToSend, applicationToSend, classToSend);
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyCtrlData.sd_err == 1) {
                    loggingTextView.setEnabled(false);
                    startStopSdLogButton.setEnabled(false);
                    loggingTextView.setText(R.string.logging_error_string);

                    lsm6dso16isAccelConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dso16isAccelOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dso16isAccelFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dso16isAccelPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dso16isAccelOdrSpinner.setEnabled(false);
                    lsm6dso16isAccelFullScaleSpinner.setEnabled(false);
                    lsm6dso16isAccelPowerModeSpinner.setEnabled(false);

                    lsm6dso16isGyroConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dso16isGyroOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dso16isGyroFullScaleTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dso16isGyroPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lsm6dso16isGyroOdrSpinner.setEnabled(false);
                    lsm6dso16isGyroFullScaleSpinner.setEnabled(false);
                    lsm6dso16isGyroPowerModeSpinner.setEnabled(false);

                    lps22hhPressConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lps22hhPressOdrTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lps22hhPressLPFTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lps22hhPressPowerModeTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                    lps22hhPressOdrSpinner.setEnabled(false);
                    lps22hhPressLPFSpinner.setEnabled(false);
                    lps22hhPressPowerModeSpinner.setEnabled(false);

                    if (ContainerFragment.appConfig.MICROPHONE_LOG_EN == 1) {
                        mp23abs1MicConfigTextView.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                        mp23abs1MicEnabledCheckBox.setEnabled(false);
                    }
                }
                else {
                    switch (MyLogging.getLogStatus())
                    {
                        case MyLogging.LOG_STATUS_IDLE:
                            loggingTextView.setEnabled(true);
                            if (lsm6dso16is_xl_pd && lsm6dso16is_g_pd && lps22hh_p_pd && mp23abs1_mic_pd && MyCtrlData.sd_msc == 0) {
                                startStopSdLogButton.setEnabled(false);
                                startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                            }
                            else {
                                startStopSdLogButton.setEnabled(true);
                                startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                            }
                            loggingTextView.setText(R.string.logging_false_string);
                            startStopSdLogButton.setText(R.string.start_string);
                            if (MyCtrlData.sd_log == 1) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                            }
                            break;
                        case MyLogging.LOG_STATUS_STARTING:
                            startStopSdLogButton.setEnabled(false);
                            startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                            startStopSdLogButton.setText(R.string.starting_string);
                            if (MyCtrlData.sd_log == 1) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_LOGGING);
                            }
                            break;
                        case MyLogging.LOG_STATUS_LOGGING:
                            loggingTextView.setText(R.string.logging_true_string);
                            startStopSdLogButton.setEnabled(true);
                            startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_pink));
                            startStopSdLogButton.setText(R.string.stop_string);
                            if (MyCtrlData.sd_log == 0) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                            }
                            break;
                        case MyLogging.LOG_STATUS_STOPPING:
                            startStopSdLogButton.setText(R.string.stopping_string);
                            startStopSdLogButton.setTextColor(ContextCompat.getColor(getContext(), R.color.color_grey));
                            startStopSdLogButton.setEnabled(false);
                            if (MyCtrlData.sd_log == 0) {
                                MyLogging.setLogStatus(MyLogging.LOG_STATUS_IDLE);
                            }
                            break;
                        default:
                            break;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

package st.oem.box;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;

import st.oem.R;

@SuppressLint("ViewConstructor")
public class CardView_DESCRIPTION extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private TextView mDemoDescriptionTextView;
    private TextView mDemoSensorsDescriptionTextView;
    private TextView mDemoCurrentConsumptionTextView;

    private CardView mMainLayout;

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mDemoDescriptionTextView = null;
        mDemoSensorsDescriptionTextView = null;
        mDemoCurrentConsumptionTextView = null;

        mMainLayout = null;
    }

    @SuppressLint("InflateParams")
    public CardView_DESCRIPTION(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_description, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mDemoDescriptionTextView = mMainLayout.findViewById(R.id.demoDescriptionTextView);
        mDemoSensorsDescriptionTextView = mMainLayout.findViewById(R.id.demoSensorsDescriptionTextView);
        mDemoCurrentConsumptionTextView = mMainLayout.findViewById(R.id.demoCurrentConsumptionTextView);

        mDemoDescriptionTextView.setText(DemoFragment.getInstance().getSelectedDemo().getDemoDescription());
        mDemoSensorsDescriptionTextView.setText(DemoFragment.getInstance().getSelectedDemo().getDemoSensorsDescription());
        mDemoCurrentConsumptionTextView.setText(DemoFragment.getInstance().getSelectedDemo().getDemoCurrentConsumption());

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });
    }
}

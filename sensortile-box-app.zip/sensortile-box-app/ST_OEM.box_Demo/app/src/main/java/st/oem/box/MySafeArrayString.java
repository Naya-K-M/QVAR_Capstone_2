package st.oem.box;

import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

public class MySafeArrayString {

    private final ArrayList<String> values;
    public ReentrantLock lock = new ReentrantLock();

    public MySafeArrayString()
    {
        values = new ArrayList<>();
    }

    public void add(String str)
    {
        lock.lock();
        values.add(str);
        lock.unlock();
    }

    public void add(ArrayList<String> str)
    {
        lock.lock();
        values.addAll(str);
        lock.unlock();
    }

    public void clear()
    {
        lock.lock();
        values.clear();
        lock.unlock();
    }

    public String getAndRemove(int index)
    {
        lock.lock();
        String tmp = values.get(index);
        values.remove(index);
        lock.unlock();

        return tmp;
    }

    public int size()
    {
        lock.lock();
        int tmp = values.size();
        lock.unlock();

        return tmp;
    }
}

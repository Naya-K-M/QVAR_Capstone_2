package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.SwitchCompat;
import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;

import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_PED extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private TextView mPedTitleTextView;
    private ImageView mPedImageView;
    private TextView mPedDataTextView;
    private SwitchCompat mPedLedSwitchCompat;
    private LinearLayout mPedLedLinearLayout;
    private SwitchCompat mPedBuzSwitchCompat;
    private LinearLayout mPedBuzLinearLayout;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    // State
    private static boolean mPedLedSwitchCompatState;
    private static boolean mPedBuzSwitchCompatState;
    private static String mPedDataTextViewString;
    private static Integer mPedImageViewResource;

    private int steps_old;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        
        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_PED_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mPedTitleTextView = null;
        mPedImageView = null;
        mPedDataTextView = null;
        mPedLedSwitchCompat = null;
        mPedLedLinearLayout = null;
        mPedBuzSwitchCompat = null;
        mPedBuzLinearLayout = null;

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }
    }

    public void saveState()
    {
        for (int i = 0; i < 1; i++)
        {
            try {
                mPedLedSwitchCompatState = mPedLedSwitchCompat.isChecked();
            } catch(Exception ignored) { }

            try {
                mPedBuzSwitchCompatState = mPedBuzSwitchCompat.isChecked();
            } catch(Exception ignored) { }

            try {
                mPedImageViewResource = (Integer)mPedImageView.getTag();
            } catch(Exception ignored) { }

            try {
                mPedDataTextViewString = mPedDataTextView.getText().toString();
            } catch(Exception ignored) { }
        }
    }

    public void restoreState()
    {
        for (int i = 0; i < 4; i++)
        {
            try {
                mPedLedSwitchCompat.setChecked(mPedLedSwitchCompatState);
            } catch(Exception ignored) { }

            try {
                mPedBuzSwitchCompat.setChecked(mPedBuzSwitchCompatState);
            } catch(Exception ignored) { }

            try {
                mPedImageView.setImageResource(mPedImageViewResource);
                mPedImageView.setTag(mPedImageViewResource);
            } catch(Exception ignored) { }

            try {
                mPedDataTextView.setText(mPedDataTextViewString);
            } catch(Exception ignored) { }
        }
    }

    @SuppressLint("InflateParams")
    public CardView_PED(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_ped, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        steps_old = -1;

        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mPedTitleTextView = mMainLayout.findViewById(R.id.ped0TitleTextView);
        mPedImageView = mMainLayout.findViewById(R.id.ped0ImageView);
        mPedImageView.setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mPedDataTextView = mMainLayout.findViewById(R.id.ped0DataTextView);

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        if (MyCtrlData.isLedSupported())
        {
            mPedLedSwitchCompat = mMainLayout.findViewById(R.id.pedLed0SwitchCompat);
            mPedLedSwitchCompat.setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
            {
                if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                    if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                        if (b)
                            DemoFragment.getInstance().ped_ledMask = (byte)(DemoFragment.getInstance().ped_ledMask | 0x08); // IS_STEP_DET bit
                        else
                            DemoFragment.getInstance().ped_ledMask = (byte)(DemoFragment.getInstance().ped_ledMask & 0xF7);

                        DemoFragment.getInstance().prepareAndSendLedMask();
                    } else {
                        mPedLedSwitchCompat.setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    mPedLedSwitchCompat.setChecked(!b);
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            mPedLedLinearLayout = mMainLayout.findViewById(R.id.pedLed0LinearLayout);
            mPedLedLinearLayout.setVisibility(GONE);
        }

        if (MyCtrlData.isBuzSupported())
        {
            mPedBuzSwitchCompat = mMainLayout.findViewById(R.id.pedBuz0SwitchCompat);
            mPedBuzSwitchCompat.setOnCheckedChangeListener((CompoundButton compoundButton, boolean b) ->
            {
                if (BluetoothLeService.mConnectionState == BluetoothLeService.STATE_CONNECTED) {
                    if (!DemoFragment.getInstance().getConfigurationOngoing()) {
                        if (b)
                            DemoFragment.getInstance().ped_buzMask = (byte)(DemoFragment.getInstance().ped_buzMask | 0x08); // IS_STEP_DET bit
                        else
                            DemoFragment.getInstance().ped_buzMask = (byte)(DemoFragment.getInstance().ped_buzMask & 0xF7);

                        DemoFragment.getInstance().prepareAndSendBuzMask();
                    } else {
                        mPedBuzSwitchCompat.setChecked(!b);
                        Toast.makeText(getContext(), getContext().getString(R.string.toast_configuration_ongoing), Toast.LENGTH_SHORT).show();
                    }
                } else {
                    mPedBuzSwitchCompat.setChecked(!b);
                    Toast.makeText(getContext(), getContext().getString(R.string.toast_board_not_connected), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            mPedBuzLinearLayout = mMainLayout.findViewById(R.id.pedBuz0LinearLayout);
            mPedBuzLinearLayout.setVisibility(GONE);
        }

        float screenDensity = getResources().getDisplayMetrics().density;
        float textSize = getResources().getDimension(R.dimen.single_demo_textsize_1) / screenDensity;
        mPedTitleTextView.setTextSize(textSize);
        mPedTitleTextView.setText(DemoFragment.getInstance().getSelectedDemo().getSingleDemoName(AppConfig.PEDOMETER_2_0_STR, 0));
        mPedDataTextView.setTextSize(textSize);

        // Initialize UI
        mPedImageView.setImageResource(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.PEDOMETER_2_0_STR, 0, AppConfig.IDLE));
        mPedImageView.setTag(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.PEDOMETER_2_0_STR, 0, AppConfig.IDLE));
        String count = String.format(getResources().getString(R.string.steps_number), 0);
        mPedDataTextView.setText(count);
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (MyMotionData.steps > 0)
                {
                    if (steps_old != MyMotionData.steps) {
                        String count = String.format(getResources().getString(R.string.steps_number), MyMotionData.steps);
                        mPedDataTextView.setText(count);

                        if ((MyMotionData.steps % 2) == 0) {
                            mPedImageView.setImageResource(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.PEDOMETER_2_0_STR, 0, AppConfig.IDLE));
                            mPedImageView.setTag(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.PEDOMETER_2_0_STR, 0, AppConfig.IDLE));
                        } else {
                            mPedImageView.setImageResource(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.PEDOMETER_2_0_STR, 0, AppConfig.EVENT));
                            mPedImageView.setTag(DemoFragment.getInstance().getSelectedDemo().getSingleDemoImageID(AppConfig.PEDOMETER_2_0_STR, 0, AppConfig.EVENT));
                        }
                        DemoFragment.getInstance().addEventToCardEvent(count);

                        steps_old = MyMotionData.steps;
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

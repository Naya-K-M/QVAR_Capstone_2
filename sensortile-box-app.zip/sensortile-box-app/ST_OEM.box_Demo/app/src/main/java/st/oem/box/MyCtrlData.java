package st.oem.box;

import android.content.Context;

import java.util.Arrays;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

public class MyCtrlData {

    static final public byte BOARD_ID_SENSORTILEBOX_SUWON25 = 1;
    static final public byte SENSORTILEBOX_SUWON25_MIN_VERSION_MAJOR = 1;
    static final public byte SENSORTILEBOX_SUWON25_MIN_VERSION_MINOR = 2;
    static final public byte SENSORTILEBOX_SUWON25_MIN_VERSION_PATCH = 2;
    static final public int SENSORTILEBOX_SUWON25_PACKET_LENGTH = 114;

    static final public byte BOARD_ID_TWSBOX_SWAN3 = 2;
    static final public byte TWSBOX_SWAN3_MIN_VERSION_MAJOR = 1;
    static final public byte TWSBOX_SWAN3_MIN_VERSION_MINOR = 5;
    static final public byte TWSBOX_SWAN3_MIN_VERSION_PATCH = 0;
    static final public int TWSBOX_SWAN3_PACKET_LENGTH = 20;

    static final public byte BOARD_ID_TWSBOX_SWAN3B = 3;
    static final public byte TWSBOX_SWAN3B_MIN_VERSION_MAJOR = 1;
    static final public byte TWSBOX_SWAN3B_MIN_VERSION_MINOR = 5;
    static final public byte TWSBOX_SWAN3B_MIN_VERSION_PATCH = 0;
    static final public int TWSBOX_SWAN3B_PACKET_LENGTH = 20;

    static final public byte BOARD_ID_SENSORTILEBOX_SUNCHON = 4;
    static final public byte SENSORTILEBOX_SUNCHON_MIN_VERSION_MAJOR = 1;
    static final public byte SENSORTILEBOX_SUNCHON_MIN_VERSION_MINOR = 2;
    static final public byte SENSORTILEBOX_SUNCHON_MIN_VERSION_PATCH = 4;
    static final public int SENSORTILEBOX_SUNCHON_PACKET_LENGTH = 114;

    static final public byte BOARD_ID_SENSORTILEBOX_PRO = 5;
    static final public byte SENSORTILEBOX_PRO_MIN_VERSION_MAJOR = 1;
    static final public byte SENSORTILEBOX_PRO_MIN_VERSION_MINOR = 4;
    static final public byte SENSORTILEBOX_PRO_MIN_VERSION_PATCH = 6;
    static final public int SENSORTILEBOX_PRO_PACKET_LENGTH = 114;

    static final public String DEVICE_LSM6DSOX = "LSM6DSOX";
    static final public String DEVICE_LSM6DSV16X = "LSM6DSV16X";
    static final public String DEVICE_LSM6DSV16BX = "LSM6DSV16BX";
    static final public String DEVICE_LSM6DSV32X = "LSM6DSV32X";
    static final public String DEVICE_LSM6DSO16IS = "LSM6DSO16IS";
    static final public String DEVICE_LIS2DUXS12 = "LIS2DUXS12";

    static public volatile short battery;
    static public volatile byte battery_level;
    static public volatile byte battery_present;
    static public volatile byte charging;
    static public volatile byte sd_err;
    static public volatile byte sd_msc;
    static public volatile byte sd_log;
    static public volatile byte conf;
    static public volatile byte audio;
    static public volatile byte ble_log;
    static public volatile byte ble_sens_en;
    static public volatile byte dil24_whoami;
    static public volatile byte dil24_rev;
    static public volatile byte afe_channels;
    static public volatile byte reserved;
    static public volatile byte board_id;
    static public volatile byte major;
    static public volatile byte minor;
    static public volatile byte patch;

    static public String device;

    public static void resetData()
    {
        battery = 0;
        battery_level = 0;
        battery_present = 0;
        charging = 0;
        sd_err = 0;
        sd_msc = 0;
        sd_log = 0;
        conf = 0;
        audio = 0;
        ble_log = 0;
        ble_sens_en = 0;
        dil24_whoami = 0;
        dil24_rev = 0;
        afe_channels = 0;
        reserved = 0;
        board_id = 0;
        major = 0;
        minor = 0;
        patch = 0;
    }

    public static boolean isBoardSupported()
    {
        return (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x6C) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x22) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x70 && (MyCtrlData.dil24_rev == 0x11 || MyCtrlData.dil24_rev == 0x12 || MyCtrlData.dil24_rev == 0x30)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x70 && (MyCtrlData.dil24_rev == 0x18 || MyCtrlData.dil24_rev == 0x19 || MyCtrlData.dil24_rev == 0x32)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x71) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x47);
    }

    public static void updateDevice()
    {
        if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25) {
            device = DEVICE_LSM6DSOX;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3) {
            device = DEVICE_LSM6DSV16X;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B) {
            device = DEVICE_LSM6DSV16BX;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) {
            device = DEVICE_LSM6DSO16IS;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x6C) {
            device = DEVICE_LSM6DSOX;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x22) {
            device = DEVICE_LSM6DSO16IS;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x70 && (MyCtrlData.dil24_rev == 0x11 || MyCtrlData.dil24_rev == 0x12 || MyCtrlData.dil24_rev == 0x30)) {
            device = DEVICE_LSM6DSV16X;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x70 && (MyCtrlData.dil24_rev == 0x18 || MyCtrlData.dil24_rev == 0x19 || MyCtrlData.dil24_rev == 0x32)) {
            device = DEVICE_LSM6DSV32X;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x71) {
            device = DEVICE_LSM6DSV16BX;
        } else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.dil24_whoami == 0x47) {
            device = DEVICE_LIS2DUXS12;
        }
    }

    public static boolean isLedSupported()
    {
        return ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSOX)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16X)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV32X)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12)));
    }

    public static boolean isBuzSupported()
    {
        return ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSOX)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16X)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV32X)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12)));
    }

    public static boolean isDemoLogSupported()
    {
        return ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSOX)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSO16IS)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16X)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV32X)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LSM6DSV16BX)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO && MyCtrlData.device.equals(MyCtrlData.DEVICE_LIS2DUXS12)));
    }

    static public boolean getBit(byte value, int position)
    {
        return (((value >> position) & 1) > 0);
    }

    public static boolean lsm6dsoxAccelStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25 && getBit(ble_sens_en, 0);
    }

    public static boolean lsm6dsoxGyroStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25 && getBit(ble_sens_en, 1);
    }

    public static boolean lps22hhPressStream()
    {
        return ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25 && getBit(ble_sens_en, 2)) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON && getBit(ble_sens_en, 2)));
    }

    public static boolean lsm6dsv16xAccelStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3 && getBit(ble_sens_en, 0);
    }

    public static boolean lsm6dsv16xGyroStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3 && getBit(ble_sens_en, 1);
    }

    public static boolean lsm6dsv16xQvarStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3 && getBit(ble_sens_en, 2);
    }

    public static boolean lsm6dsv16xQuatStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3 && getBit(ble_sens_en, 3);
    }

    public static boolean lsm6dsv16bxAccelStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B && getBit(ble_sens_en, 0);
    }

    public static boolean lsm6dsv16bxGyroStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B && getBit(ble_sens_en, 1);
    }

    public static boolean lsm6dsv16bxQvarStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B && getBit(ble_sens_en, 2);
    }

    public static boolean lsm6dsv16bxQuatStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B && getBit(ble_sens_en, 3);
    }

    public static boolean lsm6dso16isAccelStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON && getBit(ble_sens_en, 0);
    }

    public static boolean lsm6dso16isGyroStream()
    {
        return MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON && getBit(ble_sens_en, 1);
    }

    public static boolean isVersionSupported()
    {
        boolean supported = false;
        boolean versionCheck = false;
        int major = 0, minor = 0, patch = 0;

        if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25)
        {
            versionCheck = true;
            major = MyCtrlData.SENSORTILEBOX_SUWON25_MIN_VERSION_MAJOR;
            minor = MyCtrlData.SENSORTILEBOX_SUWON25_MIN_VERSION_MINOR;
            patch = MyCtrlData.SENSORTILEBOX_SUWON25_MIN_VERSION_PATCH;
        }
        else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3)
        {
            versionCheck = true;
            major = MyCtrlData.TWSBOX_SWAN3_MIN_VERSION_MAJOR;
            minor = MyCtrlData.TWSBOX_SWAN3_MIN_VERSION_MINOR;
            patch = MyCtrlData.TWSBOX_SWAN3_MIN_VERSION_PATCH;
        }
        else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_TWSBOX_SWAN3B)
        {
            versionCheck = true;
            major = MyCtrlData.TWSBOX_SWAN3B_MIN_VERSION_MAJOR;
            minor = MyCtrlData.TWSBOX_SWAN3B_MIN_VERSION_MINOR;
            patch = MyCtrlData.TWSBOX_SWAN3B_MIN_VERSION_PATCH;
        }
        else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON)
        {
            versionCheck = true;
            major = MyCtrlData.SENSORTILEBOX_SUNCHON_MIN_VERSION_MAJOR;
            minor = MyCtrlData.SENSORTILEBOX_SUNCHON_MIN_VERSION_MINOR;
            patch = MyCtrlData.SENSORTILEBOX_SUNCHON_MIN_VERSION_PATCH;
        }
        else if (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO)
        {
            versionCheck = true;
            major = MyCtrlData.SENSORTILEBOX_PRO_MIN_VERSION_MAJOR;
            minor = MyCtrlData.SENSORTILEBOX_PRO_MIN_VERSION_MINOR;
            patch = MyCtrlData.SENSORTILEBOX_PRO_MIN_VERSION_PATCH;
        }

        if (versionCheck) {
            if (MyCtrlData.major > major)
            {
                supported = true;
            }
            else if (MyCtrlData.major == major)
            {
                if (MyCtrlData.minor > minor)
                {
                    supported = true;
                }
                else if (MyCtrlData.minor == minor)
                {
                    if (MyCtrlData.patch >= patch)
                    {
                        supported = true;
                    }
                }
            }
        }

        return supported;
    }

    public static int getBatteryImageID()
    {
        if (BluetoothLeService.mConnectionState != BluetoothLeService.STATE_CONNECTED || !isBatteryReadingSupported())
            return R.drawable.status_battery_unknown;

        if (battery_present == 0)
            return R.drawable.status_battery_not_connected;

        if (charging == 0) {
            if (battery_level < 30) {
                return R.drawable.status_battery_level_low;
            } else if (battery_level < 70) {
                return R.drawable.status_battery_level_medium;
            } else if (battery_level < 90) {
                return R.drawable.status_battery_level_high;
            } else {
                return R.drawable.status_battery_level_full;
            }
        }

        if (charging > 0) {
            return R.drawable.status_battery_charging;
        }

        return R.drawable.status_battery_level_empty;
    }

    public static String getBatteryText(Context ctx)
    {
        if (BluetoothLeService.mConnectionState != BluetoothLeService.STATE_CONNECTED)
            return ctx.getString(R.string.na_string);

        if (!isBatteryReadingSupported())
            return ctx.getString(R.string.na_string);

        if (battery_present == 0)
            return ctx.getString(R.string.nc_string);

        if (battery_level > 100)
            battery_level = 100;

        return String.format(ctx.getString(R.string.battery_level), battery_level);
    }

    public static boolean isBatteryReadingSupported()
    {
        return ((MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUWON25) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_SUNCHON) ||
                (MyCtrlData.board_id == MyCtrlData.BOARD_ID_SENSORTILEBOX_PRO));
    }

    public static boolean getBleHighRate()
    {
        if (ble_log > 0) {
            return ble_log % 2 == 0;
        }

        return false;
    }

    public static boolean getAccelAxisX()
    {
        return getBit(ble_log, 3);
    }

    public static boolean getAccelAxisY()
    {
        return getBit(ble_log, 4);
    }

    public static boolean getAccelAxisZ()
    {
        return getBit(ble_log, 5);
    }

    public static boolean getAccelAxisV()
    {
        return getBit(ble_log, 6);
    }
}

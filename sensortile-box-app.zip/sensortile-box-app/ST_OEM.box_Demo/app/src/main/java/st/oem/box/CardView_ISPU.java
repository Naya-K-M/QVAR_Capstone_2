package st.oem.box;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.core.content.res.ResourcesCompat;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import st.oem.R;
import st.oem.services.ble.BluetoothLeService;

@SuppressLint("ViewConstructor")
public class CardView_ISPU extends CardView {

    private Button mExpandCollapseButton;
    private LinearLayout mViewLayout;
    private ImageView mIspuImageView;
    private TextView mIspuOutput00LDataTextView;
    private TextView mIspuOutput00HDataTextView;
    private TextView mIspuOutput01LDataTextView;
    private TextView mIspuOutput01HDataTextView;
    private TextView mIspuOutput02LDataTextView;
    private TextView mIspuOutput02HDataTextView;
    private TextView mIspuOutput03LDataTextView;
    private TextView mIspuOutput03HDataTextView;
    private TextView mIspuOutput04LDataTextView;
    private TextView mIspuOutput04HDataTextView;
    private TextView mIspuOutput05LDataTextView;
    private TextView mIspuOutput05HDataTextView;
    private TextView mIspuOutput06LDataTextView;
    private TextView mIspuOutput06HDataTextView;
    private TextView mIspuOutput07LDataTextView;
    private TextView mIspuOutput07HDataTextView;
    private TextView mIspuOutput08LDataTextView;
    private TextView mIspuOutput08HDataTextView;
    private TextView mIspuOutput09LDataTextView;
    private TextView mIspuOutput09HDataTextView;
    private TextView mIspuOutput10LDataTextView;
    private TextView mIspuOutput10HDataTextView;
    private TextView mIspuOutput11LDataTextView;
    private TextView mIspuOutput11HDataTextView;
    private TextView mIspuOutput12LDataTextView;
    private TextView mIspuOutput12HDataTextView;
    private TextView mIspuOutput13LDataTextView;
    private TextView mIspuOutput13HDataTextView;
    private TextView mIspuOutput14LDataTextView;
    private TextView mIspuOutput14HDataTextView;
    private TextView mIspuOutput15LDataTextView;
    private TextView mIspuOutput15HDataTextView;
    private TextView mIspuOutput16LDataTextView;
    private TextView mIspuOutput16HDataTextView;
    private TextView mIspuOutput17LDataTextView;
    private TextView mIspuOutput17HDataTextView;
    private TextView mIspuOutput18LDataTextView;
    private TextView mIspuOutput18HDataTextView;
    private TextView mIspuOutput19LDataTextView;
    private TextView mIspuOutput19HDataTextView;
    private TextView mIspuOutput20LDataTextView;
    private TextView mIspuOutput20HDataTextView;
    private TextView mIspuOutput21LDataTextView;
    private TextView mIspuOutput21HDataTextView;
    private TextView mIspuOutput22LDataTextView;
    private TextView mIspuOutput22HDataTextView;
    private TextView mIspuOutput23LDataTextView;
    private TextView mIspuOutput23HDataTextView;
    private TextView mIspuOutput24LDataTextView;
    private TextView mIspuOutput24HDataTextView;
    private TextView mIspuOutput25LDataTextView;
    private TextView mIspuOutput25HDataTextView;
    private TextView mIspuOutput26LDataTextView;
    private TextView mIspuOutput26HDataTextView;
    private TextView mIspuOutput27LDataTextView;
    private TextView mIspuOutput27HDataTextView;
    private TextView mIspuOutput28LDataTextView;
    private TextView mIspuOutput28HDataTextView;
    private TextView mIspuOutput29LDataTextView;
    private TextView mIspuOutput29HDataTextView;
    private TextView mIspuOutput30LDataTextView;
    private TextView mIspuOutput30HDataTextView;
    private TextView mIspuOutput31LDataTextView;
    private TextView mIspuOutput31HDataTextView;
    private LinearLayout mIspuOutMappedLinearLayout;
    private LinearLayout mIspuOutRegistersLinearLayout;

    private CardView mMainLayout;
    private Timer mTimerUpdateUI;

    private ArrayList<TextView> mIspuOutputValueArrayList = new ArrayList<>();
    public static volatile boolean mIspuPacketReceived = false;

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();

        mTimerUpdateUI = new Timer();
        mTimerUpdateUI.schedule(new TimerTask() {
            @Override
            public void run() {
                methodUITimer();
            }
        }, 0, MyTiming.UPDATE_UI_ISPU_TIMER);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();

        mExpandCollapseButton = null;
        mViewLayout = null;
        mIspuImageView = null;
        mIspuOutput00LDataTextView = null;
        mIspuOutput00HDataTextView = null;
        mIspuOutput01LDataTextView = null;
        mIspuOutput01HDataTextView = null;
        mIspuOutput02LDataTextView = null;
        mIspuOutput02HDataTextView = null;
        mIspuOutput03LDataTextView = null;
        mIspuOutput03HDataTextView = null;
        mIspuOutput04LDataTextView = null;
        mIspuOutput04HDataTextView = null;
        mIspuOutput05LDataTextView = null;
        mIspuOutput05HDataTextView = null;
        mIspuOutput06LDataTextView = null;
        mIspuOutput06HDataTextView = null;
        mIspuOutput07LDataTextView = null;
        mIspuOutput07HDataTextView = null;
        mIspuOutput08LDataTextView = null;
        mIspuOutput08HDataTextView = null;
        mIspuOutput09LDataTextView = null;
        mIspuOutput09HDataTextView = null;
        mIspuOutput10LDataTextView = null;
        mIspuOutput10HDataTextView = null;
        mIspuOutput11LDataTextView = null;
        mIspuOutput11HDataTextView = null;
        mIspuOutput12LDataTextView = null;
        mIspuOutput12HDataTextView = null;
        mIspuOutput13LDataTextView = null;
        mIspuOutput13HDataTextView = null;
        mIspuOutput14LDataTextView = null;
        mIspuOutput14HDataTextView = null;
        mIspuOutput15LDataTextView = null;
        mIspuOutput15HDataTextView = null;
        mIspuOutput16LDataTextView = null;
        mIspuOutput16HDataTextView = null;
        mIspuOutput17LDataTextView = null;
        mIspuOutput17HDataTextView = null;
        mIspuOutput18LDataTextView = null;
        mIspuOutput18HDataTextView = null;
        mIspuOutput19LDataTextView = null;
        mIspuOutput19HDataTextView = null;
        mIspuOutput20LDataTextView = null;
        mIspuOutput20HDataTextView = null;
        mIspuOutput21LDataTextView = null;
        mIspuOutput21HDataTextView = null;
        mIspuOutput22LDataTextView = null;
        mIspuOutput22HDataTextView = null;
        mIspuOutput23LDataTextView = null;
        mIspuOutput23HDataTextView = null;
        mIspuOutput24LDataTextView = null;
        mIspuOutput24HDataTextView = null;
        mIspuOutput25LDataTextView = null;
        mIspuOutput25HDataTextView = null;
        mIspuOutput26LDataTextView = null;
        mIspuOutput26HDataTextView = null;
        mIspuOutput27LDataTextView = null;
        mIspuOutput27HDataTextView = null;
        mIspuOutput28LDataTextView = null;
        mIspuOutput28HDataTextView = null;
        mIspuOutput29LDataTextView = null;
        mIspuOutput29HDataTextView = null;
        mIspuOutput30LDataTextView = null;
        mIspuOutput30HDataTextView = null;
        mIspuOutput31LDataTextView = null;
        mIspuOutput31HDataTextView = null;
        mIspuOutMappedLinearLayout.removeAllViews();
        mIspuOutRegistersLinearLayout.removeAllViews();

        mMainLayout = null;
        if (mTimerUpdateUI != null)
        {
            mTimerUpdateUI.cancel();
            mTimerUpdateUI = null;
        }

        mIspuOutputValueArrayList.clear();
        mIspuOutputValueArrayList = null;
    }

    @SuppressLint("InflateParams")
    public CardView_ISPU(Context context) {
        super(context);

        LayoutInflater inflater = LayoutInflater.from(context);
        mMainLayout = (CardView) inflater.inflate(R.layout.cardview_ispu, null, false);

        prepareUI();
        addView(mMainLayout);
    }

    private void prepareUI()
    {
        String na = getResources().getString(R.string.na_string);

        mExpandCollapseButton = mMainLayout.findViewById(R.id.expandCollapseButton);

        mViewLayout = mMainLayout.findViewById(R.id.viewLayout);
        mIspuOutput00LDataTextView = mMainLayout.findViewById(R.id.ispuOutput00LDataTextView);
        mIspuOutput00HDataTextView = mMainLayout.findViewById(R.id.ispuOutput00HDataTextView);
        mIspuOutput01LDataTextView = mMainLayout.findViewById(R.id.ispuOutput01LDataTextView);
        mIspuOutput01HDataTextView = mMainLayout.findViewById(R.id.ispuOutput01HDataTextView);
        mIspuOutput02LDataTextView = mMainLayout.findViewById(R.id.ispuOutput02LDataTextView);
        mIspuOutput02HDataTextView = mMainLayout.findViewById(R.id.ispuOutput02HDataTextView);
        mIspuOutput03LDataTextView = mMainLayout.findViewById(R.id.ispuOutput03LDataTextView);
        mIspuOutput03HDataTextView = mMainLayout.findViewById(R.id.ispuOutput03HDataTextView);
        mIspuOutput04LDataTextView = mMainLayout.findViewById(R.id.ispuOutput04LDataTextView);
        mIspuOutput04HDataTextView = mMainLayout.findViewById(R.id.ispuOutput04HDataTextView);
        mIspuOutput05LDataTextView = mMainLayout.findViewById(R.id.ispuOutput05LDataTextView);
        mIspuOutput05HDataTextView = mMainLayout.findViewById(R.id.ispuOutput05HDataTextView);
        mIspuOutput06LDataTextView = mMainLayout.findViewById(R.id.ispuOutput06LDataTextView);
        mIspuOutput06HDataTextView = mMainLayout.findViewById(R.id.ispuOutput06HDataTextView);
        mIspuOutput07LDataTextView = mMainLayout.findViewById(R.id.ispuOutput07LDataTextView);
        mIspuOutput07HDataTextView = mMainLayout.findViewById(R.id.ispuOutput07HDataTextView);
        mIspuOutput08LDataTextView = mMainLayout.findViewById(R.id.ispuOutput08LDataTextView);
        mIspuOutput08HDataTextView = mMainLayout.findViewById(R.id.ispuOutput08HDataTextView);
        mIspuOutput09LDataTextView = mMainLayout.findViewById(R.id.ispuOutput09LDataTextView);
        mIspuOutput09HDataTextView = mMainLayout.findViewById(R.id.ispuOutput09HDataTextView);
        mIspuOutput10LDataTextView = mMainLayout.findViewById(R.id.ispuOutput10LDataTextView);
        mIspuOutput10HDataTextView = mMainLayout.findViewById(R.id.ispuOutput10HDataTextView);
        mIspuOutput11LDataTextView = mMainLayout.findViewById(R.id.ispuOutput11LDataTextView);
        mIspuOutput11HDataTextView = mMainLayout.findViewById(R.id.ispuOutput11HDataTextView);
        mIspuOutput12LDataTextView = mMainLayout.findViewById(R.id.ispuOutput12LDataTextView);
        mIspuOutput12HDataTextView = mMainLayout.findViewById(R.id.ispuOutput12HDataTextView);
        mIspuOutput13LDataTextView = mMainLayout.findViewById(R.id.ispuOutput13LDataTextView);
        mIspuOutput13HDataTextView = mMainLayout.findViewById(R.id.ispuOutput13HDataTextView);
        mIspuOutput14LDataTextView = mMainLayout.findViewById(R.id.ispuOutput14LDataTextView);
        mIspuOutput14HDataTextView = mMainLayout.findViewById(R.id.ispuOutput14HDataTextView);
        mIspuOutput15LDataTextView = mMainLayout.findViewById(R.id.ispuOutput15LDataTextView);
        mIspuOutput15HDataTextView = mMainLayout.findViewById(R.id.ispuOutput15HDataTextView);
        mIspuOutput16LDataTextView = mMainLayout.findViewById(R.id.ispuOutput16LDataTextView);
        mIspuOutput16HDataTextView = mMainLayout.findViewById(R.id.ispuOutput16HDataTextView);
        mIspuOutput17LDataTextView = mMainLayout.findViewById(R.id.ispuOutput17LDataTextView);
        mIspuOutput17HDataTextView = mMainLayout.findViewById(R.id.ispuOutput17HDataTextView);
        mIspuOutput18LDataTextView = mMainLayout.findViewById(R.id.ispuOutput18LDataTextView);
        mIspuOutput18HDataTextView = mMainLayout.findViewById(R.id.ispuOutput18HDataTextView);
        mIspuOutput19LDataTextView = mMainLayout.findViewById(R.id.ispuOutput19LDataTextView);
        mIspuOutput19HDataTextView = mMainLayout.findViewById(R.id.ispuOutput19HDataTextView);
        mIspuOutput20LDataTextView = mMainLayout.findViewById(R.id.ispuOutput20LDataTextView);
        mIspuOutput20HDataTextView = mMainLayout.findViewById(R.id.ispuOutput20HDataTextView);
        mIspuOutput21LDataTextView = mMainLayout.findViewById(R.id.ispuOutput21LDataTextView);
        mIspuOutput21HDataTextView = mMainLayout.findViewById(R.id.ispuOutput21HDataTextView);
        mIspuOutput22LDataTextView = mMainLayout.findViewById(R.id.ispuOutput22LDataTextView);
        mIspuOutput22HDataTextView = mMainLayout.findViewById(R.id.ispuOutput22HDataTextView);
        mIspuOutput23LDataTextView = mMainLayout.findViewById(R.id.ispuOutput23LDataTextView);
        mIspuOutput23HDataTextView = mMainLayout.findViewById(R.id.ispuOutput23HDataTextView);
        mIspuOutput24LDataTextView = mMainLayout.findViewById(R.id.ispuOutput24LDataTextView);
        mIspuOutput24HDataTextView = mMainLayout.findViewById(R.id.ispuOutput24HDataTextView);
        mIspuOutput25LDataTextView = mMainLayout.findViewById(R.id.ispuOutput25LDataTextView);
        mIspuOutput25HDataTextView = mMainLayout.findViewById(R.id.ispuOutput25HDataTextView);
        mIspuOutput26LDataTextView = mMainLayout.findViewById(R.id.ispuOutput26LDataTextView);
        mIspuOutput26HDataTextView = mMainLayout.findViewById(R.id.ispuOutput26HDataTextView);
        mIspuOutput27LDataTextView = mMainLayout.findViewById(R.id.ispuOutput27LDataTextView);
        mIspuOutput27HDataTextView = mMainLayout.findViewById(R.id.ispuOutput27HDataTextView);
        mIspuOutput28LDataTextView = mMainLayout.findViewById(R.id.ispuOutput28LDataTextView);
        mIspuOutput28HDataTextView = mMainLayout.findViewById(R.id.ispuOutput28HDataTextView);
        mIspuOutput29LDataTextView = mMainLayout.findViewById(R.id.ispuOutput29LDataTextView);
        mIspuOutput29HDataTextView = mMainLayout.findViewById(R.id.ispuOutput29HDataTextView);
        mIspuOutput30LDataTextView = mMainLayout.findViewById(R.id.ispuOutput30LDataTextView);
        mIspuOutput30HDataTextView = mMainLayout.findViewById(R.id.ispuOutput30HDataTextView);
        mIspuOutput31LDataTextView = mMainLayout.findViewById(R.id.ispuOutput31LDataTextView);
        mIspuOutput31HDataTextView = mMainLayout.findViewById(R.id.ispuOutput31HDataTextView);

        mIspuImageView = mMainLayout.findViewById(R.id.ispuImageView);
        mIspuOutMappedLinearLayout = mMainLayout.findViewById(R.id.ispuOutMappedLinearLayout);
        mIspuOutRegistersLinearLayout = mMainLayout.findViewById(R.id.ispuOutRegistersLinearLayout);

        // Initialize UI
        mIspuImageView.setColorFilter(ResourcesCompat.getColor(getResources(), R.color.color_blue, null), PorterDuff.Mode.SRC_IN);
        mIspuImageView.setImageResource(DemoFragment.getInstance().getSelectedDemo().getDemoIconID());

        mExpandCollapseButton.setOnClickListener(view -> {
            if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.collapse))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.expand));
                mViewLayout.setVisibility(GONE);
            } else if (mExpandCollapseButton.getText().toString().equals(getContext().getString(R.string.expand))) {
                mExpandCollapseButton.setText(getContext().getString(R.string.collapse));
                mViewLayout.setVisibility(VISIBLE);
            }
        });

        if (MyJson.isJsonFound())
        {
            float screenDensity = getResources().getDisplayMetrics().density;
            float textSize_4 = getResources().getDimension(R.dimen.single_demo_textsize_4) / screenDensity;

            mIspuOutRegistersLinearLayout.setVisibility(GONE);

            mIspuOutputValueArrayList.clear();
            for (int i = 0; i < MyJson.getMappedOutputLength(); i++)
            {
                View mIspuOutputView = LayoutInflater.from(getContext()).inflate(R.layout.ispu_output, null);
                mIspuOutMappedLinearLayout.addView(mIspuOutputView);

                TextView mIspuOutputNameTextView = mIspuOutputView.findViewById(R.id.ispuOutputNameTextView);
                mIspuOutputNameTextView.setText(MyJson.getOutputLabel(i));
                mIspuOutputNameTextView.setTextSize(textSize_4);

                TextView mIspuOutputValueTextView = mIspuOutputView.findViewById(R.id.ispuOutputValueTextView);
                mIspuOutputValueTextView.setTextSize(textSize_4);
                mIspuOutputValueArrayList.add(mIspuOutputValueTextView);
                mIspuOutputValueArrayList.get(i).setText(na);
            }
        }
        else
        {
            mIspuOutMappedLinearLayout.setVisibility(GONE);

            mIspuOutput00LDataTextView.setText(na);
            mIspuOutput00HDataTextView.setText(na);
            mIspuOutput01LDataTextView.setText(na);
            mIspuOutput01HDataTextView.setText(na);
            mIspuOutput02LDataTextView.setText(na);
            mIspuOutput02HDataTextView.setText(na);
            mIspuOutput03LDataTextView.setText(na);
            mIspuOutput03HDataTextView.setText(na);
            mIspuOutput04LDataTextView.setText(na);
            mIspuOutput04HDataTextView.setText(na);
            mIspuOutput05LDataTextView.setText(na);
            mIspuOutput05HDataTextView.setText(na);
            mIspuOutput06LDataTextView.setText(na);
            mIspuOutput06HDataTextView.setText(na);
            mIspuOutput07LDataTextView.setText(na);
            mIspuOutput07HDataTextView.setText(na);
            mIspuOutput08LDataTextView.setText(na);
            mIspuOutput08HDataTextView.setText(na);
            mIspuOutput09LDataTextView.setText(na);
            mIspuOutput09HDataTextView.setText(na);
            mIspuOutput10LDataTextView.setText(na);
            mIspuOutput10HDataTextView.setText(na);
            mIspuOutput11LDataTextView.setText(na);
            mIspuOutput11HDataTextView.setText(na);
            mIspuOutput12LDataTextView.setText(na);
            mIspuOutput12HDataTextView.setText(na);
            mIspuOutput13LDataTextView.setText(na);
            mIspuOutput13HDataTextView.setText(na);
            mIspuOutput14LDataTextView.setText(na);
            mIspuOutput14HDataTextView.setText(na);
            mIspuOutput15LDataTextView.setText(na);
            mIspuOutput15HDataTextView.setText(na);
            mIspuOutput16LDataTextView.setText(na);
            mIspuOutput16HDataTextView.setText(na);
            mIspuOutput17LDataTextView.setText(na);
            mIspuOutput17HDataTextView.setText(na);
            mIspuOutput18LDataTextView.setText(na);
            mIspuOutput18HDataTextView.setText(na);
            mIspuOutput19LDataTextView.setText(na);
            mIspuOutput19HDataTextView.setText(na);
            mIspuOutput20LDataTextView.setText(na);
            mIspuOutput20HDataTextView.setText(na);
            mIspuOutput21LDataTextView.setText(na);
            mIspuOutput21HDataTextView.setText(na);
            mIspuOutput22LDataTextView.setText(na);
            mIspuOutput22HDataTextView.setText(na);
            mIspuOutput23LDataTextView.setText(na);
            mIspuOutput23HDataTextView.setText(na);
            mIspuOutput24LDataTextView.setText(na);
            mIspuOutput24HDataTextView.setText(na);
            mIspuOutput25LDataTextView.setText(na);
            mIspuOutput25HDataTextView.setText(na);
            mIspuOutput26LDataTextView.setText(na);
            mIspuOutput26HDataTextView.setText(na);
            mIspuOutput27LDataTextView.setText(na);
            mIspuOutput27HDataTextView.setText(na);
            mIspuOutput28LDataTextView.setText(na);
            mIspuOutput28HDataTextView.setText(na);
            mIspuOutput29LDataTextView.setText(na);
            mIspuOutput29HDataTextView.setText(na);
            mIspuOutput30LDataTextView.setText(na);
            mIspuOutput30HDataTextView.setText(na);
            mIspuOutput31LDataTextView.setText(na);
            mIspuOutput31HDataTextView.setText(na);
        }
    }

    private void methodUITimer() {
        ((Activity) getContext()).runOnUiThread(() ->
        {
            try {
                if (mIspuPacketReceived)
                {
                    mIspuPacketReceived = false;

                    if (MyJson.isJsonFound()) {
                        for (int i = 0; i < MyJson.getMappedOutputLength(); i++)
                        {
                            mIspuOutputValueArrayList.get(i).setText(MyJson.getConvertedOutput(i));
                        }

                        // TODO: add a timer in Quaternion card
                        if (DemoFragment.getInstance().getSelectedDemo().getDemoUsage_FusionCard()) {
                            float qx = (float)MyJson.getConvertedOutputObject(0);
                            float qy = (float)MyJson.getConvertedOutputObject(1);
                            float qz = (float)MyJson.getConvertedOutputObject(2);
                            float qw = (float)MyJson.getConvertedOutputObject(3);

                            DemoFragment.getInstance().applyRotationToQuaternionCard(qx, qy, qz, qw);
                        }

                    } else {
                        mIspuOutput00LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(0)));
                        mIspuOutput00HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(1)));
                        mIspuOutput01LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(2)));
                        mIspuOutput01HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(3)));
                        mIspuOutput02LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(4)));
                        mIspuOutput02HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(5)));
                        mIspuOutput03LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(6)));
                        mIspuOutput03HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(7)));
                        mIspuOutput04LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(8)));
                        mIspuOutput04HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(9)));
                        mIspuOutput05LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(10)));
                        mIspuOutput05HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(11)));
                        mIspuOutput06LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(12)));
                        mIspuOutput06HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(13)));
                        mIspuOutput07LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(14)));
                        mIspuOutput07HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(15)));
                        mIspuOutput08LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(16)));
                        mIspuOutput08HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(17)));
                        mIspuOutput09LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(18)));
                        mIspuOutput09HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(19)));

                        if ( BluetoothLeService.mSupportedPacketLength > 20) {
                            mIspuOutput10LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(20)));
                            mIspuOutput10HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(21)));
                            mIspuOutput11LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(22)));
                            mIspuOutput11HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(23)));
                            mIspuOutput12LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(24)));
                            mIspuOutput12HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(25)));
                            mIspuOutput13LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(26)));
                            mIspuOutput13HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(27)));
                            mIspuOutput14LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(28)));
                            mIspuOutput14HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(29)));
                            mIspuOutput15LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(30)));
                            mIspuOutput15HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(31)));
                            mIspuOutput16LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(32)));
                            mIspuOutput16HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(33)));
                            mIspuOutput17LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(34)));
                            mIspuOutput17HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(35)));
                            mIspuOutput18LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(36)));
                            mIspuOutput18HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(37)));
                            mIspuOutput19LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(38)));
                            mIspuOutput19HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(39)));
                            mIspuOutput20LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(40)));
                            mIspuOutput20HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(41)));
                            mIspuOutput21LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(42)));
                            mIspuOutput21HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(43)));
                            mIspuOutput22LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(44)));
                            mIspuOutput22HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(45)));
                            mIspuOutput23LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(46)));
                            mIspuOutput23HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(47)));
                            mIspuOutput24LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(48)));
                            mIspuOutput24HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(49)));
                            mIspuOutput25LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(50)));
                            mIspuOutput25HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(51)));
                            mIspuOutput26LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(52)));
                            mIspuOutput26HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(53)));
                            mIspuOutput27LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(54)));
                            mIspuOutput27HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(55)));
                            mIspuOutput28LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(56)));
                            mIspuOutput28HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(57)));
                            mIspuOutput29LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(58)));
                            mIspuOutput29HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(59)));
                            mIspuOutput30LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(60)));
                            mIspuOutput30HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(61)));
                            mIspuOutput31LDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(62)));
                            mIspuOutput31HDataTextView.setText(String.format("%02x", MyMotionData.ispu_dout.get(63)));
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}

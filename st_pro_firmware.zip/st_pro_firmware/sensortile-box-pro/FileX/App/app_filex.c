/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    app_filex.c
  * @author  MCD Application Team
  * @brief   FileX applicative file
  ******************************************************************************
   * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "app_filex.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "BLE_Manager.h"
#include "app_threadx.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
extern ctrl_t ctrl;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
#define FILENAME_SIZE   64
#define DEFAULT_FILE_NAME "sensortile-box-"
#define WRITE_LINE_SIZE 512

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
TX_THREAD thread_sd_card;
FX_MEDIA sd_card_media;
TX_QUEUE queue_sd;
__ALIGN_BEGIN static UCHAR sdlog_cmd_byte_short_pool_buffer[SDLOG_CMD_SHORT_POOL_SIZE] __ALIGN_END;
TX_BYTE_POOL sdlog_cmd_byte_short_pool;
__ALIGN_BEGIN static UCHAR sdlog_cmd_byte_long_pool_buffer[SDLOG_CMD_LONG_POOL_SIZE] __ALIGN_END;
TX_BYTE_POOL sdlog_cmd_byte_long_pool;
FX_FILE fx_logfile;

enum {
  SD_START = 0,
  SD_STOP = 1
} sd_state;

static char filename[FILENAME_SIZE];
static char user[20];
static char demo[20];
static char clas[20];

ALIGN_32BYTES (uint32_t media_memory[4096 / sizeof(uint32_t)]);

static uint32_t sd_log_cmd_processed;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
static void thread_sd_card_entry(ULONG thread_input);

static void sd_set_user(const char str[])
{
  strcpy(user, str);
}

static void sd_set_demo(const char str[])
{
  strcpy(demo, str);
}

static void sd_set_class(const char str[])
{
  strcpy(clas, str);
}

static void sd_clear_user(void)
{
  user[0] = 0;
}

static void sd_clear_demo(void)
{
  demo[0] = 0;
}

static void sd_clear_class(void)
{
  clas[0] = 0;
}

static void sd_clear_all(void)
{
  sd_clear_user();
  sd_clear_demo();
  sd_clear_class();
}

static void build_filename(char *str)
{
  char tmp[20 + 1];

  str[0] = 0;

  if (user[0] == 0 && demo[0] == 0 && clas[0] == 0) {
    strcat(str, DEFAULT_FILE_NAME);
  } else {

    if (user[0] != 0) {
      tmp[0] = 0;
      strcat(tmp, user);
      strcat(tmp, "_");
      strcat(str, tmp);
    }

    if (demo[0] != 0) {
      tmp[0] = 0;
      strcat(tmp, demo);
      strcat(tmp, "_");
      strcat(str, tmp);
    }

    if (clas[0] != 0) {
      tmp[0] = 0;
      strcat(tmp, clas);
      strcat(tmp, "_");
      strcat(str, tmp);
    }
  }
}

static void sd_start_log(void)
{
  char suffix[FILENAME_SIZE];
  uint16_t file_idx = 0;
  UINT ret = FX_SUCCESS;

  suffix[0] = 0;
  build_filename(suffix);

  do {
    sprintf(filename, "%s%03d.txt", suffix, file_idx++);
    ret = fx_file_create(&sd_card_media, filename);
    if (ret != FX_SUCCESS && ret != FX_ALREADY_CREATED) {
      goto err;
    }
  } while (ret != FX_SUCCESS);

  ret = fx_file_open(&sd_card_media, &fx_logfile, filename, FX_OPEN_FOR_WRITE);
  if (ret != FX_SUCCESS) {
    goto err;
  }

  /* write header */
  //res = f_write(&file, header, strlen(header), &bytes);

  sd_state = SD_START;
  printf("%s: file created/opened successfully(%s)\n", __func__, filename);
  return;

err:
  printf("%s: error\n", __func__);
}

static void sd_stop_log(void)
{
  UINT ret = FX_SUCCESS;

  ret = fx_file_close(&fx_logfile);
  if (ret != FX_SUCCESS) {
    printf("%s: file close error (%s)\n", __func__, filename);
  }

  fx_media_flush(&sd_card_media);

  sd_state = SD_STOP;
  printf("%s: file closed successfully(%s)\n", __func__, filename);
}

static void sd_log(char *log_msgp)
{
  UINT ret = FX_SUCCESS;

  if (sd_state != SD_START) {
    printf("%s: SD not started (%s)\n", __func__, log_msgp);
    return; /* LOGFILE not opened */
  }

  ret = fx_file_write(&fx_logfile, log_msgp, strlen(log_msgp));
  if (ret != FX_SUCCESS) {
    printf("%s: file write error (%s)\n", __func__, filename);
    return;
  }

  //printf("%s: log_msg = %s\n", __func__, log_msgp);
}

static void sd_set_fsync(void)
{
  fx_media_flush(&sd_card_media);
  printf("%s: media flush\n", __func__);
}

uint8_t SD_is_started(void)
{
  return (sd_state == SD_START) ? 1 : 0;
}

static void update_date_time(UINT year, UINT month, UINT day, UINT hour, UINT minute, UINT second)
{
  if (fx_system_date_set(year, month, day) != FX_SUCCESS) {
    printf("bad date: %d\t%d\t%d\n", year, month, day);
    return;
  }

  if (fx_system_time_set(hour, minute, second) != FX_SUCCESS) {
    printf("bad time: %d\t%d\t%d\n", hour, minute, second);
    return;
  }
}

/* USER CODE END PFP */

/**
  * @brief  Application FileX Initialization.
  * @param memory_ptr: memory pointer
  * @retval int
  */
UINT MX_FileX_Init(VOID *memory_ptr)
{
  UINT ret = FX_SUCCESS;
  TX_BYTE_POOL *byte_pool = (TX_BYTE_POOL*)memory_ptr;

  /* USER CODE BEGIN App_FileX_MEM_POOL */
  (void)byte_pool;
  /* USER CODE END App_FileX_MEM_POOL */

  /* USER CODE BEGIN MX_FileX_Init */
  CHAR *pointer;

  sd_state = SD_STOP;

  /* Initialize FileX.  */
  fx_system_initialize();

  /* Set initial FileX date and time */
  update_date_time(1990, 4, 3, 23, 00, 00);

  tx_byte_allocate(byte_pool, (void **)&pointer, SD_QUEUE_SIZE * SD_QUEUE_MSG_SIZE, TX_NO_WAIT);
  tx_queue_create(&queue_sd, "queue SD cmd", TX_2_ULONG, pointer, SD_QUEUE_SIZE * SD_QUEUE_MSG_SIZE);

  tx_byte_allocate(byte_pool, (void **)&pointer, 4096, TX_NO_WAIT);
  tx_thread_create(&thread_sd_card, "thread SD card", thread_sd_card_entry, 0,
                   pointer, 4096, APP_THREAD_FILEX_SD_PRIORITY,
                   APP_THREAD_FILEX_SD_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);
  tx_byte_pool_create(&sdlog_cmd_byte_short_pool, "sd-log commands short memory pool",
                      sdlog_cmd_byte_short_pool_buffer, SDLOG_CMD_SHORT_POOL_SIZE);
  tx_byte_pool_create(&sdlog_cmd_byte_long_pool, "sd-log commands memory long pool",
                      sdlog_cmd_byte_long_pool_buffer, SDLOG_CMD_LONG_POOL_SIZE);
  /* USER CODE END MX_FileX_Init */

  return ret;
}

/* USER CODE BEGIN 1 */
VOID  fx_stm32_sd_driver(FX_MEDIA *media_ptr);

static void thread_sd_card_entry(ULONG thread_input)
{
  struct sd_queue_msg sd_cmd;
  TX_THREAD *thread = tx_thread_identify();
  char *thread_name;
  UINT ret;

  tx_thread_info_get(thread, &thread_name, TX_NULL, TX_NULL, TX_NULL, TX_NULL, TX_NULL, TX_NULL, TX_NULL);

  ret = fx_media_open(&sd_card_media, "STBOX-LOG", fx_stm32_sd_driver,
                      0,(VOID *) media_memory, sizeof(media_memory));
  if (ret != FX_SUCCESS) {
    /* media open error */
    printf("SD CARD not found\n");
    ctrl.sd_err = 1;
    tx_thread_sleep(TX_WAIT_FOREVER);
  }

  while(1) {
    ret = tx_queue_receive(&queue_sd, &sd_cmd, TX_WAIT_FOREVER);
    if (ret != TX_SUCCESS) {
      printf("%s: tx_queue_receive error\n", __func__);
      continue;
    }

    /* Parse Command */
    switch(sd_cmd.cmd) {
    case SD_LOG_RESET:
      sd_clear_all();
      break;
    case SD_LOG_START:
      sd_start_log();
      break;
    case SD_LOG_STOP:
      sd_stop_log();
      break;
    case SD_LOG_RUN:
      {
        char *log_msg = (char *)sd_cmd.datap;
        sd_log(log_msg);
        tx_byte_release(log_msg);
        sd_log_cmd_processed++;
      }
      break;
    case SD_LOG_SET_USER:
      {
        char *user = (char *)sd_cmd.datap;
        sd_set_user(user);
        printf("%s: user = %s\n", __func__, user);
        tx_byte_release(user);
      }
      break;
    case SD_LOG_SET_DEMO:
      {
        char *demo = (char *)sd_cmd.datap;
        sd_set_demo(demo);
        printf("%s: demo = %s\n", __func__, demo);
        tx_byte_release(demo);
      }
      break;
    case SD_LOG_SET_CLASS:
      {
        char *class = (char *)sd_cmd.datap;
        sd_set_class(class);
        printf("%s: class = %s\n", __func__, class);
        tx_byte_release(class);
      }
      break;
    case SD_LOG_CLR_USER:
      sd_clear_user();
      printf("%s: clear-user\n", __func__);
      break;
    case SD_LOG_CLR_DEMO:
      sd_clear_demo();
      printf("%s: clear-demo\n", __func__);
      break;
    case SD_LOG_CLR_CLASS:
      sd_clear_class();
      printf("%s: clear-class\n", __func__);
      break;
    case SD_LOG_FSYNC:
      sd_set_fsync();
      printf("%s: fsync\n", __func__);
      break;
    case SD_LOG_FILEX_DATE:
      {
        UINT year;
        UINT month;
        UINT day;
        UINT hour;
        UINT minute;
        UINT second;
        char *date_str = (char *)sd_cmd.datap;

        sscanf(date_str, "%04u%02u%02u%02u%02u%02u",
               &year, &month, &day, &hour, &minute, &second);

        update_date_time(year, month, day, hour, minute, second);
        printf("%s: date = %s\n", __func__, date_str);
        tx_byte_release(date_str);
      }
      break;
   }
  }
}
/* USER CODE END 1 */

#ifndef _VERSION_H_
#define _VERSION_H_

#define MAJOR 1
#define MINOR 4
#define PATCH 0

#define SENSORTILE_BOX_PRO_ID 5

#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)
#define VERSION_STRING  "Sensortile.box-pro v" TOSTRING(MAJOR) "." TOSTRING(MINOR) "." TOSTRING(PATCH) "\n"

#endif /* _VERSION_H_ */

/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    app_threadx.h
  * @author  MCD Application Team
  * @brief   ThreadX applicative header file
  ******************************************************************************
    * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APP_THREADX_H
#define __APP_THREADX_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "tx_api.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdint.h>

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
extern TX_QUEUE queue_cmd;
extern TX_QUEUE queue_print;
extern TX_EVENT_FLAGS_GROUP spi3_dma_rx_completed;
extern TX_EVENT_FLAGS_GROUP spi3_dma_tx_completed;
extern TX_EVENT_FLAGS_GROUP spi2_dma_rx_completed;
extern TX_EVENT_FLAGS_GROUP spi2_dma_tx_completed;
extern TX_EVENT_FLAGS_GROUP i2c1_dma_tx_completed;
extern TX_EVENT_FLAGS_GROUP i2c1_dma_rx_completed;
extern TX_EVENT_FLAGS_GROUP i2c4_dma_tx_completed;
extern TX_EVENT_FLAGS_GROUP i2c4_dma_rx_completed;
extern TX_MUTEX spi3_mutex;
extern TX_MUTEX i2c1_mutex;
extern TX_MUTEX spi2_mutex;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */
#define CMD_QUEUE_SIZE 10
#define CMD_QUEUE_MSG_SIZE (TX_1_ULONG * sizeof(ULONG))
#define QUEUE_PRINT_SIZE 10
#define QUEUE_PRINT_MSG_SIZE (TX_1_ULONG * sizeof(ULONG))

#define APP_THREAD_USBX_PRIORITY              UX_THREAD_PRIORITY_CLASS
#define APP_THREAD_FILEX_SD_PRIORITY          3
#define APP_THREAD_CMD_PARSER_PRIORITY        2
#define APP_THREAD_BLE_PRIORITY               2
#define APP_THREAD_BATTERY_PRIORITY          20
#define APP_THREAD_SENSOR_EVENT_PRIORITY      1
#define APP_THREAD_SENSOR_DATA_PRIORITY       1

struct log_conf {
  uint8_t accel_en;
  uint8_t gyro_en;
  uint8_t temp_en;
  uint8_t mlc_en;
  uint8_t mlc_num;
  uint8_t fsm_en;
  uint8_t fsm_outs_en[4];
  uint8_t int_en;
  uint8_t pedo_en;
  uint8_t ah_qvar_en;
  uint8_t sflp_quat_en;
  uint8_t sflp_grav_en;
  uint8_t sflp_gbias_en;
  float acc_sens;
  float gyr_sens;
  float grav_sens;
  float gbias_sens;
  uint8_t mag_en;
  uint8_t press_en;
  uint8_t temperature_en;
  uint8_t algo_en;
  uint8_t audio_en;
};

struct fifo_data {
  uint64_t timestamp;
  int16_t accel[3];
  int16_t gyro[3];
  int16_t temp;
  int16_t ah_qvar;
  // algorithm data
  int16_t mag[3];
  uint32_t press;
  int16_t temperature;
  uint32_t algo; // shared between different algos
};

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
UINT App_ThreadX_Init(VOID *memory_ptr);
void MX_ThreadX_Init(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

#ifdef __cplusplus
}
#endif
#endif /* __APP_THREADX_H__ */

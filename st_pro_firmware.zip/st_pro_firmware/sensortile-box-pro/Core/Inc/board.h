#ifndef _BOARD_H_
#define _BOARD_H_

#include <stdint.h>

#define led_green_on()          HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET)
#define led_green_off()         HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET)
#define led_green_toggle()      HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin)
#define led_red_on()            HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET)
#define led_red_off()           HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET)
#define led_red_toggle()        HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin)
#define led_yellow_on()         HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_SET)
#define led_yellow_off()        HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, GPIO_PIN_RESET)
#define led_yellow_toggle()     HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin)
#define led_blue_on()           HAL_GPIO_WritePin(USB_enum_LED_GPIO_Port, USB_enum_LED_Pin, GPIO_PIN_SET)
#define led_blue_off()          HAL_GPIO_WritePin(USB_enum_LED_GPIO_Port, USB_enum_LED_Pin, GPIO_PIN_RESET)
#define led_blue_toggle()       HAL_GPIO_TogglePin(USB_enum_LED_GPIO_Port, USB_enum_LED_Pin)
#define dil_int1_enable()       HAL_NVIC_EnableIRQ(DIL_INT1_EXTI_IRQn)
#define dil_int1_disable()      HAL_NVIC_DisableIRQ(DIL_INT1_EXTI_IRQn)
#define dil_int2_enable()       HAL_NVIC_EnableIRQ(DIL_INT2_EXTI_IRQn)
#define dil_int2_disable()      HAL_NVIC_DisableIRQ(DIL_INT2_EXTI_IRQn)
#define dil_int3_enable()       HAL_NVIC_EnableIRQ(DIL_INT3_EXTI_IRQn)
#define dil_int3_disable()      HAL_NVIC_DisableIRQ(DIL_INT3_EXTI_IRQn)
#define buz_on()                HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3)
#define buz_off()               HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_3)

int32_t read_dil(uint8_t addr, void *val, uint16_t len);
int32_t write_dil(uint8_t addr, uint8_t val);

void buz_play(const int *melody, const int *durations, int len);
void tone(uint16_t note, uint16_t duration);

#endif /* _BOARD_H_ */

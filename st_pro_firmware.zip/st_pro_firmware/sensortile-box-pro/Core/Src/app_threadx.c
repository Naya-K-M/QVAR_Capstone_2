/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    app_threadx.c
  * @author  MCD Application Team
  * @brief   ThreadX applicative file
  ******************************************************************************
    * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "app_threadx.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdint.h>
#include <stdio.h>
#include "spi.h"
#include "gpio.h"
#include "tim.h"
#include "board.h"
#include "sensors.h"
#include "battery.h"
#include "BLE_Manager.h"
#include "version.h"
#include "unzip.h"
#include "app_filex.h"
#include "game_of_thrones.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define TX_PRINT_MEM_POOL_SIZE 4096
#define CMD_POOL_SIZE (128 * 10)
#define THREAD_BATTERY_SLEEP 5000
#define THREAD_BLE_SLEEP 1
#define LED_TIME 200
#define BUZ_TIME 200

extern ctrl_t ctrl;
extern motion_t motion;

static uint8_t led_mask[5]; /* fsm, mlc, all_int, emb_func_status, algo */
static uint8_t buz_mask[5]; /* fsm, mlc, all_int, emb_func_status, algo */
static uint8_t algo_sel;
static struct sensor *sensor;

static enum {
  LOG_SM_IDLE = 0,
  LOG_SM_RUNNING,
} log_state;

enum log_sm_cmd {
  LOG_CMD_START = 0,
  LOG_CMD_LOG,
  LOG_CMD_STOP,
  LOG_RUNNING,
};

static struct log_conf log_conf;
static struct fifo_data data;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */
#if defined ( __ICCARM__ )
#pragma data_alignment=4
#endif
__ALIGN_BEGIN static UCHAR tx_print_byte_pool_buffer[TX_PRINT_MEM_POOL_SIZE] __ALIGN_END;
TX_BYTE_POOL tx_print_byte_pool;

__ALIGN_BEGIN static UCHAR cmd_byte_pool_buffer[CMD_POOL_SIZE] __ALIGN_END;
TX_BYTE_POOL cmd_byte_pool;

TX_THREAD thread_sensor_event;
TX_THREAD thread_sensor_data;
TX_THREAD thread_battery;
TX_THREAD thread_ble;
TX_THREAD cmd_parser;
TX_EVENT_FLAGS_GROUP event_flags_hci;
TX_EVENT_FLAGS_GROUP event_flags_lsm6dsv16x_int1;

#define WAKE_EVENT_THREAD_EV_0    0x1 /* motion data must be read from device */
#define WAKE_EVENT_THREAD_EV_1    0x2 /* motion event data already read from device */
TX_EVENT_FLAGS_GROUP event_flags_dil_events;
#define WAKE_DATA_THREAD_EV_0     0x1
TX_EVENT_FLAGS_GROUP event_flags_dil_data;

TX_EVENT_FLAGS_GROUP spi3_dma_rx_completed;
TX_EVENT_FLAGS_GROUP spi3_dma_tx_completed;
TX_EVENT_FLAGS_GROUP spi2_dma_rx_completed;
TX_EVENT_FLAGS_GROUP spi2_dma_tx_completed;
TX_EVENT_FLAGS_GROUP i2c1_dma_tx_completed;
TX_EVENT_FLAGS_GROUP i2c1_dma_rx_completed;
TX_EVENT_FLAGS_GROUP i2c4_dma_tx_completed;
TX_EVENT_FLAGS_GROUP i2c4_dma_rx_completed;
TX_MUTEX spi3_mutex;
TX_MUTEX i2c1_mutex;
TX_MUTEX spi2_mutex;
TX_QUEUE queue_cmd;
TX_QUEUE queue_print;
TX_TIMER led_timer;
TX_TIMER buz_timer;
TX_TIMER ble_timer;

static uint32_t sd_log_cmd_sent;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */
void lsm6dsv16x_int1_cb(void)
{
  if (log_state != LOG_SM_IDLE)
    return;

  tx_event_flags_set(&event_flags_lsm6dsv16x_int1, 0x1, TX_OR);
}

void dil_int1_cb(void)
{
  if (log_state != LOG_SM_IDLE)
    return;

  tx_event_flags_set(&event_flags_dil_events, WAKE_EVENT_THREAD_EV_0, TX_OR);
}

void dil_int2_cb(void)
{
  tx_event_flags_set(&event_flags_dil_data, WAKE_DATA_THREAD_EV_0, TX_OR);
}

void dil_int3_cb(void)
{
  if (log_state != LOG_SM_IDLE) {
    tx_event_flags_set(&event_flags_dil_data, WAKE_DATA_THREAD_EV_0, TX_OR);
    return;
  }

  tx_event_flags_set(&event_flags_dil_events, WAKE_EVENT_THREAD_EV_0, TX_OR);
}

static void led_timer_cb(ULONG input)
{
  led_green_off();
  tx_timer_deactivate(&led_timer);
}

static void buz_timer_cb(ULONG input)
{
  buz_off();
  tx_timer_deactivate(&buz_timer);
}

static void update_led(void)
{
  switch (ctrl.dil24_whoami) {
  case SUNCHON_ID:
    led_green_toggle();
    break;
  default:
    if ((motion.fsm & led_mask[0]) ||
        (motion.mlc & led_mask[1]) ||
        (motion.hw_int & led_mask[2]) ||
        (motion.emb_func_status & led_mask[3]) ||
        (algo_sel && led_mask[4])) {
          tx_timer_deactivate(&led_timer);
          led_green_on();
          tx_timer_activate(&led_timer);
    }
    break;
  }
}

static void update_buz(void)
{
  switch (ctrl.dil24_whoami) {
  case SUNCHON_ID:
    // not supported
    break;
  default:
    if ((motion.fsm & buz_mask[0]) ||
        (motion.mlc & buz_mask[1]) ||
        (motion.hw_int & buz_mask[2]) ||
        (motion.emb_func_status & buz_mask[3]) ||
        (algo_sel && buz_mask[4])) {
          tx_timer_deactivate(&buz_timer);
          buz_on();
          tx_timer_activate(&buz_timer);
    }
    break;
  }
}

static char temp_log_buf[4096];
static int generate_header(char **header)
{
  temp_log_buf[0] = 0;
  int len;

  strcat(temp_log_buf, "Timestamp [us]\t");

  if (log_conf.accel_en)
    strcat(temp_log_buf, "A_X [LSB]\tA_Y [LSB]\tA_Z [LSB]\tA_X [mg]\tA_Y [mg]\tA_Z [mg]\t");

  if (log_conf.gyro_en)
    strcat(temp_log_buf, "G_X [LSB]\tG_Y [LSB]\tG_Z [LSB]\tG_X [dps]\tG_Y [dps]\tG_Z [dps]\t");

  if (log_conf.temp_en)
    strcat(temp_log_buf, "T [LSB]\tT [degC]\t");

  if (log_conf.ah_qvar_en)
    strcat(temp_log_buf, "QVAR [LSB]\t");

  if (log_conf.fsm_en)
    strcat(temp_log_buf, "FSM_STATUS\t");

  if (log_conf.fsm_outs_en[0])
    strcat(temp_log_buf, "FSM_OUTS1\t");

  if (log_conf.fsm_outs_en[1])
    strcat(temp_log_buf, "FSM_OUTS2\t");

  if (log_conf.fsm_outs_en[2])
    strcat(temp_log_buf, "FSM_OUTS3\t");

  if (log_conf.fsm_outs_en[3])
    strcat(temp_log_buf, "FSM_OUTS4\t");

  if (log_conf.mlc_en) {
    switch (log_conf.mlc_num) {
    case 0:
      strcat(temp_log_buf, "MLC_STATUS\tMLC0_SRC\t");
      break;
    case 1:
      strcat(temp_log_buf, "MLC_STATUS\tMLC0_SRC\tMLC1_SRC\t");
      break;
    case 2:
      strcat(temp_log_buf, "MLC_STATUS\tMLC0_SRC\tMLC1_SRC\tMLC2_SRC\t");
      break;
    case 3:
      strcat(temp_log_buf, "MLC_STATUS\tMLC0_SRC\tMLC1_SRC\tMLC2_SRC\tMLC3_SRC\t");
      break;
    default:
      strcat(temp_log_buf, "MLC_STATUS\tMLC0_SRC\tMLC1_SRC\tMLC2_SRC\tMLC3_SRC\t");
      break;
    }
  }

  if (log_conf.pedo_en)
    strcat(temp_log_buf, "STEP_COUNTER\t");

  if (log_conf.int_en)
    strcat(temp_log_buf, "ALL_INT_SRC\t");

  if (log_conf.sflp_quat_en)
    strcat(temp_log_buf, "QUAT_X\tQUAT_Y\tQUAT_Z\tQUAT_W\t");

  if (log_conf.sflp_grav_en)
    strcat(temp_log_buf, "GRAV_X [g]\tGRAV_Y [g]\tGRAV_Z [g]\t");

  if (log_conf.sflp_gbias_en)
    strcat(temp_log_buf, "GBIAS_X [dps]\tGBIAS_Y [dps]\tGBIAS_Z [dps]\t");

  if (log_conf.mag_en)
    strcat(temp_log_buf, "M_X [G]\tM_Y [G]\tM_Z [G]\t");

  if (log_conf.press_en)
    strcat(temp_log_buf, "P [LSB]\tP [hPa]\t");

  if (log_conf.temperature_en)
    strcat(temp_log_buf, "T [LSB]\tT [degC]\t");

  strcat(temp_log_buf, "\n");

  len = strlen(temp_log_buf) + 1;

  if (tx_byte_allocate(&sdlog_cmd_byte_long_pool, (void **)header,
                       len, TX_NO_WAIT) != TX_SUCCESS) {
    printf("%s cannot store command in the sd_log cmd long byte pool\n", __func__);
    return -1;
  }

  strncpy(*header, temp_log_buf, len);
  return 0;
}

static int generate_datalog(char **logmsg)
{
  uint16_t i = 0;
  int len;

  temp_log_buf[i] = 0;

  i+= sprintf(&temp_log_buf[i], "%llu\t", data.timestamp);

  if (log_conf.accel_en)
    i += sprintf(&temp_log_buf[i], "%d\t%d\t%d\t%.3f\t%.3f\t%.3f\t", data.accel[0], data.accel[1], data.accel[2],
                   data.accel[0] * log_conf.acc_sens, data.accel[1] * log_conf.acc_sens, data.accel[2] * log_conf.acc_sens);

  if (log_conf.gyro_en)
    i += sprintf(&temp_log_buf[i], "%d\t%d\t%d\t%.3f\t%.3f\t%.3f\t", data.gyro[0], data.gyro[1], data.gyro[2],
                   data.gyro[0] * log_conf.gyr_sens, data.gyro[1] * log_conf.gyr_sens, data.gyro[2] * log_conf.gyr_sens);

  if (log_conf.temp_en)
    i += sprintf(&temp_log_buf[i], "%d\t%.3f\t", data.temp, data.temp / 256.0f + 25.0f);

  if (log_conf.ah_qvar_en)
    i += sprintf(&temp_log_buf[i], "%d\t", data.ah_qvar);

  if (log_conf.fsm_en)
    i += sprintf(&temp_log_buf[i], "%02X\t", motion.fsm);

  for (uint8_t j = 0; j < 4; j++) {
    if (log_conf.fsm_outs_en[j])
      i += sprintf(&temp_log_buf[i], "%02X\t", motion.fsm_outs[j]);
  }

  if (log_conf.mlc_en) {
    switch (log_conf.mlc_num) {
    case 0:
      i += sprintf(&temp_log_buf[i], "%02X\t%02X\t", motion.mlc, motion.mlc_src[0]);
      break;
    case 1:
      i += sprintf(&temp_log_buf[i], "%02X\t%02X\t%02X\t", motion.mlc, motion.mlc_src[0], motion.mlc_src[1]);
      break;
    case 2:
      i += sprintf(&temp_log_buf[i], "%02X\t%02X\t%02X\t%02X\t", motion.mlc, motion.mlc_src[0], motion.mlc_src[1], motion.mlc_src[2]);
      break;
    case 3:
      i += sprintf(&temp_log_buf[i], "%02X\t%02X\t%02X\t%02X\t%02X\t", motion.mlc, motion.mlc_src[0], motion.mlc_src[1], motion.mlc_src[2], motion.mlc_src[3]);
      break;
    default:
      i += sprintf(&temp_log_buf[i], "%02X\t%02X\t%02X\t%02X\t%02X\t", motion.mlc, motion.mlc_src[0], motion.mlc_src[1], motion.mlc_src[2], motion.mlc_src[3]);
      break;
    }
  }

  if (log_conf.pedo_en)
    i += sprintf(&temp_log_buf[i], "%u\t", motion.steps);

  if (log_conf.int_en)
    i += sprintf(&temp_log_buf[i], "%02X\t", motion.all_int);

  if (log_conf.sflp_quat_en)
    i += sprintf(&temp_log_buf[i], "%f\t%f\t%f\t%f\t", motion.quat[0], motion.quat[1], motion.quat[2], motion.quat[3]);

  if (log_conf.sflp_grav_en)
    i += sprintf(&temp_log_buf[i], "%f\t%f\t%f\t", motion.gravity[0] * log_conf.grav_sens, motion.gravity[1] * log_conf.grav_sens, motion.gravity[2] * log_conf.grav_sens);

  if (log_conf.sflp_gbias_en)
    i += sprintf(&temp_log_buf[i], "%f\t%f\t%f\t", motion.gbias[0] * log_conf.gbias_sens, motion.gbias[1] * log_conf.gbias_sens, motion.gbias[2] * log_conf.gbias_sens);

  if (log_conf.mag_en)
    i += sprintf(&temp_log_buf[i], "%.1f\t%.1f\t%.1f\t", data.mag[0] * 1.5f, data.mag[1] * 1.5f, data.mag[2] * 1.5f);

  if (log_conf.press_en)
    i += sprintf(&temp_log_buf[i], "%d\t%.6f\t", data.press, data.press / 4096.0f);

  if (log_conf.temperature_en)
    i += sprintf(&temp_log_buf[i], "%d\t%.2f\t", data.temperature, data.temperature * 0.01f);

#if 0
  if (log_conf.algo_en)
    i += sprintf(&temp_log_buf[i], "%u\t", data.algo);
#endif

  i += sprintf(&temp_log_buf[i], "\n");

  /* calculate total log line length */
  len = strlen(temp_log_buf) + 1;

  if (tx_byte_allocate(&sdlog_cmd_byte_long_pool, (void **)logmsg,
                       len, TX_NO_WAIT) != TX_SUCCESS) {
    printf("%s cannot store command in the sd_log cmd long byte pool\n", __func__);
    return -1;
  }

  strncpy(*logmsg, temp_log_buf, len);
  return 0;
}

static void log_sm(enum log_sm_cmd cmd)
{
  struct sd_queue_msg sd_cmd;
  CHAR *ptr;

  switch(log_state) {
  case LOG_SM_IDLE:
    if (cmd == LOG_CMD_START) {
      sd_cmd.cmd = SD_LOG_START;
      tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);

      if (sensor->get_op_state(&log_conf) != 0) {
        printf("%s cannot get sensor state\n", __func__);
        break;
      }

      if (mag_sensor.get_op_state(&log_conf) != 0) {
        printf("%s cannot get mag sensor state\n", __func__);
        break;
      }

      if (env_sensor.get_op_state(&log_conf) != 0) {
        printf("%s cannot get env sensor state\n", __func__);
        break;
      }

      if (generate_header(&ptr) < 0)
        break;

      sd_cmd.cmd = SD_LOG_RUN;
      sd_cmd.datap = (void *)ptr;
      tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      ctrl.log = 1;
      BLE_CtrlUpdate((void*)&ctrl.byte);

      data.timestamp = 0;
      timer_reset();

      log_state = LOG_SM_RUNNING;
      sensor->start_data(1);

      led_red_on();
    }
    break;
  case LOG_SM_RUNNING:
    if (cmd == LOG_CMD_LOG) {
      if (generate_datalog(&ptr) < 0 )
        break;
      sd_cmd.cmd = SD_LOG_RUN;
      sd_cmd.datap = (void *)ptr;
      if (tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT)) {
        printf("%s cannot send command for the sd_log cmd long byte pool\n", __func__);
        break;
      }
      sd_log_cmd_sent++;
    } else if (cmd == LOG_CMD_STOP) {
      sensor->start_data(0);
      ctrl.log = 0;
      BLE_CtrlUpdate((void*)&ctrl.byte);
      log_state = LOG_SM_IDLE;

      sd_cmd.cmd = SD_LOG_STOP;
      tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);

      led_red_off();
    }

    break;
  }
}

static void update_data(void)
{
  data.timestamp += timer_get();
  timer_reset();
  sensor->get_data(&data);
  mag_sensor.get_data(&data);
  env_sensor.get_data(&data);
}

static void thread_sensor_event_entry(ULONG thread_input)
{
  UINT status;
  ULONG actual_flags;

  tx_timer_create(&led_timer, "led_timer", led_timer_cb, 0x1, LED_TIME, LED_TIME, TX_NO_ACTIVATE);
  tx_timer_create(&buz_timer, "buz_timer", buz_timer_cb, 0x1, BUZ_TIME, BUZ_TIME, TX_NO_ACTIVATE);

  while(1) {
    /* wait for events 0 and 1 */
    status = tx_event_flags_get(&event_flags_dil_events,
                                WAKE_EVENT_THREAD_EV_0 | WAKE_EVENT_THREAD_EV_1,
                                TX_OR_CLEAR, &actual_flags, TX_WAIT_FOREVER);

    if (status != TX_SUCCESS)
      continue;

    if (actual_flags & WAKE_EVENT_THREAD_EV_0)
      sensor->get_motion_events(&motion);

    update_led();
    update_buz();

    if (BLE_Is_Connected())
      BLE_MotionUpdate((void*)&motion.byte);
  }
}

static void thread_sensor_data_entry(ULONG thread_input)
{
  UINT status;
  ULONG actual_flags;

  tx_thread_sleep(20); // wait for sensor boot

  sensor_init(&sensor, &ctrl.dil24_whoami, &ctrl.dil24_rev);

  sensor->reset();
  mag_sensor.reset();
  env_sensor.reset();
  log_state = LOG_SM_IDLE;
  timer_start();

  while(1) {
    status = tx_event_flags_get(&event_flags_dil_data, WAKE_DATA_THREAD_EV_0, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);

    if (status != TX_SUCCESS)
      continue;

    update_data();

    /*
     * Give a chance to thread for events to run (if an event occured). This is
     * needed for devices where a single interrupt is shared for data and events.
     * If a motion event is detected, resume the event thread with event 1, which
     * means that the motion structure has already been filled.
     */
    if (sensor->get_motion_events(&motion)) {
      /* wakeup event thread */
      tx_event_flags_set(&event_flags_dil_events, WAKE_EVENT_THREAD_EV_1, TX_OR);
    }

    log_sm(LOG_CMD_LOG);
  }
}

static void thread_battery_entry(ULONG thread_input)
{
  struct battery batt;

  battery_init();

  while(1) {
    battery_get_info(&batt);
    printf("Battery: %f\t%.2f\t%.2f\t%u\n", batt.soc, batt.current, batt.voltage, batt.presence);

    ctrl.battery = (uint16_t)batt.voltage;
    ctrl.level = (uint8_t)roundf(batt.soc);
    ctrl.present = batt.presence;
    ctrl.charging = batt.current >= 0.0f ? 1 : 0;

    tx_thread_sleep(THREAD_BATTERY_SLEEP);
  }
}

void ConnectionCompletedFunction(uint16_t ConnectionHandle, uint8_t Address_Type, uint8_t addr[6])
{
  led_blue_off();
  tx_timer_deactivate(&ble_timer);
}

void DisconnectionCompletedFunction(void)
{
  tx_timer_activate(&ble_timer);
}

static void ble_timer_cb(ULONG input)
{
  static uint8_t i = 0;

  if (i++ & 0x01) {
    led_blue_on();
    tx_timer_deactivate(&ble_timer);
    tx_timer_change(&ble_timer, 50, 0);
    tx_timer_activate(&ble_timer);
  } else {
    led_blue_off();
    tx_timer_deactivate(&ble_timer);
    tx_timer_change(&ble_timer, 1000, 0);
    tx_timer_activate(&ble_timer);
  }
}

static void thread_ble_entry(ULONG thread_input)
{
  UINT status;
  ULONG actual_flags;

  BluetoothInit();

  tx_timer_create(&ble_timer, "ble_timer", ble_timer_cb, 0x1, 50, 0, TX_NO_ACTIVATE);
  tx_timer_activate(&ble_timer);

  while(1) {

    status = tx_event_flags_get(&event_flags_hci, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);

    if (status != TX_SUCCESS)
      continue;

    /* BLE Event */
    hci_user_evt_proc();

    /* Make the device discoverable */
    if (set_connectable) {
      setConnectable();
      set_connectable = FALSE;
    }
  }
}

#define BLE_MAX_CHAR_VALUE_LEN 114
#define CMD_QUEUE_MAX_SIZE 128

static void cmd_parser_entry(ULONG thread_input)
{
  struct sd_queue_msg sd_cmd;
  char tx_buff[CMD_QUEUE_MAX_SIZE];
  char *command = &tx_buff[1];
  int param[2];
  uint16_t ram_addr;
  uint8_t addr, val;
  UINT ret;
  TX_THREAD *thread = tx_thread_identify();
  char *thread_name;
  tx_thread_info_get(thread, &thread_name, TX_NULL, TX_NULL, TX_NULL, TX_NULL, TX_NULL, TX_NULL, TX_NULL);

  while(1) {
    UCHAR *ptr;
    ret = tx_queue_receive(&queue_cmd, &ptr, TX_WAIT_FOREVER);
    if (ret != TX_SUCCESS)
      continue;

    memcpy(tx_buff, (char *)ptr, CMD_QUEUE_MAX_SIZE);
    tx_byte_release(ptr);

    /* Parse Command */
    if (tx_buff[0] == '*') {
      if (strcmp(command, "reset") == 0) {
        sensor->reset();
        mag_sensor.reset();
        env_sensor.reset();
        ctrl.conf = 0;
        //algo_sel = ALGO_NONE;
        //algo_tim_stop();
        for (uint8_t i = 0; i < 5; i++)
          led_mask[i] = 0;
        //sd_clear_all();
        led_green_off();

        for (uint8_t i = 0; i < 5; i++)
          buz_mask[i] = 0;

        /* propagate reset to SD queue */
        sd_cmd.cmd = SD_LOG_RESET;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
        printf("%s: reset\n", __func__);
      }/* else if (sscanf(command, "event_print %d", &param) == 1) {
        event_print = param;
      } */else if (strcmp(command, "ver") == 0) {
        printf(VERSION_STRING);
      } else if (strncmp(command, "rtc", 3) == 0) {
        CHAR *ptr;
        sd_cmd.cmd = SD_LOG_FILEX_DATE;
        if (ret = tx_byte_allocate(&sdlog_cmd_byte_short_pool, (void **)&ptr,
                                   SDLOG_CMD_SHORT_SIZE, TX_NO_WAIT) != TX_SUCCESS) {
          printf("%s cannot store command in the sd_log cmd short byte pool\n", __func__);
          continue;
        }
        memcpy(ptr, command + 3, SDLOG_CMD_SHORT_SIZE);
        sd_cmd.datap = (void *)ptr;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      } else if (strncmp(command, "bin", 3) == 0) {
        uint8_t i = 3;
        while (i < BLE_MAX_CHAR_VALUE_LEN - 1) {
          sensor->write(command[i], command[i+1]);
          i = i + 2;
        }
        ctrl.conf = 1;
      } else if (sscanf(command, "ramwrite%03hx%02hhx", &ram_addr, &val) == 2) {
        sensor->ram_write(ram_addr, val);
        printf("ram writing 0x%03X = 0x%02X\n", ram_addr, val);
      } else if (sscanf(command, "ramread%03hx", &ram_addr) == 1) {
        sensor->ram_read(ram_addr, &val);
        printf("ram reading 0x%03X = 0x%02X\n", ram_addr, val);
      } else if (sscanf(command, "w%02hhx%02hhx", &addr, &val) == 2) {
        sensor->write(addr, val);
        ctrl.conf = 1;
        printf("writing 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "r%02hhx", &addr) == 1) {
        sensor->read(addr, &val, 1);
        printf("reading 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "aw%02hhx%02hhx", &addr, &val) == 2) {
        lis2du12_write_reg(&lis2du12, addr, &val, 1);
        ctrl.conf = 1;
        printf("acc writing 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "ar%02hhx", &addr) == 1) {
        lis2du12_read_reg(&lis2du12, addr, &val, 1);
        printf("acc reading 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "gw%02hhx%02hhx", &addr, &val) == 2) {
        lsm6dsv16x_write_reg(&lsm6dsv16x, addr, &val, 1);
        ctrl.conf = 1;
        printf("imu writing 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "gr%02hhx", &addr) == 1) {
        lsm6dsv16x_read_reg(&lsm6dsv16x, addr, &val, 1);
        printf("imu reading 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "mw%02hhx%02hhx", &addr, &val) == 2) {
        lis2mdl_write_reg(&lis2mdl, addr, &val, 1);
        ctrl.conf = 1;
        printf("mag writing 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "mr%02hhx", &addr) == 1) {
          lis2mdl_read_reg(&lis2mdl, addr, &val, 1);
          printf("mag reading 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "pw%02hhx%02hhx", &addr, &val) == 2) {
        lps22df_write_reg(&lps22df, addr, &val, 1);
        ctrl.conf = 1;
        printf("prs writing 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "pr%02hhx", &addr) == 1) {
          lps22df_read_reg(&lps22df, addr, &val, 1);
          printf("prs reading 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "tw%02hhx%02hhx", &addr, &val) == 2) {
        stts22h_write_reg(&stts22h, addr, &val, 1);
        ctrl.conf = 1;
        printf("temp writing 0x%02X = 0x%02X\n", addr, val);
      } else if (sscanf(command, "tr%02hhx", &addr) == 1) {
          stts22h_read_reg(&stts22h, addr, &val, 1);
          printf("temp reading 0x%02X = 0x%02X\n", addr, val);
      } else if (strncmp(command, "led", 3) == 0) {
        uint32_t mask[5];
        sscanf(command, "led%02x%02x%02x%02x%02x", &mask[0], &mask[1], &mask[2], &mask[3], &mask[4]);
        for (uint8_t i = 0; i < 5; i++)
          led_mask[i] = mask[i];
        printf("%s: led = %02X%02X%02X%02X%02X\n", __func__, led_mask[0], led_mask[1], led_mask[2], led_mask[3], led_mask[4]);
      } else if (strncmp(command, "buz", 3) == 0) {
        uint32_t mask[5];
        sscanf(command, "buz%02x%02x%02x%02x%02x", &mask[0], &mask[1], &mask[2], &mask[3], &mask[4]);
        for (uint8_t i = 0; i < 5; i++)
          buz_mask[i] = mask[i];
        printf("%s: buz = %02X%02X%02X%02X%02X\n", __func__, buz_mask[0], buz_mask[1], buz_mask[2], buz_mask[3], buz_mask[4]);
      } else if (strcmp(command, "battery") == 0) {
        //if (!(log_conf.audio_en && ctrl.log))
        //  update_batt();
        BLE_CtrlUpdate((void*)&ctrl.byte);
      }/* else if (strcmp(command, "mass-on") == 0) {
        sd_set_clock_div(2);
        usb_xxx_deinit();
        usb_msc_init();
        chg_led_on();
        led_on();
        ctrl.sd_msc = 1;
        ble_notify_ctrl(ctrl.byte);
      } else if (strcmp(command, "mass-off") == 0) {
        sd_set_clock_div(0);
        usb_xxx_deinit();
        usb_cdc_init();
        chg_led_off();
        led_off();
        ctrl.sd_msc = 0;
        ble_notify_ctrl(ctrl.byte);
      }*/ else if (strcmp(command, "ctrl") == 0) {
        BLE_CtrlUpdate((void*)&ctrl.byte);
      } else if (strcmp(command, "status") == 0) {
        BLE_MotionUpdate((void*)&motion.byte);
        BLE_CtrlUpdate((void*)&ctrl.byte);
      }/* else if (strcmp(command, "motionad") == 0) {
        sensor_reset();
        algo_sel = ALGO_MOTION_AD;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "motionaw") == 0) {
        sensor_reset();
        algo_sel = ALGO_MOTION_AW;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "motionfab") == 0) {
        sensor_reset();
        algo_sel = ALGO_MOTION_FA_B;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "motionfas") == 0) {
        sensor_reset();
        algo_sel = ALGO_MOTION_FA_S;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "motionfap") == 0) {
        sensor_reset();
        algo_sel = ALGO_MOTION_FA_P;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "motionpw") == 0) {
        sensor_reset();
        algo_sel = ALGO_MOTION_PW;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "motionsm") == 0) {
        sensor_reset();
        algo_sel = ALGO_MOTION_SM;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "mandown") == 0) {
        sensor_reset();
        algo_sel = ALGO_MANDOWN;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "otd") == 0) {
        sensor_reset();
        algo_sel = ALGO_OTD;
        algo_init(algo_sel);
        data.algo = 0;
        motion.algo = 0;
        algo = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strncmp(command, "conf", 4) == 0) {
        int id;
        float param;
        if (sscanf(command, "conf %d %f", &id, &param) == 2) {
          algo_set_conf(id, param, algo_sel);
        }
      } else if (strcmp(command, "audio-on") == 0) {
        log_conf.audio_en = 1;
        ctrl.audio = 1;
        ctrl.conf = 1;
        printf("%s\n", command);
      } else if (strcmp(command, "audio-off") == 0) {
        log_conf.audio_en = 0;
        ctrl.audio = 0;
        printf("%s\n", command);
      } */
        else if (strcmp(command,  "sd-start") == 0) {
        log_sm(LOG_CMD_START);
      } else if (strcmp(command,  "sd-stop") == 0) {
        log_sm(LOG_CMD_STOP);
      } else if (strncmp(command, "user", 4) == 0) {
        CHAR *ptr;
        sd_cmd.cmd = SD_LOG_SET_USER;
        if (ret = tx_byte_allocate(&sdlog_cmd_byte_short_pool, (void **)&ptr,
                                   SDLOG_CMD_SHORT_SIZE, TX_NO_WAIT) != TX_SUCCESS) {
          printf("%s cannot store command in the sd_log cmd short byte pool\n", __func__);
          continue;
        }
        memcpy(ptr, command + 5, SDLOG_CMD_SHORT_SIZE);
        sd_cmd.datap = (void *)ptr;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      } else if (strncmp(command, "demo", 4) == 0) {
        CHAR *ptr;
        sd_cmd.cmd = SD_LOG_SET_DEMO;
        if (ret = tx_byte_allocate(&sdlog_cmd_byte_short_pool, (void **)&ptr,
                                   SDLOG_CMD_SHORT_SIZE, TX_NO_WAIT) != TX_SUCCESS) {
          printf("%s cannot store command in the sd_log cmd short byte pool\n", __func__);
          continue;
        }
        memcpy(ptr, command + 5, SDLOG_CMD_SHORT_SIZE);
        sd_cmd.datap = (void *)ptr;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      } else if (strncmp(command, "class", 5) == 0) {
        CHAR *ptr;
        sd_cmd.cmd = SD_LOG_SET_CLASS;
        if (ret = tx_byte_allocate(&sdlog_cmd_byte_short_pool, (void **)&ptr,
                                   SDLOG_CMD_SHORT_SIZE, TX_NO_WAIT) != TX_SUCCESS) {
          printf("%s cannot store command in the sd_log cmd short byte pool\n", __func__);
          continue;
        }
        memcpy(ptr, command + 6, SDLOG_CMD_SHORT_SIZE);
        sd_cmd.datap = (void *)ptr;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      } else if (strcmp(command,  "clear-user") == 0) {
        sd_cmd.cmd = SD_LOG_CLR_USER;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      } else if (strcmp(command,  "clear-demo") == 0) {
        sd_cmd.cmd = SD_LOG_CLR_DEMO;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      } else if (strcmp(command,  "clear-class") == 0) {
        sd_cmd.cmd = SD_LOG_CLR_CLASS;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      } else if (strncmp(command, "fsync", 5) == 0) {
        sd_cmd.cmd = SD_LOG_FSYNC;
        ret = tx_queue_send(&queue_sd, &sd_cmd, TX_NO_WAIT);
      } /* else if (strncmp(command, "node", 4) == 0) {
        char node[20];
        if (sscanf(command, "node %s", node) == 1) {
          ble_set_name(node);
          printf("%s: node = %s\n", __func__, node);
        }
      } else if (strcmp(command, "clear-node") == 0) {
        ble_set_name(NULL);
        printf("%s: clear-node\n", __func__);
      } else if (sscanf(command, "algo_print %d", &param) == 1) {
        algo_print = param;
      } else if (strcmp(command, "ble-start") == 0) {
        ble_state = BLE_START;
      } else if (strcmp(command, "ble-stop") == 0) {
        ble_state = BLE_STOP;
      } else if (strcmp(command, "ble-reset") == 0) {
        ble_init();
      }*/ else if (sscanf(command, "zip-size %d", &param[0]) == 1) {
        unzip_init(param[0]);
        printf("%s: zip-size = %d\n", __func__, param[0]);
      } else if (strcmp(command, "zip-decompress") == 0) {
        unzip_run();
        ctrl.conf = 1;
        printf("%s: zip-decompress\n", __func__);
      } else if (strncmp(command, "zip", 3) == 0) {
        unzip_add((uint8_t *)&command[3]);
      } else if (sscanf(command, "tone %d %d", &param[0], &param[1]) == 2) {
        tone(param[0], param[1]);
      } else if (strcmp(command, "play-got") == 0) {
        printf("Playing game of thrones theme with the buzzer :)\n");
        buz_play(melody, durations,  sizeof(durations) / sizeof(int));
      } else if (strcmp(command, "dump") == 0) {
        printf("dump all sensor regs\n");
        sensor->dump_reg();
      }
    }
  }
}
/* USER CODE END PFP */

/**
  * @brief  Application ThreadX Initialization.
  * @param memory_ptr: memory pointer
  * @retval int
  */
UINT App_ThreadX_Init(VOID *memory_ptr)
{
  UINT ret = TX_SUCCESS;
  TX_BYTE_POOL *byte_pool = (TX_BYTE_POOL*)memory_ptr;

   /* USER CODE BEGIN App_ThreadX_MEM_POOL */
  (void)byte_pool;
  /* USER CODE END App_ThreadX_MEM_POOL */

  /* USER CODE BEGIN App_ThreadX_Init */
  CHAR *pointer;
  tx_byte_allocate(byte_pool, (void **)&pointer, 2048, TX_NO_WAIT);
  tx_thread_create(&thread_sensor_event, "thread sensor to handle events",
                   thread_sensor_event_entry, 0,
                   pointer, 2048, APP_THREAD_SENSOR_EVENT_PRIORITY,
                   APP_THREAD_SENSOR_EVENT_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);

  tx_byte_allocate(byte_pool, (void **)&pointer, 2048, TX_NO_WAIT);
  tx_thread_create(&thread_sensor_data, "thread sensor to handle data",
                   thread_sensor_data_entry, 0,
                   pointer, 2048, APP_THREAD_SENSOR_DATA_PRIORITY,
                   APP_THREAD_SENSOR_DATA_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);

  tx_byte_allocate(byte_pool, (void **)&pointer, 768, TX_NO_WAIT);
  tx_thread_create(&thread_battery, "thread battery", thread_battery_entry, 0,
                   pointer, 768, APP_THREAD_BATTERY_PRIORITY,
                   APP_THREAD_BATTERY_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);

  tx_byte_allocate(byte_pool, (void **)&pointer, 2048, TX_NO_WAIT);
  tx_thread_create(&thread_ble, "thread ble", thread_ble_entry, 0,
                   pointer, 2048, APP_THREAD_BLE_PRIORITY,
                   APP_THREAD_BLE_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);

  tx_byte_allocate(byte_pool, (void **)&pointer, 4096, TX_NO_WAIT);
  tx_thread_create(&cmd_parser, "Command Parser", cmd_parser_entry, 0,
                   pointer, 4096, APP_THREAD_CMD_PARSER_PRIORITY,
                   APP_THREAD_CMD_PARSER_PRIORITY, TX_NO_TIME_SLICE, TX_AUTO_START);

  tx_event_flags_create(&event_flags_hci, "event flags hci");
  tx_event_flags_create(&event_flags_lsm6dsv16x_int1, "event flags lsm6dsv16x int1");
  tx_event_flags_create(&event_flags_dil_events, "event flags dil sensor events");
  tx_event_flags_create(&event_flags_dil_data, "event flags dil sensor data");
  tx_event_flags_create(&spi3_dma_rx_completed, "SPI3 DMA rx completed event flags");
  tx_event_flags_create(&spi3_dma_tx_completed, "SPI3 DMA tx completed event flags");
  tx_event_flags_create(&spi2_dma_rx_completed, "SPI2 DMA rx completed event flags");
  tx_event_flags_create(&spi2_dma_tx_completed, "SPI2 DMA tx completed event flags");
  tx_event_flags_create(&i2c1_dma_rx_completed, "I2C1 DMA rx completed event flags");
  tx_event_flags_create(&i2c1_dma_tx_completed, "I2C1 DMA tx completed event flags");
  tx_event_flags_create(&i2c4_dma_rx_completed, "I2C4 DMA rx completed event flags");
  tx_event_flags_create(&i2c4_dma_tx_completed, "I2C4 DMA tx completed event flags");

  tx_mutex_create(&spi3_mutex, "spi3 mutex", TX_NO_INHERIT);
  tx_mutex_create(&i2c1_mutex, "i2c1 mutex", TX_NO_INHERIT);
  tx_mutex_create(&spi2_mutex, "spi2 mutex", TX_NO_INHERIT);

  tx_byte_pool_create(&tx_print_byte_pool, "Tx print memory pool", tx_print_byte_pool_buffer, TX_PRINT_MEM_POOL_SIZE);
  tx_byte_pool_create(&cmd_byte_pool, "cmd memory pool", cmd_byte_pool_buffer, CMD_POOL_SIZE);

  tx_byte_allocate(byte_pool, (void **)&pointer, CMD_QUEUE_SIZE * CMD_QUEUE_MSG_SIZE, TX_NO_WAIT);
  tx_queue_create(&queue_cmd, "queue cmd", TX_1_ULONG, pointer, CMD_QUEUE_SIZE * CMD_QUEUE_MSG_SIZE);

  tx_byte_allocate(byte_pool, (void **)&pointer, QUEUE_PRINT_SIZE * QUEUE_PRINT_MSG_SIZE, TX_NO_WAIT);
  tx_queue_create(&queue_print, "queue cmd", TX_1_ULONG, pointer, QUEUE_PRINT_SIZE * QUEUE_PRINT_MSG_SIZE);

  /* USER CODE END App_ThreadX_Init */

  return ret;
}

  /**
  * @brief  MX_ThreadX_Init
  * @param  None
  * @retval None
  */
void MX_ThreadX_Init(void)
{
  /* USER CODE BEGIN  Before_Kernel_Start */

  /* USER CODE END  Before_Kernel_Start */

  tx_kernel_enter();

  /* USER CODE BEGIN  Kernel_Start_Error */

  /* USER CODE END  Kernel_Start_Error */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

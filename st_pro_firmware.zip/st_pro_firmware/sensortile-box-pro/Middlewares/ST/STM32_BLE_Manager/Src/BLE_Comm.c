/**
  ******************************************************************************
  * @file    BLE_Comm.c
  * @author  System Research & Applications Team - Agrate/Catania Lab.
  * @version 1.6.0
  * @date    15-September-2022
  * @brief   Add comm info services using vendor specific profiles.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include "BLE_Manager.h"
#include "BLE_ManagerCommon.h"

#include "tx_api.h"
#include "app_threadx.h"

/* Private define ------------------------------------------------------------*/
#define COPY_COMM_CHAR_UUID(uuid_struct) COPY_UUID_128(uuid_struct,0x00,0x00,0x00,0x00,0x00,0x01,0x11,0xe1,0xac,0x36,0x00,0x02,0xa5,0xd5,0xc5,0x1b)

#define COMM_ADVERTISE_DATA_POSITION  16

/* Exported variables --------------------------------------------------------*/
CustomNotifyEventComm_t CustomNotifyEventComm = NULL;

/* Private variables ---------------------------------------------------------*/
/* Data structure pointer for comm info service */
static BleCharTypeDef BleCharComm;

/* Private functions ---------------------------------------------------------*/
static void Write_Request_Comm(void *BleCharPointer, uint16_t attr_handle, uint16_t Offset, uint8_t data_length, uint8_t *att_data);

/**
 * @brief  Init comm info service
 * @param  None
 * @retval BleCharTypeDef* BleCharPointer: Data structure pointer for comm info service
 */
BleCharTypeDef* BLE_InitCommService(void)
{
  /* Data structure pointer for BLE service */
  BleCharTypeDef *BleCharPointer;

  /* Init data structure pointer for comm info service */
  BleCharPointer = &BleCharComm;
  memset(BleCharPointer, 0, sizeof(BleCharTypeDef));
  BleCharPointer->Write_Request_CB = Write_Request_Comm;
  COPY_COMM_CHAR_UUID((BleCharPointer->uuid));
  BleCharPointer->Char_UUID_Type = UUID_TYPE_128;
  BleCharPointer->Char_Value_Length = 114;
  BleCharPointer->Char_Properties = CHAR_PROP_WRITE_WITHOUT_RESP;
  BleCharPointer->Security_Permissions = ATTR_PERMISSION_NONE;
  BleCharPointer->GATT_Evt_Mask = GATT_NOTIFY_ATTRIBUTE_WRITE;
  BleCharPointer->Enc_Key_Size = 16;
  BleCharPointer->Is_Variable = 1;

  BLE_MANAGER_PRINTF("BLE Comm features ok\r\n");

  return BleCharPointer;
}

#ifndef BLE_MANAGER_SDKV2
/**
 * @brief  Setting Comm Advertise Data
 * @param  uint8_t *manuf_data: Advertise Data
 * @retval None
 */
void BLE_SetCommAdvertiseData(uint8_t *manuf_data)
{
  /* Setting Comm Advertise Data */
  manuf_data[COMM_ADVERTISE_DATA_POSITION] |= 0x02U;
}
#endif /* BLE_MANAGER_SDKV2 */

/**
 * @brief  Update Comm characteristic
 * @param  int32_t CommLevel %Charge level
 * @param  uint32_t Voltage Comm Voltage
 * @param  uint32_t Current Comm Current (0x8000 if not available)
 * @param  uint32_t Status Charging/Discharging
 * @retval tBleStatus   Status
 */
tBleStatus BLE_CommUpdate(uint32_t CommLevel, uint32_t Voltage, uint32_t Current, uint32_t Status)
{
  tBleStatus ret;

  uint8_t buff[2+2+2+2+1];

  STORE_LE_16(buff  ,(HAL_GetTick()>>3));
  STORE_LE_16(buff+2,(CommLevel*10U));
  STORE_LE_16(buff+4,(Voltage));
  STORE_LE_16(buff+6,(Current));
  buff[8] = (uint8_t)Status;

  ret = ACI_GATT_UPDATE_CHAR_VALUE(&BleCharComm, 0, 2+2+2+2+1,buff);

  if (ret != BLE_STATUS_SUCCESS){
    if(BLE_StdErr_Service==BLE_SERV_ENABLE){
      BytesToWrite = (uint8_t)sprintf((char *)BufferToWrite, "Error Updating Comm Char\n");
      Stderr_Update(BufferToWrite,BytesToWrite);
    } else {
      BLE_MANAGER_PRINTF("Error Updating Comm Char\r\n");
    }
  }
  return ret;
}

#define MAX_PACKET_SIZE 128
extern TX_BYTE_POOL cmd_byte_pool;

static void Write_Request_Comm(void *BleCharPointer, uint16_t attr_handle, uint16_t Offset, uint8_t data_length, uint8_t *att_data)
{
  UINT ret;

  if (data_length > MAX_PACKET_SIZE) {
    BLE_MANAGER_PRINTF("Write_Request_Comm data_length exceeds MAX_PACKET_SIZE (%d vs %d)\r\n", data_length, MAX_PACKET_SIZE);
    return;
  }

  CHAR *ptr;
  if (tx_byte_allocate(&cmd_byte_pool, (void **)&ptr, MAX_PACKET_SIZE, TX_NO_WAIT) != TX_SUCCESS) {
    BLE_MANAGER_PRINTF("%s data_length cannot be stored in the cmd byte pool\r\n", __func__);
    return;
  }

  memset(ptr, 0, MAX_PACKET_SIZE);
  memcpy(ptr, att_data, data_length);
  ret = tx_queue_send(&queue_cmd, &ptr, TX_NO_WAIT);

  if (ret) {
    BLE_MANAGER_PRINTF("Write_Request_Comm tx_queue_send error %d\r\n", ret);
  }
}

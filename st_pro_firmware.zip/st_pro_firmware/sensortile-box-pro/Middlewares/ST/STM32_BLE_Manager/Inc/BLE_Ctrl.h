/**
  ******************************************************************************
  * @file    BLE_Ctrl.h
  * @author  System Research & Applications Team - Agrate/Catania Lab.
  * @version 1.6.0
  * @date    15-September-2022
  * @brief   Ctrl info services APIs.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _BLE_CTRL_H_
#define _BLE_CTRL_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Exported typedef --------------------------------------------------------- */
typedef void (*CustomNotifyEventCtrl_t)(BLE_NotifyEvent_t Ctrl);
typedef union {
  struct {
    uint16_t battery; // battery voltage [mV]
    uint8_t level; // battery level [%]
    uint8_t present; // battery present
    uint8_t charging; // battery charging [0, 1, 2]
    uint8_t sd_err; // sd card error
    uint8_t sd_msc; // usb mass-storage enabled
    uint8_t log; // sd card logging
    uint8_t conf; // conf loaded
    uint8_t audio; // audio enabled
    uint8_t ble_log; // ble logging
    uint8_t ble_sens_on; // bitmask with sensors on
    uint8_t dil24_whoami; // whoami of sensor on dil24
    uint8_t dil24_rev; // asic revision of sensor on dil24
    uint8_t reserved[2];
    uint8_t board; // board id
    uint8_t major;
    uint8_t minor;
    uint8_t patch;
  };
  uint8_t byte[20];
} ctrl_t;

/* Exported Variables ------------------------------------------------------- */
extern CustomNotifyEventCtrl_t CustomNotifyEventCtrl;

/* Exported functions ------------------------------------------------------- */

/**
 * @brief  Init ctrl info service
 * @param  None
 * @retval BleCharTypeDef* BleCharPointer: Data structure pointer for ctrl info service
 */
extern BleCharTypeDef* BLE_InitCtrlService(void);

#ifndef BLE_MANAGER_SDKV2
/**
 * @brief  Setting Ctrl Advertise Data
 * @param  uint8_t *manuf_data: Advertise Data
 * @retval None
 */
extern void BLE_SetCtrlAdvertiseData(uint8_t *manuf_data);
#endif /* BLE_MANAGER_SDKV2 */

/**
 * @brief  Update Ctrl characteristic
 * @param  int32_t CtrlLevel %Charge level
 * @param  uint32_t Voltage Ctrl Voltage
 * @param  uint32_t Current Ctrl Current (0x8000 if not available)
 * @param  uint32_t Status Charging/Discharging
 * @retval tBleStatus   Status
 */
tBleStatus BLE_CtrlUpdate(void *packet);

#ifdef __cplusplus
}
#endif

#endif /* _BLE_CTRL_H_ */


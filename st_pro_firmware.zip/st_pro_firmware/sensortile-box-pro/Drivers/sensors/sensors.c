#include "sensors.h"

#include <stdio.h>
#include "spi.h"
#include "i2c.h"
#include "main.h"
#include "board.h"

#define SFLP_DEBUG 0

static void sflp2q(float quat[4], __fp16 sflp[3]);

static int32_t lis2du12_write(void *ctx, uint8_t address, const uint8_t *val, uint16_t len)
{
  int32_t ret = -1;
  uint8_t tx[2] = { address, *val };

  tx_mutex_get(&spi2_mutex, TX_WAIT_FOREVER);
  HAL_GPIO_WritePin(CS_A_GPIO_Port, CS_A_Pin, GPIO_PIN_RESET);

  if (len == 1) {
    if (HAL_SPI_Transmit_DMA(&hspi2, tx, 2) == HAL_OK) {
      UINT status;
      ULONG actual_flags;

      ret = 0;
      status = tx_event_flags_get(&spi2_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                  &actual_flags, TX_WAIT_FOREVER);
      if (status != TX_SUCCESS)
        ret = -1;
    }
  } else {
    ret = HAL_SPI_Transmit(&hspi2, &address, 1, 10);
    if (ret == 0 && HAL_SPI_Transmit_DMA(&hspi2, (uint8_t *)val, len) == HAL_OK) {
      UINT status;
      ULONG actual_flags;

      ret = 0;
      status = tx_event_flags_get(&spi2_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                  &actual_flags, TX_WAIT_FOREVER);
      if (status != TX_SUCCESS)
        ret = -1;
    }
  }

  HAL_GPIO_WritePin(CS_A_GPIO_Port, CS_A_Pin, GPIO_PIN_SET);
  tx_mutex_put(&spi2_mutex);

  return ret;
}

static int32_t lis2du12_read(void *ctx, uint8_t address, uint8_t *val, uint16_t len)
{
  int32_t ret = -1;
  address = address | 0x80;

  tx_mutex_get(&spi2_mutex, TX_WAIT_FOREVER);
  HAL_GPIO_WritePin(CS_A_GPIO_Port, CS_A_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi2, &address, 1, 10);

  if (HAL_SPI_Receive_DMA(&hspi2, val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&spi2_dma_rx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  HAL_GPIO_WritePin(CS_A_GPIO_Port, CS_A_Pin, GPIO_PIN_SET);
  tx_mutex_put(&spi2_mutex);

  return ret;
}

static int32_t lis2mdl_read(void *ctx, uint8_t address, uint8_t *val, uint16_t len)
{
  int32_t ret = -1;

  tx_mutex_get(&i2c1_mutex, TX_WAIT_FOREVER);

  if (HAL_I2C_Mem_Read_DMA(&hi2c1, LIS2MDL_I2C_ADD, address, I2C_MEMADD_SIZE_8BIT,
                           val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&i2c1_dma_rx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  tx_mutex_put(&i2c1_mutex);

  return ret;
}

static int32_t lis2mdl_write(void *ctx, uint8_t address, const uint8_t *val, uint16_t len)
{
  int32_t ret = -1;

  tx_mutex_get(&i2c1_mutex, TX_WAIT_FOREVER);

  if (HAL_I2C_Mem_Write_DMA(&hi2c1, LIS2MDL_I2C_ADD, address, I2C_MEMADD_SIZE_8BIT,
                            (uint8_t *)val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&i2c1_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  tx_mutex_put(&i2c1_mutex);

  return ret;
}

static int32_t lps22df_write(void *ctx, uint8_t address, const uint8_t *val, uint16_t len)
{
  int32_t ret = -1;

  tx_mutex_get(&i2c1_mutex, TX_WAIT_FOREVER);

  if (HAL_I2C_Mem_Write_DMA(&hi2c1, LPS22DF_I2C_ADD_H, address, I2C_MEMADD_SIZE_8BIT,
                            (uint8_t *)val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&i2c1_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  tx_mutex_put(&i2c1_mutex);

  return ret;
}

static int32_t lps22df_read(void *ctx, uint8_t address, uint8_t *val, uint16_t len)
{
  int32_t ret = -1;

  tx_mutex_get(&i2c1_mutex, TX_WAIT_FOREVER);

  if (HAL_I2C_Mem_Read_DMA(&hi2c1, LPS22DF_I2C_ADD_H, address, I2C_MEMADD_SIZE_8BIT,
                           val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&i2c1_dma_rx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  tx_mutex_put(&i2c1_mutex);

  return ret;
}

static int32_t lsm6dsv16x_write(void *ctx, uint8_t address, const uint8_t *val, uint16_t len)
{
  int32_t ret = -1;
  uint8_t tx[2] = { address, *val };

  tx_mutex_get(&spi2_mutex, TX_WAIT_FOREVER);
  HAL_GPIO_WritePin(CS_G_GPIO_Port, CS_G_Pin, GPIO_PIN_RESET);

  if (len == 1) {
    if (HAL_SPI_Transmit_DMA(&hspi2, tx, 2) == HAL_OK) {
      UINT status;
      ULONG actual_flags;

      ret = 0;
      status = tx_event_flags_get(&spi2_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                  &actual_flags, TX_WAIT_FOREVER);
      if (status != TX_SUCCESS)
        ret = -1;
    }
  } else {
    ret = HAL_SPI_Transmit(&hspi2, &address, 1, 10);
    if (ret == 0 && HAL_SPI_Transmit_DMA(&hspi2, (uint8_t *)val, len) == HAL_OK) {
      UINT status;
      ULONG actual_flags;

      ret = 0;
      status = tx_event_flags_get(&spi2_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                  &actual_flags, TX_WAIT_FOREVER);
      if (status != TX_SUCCESS)
        ret = -1;
    }
  }

  HAL_GPIO_WritePin(CS_G_GPIO_Port, CS_G_Pin, GPIO_PIN_SET);
  tx_mutex_put(&spi2_mutex);

  return ret;
}

static int32_t lsm6dsv16x_read(void *ctx, uint8_t address, uint8_t *val, uint16_t len)
{
  int32_t ret = -1;
  address = address | 0x80;

  tx_mutex_get(&spi2_mutex, TX_WAIT_FOREVER);
  HAL_GPIO_WritePin(CS_G_GPIO_Port, CS_G_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi2, &address, 1, 10);

  if (HAL_SPI_Receive_DMA(&hspi2, val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&spi2_dma_rx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  HAL_GPIO_WritePin(CS_G_GPIO_Port, CS_G_Pin, GPIO_PIN_SET);
  tx_mutex_put(&spi2_mutex);

  return ret;
}

static int32_t stts22h_write(void *ctx, uint8_t address, const uint8_t *val, uint16_t len)
{
  int32_t ret = -1;

  tx_mutex_get(&i2c1_mutex, TX_WAIT_FOREVER);

  if (HAL_I2C_Mem_Write_DMA(&hi2c1, STTS22H_I2C_ADD_H, address, I2C_MEMADD_SIZE_8BIT,
                            (uint8_t *)val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&i2c1_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  tx_mutex_put(&i2c1_mutex);

  return ret;
}

static int32_t stts22h_read(void *ctx, uint8_t address, uint8_t *val, uint16_t len)
{
  int32_t ret = -1;

  tx_mutex_get(&i2c1_mutex, TX_WAIT_FOREVER);

  if (HAL_I2C_Mem_Read_DMA(&hi2c1, STTS22H_I2C_ADD_H, address, I2C_MEMADD_SIZE_8BIT,
                           val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&i2c1_dma_rx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  tx_mutex_put(&i2c1_mutex);

  return ret;
}

static void mdelay(uint32_t delay_ms)
{
  tx_thread_sleep(delay_ms);
}

stmdev_ctx_t lis2du12 = {
  .read_reg = lis2du12_read,
  .write_reg = lis2du12_write,
  .mdelay = mdelay
};

stmdev_ctx_t lis2mdl = {
  .read_reg = lis2mdl_read,
  .write_reg = lis2mdl_write,
  .mdelay = mdelay
};

stmdev_ctx_t lps22df = {
  .read_reg = lps22df_read,
  .write_reg = lps22df_write,
  .mdelay = mdelay
};

stmdev_ctx_t lsm6dsv16x = {
  .read_reg = lsm6dsv16x_read,
  .write_reg = lsm6dsv16x_write,
  .mdelay = mdelay
};

stmdev_ctx_t stts22h = {
  .read_reg = stts22h_read,
  .write_reg = stts22h_write,
  .mdelay = mdelay
};

static void lsm6dsox_reset(void)
{
  /* set device in power-down */
  write_dil(0x10, 0x00);
  write_dil(0x11, 0x00);

  /* manual reset advanced page */
  write_dil(0x01, 0x80);
  write_dil(0x02, 0x01);
  write_dil(0x04, 0x00);
  write_dil(0x05, 0x00);

  for (uint8_t i = 0x08; i < 0x11; i++)
    write_dil(i, 0x00);

  write_dil(0x17, 0x00);
  write_dil(0x44, 0x00);

  for (uint8_t i = 0x46; i < 0x4A; i++)
    write_dil(i, 0x00);

  write_dil(0x5F, 0x4B);
  write_dil(0x60, 0x15);
  write_dil(0x66, 0x00);
  write_dil(0x67, 0x00);

  /* reset stmc */
  write_dil(0x02, 0x00);
  write_dil(0x02, 0x01);
  write_dil(0x01, 0x00);

  /* sw reset */
  write_dil(0x12, 0x01);
  tx_thread_sleep(1);

  /* boot */
  write_dil(0x12, 0x84);
  tx_thread_sleep(10);
}

static uint8_t lsm6dsox_get_motion_events(motion_t *motion)
{
  read_dil(0x1A, &motion->all_int, 1);
  motion->hw_free_fall = motion->all_int & 0x01 ? 1 : 0;
  motion->hw_wake_up = motion->all_int & 0x02 ? 1 : 0;
  motion->hw_tap_single = motion->all_int & 0x04 ? 1 : 0;
  motion->hw_tap_double = motion->all_int & 0x08 ? 1 : 0;
  read_dil(0x35, &motion->emb_func_status, 1);
  read_dil(0x36, &motion->fsm, 1);
  read_dil(0x38, &motion->mlc, 1);
  write_dil(0x01, 0x80);
  read_dil(0x48, &motion->lc, 2);
  read_dil(0x4C, motion->fsm_outs, 4);
  read_dil(0x70, motion->mlc_src, 4);
  read_dil(0x62, &motion->steps, 2);
  write_dil(0x01, 0x00);

  if (motion->fsm != 0 || motion->mlc != 0 || motion->emb_func_status != 0 || motion->all_int != 0) {
    /* motion event has occoured */
    return 1;
  }

  return 0;
}

static void lsm6dsox_ram_write(uint16_t addr, uint8_t val)
{
  uint8_t tmp;

  uint8_t page = ((addr >> 8) << 4) | 0x01;
  uint8_t reg = addr & 0x00FF;

  write_dil(0x01, 0x80);
  do
    read_dil(0x16, &tmp, 1);
  while ((tmp & 0x9F) != 0x80); /* check stmc idle */

  write_dil(0x17, 0x40);
  write_dil(0x02, page);
  write_dil(0x08, reg);
  write_dil(0x09, val);
  write_dil(0x02, 0x01);
  write_dil(0x17, 0x00);

  write_dil(0x01, 0x00);
}

static void lsm6dsox_ram_read(uint16_t addr, uint8_t *val)
{
  uint8_t tmp;

  uint8_t page = ((addr >> 8) << 4) | 0x01;
  uint8_t reg = addr & 0x00FF;

  write_dil(0x01, 0x80);

  do
    read_dil(0x16, &tmp, 1);
  while ((tmp & 0x9F) != 0x80); /* check stmc idle */

  write_dil(0x17, 0x20);
  write_dil(0x02, page);
  write_dil(0x08, reg);
  read_dil(0x09, val, 1);
  write_dil(0x02, 0x01);
  write_dil(0x17, 0x00);

  write_dil(0x01, 0x00);
}

static int32_t lsm6dsox_get_op_state(struct log_conf *conf)
{
  uint8_t ctrl1_xl;
  uint8_t ctrl2_g;
  uint8_t emb_func_en_a = 0;
  uint8_t emb_func_en_b = 0;
  uint8_t tmp = 0;

  read_dil(0x10, &ctrl1_xl, 1);
  conf->accel_en = (ctrl1_xl & 0xF0) == 0 ? 0 : 1;

  switch (ctrl1_xl & 0x0C) {
  case 0x00:
    conf->acc_sens = 0.061f;
    break;
  case 0x04:
    conf->acc_sens = 0.488f;
    break;
  case 0x08:
    conf->acc_sens = 0.122f;
    break;
  case 0x0C:
    conf->acc_sens = 0.244f;
    break;
  default:
    conf->acc_sens = 0.0f;
    break;
  }

  read_dil(0x11, &ctrl2_g, 1);
  conf->gyro_en = (ctrl2_g & 0xF0) == 0 ? 0 : 1;

  switch (ctrl2_g & 0x0C) {
  case 0x00:
    conf->gyr_sens = 0.00875f;
    break;
  case 0x04:
    conf->gyr_sens = 0.0175f;
    break;
  case 0x08:
    conf->gyr_sens = 0.035f;
    break;
  case 0x0C:
    conf->gyr_sens = 0.070f;
    break;
  default:
    conf->gyr_sens = 0.0f;
    break;
  }

  if (ctrl2_g & 0x02)
    conf->gyr_sens = 0.004375f;

  if (conf->accel_en || conf->gyro_en)
    conf->temp_en = 1;
  else
    conf->temp_en = 0;

  read_dil(0x58, &tmp, 1);
  conf->int_en = (tmp & 0x80) == 0 ? 0 : 1;

  write_dil(0x01, 0x80);
  read_dil(0x04, &emb_func_en_a, 1);
  conf->pedo_en = (emb_func_en_a & 0x08) == 0 ? 0 : 1;
  read_dil(0x05, &emb_func_en_b, 1);
  conf->mlc_en = (emb_func_en_b & 0x10) == 0 ? 0 : 1;
  conf->fsm_en = (emb_func_en_b & 0x01) == 0 ? 0 : 1;
  read_dil(0x46, &tmp, 1);
  conf->fsm_outs_en[0] = (tmp & 0x01) == 0 ? 0 : 1;
  conf->fsm_outs_en[1] = (tmp & 0x02) == 0 ? 0 : 1;
  conf->fsm_outs_en[2] = (tmp & 0x04) == 0 ? 0 : 1;
  conf->fsm_outs_en[3] = (tmp & 0x08) == 0 ? 0 : 1;

  /* check enabled dectrees */
  if (conf->mlc_en) {
    write_dil(0x04, 0x00);
    write_dil(0x05, 0x00);
    do
      read_dil(0x16, &tmp, 1);
    while (!(tmp & 0x80));
    write_dil(0x17, 0x20);
    write_dil(0x02, 0x11);
    write_dil(0x08, 0xEF);
    read_dil(0x09, &tmp, 1);
    write_dil(0x17, 0x00);
    write_dil(0x02, 0x01);
    write_dil(0x04, emb_func_en_a);
    write_dil(0x05, emb_func_en_b);
    conf->mlc_num = tmp;
    printf("%s: mlc_num = %u\n", __func__, conf->mlc_num);
  }

  write_dil(0x01, 0x00);

  return 0;
}

static void lsm6dsox_get_data(struct fifo_data *data)
{
  read_dil(0x28, (uint8_t *)data->accel, 6);
  read_dil(0x22, (uint8_t *)data->gyro, 6);
  read_dil(0x20, (uint8_t *)&data->temp, 2);
}

static void lsm6dsox_start_data(uint8_t val)
{
  switch(val) {
  case 0:
    write_dil(0x0E, 0x00);
    write_dil(0x0B, 0x00);
    break;
  case 1:
  default:
    write_dil(0x0B, 0x80); /* drdy pulsed */
    write_dil(0x0E, 0x03); /* DRDY_XL and DRDY_G */
    break;
  }
}

static void suwon3_reset(void)
{
  write_dil(0x01, 0x04); // SW_POR
  tx_thread_sleep(30);
}

static uint8_t suwon3_get_motion_events(motion_t *motion)
{
  uint8_t tap_src, fifo_status;
  uint16_t diff;

  read_dil(0x46, &tap_src, 1);
  read_dil(0x1D, &motion->all_int, 1);
  motion->hw_free_fall = motion->all_int & 0x01 ? 1 : 0;
  motion->hw_wake_up = motion->all_int & 0x02 ? 1 : 0;
  motion->hw_tap_single = tap_src & 0x20 ? 1 : 0;
  motion->hw_tap_double = tap_src & 0x10 ? 1 : 0;
  read_dil(0x49, &motion->emb_func_status, 1);
  read_dil(0x4A, &motion->fsm, 1);
  read_dil(0x4B, &motion->mlc, 1);
  write_dil(0x01, 0x80);
  read_dil(0x48, &motion->lc, 2);
  read_dil(0x4C, motion->fsm_outs, 4);
  read_dil(0x70, motion->mlc_src, 4);
  read_dil(0x62, &motion->steps, 2);
  write_dil(0x01, 0x00);

  read_dil(0x1B, &fifo_status, 2);
  diff = fifo_status &= 0x1FF;

  for (uint16_t i = 0; i < diff; i++) {
    uint8_t tag, fifo[7];
    read_dil(0x78, fifo, 7);
    tag = fifo[0] >> 3;

    switch (tag) {
    case 0x13:
      sflp2q(motion->quat, (__fp16 *)&fifo[1]);
#if SFLP_DEBUG
      printf("%f\t%f\t%f\t%f\t", motion->quat[0], motion->quat[1], motion->quat[2], motion->quat[3]);
#endif
      break;
    case 0x16:
      memcpy(motion->gbias, &fifo[1], 6);
#if SFLP_DEBUG
      printf("%d\t%d\t%d\t", motion->gbias[0], motion->gbias[1], motion->gbias[2]);
#endif
      break;
    case 0x17:
      memcpy(motion->gravity, &fifo[1], 6);
#if SFLP_DEBUG
      printf("%d\t%d\t%d\n", motion->gravity[0], motion->gravity[1], motion->gravity[2]);
#endif
      break;
    }
  }

  if (motion->fsm != 0 || motion->mlc != 0 || motion->emb_func_status != 0
      || motion->all_int != 0 || diff != 0) {
    /* motion event has occoured */
    return 1;
  }

  return 0;
}

static void suwon3_ram_write(uint16_t addr, uint8_t val)
{
  uint8_t tmp;

  uint8_t page = ((addr >> 8) << 4) | 0x01;
  uint8_t reg = addr & 0x00FF;

  write_dil(0x01, 0x80);

  do
    read_dil(0x07, &tmp, 1);
  while (!(tmp & 0x01)); /* check stmc idle */

  write_dil(0x17, 0x40);
  write_dil(0x02, page);
  write_dil(0x08, reg);
  write_dil(0x09, val);
  write_dil(0x02, 0x01);
  write_dil(0x17, 0x00);

  write_dil(0x01, 0x00);
}

static void suwon3_ram_read(uint16_t addr, uint8_t *val)
{
  uint8_t tmp;

  uint8_t page = ((addr >> 8) << 4) | 0x01;
  uint8_t reg = addr & 0x00FF;

  write_dil(0x01, 0x80);

  do
    read_dil(0x07, &tmp, 1);
  while (!(tmp & 0x01)); /* check stmc idle */

  write_dil(0x17, 0x20);
  write_dil(0x02, page);
  write_dil(0x08, reg);
  read_dil(0x09, val, 1);
  write_dil(0x02, 0x01);
  write_dil(0x17, 0x00);

  write_dil(0x01, 0x00);
}

static int32_t suwon3_get_op_state(struct log_conf *conf)
{
  uint8_t ctrl1, ctrl2, ctrl6, ctrl8;
  uint8_t emb_func_en_a, emb_func_en_b, emb_func_fifo_en_a;
  uint8_t tmp;

  read_dil(0x10, &ctrl1, 1);
  conf->accel_en = (ctrl1 & 0x0F) == 0 ? 0 : 1;

  read_dil(0x17, &ctrl8, 1);
  switch (ctrl8 & 0x03) {
  case 0x00:
    conf->acc_sens = 0.061f;
    break;
  case 0x01:
    conf->acc_sens = 0.122f;
    break;
  case 0x02:
    conf->acc_sens = 0.244f;
    break;
  case 0x03:
    conf->acc_sens = 0.488f;
    break;
  default:
    conf->acc_sens = 0.0f;
    break;
  }

  conf->acc_sens = (ctrl8 & 0x04) ? conf->acc_sens * 2.0f : conf->acc_sens;

  conf->grav_sens = 0.000061f;
  conf->grav_sens = (ctrl8 & 0x04) ? conf->grav_sens * 2.0f : conf->grav_sens;

  read_dil(0x11, &ctrl2, 1);
  conf->gyro_en = (ctrl2 & 0x0F) == 0 ? 0 : 1;

  read_dil(0x15, &ctrl6, 1);
  switch (ctrl6 & 0x0F) {
  case 0x00:
    conf->gyr_sens = 0.004375f;
    break;
  case 0x01:
    conf->gyr_sens = 0.00875f;
    break;
  case 0x02:
    conf->gyr_sens = 0.0175f;
    break;
  case 0x03:
    conf->gyr_sens = 0.035f;
    break;
  case 0x04:
    conf->gyr_sens = 0.070f;
    break;
  case 0x0c:
    conf->gyr_sens = 0.140f;
    break;
  default:
    conf->gyr_sens = 0.0f;
    break;
  }

  conf->gbias_sens = 0.004375f;

  if (conf->accel_en || conf->gyro_en)
    conf->temp_en = 1;
  else
    conf->temp_en = 0;

  read_dil(0x50, &tmp, 1);
  conf->int_en = (tmp & 0x80) == 0 ? 0 : 1;

  write_dil(0x01, 0x80);
  read_dil(0x04, &emb_func_en_a, 1);
  conf->pedo_en = (emb_func_en_a & 0x08) == 0 ? 0 : 1;
  read_dil(0x05, &emb_func_en_b, 1);
  conf->mlc_en = ((emb_func_en_a & 0x80) || (emb_func_en_b & 0x10)) ? 1 : 0;
  conf->fsm_en = (emb_func_en_b & 0x01) == 0 ? 0 : 1;
  read_dil(0x46, &tmp, 1);
  conf->fsm_outs_en[0] = (tmp & 0x01) == 0 ? 0 : 1;
  conf->fsm_outs_en[1] = (tmp & 0x02) == 0 ? 0 : 1;
  conf->fsm_outs_en[2] = (tmp & 0x04) == 0 ? 0 : 1;
  conf->fsm_outs_en[3] = (tmp & 0x08) == 0 ? 0 : 1;

  /* check enabled dectrees */
  if (conf->mlc_en) {
    write_dil(0x04, 0x00);
    write_dil(0x05, 0x00);
    do
      read_dil(0x07, &tmp, 1);
    while (!(tmp & 0x01)); /* check stmc idle */
    write_dil(0x17, 0x20);
    write_dil(0x02, 0x11);
    write_dil(0x08, 0xEF);
    read_dil(0x09, &tmp, 1);
    write_dil(0x17, 0x00);
    write_dil(0x02, 0x01);
    write_dil(0x04, emb_func_en_a);
    write_dil(0x05, emb_func_en_b);
    conf->mlc_num = tmp;
    printf("%s: mlc_num = %u\n", __func__, conf->mlc_num);
  }

  read_dil(0x44, &emb_func_fifo_en_a, 1);
  conf->sflp_quat_en = (emb_func_fifo_en_a & 0x02) == 0 ? 0 : 1;
  conf->sflp_grav_en = (emb_func_fifo_en_a & 0x10) == 0 ? 0 : 1;
  conf->sflp_gbias_en = (emb_func_fifo_en_a & 0x20) == 0 ? 0 : 1;

  write_dil(0x01, 0x00);

  return 0;
}

static void suwon3_get_data(struct fifo_data *data)
{
  read_dil(0x28, (uint8_t *)data->accel, 6);
  read_dil(0x22, (uint8_t *)data->gyro, 6);
  read_dil(0x20, (uint8_t *)&data->temp, 2);
}

static void suwon3_start_data(uint8_t val)
{
  switch(val) {
  case 0:
    write_dil(0x0E, 0x00);
    write_dil(0x13, 0x00);
    break;
  case 1:
  default:
    write_dil(0x13, 0x02); /* drdy pulsed */
    write_dil(0x0E, 0x03); /* DRDY_XL and DRDY_G */
    break;
  }
}

static void suwon3b_reset(void)
{
  write_dil(0x01, 0x04); // SW_POR
  tx_thread_sleep(30);
}

static uint8_t suwon3b_get_motion_events(motion_t *motion)
{
  uint8_t tap_src, fifo_status;
  uint16_t diff;

  read_dil(0x46, &tap_src, 1);
  read_dil(0x1D, &motion->all_int, 1);
  motion->hw_free_fall = motion->all_int & 0x01 ? 1 : 0;
  motion->hw_wake_up = motion->all_int & 0x02 ? 1 : 0;
  motion->hw_tap_single = tap_src & 0x40 ? 1 : 0;
  motion->hw_tap_double = tap_src & 0x20 ? 1 : 0;
  read_dil(0x49, &motion->emb_func_status, 1);
  read_dil(0x4A, &motion->fsm, 1);
  read_dil(0x4B, &motion->mlc, 1);
  write_dil(0x01, 0x80);
  read_dil(0x48, &motion->lc, 2);
  read_dil(0x4C, motion->fsm_outs, 4);
  read_dil(0x70, motion->mlc_src, 4);
  read_dil(0x62, &motion->steps, 2);
  write_dil(0x01, 0x00);

  read_dil(0x1B, &fifo_status, 2);
  diff = fifo_status &= 0x1FF;

  for (uint16_t i = 0; i < diff; i++) {
    uint8_t tag, fifo[7];
    read_dil(0x78, fifo, 7);
    tag = fifo[0] >> 3;

    switch (tag) {
    case 0x13:
      sflp2q(motion->quat, (__fp16 *)&fifo[1]);
#if SFLP_DEBUG
      printf("%f\t%f\t%f\t%f\t", motion->quat[0], motion->quat[1], motion->quat[2], motion->quat[3]);
#endif
      break;
    case 0x16:
      memcpy(motion->gbias, &fifo[1], 6);
#if SFLP_DEBUG
      printf("%d\t%d\t%d\t", motion->gbias[0], motion->gbias[1], motion->gbias[2]);
#endif
      break;
    case 0x17:
      memcpy(motion->gravity, &fifo[1], 6);
#if SFLP_DEBUG
      printf("%d\t%d\t%d\n", motion->gravity[0], motion->gravity[1], motion->gravity[2]);
#endif
      break;
    }
  }

  if (motion->fsm != 0 || motion->mlc != 0 || motion->emb_func_status != 0
      || motion->all_int != 0 || diff != 0) {
    /* motion event has occoured */
    return 1;
  }

  return 0;
}

static void suwon3b_ram_write(uint16_t addr, uint8_t val)
{
  uint8_t tmp;

  uint8_t page = ((addr >> 8) << 4) | 0x01;
  uint8_t reg = addr & 0x00FF;

  write_dil(0x01, 0x80);

  do
    read_dil(0x07, &tmp, 1);
  while (!(tmp & 0x01)); /* check stmc idle */

  write_dil(0x17, 0x40);
  write_dil(0x02, page);
  write_dil(0x08, reg);
  write_dil(0x09, val);
  write_dil(0x02, 0x01);
  write_dil(0x17, 0x00);

  write_dil(0x01, 0x00);
}

static void suwon3b_ram_read(uint16_t addr, uint8_t *val)
{
  uint8_t tmp;

  uint8_t page = ((addr >> 8) << 4) | 0x01;
  uint8_t reg = addr & 0x00FF;

  write_dil(0x01, 0x80);

  do
    read_dil(0x07, &tmp, 1);
  while (!(tmp & 0x01)); /* check stmc idle */

  write_dil(0x17, 0x20);
  write_dil(0x02, page);
  write_dil(0x08, reg);
  read_dil(0x09, val, 1);
  write_dil(0x02, 0x01);
  write_dil(0x17, 0x00);

  write_dil(0x01, 0x00);
}

static int32_t suwon3b_get_op_state(struct log_conf *conf)
{
  uint8_t ctrl1, ctrl2, ctrl7, ctrl8, ctrl6;
  uint8_t emb_func_en_a, emb_func_en_b, emb_func_fifo_en_a;
  uint8_t tmp;

  read_dil(0x10, &ctrl1, 1);
  conf->accel_en = (ctrl1 & 0x0F) == 0 ? 0 : 1;

  read_dil(0x17, &ctrl8, 1);
  switch (ctrl8 & 0x03) {
  case 0x00:
    conf->acc_sens = 0.061f;
    break;
  case 0x01:
    conf->acc_sens = 0.122f;
    break;
  case 0x02:
    conf->acc_sens = 0.244f;
    break;
  case 0x03:
    conf->acc_sens = 0.488f;
    break;
  default:
    conf->acc_sens = 0.0f;
    break;
  }

  conf->grav_sens = 0.000061f;

  read_dil(0x11, &ctrl2, 1);
  conf->gyro_en = (ctrl2 & 0x0F) == 0 ? 0 : 1;

  read_dil(0x15, &ctrl6, 1);
  switch (ctrl6 & 0x0F) {
  case 0x00:
    conf->gyr_sens = 0.004375f;
    break;
  case 0x01:
    conf->gyr_sens = 0.00875f;
    break;
  case 0x02:
    conf->gyr_sens = 0.0175f;
    break;
  case 0x03:
    conf->gyr_sens = 0.035f;
    break;
  case 0x04:
    conf->gyr_sens = 0.070f;
    break;
  case 0x0c:
    conf->gyr_sens = 0.140f;
    break;
  default:
    conf->gyr_sens = 0.0f;
    break;
  }

  conf->gbias_sens = 0.004375f;

  if (conf->accel_en || conf->gyro_en)
    conf->temp_en = 1;
  else
    conf->temp_en = 0;

  read_dil(0x16, &ctrl7, 1);
  conf->ah_qvar_en = (ctrl7 & 0x80) == 0 ? 0 : 1;

  read_dil(0x50, &tmp, 1);
  conf->int_en = (tmp & 0x80) == 0 ? 0 : 1;

  write_dil(0x01, 0x80);
  read_dil(0x04, &emb_func_en_a, 1);
  conf->pedo_en = (emb_func_en_a & 0x08) == 0 ? 0 : 1;
  read_dil(0x05, &emb_func_en_b, 1);
  conf->mlc_en = ((emb_func_en_a & 0x80) || (emb_func_en_b & 0x10)) ? 1 : 0;
  conf->fsm_en = (emb_func_en_b & 0x01) == 0 ? 0 : 1;
  read_dil(0x46, &tmp, 1);
  conf->fsm_outs_en[0] = (tmp & 0x01) == 0 ? 0 : 1;
  conf->fsm_outs_en[1] = (tmp & 0x02) == 0 ? 0 : 1;
  conf->fsm_outs_en[2] = (tmp & 0x04) == 0 ? 0 : 1;
  conf->fsm_outs_en[3] = (tmp & 0x08) == 0 ? 0 : 1;

  /* check enabled dectrees */
  if (conf->mlc_en) {
    write_dil(0x04, 0x00);
    write_dil(0x05, 0x00);
    do
      read_dil(0x07, &tmp, 1);
    while (!(tmp & 0x01)); /* check stmc idle */
    write_dil(0x17, 0x20);
    write_dil(0x02, 0x11);
    write_dil(0x08, 0xEF);
    read_dil(0x09, &tmp, 1);
    write_dil(0x17, 0x00);
    write_dil(0x02, 0x01);
    write_dil(0x04, emb_func_en_a);
    write_dil(0x05, emb_func_en_b);
    conf->mlc_num = tmp;
    printf("%s: mlc_num = %u\n", __func__, conf->mlc_num);
  }

  read_dil(0x44, &emb_func_fifo_en_a, 1);
  conf->sflp_quat_en = (emb_func_fifo_en_a & 0x02) == 0 ? 0 : 1;
  conf->sflp_grav_en = (emb_func_fifo_en_a & 0x10) == 0 ? 0 : 1;
  conf->sflp_gbias_en = (emb_func_fifo_en_a & 0x20) == 0 ? 0 : 1;

  write_dil(0x01, 0x00);

  return 0;
}

static void suwon3b_get_data(struct fifo_data *data)
{
  read_dil(0x28, (uint8_t *)data->accel, 6);
  read_dil(0x22, (uint8_t *)data->gyro, 6);
  read_dil(0x20, (uint8_t *)&data->temp, 2);
  read_dil(0x3A, (uint8_t *)&data->ah_qvar, 2);
}

static void suwon3b_start_data(uint8_t val)
{
  switch(val) {
  case 0:
    write_dil(0x0E, 0x00);
    write_dil(0x13, 0x00);
    break;
  case 1:
  default:
    write_dil(0x13, 0x02); /* drdy pulsed */
    write_dil(0x0E, 0x03); /* DRDY_XL and DRDY_G */
    break;
  }
}

static void sunchon_reset(void)
{
  /* set device in power-down */
  write_dil(0x10, 0x00);
  write_dil(0x11, 0x00);

  /* sw reset */
  write_dil(0x12, 0x01);
  tx_thread_sleep(1);
}

static uint8_t sunchon_get_motion_events(motion_t *motion)
{
  write_dil(0x01, 0x80);
  read_dil(0x10, motion->byte, 64);
  write_dil(0x01, 0x00);

  if (motion->fsm != 0 || motion->mlc != 0 || motion->emb_func_status != 0) {
    /* motion event has occoured */
    return 1;
  }

  return 0;
}

static void sunchon_ram_write(uint16_t addr, uint8_t val)
{
  printf("%s: not supported\n", __func__);
}

static void sunchon_ram_read(uint16_t addr, uint8_t *val)
{
  printf("%s: not supported\n", __func__);
}

static int32_t sunchon_get_op_state(struct log_conf *conf)
{
  uint8_t ctrl1_xl;
  uint8_t ctrl2_g;

  read_dil(0x10, &ctrl1_xl, 1);
  conf->accel_en = (ctrl1_xl & 0xF0) == 0 ? 0 : 1;

  switch (ctrl1_xl & 0x0C) {
  case 0x00:
    conf->acc_sens = 0.061f;
    break;
  case 0x04:
    conf->acc_sens = 0.488f;
    break;
  case 0x08:
    conf->acc_sens = 0.122f;
    break;
  case 0x0C:
    conf->acc_sens = 0.244f;
    break;
  default:
    conf->acc_sens = 0.0f;
    break;
  }

  read_dil(0x11, &ctrl2_g, 1);
  conf->gyro_en = (ctrl2_g & 0xF0) == 0 ? 0 : 1;

  switch (ctrl2_g & 0x0C) {
  case 0x00:
    conf->gyr_sens = 0.00875f;
    break;
  case 0x04:
    conf->gyr_sens = 0.0175f;
    break;
  case 0x08:
    conf->gyr_sens = 0.035f;
    break;
  case 0x0C:
    conf->gyr_sens = 0.070f;
    break;
  default:
    conf->gyr_sens = 0.0f;
    break;
  }

  if (ctrl2_g & 0x02)
    conf->gyr_sens = 0.004375f;

  if (conf->accel_en || conf->gyro_en)
    conf->temp_en = 1;
  else
    conf->temp_en = 0;

  return 0;
}

static void sunchon_get_data(struct fifo_data *data)
{
  read_dil(0x28, (uint8_t *)data->accel, 6);
  read_dil(0x22, (uint8_t *)data->gyro, 6);
  read_dil(0x20, (uint8_t *)&data->temp, 2);
}

static void sunchon_start_data(uint8_t val)
{
  switch(val) {
  case 0:
    write_dil(0x0E, 0x00);
    write_dil(0x0B, 0x00);
    break;
  case 1:
  default:
    write_dil(0x0B, 0x80); /* drdy pulsed */
    write_dil(0x0E, 0x03); /* DRDY_XL and DRDY_G */
    break;
  }
}

static struct sensor lis2duxs12_sensor;

static void lis2duxs12_reset(void)
{
  write_dil(0x3D, 0x01);
  tx_thread_sleep(2);
  write_dil(0x3E, 0x01);
  tx_thread_sleep(25);
  write_dil(0x13, 0x10);
  tx_thread_sleep(10);
}

static uint8_t lis2duxs12_get_motion_events(motion_t *motion)
{
  read_dil(0x24, &motion->all_int, 1);
  motion->hw_free_fall = motion->all_int & 0x01 ? 1 : 0;
  motion->hw_wake_up = motion->all_int & 0x02 ? 1 : 0;
  motion->hw_tap_single = motion->all_int & 0x04 ? 1 : 0;
  motion->hw_tap_double = motion->all_int & 0x08 ? 1 : 0;
  motion->hw_tap_triple = motion->all_int & 0x10 ? 1 : 0;
  read_dil(0x34, &motion->emb_func_status, 1);
  read_dil(0x35, &motion->fsm, 1);
  read_dil(0x36, &motion->mlc, 1);
  write_dil(0x3F, 0x80);
  read_dil(0x1C, &motion->lc, 2);
  read_dil(0x20, motion->fsm_outs, 4);
  read_dil(0x34, motion->mlc_src, 4);
  read_dil(0x28, &motion->steps, 2);
  write_dil(0x3F, 0x00);

  if (motion->fsm != 0 || motion->mlc != 0 || motion->emb_func_status != 0 || motion->all_int != 0) {
    /* motion event has occoured */
    return 1;
  }

  return 0;
}

static void lis2duxs12_ram_write(uint16_t addr, uint8_t val)
{
  uint8_t tmp;

  uint8_t page = ((addr >> 8) << 4) | 0x01;
  uint8_t reg = addr & 0x00FF;

  write_dil(0x3F, 0x80);

  do
    read_dil(0x07, &tmp, 1);
  while (!(tmp & 0x01)); /* check stmc idle */

  write_dil(0x17, 0x40);
  write_dil(0x02, page);
  write_dil(0x08, reg);
  write_dil(0x09, val);
  write_dil(0x02, 0x01);
  write_dil(0x17, 0x00);

  write_dil(0x3F, 0x00);
}

static void lis2duxs12_ram_read(uint16_t addr, uint8_t *val)
{
  uint8_t tmp;

  uint8_t page = ((addr >> 8) << 4) | 0x01;
  uint8_t reg = addr & 0x00FF;

  write_dil(0x3F, 0x80);

  do
    read_dil(0x07, &tmp, 1);
  while (!(tmp & 0x01)); /* check stmc idle */

  write_dil(0x17, 0x20);
  write_dil(0x02, page);
  write_dil(0x08, reg);
  read_dil(0x09, val, 1);
  write_dil(0x02, 0x01);
  write_dil(0x17, 0x00);

  write_dil(0x3F, 0x00);
}

static int32_t lis2duxs12_get_op_state(struct log_conf *conf)
{
  uint8_t ctrl5;
  uint8_t ah_qvar_cfg;
  uint8_t emb_func_en_a = 0;
  uint8_t emb_func_en_b = 0;
  uint8_t tmp;

  read_dil(0x14, &ctrl5, 1);
  conf->accel_en = (ctrl5 & 0xF0) == 0 ? 0 : 1;

  switch (ctrl5 & 0x03) {
  case 0x0:
    conf->acc_sens = 0.061f;
    break;
  case 0x1:
    conf->acc_sens = 0.122f;
    break;
  case 0x2:
    conf->acc_sens = 0.244f;
    break;
  case 0x3:
    conf->acc_sens = 0.488f;
    break;
  default:
    conf->acc_sens = 0.0f;
    break;
  }

  read_dil(0x17, &tmp, 1);
  conf->int_en = (tmp & 0x01) == 0 ? 0 : 1;

  write_dil(0x3F, 0x80);
  read_dil(0x04, &emb_func_en_a, 1);
  conf->pedo_en = (emb_func_en_a & 0x08) == 0 ? 0 : 1;
  read_dil(0x05, &emb_func_en_b, 1);
  conf->mlc_en = ((emb_func_en_a & 0x80) || (emb_func_en_b & 0x10)) ? 1 : 0;
  conf->fsm_en = (emb_func_en_b & 0x01) == 0 ? 0 : 1;
  read_dil(0x1A, &tmp, 1);
  conf->fsm_outs_en[0] = (tmp & 0x01) == 0 ? 0 : 1;
  conf->fsm_outs_en[1] = (tmp & 0x02) == 0 ? 0 : 1;
  conf->fsm_outs_en[2] = (tmp & 0x04) == 0 ? 0 : 1;
  conf->fsm_outs_en[3] = (tmp & 0x08) == 0 ? 0 : 1;

  /* check enabled dectrees */
  if (conf->mlc_en) {
    write_dil(0x04, 0x00);
    write_dil(0x05, 0x00);
    do
      read_dil(0x07, &tmp, 1);
    while (!(tmp & 0x01)); /* check stmc idle */
    write_dil(0x17, 0x20);
    write_dil(0x02, 0x01);
    write_dil(0x08, 0xBD);
    read_dil(0x09, &tmp, 1);
    write_dil(0x17, 0x00);
    write_dil(0x02, 0x01);
    write_dil(0x04, emb_func_en_a);
    write_dil(0x05, emb_func_en_b);
    conf->mlc_num = tmp;
    printf("%s: mlc_num = %u\n", __func__, conf->mlc_num);
  }

  write_dil(0x3F, 0x00);

  read_dil(0x31, &ah_qvar_cfg, 1);
  conf->ah_qvar_en = (ah_qvar_cfg & 0x80) == 0 ? 0 : 1;

  return 0;
}

static void lis2duxs12_get_data(struct fifo_data *data)
{
  read_dil(0x28, (uint8_t *)data->accel, 6);
  read_dil(0x2E, (uint8_t *)&data->ah_qvar, 2);
}

static void lis2duxs12_start_data(uint8_t val)
{
  uint8_t ctrl1;

  read_dil(0x10, &ctrl1, 1);

  switch(val) {
  case 0:
    write_dil(0x11, 0x0); /* clear INT1_DRDY */
    ctrl1 &= ~0x08; /* clear PULSED bit */
    write_dil(0x10, ctrl1);
    write_dil(0x1F, lis2duxs12_sensor.store[0]);
    break;
  case 1:
  default:
    read_dil(0x1F, &lis2duxs12_sensor.store[0], 1);
    write_dil(0x1F, 0x00);
    ctrl1 |= 0x08; /* set PULSED bit */
    write_dil(0x10, ctrl1);
    write_dil(0x11, 0x8); /* set INT1_DRDY */
    break;
  }
}

static void lis2duxs12_dump_reg(void)
{
  uint8_t i, j;
  uint8_t addr;
  uint8_t val[8];

  for (i = 0; i < 32; i++) {
    addr = i*8;
    read_dil(addr, val, 8);
    printf("[%02x]:", addr);

    for (j = 0; j < 8; j++) {
      printf(" [%02x]", val[j]);
    }
    printf("\n");
  }
}

static void env_reset(void)
{
  lps22df_init_set(&lps22df, LPS22DF_RESET);
  tx_thread_sleep(1);
  lps22df_init_set(&lps22df, LPS22DF_DRV_RDY);

  uint8_t ctrl = 0x48;
  stts22h_write(&stts22h, STTS22H_CTRL, &ctrl, 1);
}

static int32_t env_get_op_state(struct log_conf *conf)
{
  lps22df_md_t lps22df_mode;
  stts22h_odr_temp_t stts22h_odr;

  lps22df_mode_get(&lps22df, &lps22df_mode);
  conf->press_en = (lps22df_mode.odr == LPS22DF_ONE_SHOT) ? 0 : 1;
  env_sensor.store[0] = conf->press_en;

  stts22h_temp_data_rate_get(&stts22h, &stts22h_odr);
  conf->temperature_en = (stts22h_odr == STTS22H_POWER_DOWN || stts22h_odr == STTS22H_ONE_SHOT) ? 0 : 1;;
  env_sensor.store[1] = conf->temperature_en;

  return 0;
}

static void env_get_data(struct fifo_data *data)
{
  if (env_sensor.store[0] == 1) {
    data->press = 0;
    lps22df_read(&lps22df, LPS22DF_PRESS_OUT_XL, (uint8_t *)&data->press, 3);
  }

  if (env_sensor.store[1] == 1)
    stts22h_temperature_raw_get(&stts22h, &data->temperature);
}

static void mag_reset(void)
{
  lis2mdl_reset_set(&lis2mdl, PROPERTY_ENABLE);
  lis2mdl_offset_temp_comp_set(&lis2mdl, PROPERTY_ENABLE);
  lis2mdl_block_data_update_set(&lis2mdl, PROPERTY_ENABLE);
}

static int32_t mag_get_op_state(struct log_conf *conf)
{
  lis2mdl_md_t mode;
  lis2mdl_operating_mode_get(&lis2mdl, &mode);

  conf->mag_en = (mode != LIS2MDL_CONTINUOUS_MODE) ? 0 : 1;
  mag_sensor.store[0] = conf->mag_en;

  return 0;
}

static void mag_get_data(struct fifo_data *data)
{
  if (mag_sensor.store[0] == 1)
    lis2mdl_magnetic_raw_get(&lis2mdl, data->mag);
}

static void reset_not_supported(void)
{
  printf("Error: device not mounted on DIL24 connector\n");
}

static void ram_write_not_supported(uint16_t addr, uint8_t val)
{
  printf("Error: device not mounted on DIL24 connector\n");
}

static void ram_read_not_supported(uint16_t addr, uint8_t *val)
{
  printf("Error: device not mounted on DIL24 connector\n");
}

static int32_t write_not_supported(uint8_t addr, uint8_t val)
{
  printf("Error: device not mounted on DIL24 connector\n");

  return -1;
}

static int32_t read_not_supported(uint8_t addr, void *val, uint16_t len)
{
  printf("Error: device not mounted on DIL24 connector\n");

  return -1;
}

static uint8_t get_motion_events_not_supported(motion_t *motion)
{
  printf("Error: device not mounted on DIL24 connector\n");
  return 0;
}

static int32_t get_op_state_not_supported(struct log_conf *conf)
{
  printf("Error: device not mounted on DIL24 connector\n");
  return -1;
}

static void get_data_not_supported(struct fifo_data *data)
{
  printf("Error: device not mounted on DIL24 connector\n");
}

static void start_data_not_supported(uint8_t val)
{
  printf("Error: device not mounted on DIL24 connector\n");
}

static void dump_reg_not_supported(void)
{
  printf("Error: device not mounted on DIL24 connector\n");
}

static struct sensor lsm6dsox_sensor = {
    lsm6dsox_reset,
    write_dil,
    read_dil,
    lsm6dsox_get_motion_events,
    lsm6dsox_ram_write,
    lsm6dsox_ram_read,
    lsm6dsox_get_op_state,
    lsm6dsox_get_data,
    lsm6dsox_start_data,
    dump_reg_not_supported,
};

static struct sensor suwon3_sensor = {
    suwon3_reset,
    write_dil,
    read_dil,
    suwon3_get_motion_events,
    suwon3_ram_write,
    suwon3_ram_read,
    suwon3_get_op_state,
    suwon3_get_data,
    suwon3_start_data,
    dump_reg_not_supported,
};

static struct sensor suwon3b_sensor = {
    suwon3b_reset,
    write_dil,
    read_dil,
    suwon3b_get_motion_events,
    suwon3b_ram_write,
    suwon3b_ram_read,
    suwon3b_get_op_state,
    suwon3b_get_data,
    suwon3b_start_data,
    dump_reg_not_supported,
};

static struct sensor sunchon_sensor = {
    sunchon_reset,
    write_dil,
    read_dil,
    sunchon_get_motion_events,
    sunchon_ram_write,
    sunchon_ram_read,
    sunchon_get_op_state,
    sunchon_get_data,
    sunchon_start_data,
    dump_reg_not_supported,
};

static struct sensor lis2duxs12_sensor = {
    lis2duxs12_reset,
    write_dil,
    read_dil,
    lis2duxs12_get_motion_events,
    lis2duxs12_ram_write,
    lis2duxs12_ram_read,
    lis2duxs12_get_op_state,
    lis2duxs12_get_data,
    lis2duxs12_start_data,
    lis2duxs12_dump_reg,
};

struct sensor env_sensor = {
    env_reset,
    write_not_supported,
    read_not_supported,
    get_motion_events_not_supported,
    ram_write_not_supported,
    ram_read_not_supported,
    env_get_op_state,
    env_get_data,
    start_data_not_supported,
    dump_reg_not_supported,
};

struct sensor mag_sensor = {
    mag_reset,
    write_not_supported,
    read_not_supported,
    get_motion_events_not_supported,
    ram_write_not_supported,
    ram_read_not_supported,
    mag_get_op_state,
    mag_get_data,
    start_data_not_supported,
    dump_reg_not_supported,
};

static struct sensor unsupported_sensor = {
    reset_not_supported,
    write_not_supported,
    read_not_supported,
    get_motion_events_not_supported,
    ram_write_not_supported,
    ram_read_not_supported,
    get_op_state_not_supported,
    get_data_not_supported,
    start_data_not_supported,
    dump_reg_not_supported,
};

void sensor_init(struct sensor **sensor, uint8_t *whoami, uint8_t *rev)
{
  read_dil(0x0F, whoami, 1);
  read_dil(0x1F, rev, 1);

  if (*whoami == 0x00 || *whoami == 0xFF || *whoami == 0x47) {
    write_dil(0x3E, 0x01); // try waking-up lis2duxs12 from deep power-down
    tx_thread_sleep(25); // wait for sensor boot
    read_dil(0x0F, whoami, 1);
    dil_int1_disable();
    dil_int2_disable();
    dil_int3_enable();
  } else {
    dil_int3_disable();
  }

  switch (*whoami) {
  case LSM6DSOX_ID:
    *sensor = &lsm6dsox_sensor;
    break;
  case SUWON3_ID:
    *sensor = &suwon3_sensor;
    break;
  case SUWON3B_ID:
    *sensor = &suwon3b_sensor;
    break;
  case SUNCHON_ID:
    *sensor = &sunchon_sensor;
    break;
  case LIS2DUXS12_ID:
    *sensor = &lis2duxs12_sensor;
    break;
  default:
    *sensor = &unsupported_sensor;
    break;
  }
}

static void sflp2q(float quat[4], __fp16 sflp[3])
{
  float sumsq = 0;

  quat[0] = sflp[0];
  quat[1] = sflp[1];
  quat[2] = sflp[2];

  for (uint8_t i = 0; i < 3; i++)
    sumsq += quat[i] * quat[i];

  if (sumsq > 1.0f) {
    float n = sqrtf(sumsq);
    quat[0] /= n;
    quat[1] /= n;
    quat[2] /= n;
    sumsq = 1.0f;
  }

  quat[3] = sqrtf(1.0f - sumsq);
}

/**
  ******************************************************************************
  * @file    BLE_Comm.h
  * @author  System Research & Applications Team - Agrate/Catania Lab.
  * @version 1.6.0
  * @date    15-September-2022
  * @brief   Comm info services APIs.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/  
#ifndef _BLE_COMM_H_
#define _BLE_COMM_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Exported typedef --------------------------------------------------------- */
typedef void (*CustomNotifyEventComm_t)(BLE_NotifyEvent_t Comm);
   
/* Exported Variables ------------------------------------------------------- */
extern CustomNotifyEventComm_t CustomNotifyEventComm;

/* Exported functions ------------------------------------------------------- */

/**
 * @brief  Init comm info service
 * @param  None
 * @retval BleCharTypeDef* BleCharPointer: Data structure pointer for comm info service
 */
extern BleCharTypeDef* BLE_InitCommService(void);

#ifndef BLE_MANAGER_SDKV2
/**
 * @brief  Setting Comm Advertise Data
 * @param  uint8_t *manuf_data: Advertise Data
 * @retval None
 */
extern void BLE_SetCommAdvertiseData(uint8_t *manuf_data);
#endif /* BLE_MANAGER_SDKV2 */

/**
 * @brief  Update Comm characteristic
 * @param  int32_t CommLevel %Charge level
 * @param  uint32_t Voltage Comm Voltage
 * @param  uint32_t Current Comm Current (0x8000 if not available)
 * @param  uint32_t Status Charging/Discharging
 * @retval tBleStatus   Status
 */
tBleStatus BLE_CommUpdate(uint32_t CommLevel, uint32_t Voltage, uint32_t Current, uint32_t Status);

#ifdef __cplusplus
}
#endif

#endif /* _BLE_COMM_H_ */


/**
  ******************************************************************************
  * @file    BLE_Motion.h
  * @author  System Research & Applications Team - Agrate/Catania Lab.
  * @version 1.6.0
  * @date    15-September-2022
  * @brief   Motion info services APIs.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _BLE_MOTION_H_
#define _BLE_MOTION_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Exported typedef --------------------------------------------------------- */
typedef void (*CustomNotifyEventMotion_t)(BLE_NotifyEvent_t Motion);
typedef union {
  struct {
    uint8_t fsm;
    uint8_t fsm_outs[4];
    uint8_t mlc;
    uint8_t mlc_src[4];
    uint16_t steps;
    union {
      uint8_t hw_int;
      struct {
        uint8_t hw_free_fall : 1;
        uint8_t hw_wake_up : 1;
        uint8_t hw_tap_single : 1;
        uint8_t hw_tap_double : 1;
        uint8_t hw_tap_triple : 1;
        uint8_t hw_reserved : 3;
      };
    };
    uint8_t emb_func_status;
    uint16_t algo;
    uint16_t lc;
    uint8_t all_int;
    uint8_t res; // reserved
    float quat[4];
    int16_t gravity[3];
    int16_t gbias[3];
    uint8_t reserved[16]; // reserved
  };
  uint8_t byte[64];
} motion_t;

/* Exported Variables ------------------------------------------------------- */
extern CustomNotifyEventMotion_t CustomNotifyEventMotion;

/* Exported functions ------------------------------------------------------- */

/**
 * @brief  Init motion info service
 * @param  None
 * @retval BleCharTypeDef* BleCharPointer: Data structure pointer for motion info service
 */
extern BleCharTypeDef* BLE_InitMotionService(void);

#ifndef BLE_MANAGER_SDKV2
/**
 * @brief  Setting Motion Advertise Data
 * @param  uint8_t *manuf_data: Advertise Data
 * @retval None
 */
extern void BLE_SetMotionAdvertiseData(uint8_t *manuf_data);
#endif /* BLE_MANAGER_SDKV2 */

/**
 * @brief  Update Motion characteristic
 * @param  int32_t MotionLevel %Charge level
 * @param  uint32_t Voltage Motion Voltage
 * @param  uint32_t Current Motion Current (0x8000 if not available)
 * @param  uint32_t Status Charging/Discharging
 * @retval tBleStatus   Status
 */
tBleStatus BLE_MotionUpdate(void *packet);

#ifdef __cplusplus
}
#endif

#endif /* _BLE_MOTION_H_ */


/**
  ******************************************************************************
  * @file    BLE_MotionStream.h
  * @author  System Research & Applications Team - Agrate/Catania Lab.
  * @version 1.6.0
  * @date    15-September-2022
  * @brief   MotionStream info services APIs.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _BLE_MOTION_STREAM_H_
#define _BLE_MOTION_STREAM_H_

#ifdef __cplusplus
 extern "C" {
#endif

/* Exported typedef --------------------------------------------------------- */
typedef void (*CustomNotifyEventMotionStream_t)(BLE_NotifyEvent_t MotionStream);

/* Exported Variables ------------------------------------------------------- */
extern CustomNotifyEventMotionStream_t CustomNotifyEventMotionStream;

/* Exported functions ------------------------------------------------------- */

/**
 * @brief  Init motion stream info service
 * @param  None
 * @retval BleCharTypeDef* BleCharPointer: Data structure pointer for motion stream info service
 */
extern BleCharTypeDef* BLE_InitMotionStreamService(void);

#ifndef BLE_MANAGER_SDKV2
/**
 * @brief  Setting MotionStream Advertise Data
 * @param  uint8_t *manuf_data: Advertise Data
 * @retval None
 */
extern void BLE_SetMotionStreamAdvertiseData(uint8_t *manuf_data);
#endif /* BLE_MANAGER_SDKV2 */

/**
 * @brief  Update MotionStream characteristic
 * @param  int32_t MotionStreamLevel %Charge level
 * @param  uint32_t Voltage MotionStream Voltage
 * @param  uint32_t Current MotionStream Current (0x8000 if not available)
 * @param  uint32_t Status Charging/Discharging
 * @retval tBleStatus   Status
 */
tBleStatus BLE_MotionStreamUpdate(void *packet);

#ifdef __cplusplus
}
#endif

#endif /* _BLE_MOTION_STREAM_H_ */


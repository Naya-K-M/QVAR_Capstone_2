/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    app_filex.h
  * @author  MCD Application Team
  * @brief   FileX applicative header file
  ******************************************************************************
    * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __APP_FILEX_H__
#define __APP_FILEX_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "fx_api.h"
#include "fx_stm32_sd_driver.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
extern TX_QUEUE queue_sd;
extern TX_BYTE_POOL sdlog_cmd_byte_short_pool;
extern TX_BYTE_POOL sdlog_cmd_byte_long_pool;
/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */
#define SD_QUEUE_SIZE 1000
#define SD_QUEUE_MSG_SIZE (TX_2_ULONG * sizeof(ULONG))
#define SDLOG_CMD_SHORT_SIZE 32
#define SDLOG_CMD_SHORT_POOL_SIZE (SDLOG_CMD_SHORT_SIZE * 32)
#define SDLOG_CMD_LONG_SIZE 256
#define SDLOG_CMD_LONG_POOL_SIZE (SDLOG_CMD_LONG_SIZE * SD_QUEUE_SIZE)

#define SD_LOG_RESET      0
#define SD_LOG_START      1
#define SD_LOG_STOP       2
#define SD_LOG_RUN        3
#define SD_LOG_SET_USER   4
#define SD_LOG_SET_DEMO   5
#define SD_LOG_SET_CLASS  6
#define SD_LOG_CLR_USER   7
#define SD_LOG_CLR_DEMO   8
#define SD_LOG_CLR_CLASS  9
#define SD_LOG_FSYNC      10
#define SD_LOG_FILEX_DATE 11

struct sd_queue_msg {
  ULONG cmd;
  void *datap;
};

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
UINT MX_FileX_Init(VOID *memory_ptr);

/* USER CODE BEGIN EFP */
uint8_t SD_is_started(void);

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
#ifdef __cplusplus
}
#endif
#endif /* __APP_FILEX_H__ */

#ifndef _SENSORS_H_
#define _SENSORS_H_

#ifdef __cplusplus
 extern "C" {
#endif

#include <stdint.h>
#include "app_threadx.h"

#include "lis2du12_reg.h"
#include "lis2mdl_reg.h"
#include "lps22df_reg.h"
#include "lsm6dsv16x_reg.h"
#include "stts22h_reg.h"
#include "BLE_Manager.h"

#define LSM6DSOX_ID 0x6C
#define SUWON3_ID 0x70
#define SUWON3B_ID 0x71
#define SUNCHON_ID 0x22
#define LIS2DUXS12_ID 0x47

extern stmdev_ctx_t lis2du12;
extern stmdev_ctx_t lis2mdl;
extern stmdev_ctx_t lps22df;
extern stmdev_ctx_t lsm6dsv16x;
extern stmdev_ctx_t stts22h;

struct sensor {
  void (*reset)(void);
  int32_t (*write)(uint8_t addr, uint8_t val);
  int32_t (*read)(uint8_t addr, void *val, uint16_t len);
  uint8_t (*get_motion_events)(motion_t *motion);
  void (*ram_write)(uint16_t addr, uint8_t val);
  void (*ram_read)(uint16_t addr, uint8_t *val);
  int32_t (*get_op_state)(struct log_conf *conf);
  void (*get_data)(struct fifo_data *data);
  void (*start_data)(uint8_t val);
  void (*dump_reg)(void);
  uint8_t store[4]; // reserved to store parameters
};

extern struct sensor env_sensor;
extern struct sensor mag_sensor;

void sensor_init(struct sensor **sensor, uint8_t *whoami, uint8_t *rev);

#ifdef __cplusplus
}
#endif

#endif /* _SENSORS_H_ */

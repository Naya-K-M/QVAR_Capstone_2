#!/bin/bash

for file in $(find -type f -iname "*.[ch]")
do
	echo changing permission for $file...
	chmod 644 $file
done

for file in $(find -type f -iname "*.ew*" -or -iname "*.s" -or -iname "*.icf" -or -iname "*.txt" -or -iname "*.txt" -or -iname "*.dep" -or -iname "*.ioc")
do
	echo changing permission for $file...
	chmod 644 $file
done

for file in $(find -type d | grep -v "^.$\|.git\|EWARM/sensortile-box-pro\|EWARM/settings")
do
	echo changing permission for $file...
	chmod 755 $file
done



rm -rf BlueNRG_2/
rm -rf Middlewares/ST/BlueNRG-2/
git checkout BLE\ Core/App/
git checkout Middlewares/ST/STM32_BLE_Manager/Inc/BLE_Manager.h
git checkout Middlewares/ST/STM32_BLE_Manager/Src/BLE_Manager.c
git checkout .mxproject
git checkout EWARM/sensortile-box-pro.ewp

#include "unzip.h"

#include <string.h>
#include <stdio.h>
#include "uzlib.h"
#include "board.h"
#include "sensors.h"

#include "tx_api.h"

#define UNZIP_DEBUG     0
#define BLE_MAX_CHAR_VALUE_LEN 114

static void unzip_load(void);

static uint8_t source[40960 * 2]; // compressed data
static uint8_t dest[40960 * 3]; // ucf in binary format
static uint32_t idx; // index for writing compressed data
static uint32_t len;
static uint32_t outlen;
static uint32_t dlen;

void unzip_init(uint32_t size)
{
  len = size;
  idx = 0;
}

void unzip_add(uint8_t data[BLE_MAX_CHAR_VALUE_LEN - 4])
{
  for (uint8_t i = 0; i < BLE_MAX_CHAR_VALUE_LEN - 4; i++) {
    if (idx < len)
      source[idx] = data[i];
    idx++;
#if UNZIP_DEBUG
    printf("%02X\t", data[i]);
#endif
  }

#if UNZIP_DEBUG
  printf("\n");
#endif
}

#define OUT_CHUNK_SIZE 1

void unzip_run(void)
{
  struct uzlib_uncomp d;
  int res;

  uzlib_init();

  dlen = source[len - 1];
  dlen = 256 * dlen + source[len - 2];
  dlen = 256 * dlen + source[len - 3];
  dlen = 256 * dlen + source[len - 4];
  outlen = dlen;
  dlen++;

  printf("%s: %u\n", __func__, outlen);

  uzlib_uncompress_init(&d, NULL, 0);
  d.source = source;
  d.source_limit = source + len - 4;
  d.source_read_cb = NULL;

  res = uzlib_gzip_parse_header(&d);
  if (res != TINF_OK) {
    printf("%s: error parsing the header: %d\n", __func__, res);
    return;
  }

  d.dest_start = d.dest = dest;

  while (dlen) {
    unsigned int chunk_len = dlen < OUT_CHUNK_SIZE ? dlen : OUT_CHUNK_SIZE;
    d.dest_limit = d.dest + chunk_len;
    res = uzlib_uncompress_chksum(&d);
    dlen -= chunk_len;
    if (res != TINF_OK) {
      break;
    }
  }

  if (res != TINF_DONE) {
    printf("%s: error during decompression: %d\n", __func__, res);
    return;
  }

  unzip_load();
}

#define WRITE 0
#define DELAY 1

static void unzip_load(void)
{
  for (uint32_t i = 0; i < outlen; i += 3) {
    if (dest[i] == WRITE) {
      uint8_t addr = dest[i + 1];
      uint8_t val = dest[i + 2];
      write_dil(addr, val);
#if UNZIP_DEBUG
      printf("Ac %02X %02X\n", addr, val);
#endif
    } else if (dest[i] == DELAY) {
      uint16_t time = dest[i + 1] + 256 * dest[i + 2];
      tx_thread_sleep(time);
#if UNZIP_DEBUG
      printf("Delay %u\n", time);
#endif
    }
  }
}

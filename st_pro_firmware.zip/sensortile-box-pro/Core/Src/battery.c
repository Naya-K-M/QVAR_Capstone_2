#include <stdio.h>

#include "battery.h"
#include "stm32u5xx_hal.h"
#include "main.h"
#include "i2c.h"
#include "app_threadx.h"

#define STC3315_I2C_ADDR 0xE0

#define STC3315_REG_MODE   0x00
#define STC3315_REG_CTRL   0x01
#define STC3315_REG_SOC    0x02
#define STC3315_REG_OCV    0x0D
#define STC3315_REG_CC_CNF 0x0F
#define STC3315_REG_VM_CNF 0x11
#define STC3315_REG_ID     0x18
#define STC3315_REG_OCVTAB 0x30

/* battery parameters */
#define RSENSE 50
#define CNOM   480
#define RI     160
static const int8_t ocv_offset_tab[16] = { 0, -40, -100, -58, -31, -30, -9, -19, -36, -40, -4, -36, -40, -23, -41, -20 };

static int32_t stc3115_read(uint8_t addr, void *val, uint16_t len)
{
  int32_t ret = -1;

  if (HAL_I2C_Mem_Read_DMA(&hi2c4, STC3315_I2C_ADDR, addr, I2C_MEMADD_SIZE_8BIT,
                           val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&i2c4_dma_rx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  return ret;
}

static int32_t stc3115_write(uint8_t addr, void *val, uint16_t len)
{
  int32_t ret = -1;

  if (HAL_I2C_Mem_Write_DMA(&hi2c4, STC3315_I2C_ADDR, addr, I2C_MEMADD_SIZE_8BIT,
                            val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&i2c4_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  return ret;
}

void battery_init(void)
{
  uint8_t reg_id, val;
  uint16_t ocv, cc_cnf, vm_cnf;

  stc3115_read(STC3315_REG_ID, &reg_id, 1);
  stc3115_read(STC3315_REG_OCV, &ocv, 2);
  val = 0x00;
  stc3115_write(STC3315_REG_MODE, &val, 1);

  cc_cnf = (uint16_t)(RSENSE * CNOM / 49.556f);
  vm_cnf = (uint16_t)(RI * CNOM / 977.78f);
  stc3115_write(STC3315_REG_CC_CNF, &cc_cnf, 2);
  stc3115_write(STC3315_REG_VM_CNF, &vm_cnf, 2);
  stc3115_write(STC3315_REG_OCV, &ocv, 2);
  stc3115_write(STC3315_REG_OCVTAB, (void *)ocv_offset_tab, 16);

  val = 0x10;
  stc3115_write(STC3315_REG_MODE, &val, 1);
}

void battery_get_info(struct battery *battery)
{
  uint8_t buff[9];

  stc3115_read(STC3315_REG_CTRL, buff, 9);

  battery->soc = (buff[2] * 256 + buff[1]) / 512.0f;
  battery->current = ((int16_t)((int16_t)buff[6] * 256 + (int16_t)buff[5])) * 5.88f;
  battery->voltage = ((int16_t)((int16_t)buff[8] * 256 + (int16_t)buff[7])) * 2.2f;
  battery->presence = buff[0] & 0x08 ? 0 : 1;
}

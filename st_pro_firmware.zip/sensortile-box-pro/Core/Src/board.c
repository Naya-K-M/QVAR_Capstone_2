#include <stdio.h>

#include "board.h"
#include "stm32u5xx_hal.h"
#include "main.h"
#include "app_threadx.h"
#include "spi.h"
#include "usart.h"
#include "tim.h"
#include "tx_api.h"

extern TX_BYTE_POOL tx_print_byte_pool;
extern TX_QUEUE queue_print;

#define TX_BUFF_SIZE 512

static struct {
  char buff[TX_BUFF_SIZE];
  uint16_t i;
} tx;

size_t __write(int file, char *data, int len)
{
  if (data == NULL || len == 0)
    return 0;

  for (int i = 0; i < len; i++) {
    tx.buff[tx.i] = data[i];
    tx.i = (tx.i + 1) % sizeof(tx.buff);

    if (data[i] == '\n') {
      CHAR *ptr;
      if (tx_byte_allocate(&tx_print_byte_pool, (void **)&ptr, tx.i + 1, TX_NO_WAIT) != TX_SUCCESS)
        return 0;
      strncpy(ptr, tx.buff, tx.i);
      ptr[tx.i] = '\0';
      tx.i = 0;
      tx_queue_send(&queue_print, &ptr, TX_NO_WAIT);
    }
  }

  return len;
}

int32_t read_dil(uint8_t addr, void *val, uint16_t len)
{
  int32_t ret = -1;

  tx_mutex_get(&spi3_mutex, TX_WAIT_FOREVER);

  addr = addr | 0x80;
  HAL_GPIO_WritePin(SPI3_DIL_CS_GPIO_Port, SPI3_DIL_CS_Pin, GPIO_PIN_RESET);
  HAL_SPI_Transmit(&hspi3, &addr, 1, 10);

  if (HAL_SPI_Receive_DMA(&hspi3, val, len) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&spi3_dma_rx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  HAL_GPIO_WritePin(SPI3_DIL_CS_GPIO_Port, SPI3_DIL_CS_Pin, GPIO_PIN_SET);
  tx_mutex_put(&spi3_mutex);

  return ret;
}

int32_t write_dil(uint8_t addr, uint8_t val)
{
  int32_t ret = -1;
  uint8_t tx[2] = { addr, val };

  tx_mutex_get(&spi3_mutex, TX_WAIT_FOREVER);

  HAL_GPIO_WritePin(SPI3_DIL_CS_GPIO_Port, SPI3_DIL_CS_Pin, GPIO_PIN_RESET);

  if (HAL_SPI_Transmit_DMA(&hspi3, tx, 2) == HAL_OK) {
    UINT status;
    ULONG actual_flags;

    ret = 0;
    status = tx_event_flags_get(&spi3_dma_tx_completed, 0x1, TX_OR_CLEAR,
                                &actual_flags, TX_WAIT_FOREVER);
    if (status != TX_SUCCESS)
      ret = -1;
  }

  HAL_GPIO_WritePin(SPI3_DIL_CS_GPIO_Port, SPI3_DIL_CS_Pin, GPIO_PIN_SET);
  tx_mutex_put(&spi3_mutex);

  return ret;
}

__weak void lsm6dsv16x_int1_cb(void)
{
  printf("%s\n", __func__);
}

__weak void lsm6dsv16x_int2_cb(void)
{
  printf("%s\n", __func__);
}

__weak void dil_int1_cb(void)
{
  printf("%s\n", __func__);
}

__weak void dil_int2_cb(void)
{
  printf("%s\n", __func__);
}

__weak void dil_int3_cb(void)
{
  printf("%s\n", __func__);
}

void HAL_GPIO_EXTI_Rising_Callback(uint16_t GPIO_Pin)
{
  switch (GPIO_Pin) {
  case DIL_INT1_Pin:
    dil_int1_cb();
    break;
  case DIL_INT2_Pin:
    dil_int2_cb();
    break;
  case DIL_INT3_Pin:
    dil_int3_cb();
    break;
  case IMU_INT1_Pin:
    lsm6dsv16x_int1_cb();
    break;
#if 0
  // Check the IMU_INT2 EXTI11 which is the same as BT_GPIO_1
  case IMU_INT2_Pin:
    lsm6dsv16x_int2_cb();
    break;
#endif
  }
}

static void set_tone(uint16_t freq)
{
  uint16_t period = freq == 0 ? 0 : (uint16_t)((1.0f / freq) * 1000000.0f);
  __HAL_TIM_SET_AUTORELOAD(&htim1, period);

  TIM_OC_InitTypeDef sConfigOC = {0};
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = period / 2;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3);
}

void tone(uint16_t note, uint16_t duration)
{
  set_tone(note);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
  tx_thread_sleep(duration);
  HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_3);
  set_tone(440);
}

void buz_play(const int *melody, const int *durations, int len)
{
  int size = len;

  for (int note = 0; note < size; note++) {
    int duration = 1000 / durations[note];
    tone(melody[note], duration);
    int pause = (int)(duration * 1.30f);
    tx_thread_sleep(pause);
  }

  set_tone(440);
}

#ifndef __UNZIP_H
#define __UNZIP_H

#include <stdint.h>

void unzip_init(uint32_t size);
void unzip_add(uint8_t data[16]);
void unzip_run(void);

#endif /* __UNZIP_H */

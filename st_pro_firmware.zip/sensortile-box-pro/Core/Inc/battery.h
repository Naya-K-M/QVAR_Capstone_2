#ifndef _BATTERY_H_
#define _BATTERY_H_

#include <stdint.h>

struct battery {
  float soc;
  float voltage;
  float current;
  uint8_t presence;
};

void battery_init(void);
void battery_get_info(struct battery *battery);

#endif /* _BATTERY_H_ */
